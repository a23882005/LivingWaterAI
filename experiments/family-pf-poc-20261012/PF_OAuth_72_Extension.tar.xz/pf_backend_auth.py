"""PF server-side client authorization prototype. Synthetic identities only.
Production OAuth access tokens MUST be checked by a real trusted issuer verifier;
this module receives only the verifier's trusted user_id. No project-name trust.
"""
from dataclasses import dataclass
from typing import Mapping, FrozenSet

@dataclass(frozen=True)
class Resource:
    resource_id: str
    client_id: str
    content: str

class AuthorizationDenied(Exception):
    pass

class ClientScope:
    def __init__(self, grants: Mapping[str, FrozenSet[str]], resources: Mapping[str, Resource]):
        self._grants = {user: frozenset(clients) for user, clients in grants.items()}
        self._resources = dict(resources)
        self.audit = []

    def read(self, *, verified_user_id: str | None, active_client_id: str | None,
             resource_id: str, project_hint: str | None = None):
        # No fallback to project_hint, Library name, Drive name, or prompt fields.
        r = self._resources.get(resource_id)
        authorized = bool(verified_user_id and active_client_id and r
                          and active_client_id in self._grants.get(verified_user_id, frozenset())
                          and r.client_id == active_client_id)
        self.audit.append({'action': 'resource_read',
                           'verified_user_id': verified_user_id or 'UNVERIFIED',
                           'active_client_id': active_client_id,
                           'resource_id': resource_id,
                           'decision': 'ALLOW' if authorized else 'DENY'})
        if not authorized:
            raise AuthorizationDenied('access_denied')
        return r.content
