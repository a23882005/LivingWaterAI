import json
import tempfile
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'/'src'/'main'/'python'))
from family_offline import api

class OfflineDatabaseTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.tmp.name)/'private.db')
    def tearDown(self): self.tmp.cleanup()
    def call(self,op,**kw):
        return json.loads(api(self.path,op,json.dumps(kw,ensure_ascii=False)))
    def boot(self):
        self.assertFalse(self.call('init')['pin_set'])
        self.assertTrue(self.call('pin_setup',pin='123456',owner='第五位家人')['ok'])
        self.assertTrue(self.call('pin_login',pin='123456')['ok'])

    def test_pin_login_change(self):
        self.boot()
        self.assertFalse(self.call('pin_login',pin='bad')['ok'])
        self.assertTrue(self.call('pin_change',old='123456',new='678901')['ok'])
        self.assertFalse(self.call('pin_login',pin='123456')['ok'])
        self.assertTrue(self.call('pin_login',pin='678901')['ok'])
        self.assertFalse(self.call('pin_setup',pin='9999')['ok'])
    def test_portfolio_buy_sell_and_audit(self):
        self.boot()
        self.assertTrue(self.call('first_allocation',symbol='VT',qty='10',price='100',currency='USD')['ok'])
        self.assertTrue(self.call('record_event',kind='buy',symbol='VT',qty='10',price='110',currency='USD')['ok'])
        p=self.call('read_portfolio')['text']
        self.assertIn('20 股',p)
        self.assertIn('2100 USD',p)
        self.assertFalse(self.call('record_event',kind='sell',symbol='VT',qty='21',price='120')['ok'])
        self.assertTrue(self.call('record_event',kind='sell',symbol='VT',qty='5',price='120')['ok'])
        p=self.call('read_portfolio')['text']
        self.assertIn('15 股',p)
        self.assertIn('1575 USD',p)
        self.assertEqual(self.call('events')['text'].count('sell'),1)
    def test_target_validation_and_drifts(self):
        self.boot()
        self.call('first_allocation',symbol='VT',qty='10',price='100')
        self.assertTrue(self.call('adjust_target',symbol='VT',pct='60')['ok'])
        self.assertFalse(self.call('adjust_target',symbol='VOO',pct='50')['ok'])
        self.assertTrue(self.call('adjust_target',symbol='VOO',pct='40')['ok'])
        self.assertIn('60%',self.call('deployment_pace')['text'])
        self.assertIn('100%',self.call('targets')['text'])
    def test_invalid_and_multicurrency(self):
        self.boot()
        self.assertFalse(self.call('first_allocation',symbol='VT;DROP TABLE',qty=1,price=12)['ok'])
        self.assertFalse(self.call('first_allocation',symbol='VT',qty=-1,price=12)['ok'])
        self.call('first_allocation',symbol='VT',qty='2',price='100')
        self.call('first_allocation',symbol='0050',qty='10',price='70',currency='TWD')
        self.assertIn('多種幣別',self.call('deployment_pace')['text'])
    def test_reports_keep_history_html_sanitized(self):
        self.boot()
        self.call('update_profile',note='<script>bad()</script>')
        result=self.call('generate_report')
        self.assertTrue(result['ok'])
        self.assertIn('&lt;script&gt;',result['html'])
        self.assertNotIn('<script>',result['html'])
        self.assertEqual(self.call('previous_report')['html'],result['html'])
        self.assertTrue(self.call('generate_report')['ok'])
    def test_local_funding_notes_and_unknown(self):
        self.boot()
        self.assertTrue(self.call('new_funding',amount='20000',currency='TWD')['ok'])
        self.assertTrue(self.call('research_candidates',symbol='SOXX',note='觀察價格')['ok'])
        self.assertIn('SOXX',self.call('candidates')['text'])
        self.assertFalse(self.call('random_unknown')['ok'])


    def test_fifth_family_identity_isolated(self):
        self.assertEqual(self.call('init')['owner'], '第五位家人')
        self.boot()
        self.assertEqual(self.call('init')['owner'], '第五位家人')
        import sqlite3
        from contextlib import closing
        with closing(sqlite3.connect(self.path)) as db:
            with db:
                self.assertEqual(db.execute("SELECT val FROM app_meta WHERE key='family_scope'").fetchone()[0], 'FAMILY5_STANDALONE')
                db.execute("UPDATE app_meta SET val='OTHER_FAMILY' WHERE key='family_scope'")
        out=self.call('init')
        self.assertFalse(out['ok'])
        self.assertEqual(out['error'],'PERSONAL_DATABASE_SCOPE_MISMATCH')

if __name__=='__main__': unittest.main()
