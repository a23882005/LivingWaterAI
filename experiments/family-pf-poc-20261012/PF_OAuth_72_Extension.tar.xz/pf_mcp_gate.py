"""PF-03/04/05 preflight security gate. Synthetic testing only.
A remote client cannot self-assert ChatGPT Project identity. Until a verified
platform attestation is provided via a trusted integration, deny all data tools.
No token issuer, identity bypass, real customer DB, or public deployment.
"""
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI(title='Family PF untrusted identity gate',docs_url=None,redoc_url=None,openapi_url=None)

def denied(reason='trusted_project_attestation_unavailable'):
    return JSONResponse(status_code=403, content={'error':reason,'gate':'HOLD'})

@app.get('/healthz')
async def healthz():
    return {'status':'up','gate':'HOLD','data_access':False}

@app.post('/mcp')
async def mcp(req:Request):
    try:
        body=await req.json()
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(400, 'invalid_json')
    if not isinstance(body,dict):
        raise HTTPException(400,'invalid_jsonrpc')
    method=body.get('method')
    # Public discovery provides no customer data and no write capability.
    if method=='initialize':
        return {'jsonrpc':'2.0','id':body.get('id'), 'result':{
            'protocolVersion':'2025-06-18',
            'capabilities':{'tools':{}},
            'serverInfo':{'name':'family-pf-attestation-gate','version':'0.1.0'}}}
    if method=='notifications/initialized':
        return JSONResponse(status_code=202,content={})
    if method=='tools/list':
        return {'jsonrpc':'2.0','id':body.get('id'),'result':{'tools':[]}}
    if method=='tools/call':
        return denied()
    return JSONResponse(status_code=400,content={'error':'unsupported_method'})
