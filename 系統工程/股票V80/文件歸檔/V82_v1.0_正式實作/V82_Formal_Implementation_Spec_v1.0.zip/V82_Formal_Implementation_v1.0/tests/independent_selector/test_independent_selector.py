"""Independent synthetic selector checks only, not formal integration tests."""
import unittest
from decimal import Decimal as D
from itertools import product
from selector_snapshot import evaluate, CUTS, AND

class IndependentSelectorChecks(unittest.TestCase):
    def call(self,c,p=100,v=0,d=1,entry=True,legal=True,pe=None,app="CLASS_DEFAULT"):
        if pe is None: pe=CUTS[c][0]-1 if CUTS[c] else 10
        if app == 'CLASS_DEFAULT': app=CUTS[c] is not None
        return evaluate(c,entry,legal,d,p,v,'FORWARD_PE',pe,app)
    def test_all_classes_all_stages_with_legal_forward_pe_fixture(self):
        for c in CUTS:
            for p,v,s in [(0,90,2),(75,59,3),(75,39,4),(90,39,5),(90,19,6),(97.5,19,7)]:
                with self.subTest(c=c,s=s):self.assertEqual(self.call(c,p,v)['candidate_stage'],s)
    def test_every_absolute_boundary(self):
        for c,cuts in CUTS.items():
            if cuts:
                cheap,normal=map(D,cuts)
                for pe,s in [(cheap-D('.001'),7),(cheap,5),(normal-D('.001'),5),(normal,2)]:
                    with self.subTest(c=c,pe=pe):self.assertEqual(self.call(c,pe=pe)['candidate_stage'],s)
    def test_invalid_forward_pe_does_not_become_cheap(self):
        for c in CUTS:
            for pe in [0,-1,None,'NaN','Infinity',True,'not_a_number']:
                with self.subTest(c=c,pe=pe):
                    r=evaluate(c,True,True,1,100,0,'FORWARD_PE',pe,True)
                    self.assertEqual(r['status'],'UNKNOWN'); self.assertIsNone(r['candidate_stage'])
    def test_three_value_and(self):
        expected={(False,False):False,(False,True):False,(False,None):False,(True,False):False,(True,True):True,(True,None):None,(None,False):False,(None,True):None,(None,None):None}
        for xs,want in expected.items():self.assertIs(AND(*xs),want)
    def test_nesting_finite_grid(self):
        for c,p,v,d,legal in product(CUTS,[0,74.99,75,89.99,90,97.49,97.5,100],[0,19.99,20,39.99,40,59.99,60,100],[0,1],[False,True,None]):
            r=self.call(c,p,v,d,legal=legal)
            for s in range(3,8):self.assertFalse(r['states'][s] is True and r['states'][s-1] is False)
            self.assertIsNone(r['formal_stage'])
    def test_unknown_highest_never_executes_lower_bound(self):
        for c in CUTS:
            r=self.call(c,p=None,v=None)
            self.assertEqual(r['status'],'UNKNOWN');self.assertIsNone(r['candidate_stage']);self.assertIs(r['states'][2],True)
    def test_range_unknown_not_na(self):
        for c,cuts in CUTS.items():
            if cuts:
                r=self.call(c,app=None)
                self.assertEqual(r['status'],'UNKNOWN');self.assertIsNone(r['candidate_stage'])
    def test_unresolved_or_unsupported_override_does_not_pass(self):
        for c,cuts in CUTS.items():
            if not cuts:
                for app in [None,True]:
                    r=self.call(c,app=app)
                    self.assertEqual(r['status'],'UNKNOWN')
                self.assertEqual(self.call(c,app=False)['candidate_stage'],7)
    def test_no_support_distinct_from_unknown(self):
        for c in CUTS:
            r=self.call(c,entry=False)
            self.assertEqual(r['status'],'DETERMINATE');self.assertIsNone(r['candidate_stage']);self.assertEqual(r['boolean_upper_bound_possible_stages'],[None])

if __name__=='__main__':unittest.main(verbosity=2)
