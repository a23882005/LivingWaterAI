最後修改日期時間：2026/10/25 07:59（台灣時間）

# 第五位家人 APK｜程式映射

本版只借用原 Family 14 選單的**功能名稱與流程概念**，不讀寫既有四個家人個人的任何資料。

- Android UI：`app/src/main/java/tw/livingwater/family5/MainActivity.java`
- Python 本機服務：`app/src/main/python/family_offline.py`
- SQLite：Android 私有 `livingwater_family5.db`，範圍標記 `FAMILY5_STANDALONE`
- 使用者驗證：本機密碼；個人資料隔離與原 Google Drive／Family 服務無關
- 來源參考：GitHub `a23882005/LivingWaterAI` `系統工程/Family/W7/family_menu.py` 的 14 項編號與操作鍵
- 尚未移植的正式引擎：Family W5、V82/V75、W6 renderer，及 W2 標的研究流程
- 本機 07～09 需要網路，只有 01～06、10～14 的基礎資料動作能離線運作

**重要：**此專案的 `05` 只顯示歷史成本占比，`13` 只產生本機資料報告。待接正式數據與投資計算流程後再做完整驗收。
