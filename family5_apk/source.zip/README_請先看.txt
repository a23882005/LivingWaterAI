🏞️ 活水AI｜第五位家人單機 APK v0.2
日期：2026/10/25 07:59（台灣時間）

1. 對象是新加入的「第五位家人」，並非既有家人的個人投資專案。
2. ZIP 內有獨立 APK 原始專案：Android 14 項選單、Python、本機 SQLite、單人密碼與 GitHub Actions 建置設定。
3. 安裝後先設定顯示名稱與本機密碼。全新空白第五位家人資料庫；與既有四位資料隔離。
4. 07～09 查最新網頁需要網路；05、13 的正式引擎仍須移植，現為本機成本分析及 HTML 資料摘要。
5. 本 ZIP 是原始碼，尚非已編譯的 APK。此環境未執行 Android SDK 建置；詳見 README.md。
6. 未改動正式 Google Drive 或 LivingWaterAI GitHub 主線。
