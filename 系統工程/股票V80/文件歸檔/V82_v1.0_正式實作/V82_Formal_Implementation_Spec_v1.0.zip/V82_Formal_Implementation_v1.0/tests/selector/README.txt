V82 v0.4 候選規格參考測試

本資料夾只驗證本次新增候選的數學分支與邊界，不驗證正式 V82 引擎、真實行情、策略獲利或交易安全。
正式 V82 與上一版全球 ETF 研究原型均未被替換。
新候選需策略審核與實證；禁止直接接入正式下單。

boolean_upper_bound_possible_stages 是巢狀布林未知的保守上界集合，不是共享數值特徵約束下精確可達階段；不得拿它推導最低買入或機率。
參考器假定當前估值已通過各類合法Waterfall；不實作資料Resolver或專屬Range Override。absolute_range_applicability須顯式提供，未知不能當N/A。
