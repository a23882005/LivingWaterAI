﻿最後修改日期時間：2026/09/23 09:01（台灣時間）
文件版本：v1.21.0
文件狀態：正式
# V82 股票／股票ETF長期持有 × 動態資金部署完整正式可執行版


## 2026/09/23 09:01｜V82系統工程77｜工程28～76 Final Formal Commit＋程式化前正式封版｜v1.21.0

- **正式狀態：FORMAL SOT／工程77 Final Formal Commit版本。** 工程28～76由Work1～8累積之Workspace成果，在Fresh Read、三方Conflict Check與修改前Backup Gate通過後納入本母規則；正式Drive Read-back、全域QA與A線CLOSED證據由`A_V82系統工程紀錄.md`與Work9 Final Checkpoint保存。
- 工程28～34：Valuation Waterfall／PIT-Freshness-Completion／股票與ETF Fundamentals／Macro與Credit-Liquidity介面／T+1 Gap Recheck。
- 工程35～44：九階累積部署、Execution／金額股數、Target-Gap-Completion、Hard Gate、Base／Left／Right／Trend／Runaway Down。
- 工程45～62：Structural Break、Risk Grade／FC／AP／RRG、Reduction、Emergency／Recovery／Episode，以及Event／Evidence／Lineage／Freshness／Coverage／Cold Start。
- 工程63～67：V70 Tactical Budget、SGOV／資金來源／FX、49欄Canonical Analysis Contract、13欄Execution View、Shared `run_id`／`v82_snapshot_id`／Persistence。
- 工程68～76：Candidate／TBD、公式／State／Priority／資料結構／歷史規則清掃，15組Cross-Section Edge Cases與九維Machine-Readable Determinism Audit。
- FINAL RECHECK固定維持：`new_buy_order_permission`只由Data Sufficiency、Hard Gate、更高Priority Risk與Required Project／Execution Inputs裁決；Final Deployment Gap只在形成Executable Buy Order時另外檢查，Permission與Gap不混用。
- 本次封版**未新增或修改**既有投資Threshold、九階部署比例、Default、Fallback、Hard Gate種類、Candidate Parameter、Risk Clock、Emergency Rate或Search Window。
- Python／Tests仍依施工圖凍結；下一工程為**V82系統工程78｜新版Python施工藍圖／Implementation Blueprint**，其唯一策略來源為本v1.21.0正式封版。

> **正式宣告：V82.md 程式化前人類可讀母規則正式定稿。**



## 2026/09/19 23:51｜V82系統工程27｜五層Price Map Canonical Contract｜v1.20.0


### 27-A｜最高Invariant
> 五層Price Map ≠ 九階Deployment Ladder。Price Map回答「價格到了哪裡」；Deployment Ladder回答「累積部位完成到哪裡」。兩者是Orthogonal Dimensions，禁止固定一對一映射。


### 27-B｜Layer與輸入
- 每一股票／股票ETF建立LAYER_1～LAYER_5五個由淺至深的價格區；Layer編號代表相對價格深度，不代表固定買入比例。
- 每層必須由該標的自身資料重算，輸入至少包含：Confirmed／Provisional Swing High、Swing Low、ATR(14)、MA、Previous High、Previous Low、Support、Resistance、Valuation、Fundamentals；可用成交密集區／缺口與該標的既有專屬框架作補充。
- 本工程不新增全市場共用固定百分比門檻。第一左側／甜甜價／深度折價／極端折價等既有語意可作人類可讀Label，但不得反推成未核定的固定百分比。


### 27-C｜Asset-local Rule
- 每一標的只能使用自己的價格、ATR、Swing、MA、支撐壓力、估值與基本面建立Price Map；代理框架只借股性與分析骨架，不借價格。
- SOXX、QQQ、0050、NATO、VWRA、個股等不得互相複製Layer價格。交叉市場只作Context／Confirmation。
- 市場結構、Swing、ATR、估值、基本面、信用／流動性或波動實質改變時可重算；單日漲跌本身不得機械上移／下移整張Map。


### 27-D｜Layer State與UNKNOWN
- 正式輸出至少保存asset_id、layer_id、lower_bound／upper_bound或等價價格區、evidence、as_of、source、data_quality、map_version。
- 若必要輸入不足而無法可靠界定某層，該層=UNKNOWN／INCOMPLETE，不得以0、前次舊值或其他標的價格補齊。
- 若只部分Layer可可靠建立，保存已知Layer並標示Map Completion；不得假裝五層全部完成。


### 27-E｜與Deployment整合
- 價格進入某Layer只代表「重新評估部署強度／是否達到合理價格區」，不是自動成交。
- 正式投入仍需依九階Deployment Ladder、目前已完成部位、Asset Grade／專案上限、Hard Gate、Runaway Down、基本面、估值與技術成熟度決定。
- 同一Layer可對應不同Deployment Stage；同一Deployment Stage也可能在不同市場環境落於不同Layer。禁止建立L1=Stage1、L2=Stage2等固定映射。






## 2026/09/19 23:31｜V82系統工程26｜日／週／月多週期 Canonical Contract｜v1.19.0




本版正式化Daily／Weekly／Monthly的角色、衝突與資料對齊；不新增投資Threshold，不修改Price Map、Deployment Ladder、Priority、Hard Gate、Structural Break、Reduction、Emergency；Python／Tests維持凍結。




### 26-A｜Timeframe Roles
- DAILY＝Tactical Execution：主要負責Base／Left／Right／Trend的實際進退節奏與短期價格／技術狀態。
- WEEKLY＝Medium-term Trend／Confirmation：判斷日線變動屬正常修正、反彈，或中期結構開始改變。
- MONTHLY＝Structural Trend Context：提供長期牛熊結構與長期投資論點的價格位置背景；不得單獨作為短線第一買點或單日交易命令。




### 26-B｜Conflict Matrix
- Daily Bullish／Weekly Bullish／Monthly Bullish＝MULTI_TIMEFRAME_BULLISH_CONFLUENCE；右側確認可信度最高，但仍受價格、估值、基本面與Hard Gate約束。
- Daily Bearish／Weekly Bullish／Monthly Bullish＝LONG_TERM_UPTREND_SHORT_TERM_CORRECTION；長期多頭中的短線修正，甜甜價部署不得只因日線未完全止跌而機械歸零。
- Daily Bullish／Weekly Bearish／Monthly Bullish＝COUNTERTREND_REBOUND_IN_MEDIUM_WEAKNESS；中期弱勢中的短線反彈，日線轉強不得自動宣告中期趨勢修復。
- Daily Bearish／Weekly Bearish／Monthly Bearish＝MULTI_TIMEFRAME_BEARISH_CONFLUENCE；進入高風險技術背景，優先暫停新增左側接刀並交由既有Hard Gate／Runaway Down／Risk Reduction規則決定正式行動。
- 其他混合組合＝MIXED_TIMEFRAME；不得強塞進上述四型。




### 26-C｜Longer-timeframe Priority／Shorter-timeframe Permission
- 長週期決定Context與Confirmation強度；短週期決定Tactical Execution時點。長週期Context不得直接取代短週期價格／執行條件，短週期訊號也不得覆寫已確認的長週期結構。
- Weekly／Monthly仍健康時，Daily正常修正可依既有左側規則部署；Weekly／Monthly結構同步惡化時，Daily單日反彈只作短線改善證據，不自動解除更高層風險。
- 任何Timeframe均不得單獨越權覆蓋Hard Gate、Structural Break、Emergency或20號Primary Priority。




### 26-D｜UNKNOWN Propagation
- Daily／Weekly／Monthly各自獨立保存Data Quality。任一週期UNKNOWN只污染依賴該週期的Composite判定，不得把其他已知週期清零。
- 需要三週期完整判斷的Confluence若任一必要週期UNKNOWN，Composite=UNKNOWN或PARTIAL_CONTEXT；不得把UNKNOWN當Bullish、Bearish或Neutral。
- 已知Daily訊號仍可保存為Tactical Observation，但若正式執行規則明確依賴缺失的Weekly／Monthly確認，該確認不得假裝PASS。




### 26-E｜Same-run Data Alignment
- 同一正式Run必須為Daily／Weekly／Monthly保存各自as_of_period、source、retrieved_at、bar_completion_state與data_quality。
- 三週期應由同一個正式Run的最新可得Completed Bars建立；不同交易日曆／週月收盤自然差異不是錯誤，但必須能追溯各自最後Completed Period。
- 若來源時間戳或週期資料明顯不一致到足以改變判斷，標記TIMEFRAME_ALIGNMENT_ISSUE並依22號Data Quality處理，不得靜默拼接。












## 2026/09/19 23:21｜V82系統工程25｜EMV／RSI／成交量量價 Canonical Contract｜v1.18.0








本版只把既有EMV、RSI與成交量／量價規則工程化；不新增未核定投資門檻，不修改Price Map、Deployment Ladder、Priority、Hard Gate、Structural Break、Reduction、Emergency；Python／Tests維持凍結。








### 25-A｜EMV
- 正式參數沿用EMV 3,3；正式輸出狀態至少為POSITIVE、NEGATIVE、RISING、FALLING、UNKNOWN。
- POSITIVE／NEGATIVE依同一公式同一平台或同一自行計算序列相對零軸判定；RISING／FALLING比較相鄰Completed Bar的EMV方向。
- 由負往0改善、由負轉正、正值走高、高位轉弱與價格背離均保留既有Signal語意。平台公式有差異時不得跨平台比較絕對值。
- EMV為Soft Signal，不得單獨決定買賣、Hard Gate、Structural Break或真正降低風險。








### 25-B｜RSI
- 固定RSI(14)。RSI<30=OVERSOLD；RSI>70=OVERBOUGHT／過熱；30～50區間若持續回升屬右側改善。30與70沿用既有正式門檻。
- RSI Value必須保存數值；Range至少能區分<30、30～50、>70，以及其餘已知區間，不得把未落入三個敘事區間的已知值誤寫UNKNOWN。
- Divergence只有在價格與RSI存在可比較的已確認Swing結構時才可判定；資料不足輸出UNKNOWN，不主觀補值。
- Runaway Up中不得因RSI>70單獨賣出；RSI亦不得單獨觸發真正降低風險。








### 25-C｜成交量／量價
- 正式比較當日Completed Volume與5日、20日平均量；50日平均量在既有規則需要時加入。平均量資料不足所需Completed Bars時，該比較=UNKNOWN，不以較短期間冒充。
- Canonical四象限：PRICE_UP_VOLUME_UP、PRICE_UP_VOLUME_DOWN、PRICE_DOWN_VOLUME_UP、PRICE_DOWN_VOLUME_DOWN；價格無實質方向或必要量價資料不足分別輸出FLAT、INSUFFICIENT／UNKNOWN。
- 價漲量增=正面確認；價漲量縮=突破確認度下降；價跌量增=賣壓增加；價跌量縮=支撐附近可能代表賣壓衰退。這些是Context Signal，不是獨立交易命令。
- 爆量不漲保留為高檔風險Signal；不得單獨等同技術減碼或真正降低風險。
- 理想左→右演化固定：大跌放量→後續下跌量縮→價格不再破低→反彈放量。








### 25-D｜Data Quality／UNKNOWN
- EMV、RSI、Volume/Price正式值只使用Completed Bars；盤中觀察標PROVISIONAL，不得覆寫Confirmed。
- 全部繼承工程22 Data Quality／UNKNOWN Contract；缺資料、過期、衝突無法裁決、方法不可驗證時受影響欄位=UNKNOWN，不得轉成0、False或Neutral。
- Partial Calculation按依賴傳遞：例如Volume缺失只污染量價與依賴Volume的Signal，不得把RSI或整份V82清零。
- 正式輸出保存timeframe、data_as_of、source、method、data_quality與必要Issue Code；日／週／月不得混算。
























## 2026/09/19 22:06｜V82系統工程24｜KD／MACD／MA Canonical Contract｜v1.17.0
















本版只將既有KD、MACD與MA規則工程化為可機械判定、可追溯的Canonical Contract；不修改九階Deployment Ladder、五層Price Map、20號Primary Priority、Hard Gate、Structural Break、Reduction、Emergency或客戶專屬配置；Python／Tests維持凍結。
















### 24-A｜KD Canonical Contract
- 正式參數固定KD 9,3,3；使用同一時間框架可靠Completed OHLC。
- KD_GOLDEN_CROSS：前一Completed Bar K<=D，最新K>D；KD_DEATH_CROSS反向。
- KD_OVERSOLD：K<20或D<20；KD_OVERBOUGHT：K>80或D>80。20／80沿用既有正式門檻。
- KD_RISING：最新K與D相較前一Bar均改善；KD_FALLING反向；方向分歧輸出MIXED。
- 高檔鈍化、低檔轉強、背離保留既有Signal語意，不新增第二套門檻。
- KD是Soft Signal，不得單獨決定買賣、Hard Gate、Structural Break或真正降低風險。
















### 24-B｜MACD Canonical Contract
- 固定12,26,9；DIF=EMA12-EMA26；DEA/Signal=EMA9(DIF)；Histogram以DIF-DEA作Canonical方向值。外部平台若顯示2倍柱值只屬Display Scaling。
- MACD_GOLDEN_CROSS：前一DIF<=DEA，最新DIF>DEA；MACD_DEATH_CROSS反向。
- ABOVE_ZERO／BELOW_ZERO：DIF與DEA均在零軸同側；一正一負為STRADDLING_ZERO。
- HISTOGRAM_EXPANDING：Histogram絕對值較前Bar增加且符號未跨零；HISTOGRAM_CONTRACTING：絕對值減少且符號未跨零。跨零優先記錄方向切換。
- 空方柱縮短＝Histogram<0且abs(Histogram)下降；是空方動能減弱Signal，不是獨立買點。
- MACD是Soft Signal，不得單獨建立Classification、Hard Gate、Structural Break或Sell Intent。
















### 24-C｜MA Canonical Contract
- 固定MA5、MA10、MA20、MA50、MA60、MA200；各MA為最近N個可靠Completed Close的簡單移動平均。資料不足N根則UNKNOWN。
- ABOVE_MA_N：Close>MA_N；BELOW_MA_N：Close<MA_N；相等為AT_MA_N。
- MA_RECLAIM_N：前一Close<=前一MA_N，最新Close>最新MA_N；MA_BREAKDOWN_N反向。
- BULLISH_ALIGNMENT：MA5>MA10>MA20>MA50>MA200；BEARISH_ALIGNMENT反向。MA60為台股／既有專案輔助，不插入跨市場Canonical Alignment鏈，也不得替代MA50。
- Reclaim／Breakdown／Alignment均為Technical Signal，不得單獨等於右側加碼、Runaway Down、技術減碼或真正降低風險。
















### 24-D｜Data Quality／Timeframe／Output
- 正式值只用Completed Bars；盤中值標PROVISIONAL，不得覆蓋Confirmed。
- 繼承22號Data Quality／UNKNOWN Contract；資料不足、時間框架錯配或計算失敗時Signal=UNKNOWN，不得當False、Zero或Neutral。
- 保存timeframe、data_as_of、data_quality與必要Issue Code；日／週／月分開計算。
- 技術順序仍為高TD9→低TD9→KD→MACD→MA→EMV→RSI→成交量／量價。
































## 2026/09/19 16:37｜V82系統工程23｜TD9 Canonical Contract｜v1.16.0
















本版只將既有TD9概念工程化為可機械判定、可追溯、可於79+實作的Canonical Contract；**不修改九階Deployment Ladder、五層Price Map、20號Primary Priority、Hard Gate真正風險條件、Structural Break／Reduction／Emergency既有數字、Asset Type／Asset Grade Matrix、V70／債券V75或任何V82 Python／Tests。**
















最高不變量：
















> **High TD與Low TD必須分開；TD9是技術訊號，不是Hard Gate、Structural Break、Emergency或獨立買賣開關。UNKNOWN不得被轉成0、False、Neutral或「沒有TD9」。**
















### TD9-A｜正式週期、資料來源與Completed Bar
















1. V82 TD9正式Canonical週期固定為**日K（DAILY）**。V82的週線／月線趨勢角色仍保留，但本工程不建立週／月TD9；多週期整合留待V82系統工程26。V70內部既有Weekly High TD9若存在，屬V70自己的Macro／H-Score輔助訊號，不反向成為V82 TD9 Rule Owner。
2. 正式TD9必須優先由可靠市場資料的Completed Daily Bar自行計算；第三方頁面只顯示「TD9=6／9」不得直接成為V82正式值。
3. Canonical OHLCV資料包仍保存`session_date / open / high / low / close / volume / source / retrieved_at`；但TD9公式的直接計算依賴只有**交易日＋Close**。因此Open／High／Low／Volume單獨缺失不得污染TD9，應只污染依賴那些欄位的其他技術模組；這是22號Partial Calculation／Dependency Propagation的直接套用。
4. 要在沒有前序state cache的情況下重新計算「目前正式TD9狀態」，最低需**13根連續、已完成交易日且Close有效的日K**：9個可判定序列位置各需比較`Close[t-4]`，故最早需到`t-12`。週末／休市日不是缺資料；應依該市場正式交易日曆判斷連續交易session。
5. `Completed Bar`＝該標的主要交易市場當日正式交易session已收盤，且該session的正式Close已可可靠取得。盤中價格不得覆寫Completed Bar TD9。
6. 若需盤中觀察，可另產生`td9_provisional_*`，並明確標記`bar_completion_state = INTRADAY_PROVISIONAL`；它只供觀察，不得寫回`confirmed_td9_*`、不得進Formal Output、不得觸發正式Classification／Reduction／Order Permission。
7. 正式`as_of_session_date`固定指向最新可用Completed Bar；若資料落後於`expected_latest_completed_session`，必須標記`STALE`，不得沿用舊TD值冒充今日值。
















### TD9-B｜Canonical公式與序列狀態機
















對每一根Completed Daily Bar `t`：
















```text
High TD condition H[t] = Close[t] > Close[t-4]
Low  TD condition L[t] = Close[t] < Close[t-4]
Equal condition         = Close[t] == Close[t-4]
```
















Canonical規則：
















1. `H[t] = TRUE`時，只能推進High TD；`L[t] = TRUE`時，只能推進Low TD。正常已知Close下High／Low同一根bar互斥。
2. 若High序列尚未完成且`H[t] = TRUE`：`high_td_count = prior_high_td_count + 1`，上限9；Low序列同理。
3. 若序列到9：`state = COMPLETED`、`count = 9`。**完成9後不延伸10～13。** 若之後同方向條件持續成立，維持`COMPLETED / 9`；不製造10、11、12、13，也不重複產生新的完成9事件。
4. 條件中斷即Reset。若High進行中而當根變成Low，High當根Reset，Low可在同一根Completed Bar由1開始；Low→High同理。
5. 若`Close[t] == Close[t-4]`且資料可信，High與Low條件均為FALSE，兩側序列均Reset為已知`INACTIVE / 0`。這個0是「已知沒有進行中的該方向序列」，**不是把UNKNOWN轉成0**。
6. `COMPLETED / 9`只在相同方向條件持續時鎖定；一旦該方向條件不成立即Reset。之後再次符合時才建立新的序列。
7. 同一Completed Bar若上游Close被正式更正，必須自受影響bar起重新計算到最新bar，更新`calculation_timestamp`與Issue／Source lineage；不得只手動改最後一個count。
















### TD9-C｜State、Count、Direction必須分離
















正式至少保存：
















```text
td9_timeframe: DAILY
high_td_state: INACTIVE / COUNTING / COMPLETED / UNKNOWN
high_td_count: 0..9 / UNKNOWN
low_td_state: INACTIVE / COUNTING / COMPLETED / UNKNOWN
low_td_count: 0..9 / UNKNOWN
td9_direction: HIGH / LOW / NONE / UNKNOWN
as_of_session_date:
expected_latest_completed_session:
bar_completion_state: COMPLETED / INTRADAY_PROVISIONAL
source:
calculation_method: CLOSE_VS_CLOSE_T_MINUS_4_SELF_COMPUTED
calculation_timestamp:
data_quality: OK / FALLBACK_USED / INSUFFICIENT / UNKNOWN
data_issue_codes:
freshness:
```
















- `COUNTING`只允許count 1～8。
- `COMPLETED`只允許count 9。
- `INACTIVE`只允許count 0。
- `UNKNOWN`的count也必須是`UNKNOWN`，不得填0。
- 正常已知資料下，High與Low不能同時`COUNTING／COMPLETED`；若來源衝突使方向無法裁決，兩側受影響輸出皆回UNKNOWN。
















### TD9-D｜Low TD正式階梯分數與×4權重
















既有核定的Low TD階梯固定如下，**數字不得自行調整**：
















| Low TD count | low_td_stage_score |
|---:|---:|
| 1 | +0.5 |
| 2 | +0.8 |
| 3 | +1.0 |
| 4 | +1.5 |
| 5 | +1.8 |
| 6 | +2.0 |
| 7 | +2.5 |
| 8 | +3.0 |
| 9 | +4.0 |
















Canonical權重固定：
















```text
td9_weight_multiplier = 4
low_td_weighted_score = low_td_stage_score × 4
```
















因此在**明確使用TD9技術評分的上層scoring context**中，Low TD1～9的加權貢獻依序為`+2.0 / +3.2 / +4.0 / +6.0 / +7.2 / +8.0 / +10.0 / +12.0 / +16.0`。此加權值只供已定義的技術成熟度／評分模組消費，**不得直接映射為九階Deployment Ladder比例、不得單獨產生買單權限、不得繞過Hard Gate或20號Priority。**
















已知沒有Low TD序列時可記`low_td_stage_score = 0`；若Low TD本身為UNKNOWN，分數亦必須`UNKNOWN`，不得填0。
















### TD9-E｜High TD正式語義
















1. High TD與Low TD是不同方向的訊號，**High TD不得吃到Low TD買進分數**；`high_td_buy_score = NOT_APPLICABLE`。
2. High TD1～7只表示上行序列成熟度逐步增加；High TD8～9可作「高檔成熟／過熱可能提高」的技術證據之一。
3. `High TD9 = COMPLETED / 9`固定視為**變盤／過熱警戒**，不是「強買」，也不是單獨賣點。
4. High TD9不得單獨等於：技術減碼、真正降低風險、Runaway Down、Hard Gate、Structural Break、Emergency或強制賣出。只有與價格、KD／MACD／MA／EMV／RSI／量價、估值、基本面、Macro／信用／流動性等既有條件共振後，才能支援相應上層Predicate。
















### TD9-F｜Data Quality／UNKNOWN／Freshness
















TD9正式繼承第六十二章Canonical Data Quality Contract：
















- TD9資料類別＝`DERIVED_DATA + SOFT_SIGNAL`。
- Requirement Level預設＝`MODULE_REQUIRED`；只有某個上層Predicate明文需要TD9時才污染該Predicate。TD9本身不是`SAFETY_REQUIRED`，單獨缺失不得讓Fundamentals、Valuation、Price Map、Macro Safety或整份V82一律UNKNOWN。
- 可靠Primary OHLCV／Close可得時，優先自行計算；若依正式合法替代資料源完成，依22號Fallback Contract標示`FALLBACK_USED`。
- 缺少13根必要Completed Close、必要session缺失、Close無效或最新session缺失且無合法Fallback：受影響TD9輸出＝`UNKNOWN`，`data_quality = INSUFFICIENT`，Issue Code依事實使用`MISSING / STALE / FIELD_INCOMPLETE / INVALID_VALUE / SOURCE_UNAVAILABLE`等。
- 多來源衝突若可由較高權責來源正式裁決，可用裁決後資料計算並保留`CONFLICT`紀錄；若無法可靠裁決，TD9＝`UNKNOWN`、`data_quality = UNKNOWN`或至少不得為OK。
- 計算方法無法取得／無法驗證時，依22號既有Issue Code使用`METHODOLOGY_UNAVAILABLE / UNVERIFIABLE`；不得用第三方文字值偷偷補成正式TD9。
- 市場休市、週末、法定假日只要最新資料等於`expected_latest_completed_session`，不算STALE。
- 歷史`last_confirmed_td9_*`可以保存，但不得當成目前值；目前值的Freshness失格時，Current TD9仍須UNKNOWN。
















### TD9-G｜與Special Classification／Hard Gate／Structural Break邊界
















TD9只可作上層證據，不擁有最終裁決權：
















- Low TD可支援左側買點成熟度；與價格止穩等條件共振時可支援右側加碼。
- High TD可支援Runaway Up的過熱／成熟證據，或與其他轉弱訊號共振後支援技術減碼。
- TD9可作Runaway Down／其他技術Predicate的其中一項證據，但不得單獨建立該分類。
- 20號Primary Priority固定不變：`真正降低風險 > Runaway Down > 技術減碼 > Runaway Up > 右側加碼 > 左側買點 > 無特殊分類`。
- 較高Priority Predicate若因必要TD9而UNKNOWN且可能搶占較低已知TRUE，仍依22號三值Priority規則保留Primary UNKNOWN語義；不得把TD9 UNKNOWN默默當FALSE。
- TD9本身**不是Hard Gate**。Low TD9=9不代表安全；High TD9=9不代表風險事件成立。
- TD9本身**不得直接觸發Structural Break／Emergency／真正降低風險**；這些仍由既有基本面、信用、流動性、事件與Structural Break Contract裁決。
















### TD9-H｜Formal Output與可追溯性
















每次正式TD9輸出至少要能追溯：`value/count + direction/state + as_of_session_date + source + calculation_method + calculation_timestamp + data_quality + issue_code + freshness + completed/provisional`。
















若TD9只是一個非必要Soft Signal且UNKNOWN，依22號Partial Calculation只污染依賴TD9的下游訊號；**不得因單一TD9 UNKNOWN就把整份V82 Formal Output一律關閉。** 若某個當輪Required Classification明文需要TD9且無其他合法路徑可裁決，該Classification Predicate＝UNKNOWN，Formal Output是否可交付再依第六十二章`formal_output_eligible`與Requirement／Dependency判斷。
















---
















## 2026/09/19 16:03｜V82系統工程22｜Data Quality／UNKNOWN Contract｜v1.15.0
















本版將既有分散於估值、技術、新聞／事件、Hard Gate與正式報告的資料品質規則收斂為單一、可機械判定的Canonical Contract。**本版不改任何投資比例、九階Deployment Ladder、五層Price Map、20號Primary Priority、Hard Gate真正風險觸發條件、Structural Break／Reduction／Emergency既有數字、Asset Type／Asset Grade Matrix或任何V82 Python／Tests。**
















最高不變量：
















> **UNKNOWN ≠ False ≠ Zero ≠ Neutral；資料不足 ≠ 市場風險惡化；資料不足也 ≠ 安全。**
















本版正式建立／封口：
















- `Field Value State = KNOWN / NONE / UNKNOWN / NOT_APPLICABLE`。
- `Data Quality = OK / FALLBACK_USED / INSUFFICIENT / UNKNOWN`。
- `Data Issue Code`獨立保存Missing／Stale／Conflict等原因，不再與Quality混成同一欄。
- `Data Class`與`Requirement Level`分離：同一資料可同時是Derived Data與Soft Signal；是否屬Safety Required另行判定。
- 所有Boolean Predicate正式使用`TRUE / FALSE / UNKNOWN`三值邏輯；UNKNOWN必須向下游傳遞，不得默默轉False。
- `Hard Gate Evaluation = TRIGGERED / NOT_TRIGGERED / UNKNOWN`與`Data Sufficiency Gate = PASS / FAIL / UNKNOWN`正式分離；重大安全資料缺失可阻擋新增買進權限，但不得假裝Hard Gate已被市場風險「觸發」。
- `Formal Output Eligible = TRUE / FALSE`正式控制客戶可交付輸出；Required資料為INSUFFICIENT／UNKNOWN且無合法Fallback時不得交付正式結論。
- Partial Calculation採Dependency Propagation：只污染依賴缺失資料的輸出，不把整套V82一律清零。
- Structural Break Reduction的技術資料不足採Safety-preserving Reduction Fallback：已確認需要降低風險時，缺少加速／減速技術證據可回到既有`NORMAL`減碼速度，但同時保留`technical_data_quality = INSUFFICIENT`；**這不是UNKNOWN=Normal。**
















## 2026/09/19 15:03｜V82系統工程21｜Asset Type／Asset Grade｜v1.14.0
















本版將股票／股票ETF的「它是什麼」與「結構性風險／部署等級」正式拆成兩個獨立、可機械判定的Canonical維度：`Asset Type`與`Asset Grade`。本版不改九階Deployment Ladder、五層Price Map、Hard Gate核心定義、Structural Break／Reduction／Emergency既有數字，也不修改任何V82 Python／Tests。
















最高不變量：
















> **Asset Type ≠ Asset Grade ≠ Portfolio Role ≠ Primary Valuation Class ≠ Company Risk Grade。任何一個欄位UNKNOWN都不得被False、Zero、Neutral或預設A級取代。**
















本版正式建立：
















- `Asset Type`唯一Primary Enum：`INDIVIDUAL_STOCK / BROAD_ETF / SECTOR_ETF / INDUSTRY_ETF / THEME_ETF / HIGH_VOLATILITY_ETF / OTHER_APPROVED_EQUITY_VEHICLE`。
- `Asset Grade`固定：`A / B / C / D`；只可影響施工圖21允許的六類項目：Deployment Speed、Concentration Limit、Valuation Requirement、Look-through Requirement、Position Limit、Data Requirement。
- `Portfolio Role = CORE / SATELLITE / UNKNOWN`由客戶專案／配置層提供，V82只消費，不得由Asset Type或Asset Grade自行推導。
- `Asset Classification Status = COMPLETE / UNKNOWN / INVALID_COMBINATION`，用來處理證據不足與非法Type × Grade組合；它不是Special Classification、Hard Gate、Deployment Mode或WAIT。
- 個股Thesis／R1-R3／FC／RRG／B-series Structural Break Reduction仍只適用`INDIVIDUAL_STOCK`；股票ETF不使用個股Thesis計分，依ETF自身結構安全規則處理。
















## 2026/09/19 14:30｜V82系統工程20｜特殊分類＋全域Priority／Coexistence／Preemption Matrix｜v1.13.0
















本版只把既有六類Special Classification、Hard Gate、Structural Break、Emergency、Deployment Mode與Deployment Gap整理成**唯一可裁決的全域優先／共存／搶占契約**；不修改九階梯`10/20/30/45/60/75/85/95/100%`、五層Price Map、Hard Gate核心定義、Structural Break／Reduction／Emergency既有數值或任何既有Candidate／TBD。
















最高不變量：
















> **WAIT不得以任何名稱重新出現成第七個State。六類皆未成立時只輸出「無特殊分類」；「本輪不新增」只是一個Execution Result。**
















全域Special Classification Primary Priority正式固定為：
















> **真正降低風險 > Runaway Down > 技術減碼 > Runaway Up > 右側加碼 > 左側買點 > 無特殊分類。**
















此Priority只裁決「多個Special Classification條件同輪同時成立時，哪一個輸出為Primary」。Hard Gate仍是Gate；Emergency／Structural Break仍是各自Business／Event State；Deployment Mode仍是正常資金部署方式，均不得被升格或混入Special Classification Enum。
















---
















## 2026/09/19 09:34｜V82系統工程19｜Rule Ownership＋System Boundary｜v1.12.0
















本版只正式化**規則所有權與系統邊界**，不修改九階梯 `10/20/30/45/60/75/85/95/100%`、Hard Gate、Structural Break、Reduction、Emergency或其他既有投資數字／公式。
















最高不變量：
















> **同一條正式 Business Rule 只能有一個 Primary Rule Owner。**
















正式Owner邊界：
















| Owner | Primary Responsibility | Business Rule Authority | 明確禁止 |
|---|---|---|---|
| `V82` | 股票／股票ETF共同戰術規則、逐檔分析、Classification、Deployment與標的層風控 | 股票／股票ETF Rule Owner | 不決定客戶人生配置、不決定跨資產總額度、不管理債券規則 |
| `V70` | Macro、Strategic Risk Budget規則、跨資產股票／債券／原生Dry Powder戰術總額度 | Macro／Strategic Risk Budget／Tactical Budget Rule Owner | 不決定逐檔股票或逐檔債券 |
| `Mentor` | 訪談、流程、路由、工具選擇、跨引擎Orchestration／Integration、客戶解釋與確認 | **不是投資算法Owner** | 不重算V70／V82／V75核心規則，不因整合而取得其Rule Authority |
| `客戶專案` | 客戶事實、資金、持倉、限制、授權、核准Universe、核准目標與正式結果Persistence | 客戶專屬限制／授權Authority；非跨客戶投資算法Owner | 不建立第二套V70／V82／V75演算法 |
| `債券V75` | 債券／債券ETF資格、久期／信用／利率／流動性判斷與逐檔部署 | 債券／債券ETF Rule Owner | 不管理股票ETF，不決定跨資產總額度 |
| `Market Data` | Price／OHLCV／財務／總經／信用／利率等事實資料與timestamp/source | Fact Provider | 不決定Classification、Target、Gap或Recommendation |
| `News Provider` | Search／Retrieval／Document／Source Metadata | Search／Retrieval Provider | 不因提供新聞而成為Canonical Event／Emergency／Structural Break Rule Owner |
| `Broker` | Submitted／Open／Filled／Cancel／Reject、Executed Price／Quantity、Broker Confirmed Position | Execution Fact Authority | 不決定Canonical Target、Deployment Mode或Investment Recommendation |
| `Database` | Persistence、Snapshot、History、Version、Audit、Traceability | Persistence Layer | 不因保存State而決定Business State如何轉移 |
| `Execution Adapter` | Tick size、lot／fractional、precision、minimum notional、Order translation、Cancel／Replace mechanics | Technical Execution Authority | 不決定是否買、Canonical Target、Deployment Gap、FC、RRG或Recommendation |
















`Report／UI`只可Consume／Render正式結果，不得重新計算V70／V82／V75決策。
















### Logical SOT與Physical Persistence不得形成雙重真相
















- 現行Markdown階段，`客戶專案`是單一客戶已核准資料、限制、Authorized Universe與正式Latest State的**Logical Client State SOT**。
- 未來`Database`是這些正式狀態的**Physical Persistence Implementation**；Database可以保存／版本化／查詢／稽核，但不得自行生成另一套客戶目標或投資決策。
- Migration期間必須只有一條Canonical Write Path；不得讓Markdown與Database各自獨立修改同一Business State。詳細run_id／Latest State／Snapshot Persistence Contract Deferred至**V82系統工程67**。
- `News Provider`只提供Document／Article／Metadata／Retrieval結果；Canonical Event／Emergency／Structural Break等業務判斷仍由V82 Event／Risk規則擁有，詳細Event Schema Deferred至**V82系統工程57～62**。
















### S0/B0正式Ownership與現行實作狀態
















- **Rule Owner＝V70。** Strategic Risk Budget（含S0/B0如何由客戶風險資料形成）的正式規則歸V70。
- **Current／Legacy Producer＝Mentor／人工既有流程。** 截至本版，現行`V70_2.html`只接受外部已核准S0/B0輸入，再計算C／T與股票／債券／`V70_ORIGINAL_DRY_POWDER`戰術總額度；它**尚未**具備「從完整客戶風險資料自行推導S0/B0」的完整可執行演算法。
- `Mentor`負責蒐集資料、路由、解釋與取得客戶確認；不得因目前Legacy流程產生／輸入S0/B0就取得Strategic Risk Budget Rule Authority。
- `客戶專案`保存客戶核准後的正式S0/B0、目標、限制與授權。
- **Migration Required**：真正將S0/B0推導演算法完整實作進V70，Deferred至後續V70正式程式化工程；V82系統工程63只驗證V70→V82 Tactical Budget介面，不假裝此Migration已完成。
















### SGOV_DRY_POWDER_BUCKET Integration Contract
















固定公式維持：
















`SGOV_DRY_POWDER_BUCKET = V70_ORIGINAL_DRY_POWDER + V82_UNDEPLOYED_TO_SGOV + V75_UNDEPLOYED_TO_SGOV`
















此式是**Integration Contract，不是Investment Rule**：
















- V70／V82／V75各自只對自己的輸出值擁有Rule Authority。
- Mentor／Integration Layer只負責依既定Contract整合三個已算好的值。
- 客戶專案只保存正式整合結果與其來源／時間戳。
- Mentor不得因Integration責任取得V70／V82／V75的投資Rule Authority。
















### 事實來源、保存、執行與決策不得混用
















> **Source of Fact ≠ Rule Owner；Persistence ≠ Rule Owner；Execution Mechanics ≠ Investment Decision。**
















Broker可作成交／持倉事實來源；Database可保存狀態；Execution Adapter可把已核准Intent轉成券商合法訂單；三者均不得反向改寫V82策略。
















---
















## 版本定位
















V82為股票與股票ETF目前最高優先的完整正式操作框架。
















V82完整承接V81的分類骨架、價格地圖、技術、基本面、估值、Macro、信用／流動性、日線＋週線＋月線、ATR、Swing High／Low、Hard Gate、Look-through、下單與取消等核心規則；現行正式分類已收斂為六類特殊分類，`WAIT／一般等待`不再是正式State／分類／Deployment Mode。
















> **V82不是波段交易系統，而是「長期持有前提下的動態資金部署系統」。**
















對已由客戶核准列入 `Authorized Universe／長期配置目標`、並由V82依正式股票資格規則持續檢查的股票／股票ETF，V82的主要任務不是等到所有右側訊號都確認後才決定要不要參與，而是回答：
















1. 這項資產長期是否仍值得持有？
2. 現在價格合理、便宜、甜甜價、深度折價，還是過熱？
3. 在安全前提下，現在應投入多少、投入多快？
4. 若價格繼續變甜，是否應提高部署？
5. 若市場直接轉強而部位仍低配，是否應啟動Trend Deployment跟上？
6. 何時因Hard Gate或Runaway Down停止正常新增？何時因Structural Break／Emergency／投資論點破壞而真正降低風險？
















V82正式核心口訣：
















> **價格決定值得買多少。**  
> **技術決定今天先買多少、後面加多快。**  
> **Hard Gate決定暫時能不能買。**
















再加一條長期投資原則：
















> **長期好資產，價格越甜、基本面與信用／流動性越安全，原則上應提高部署，而不是因為短期技術還沒完全止跌就反而買得更少。**
















股票與股票ETF：
















**一律使用V82。**
















債券與債券ETF：
















**仍沿用債券V75。**
















---
















## V82系統工程18｜Canonical Terminology＋Data Dictionary正式定義｜2026/09/19 08:52（台灣時間）
















本節只統一正式語意、型別與資料字典；**不改變既有投資哲學、九階梯比例、Hard Gate、Structural Break、Reduction、Emergency或任何既有數值規則。** 未來Machine-readable欄位／Enum不得用同一名稱承載兩種不同型別。
















### A. 正式語意型別
















- **State**：某一明確Domain Object的持續狀態。Machine-readable合約不得裸用`State`；必須寫明例如`Thesis State`、`Event State`、`Order State`、`Execution State`、`Position State`。不同Domain的State不得共用同一Enum。
- **Special Classification｜特殊分類**：V82六類特殊分類的判斷結果；若六類皆未成立，輸出「無特殊分類」，**不建立第七類、不建立WAIT**。
- **Deployment Mode｜部署模式**：正常資金部署的方式，正式只指`Base Deployment / Left Overweight / Right Confirmation / Trend Deployment`。它不是Special Classification，也不是Order State。
- **Reduction Execution Mode｜減碼執行模式**：Structural Break Reduction內的`SLOW / NORMAL / ACCELERATED`；只控制減碼速度，與正常買進的Deployment Mode完全分離。
- **Signal｜訊號**：單一觀察或衍生條件，例如KD黃金交叉、MACD改善、MA Reclaim、Swing Breakdown。Signal本身不是Classification、Mode、Gate、Permission或Order。
- **Gate｜閘門**：安全／完整度檢查結果，例如Hard Gate。Gate控制是否允許特定Execution，不得反向改寫合理的Canonical Target或既有Position事實。
- **Permission｜權限**：是否允許特定執行行為。新增買進正式優先使用`New Buy Order Permission / new_buy_order_permission`；不得以模糊`new_order_permission`同時涵蓋買與賣。
- **Recommendation｜建議**：LivingWaterAI的正式決策建議；Recommendation不是Order，也不是Fill。
- **Execution Result｜執行結果**：本輪決策／執行的結果描述，例如「本輪不新增」「被Hard Gate阻擋新增買進」。Execution Result不是第七個State或新的Special Classification。
- **Order State｜訂單狀態**：Recommendation之後的券商／Execution流程狀態；完整State Contract由V82系統工程36封口。
- **Position State｜部位狀態**：部位資料的確認程度與來源狀態；不得把Pending／Open Order預先視為已成交部位。
















### B. Deployment／Target／Position資料字典
















- **Deployment**：實際部位向當下合理目標部位逐步前進的資金部署過程。
- **Deployment Stage**：九階梯中的目前層級／累積目標層級；**Deployment Stage ≠ Deployment Mode**。
- **Canonical Deployment Target Rate**：九階梯在當下條件下對應的正式累積目標比例。現行正式值仍為`10% / 20% / 30% / 45% / 60% / 75% / 85% / 95% / 100%`。
- **Canonical Deployment Target Amount**：由客戶專案保存的已核准Project Target Position與Canonical Deployment Target Rate映射出的當下合理目標金額；精確Cash／Order Exposure數學留待V82系統工程37～38封口。
- **Project Target Position｜客戶專案目標部位**：客戶專案保存客戶已核准的該標的長期目標部位；客戶專案是此客戶值的Persistence／Authorization SOT，不自行產生跨客戶V82配置演算法。**Project Target Position ≠ OTP**。
- **Current Position**：目前觀察到的部位資料；若來源尚未確認，不得直接作為正式成交事實。
- **Confirmed Position**：經券商確認持倉／Confirmed Fill等可靠來源確認的正式部位Snapshot。
- **AP (Actual Position)**：V82正式運算採用的最新實際部位；只由Confirmed Position／Confirmed Fill／券商確認持倉更新。Pending／Open Order不得提前改AP。
- **Actual Completion Rate**：`AP ÷ Project Target Position`。它回答「客戶目前實際完成長期目標部位多少」。
- **Canonical Deployment Target Rate**回答「依九階梯目前應累積到多少」。**Actual Completion Rate ≠ Canonical Deployment Target Rate**。
- **Deployment Gap**：當下合理目標與已確認實際部位／正式Order Exposure之間尚待部署的差額概念；完整公式與Active Order Exposure處理留待V82系統工程36～38封口。
















### C. Structural Break／Reduction正式縮寫
















- **OTP (Original Target Position)**：個股正式納入股票池／Structural Break框架時確定的原始目標部位基準，視為100%；它不是客戶目前可變動的Project Target Position同義詞。
- **FC (Fundamental Cap)**：Fundamental Cap，基本面結構性破壞後允許保留的最大部位上限。
- **RRG (Remaining Reduction Gap)**：Remaining Reduction Gap，現行正式公式維持`MAX(AP - FC, 0)`；不得改寫成Required Reduction Gap。
- **Episode**：一次完整業務／執行生命週期容器，例如Reduction Episode。Risk Grade變化不得僅因數值改變任意重開Episode。
- **Recovery**：依事前正式Recovery Requirement成立後的恢復程序；價格反彈、Emergency Deconfirmed或單一好消息本身都不自動等於Recovery。
- **Reconciliation**：對Active Orders、Confirmed Fills、Broker Position與Exposure重新對帳的正式程序；它不是Classification或Mode。
















### D. Event／Evidence資料字典
















- **Event**：可被追蹤、版本化並具明確業務邊界的事件；正式事件系統使用`Canonical Event`。Technical Crossing Event等其他Event必須以Domain前綴區分，不得與Canonical News/Event共用同一語意。
- **Evidence**：具有可追溯來源、Lineage與權責層級、用來支持或反駁判斷的證據物件。
- **Assertion**：Evidence內可獨立驗證、修改、撤回、取代或失效的具體主張。Document Recency不得直接等同Assertion Validity。
















### E. Candidate／TBD／Tentative／Provisional／UNKNOWN治理
















- **Candidate**：未批准的候選規則、候選值或Candidate Parameter；在正式批准／升格以前**不可進Executable Branch**。
- **TBD (To Be Determined)**：尚未決定。TBD不得自行補Default，不得因程式需要數值就猜24小時、7天、0或其他假精確值。
- **Tentative**：討論中的暫定方案；未正式批准前不得進Final Rule或Executable Branch。
- **Provisional Rule／Value**：已明確標示為臨時的規則／值；只有在正式批准並明定適用範圍、有效期間／替換條件時才可暫時執行，不得自動升格為永久正式規則。
- **UNKNOWN**：資料未知或無法可靠判定。固定：`UNKNOWN ≠ False`、`UNKNOWN ≠ Zero`、`UNKNOWN ≠ Neutral`。
- **NONE**：已知「沒有／未成立」，與UNKNOWN完全不同。
- **例外一｜EXTREME_CANDIDATE**：這是已正式定義的`ValuationLevel`列舉名稱，不代表「未批准的治理Candidate」。
- **例外二｜Provisional Low**：這是尚未完成確認條件的技術價格結構名詞，不等於`Provisional Rule／Value`。
















### F. 三組名稱衝突正式裁決
















1. **左側買點 vs Left Overweight**：`左側買點`＝Special Classification；`Left Overweight`＝Deployment Mode。兩者相關，但**不是同義詞**。左側買點回答「是否出現左側特殊情境」；Left Overweight回答「正常資金部署是否採左側加速模式」。
2. **右側加碼 vs Right Confirmation**：`右側加碼`＝Special Classification；個別KD／MACD／前低墊高等為`Right-side Confirmation Signals`；`Right Confirmation`＝Deployment Mode。Signal → Classification → Deployment Mode不得混成同一欄位。
3. **Runaway Up vs Trend Deployment**：`Runaway Up`＝Special Classification；`Trend Deployment`＝Deployment Mode。Runaway Up成立不代表一定新增買進；只有在Hard Gate未觸發、基本面／信用／流動性安全、且Deployment Gap與客戶專案邊界允許時，才可由Trend Deployment逐步跟上。
















### G. Recommendation／Order／Fill／Position不可混用
















正式責任鏈固定：
















> **Recommendation ≠ Order Intent ≠ Submitted/Open Order ≠ Fill ≠ Confirmed Position。**
















只有Confirmed Fill／券商確認持倉可更新AP。Pending、Open、GTC、預掛、Recommendation或Order Intent均不得提前改寫正式實際部位。
















---
















## V82系統工程20｜Canonical Priority／Coexistence／Preemption Contract
















### 20-A｜輸出欄位與最高Invariant
















同一輪必須先各自判定六類Special Classification的Predicate，再做全域裁決：
















- `active_special_classifications`：六類Predicate中實際成立者，可為0～多個；只供可解釋性與衝突診斷，不直接代表多個Execution Intent。
- `primary_special_classification`：同一輪最多只能有1個Primary；若六類皆未成立，顯示值為「無特殊分類」。
- 「無特殊分類」不是第七個State、不是Classification Enum成員、不是Deployment Mode，也不是WAIT。
- `Hard Gate`、`Emergency Event State`、`Structural Break Business State`、`Deployment Mode`、`Reduction Execution Mode`仍保有各自Domain，禁止塞入`primary_special_classification`。
















最高Invariant固定：
















> **WAIT不得以任何名稱、別名、fallback、normal state或execution status復活成第七個State。**
















### 20-B｜六類Canonical Entry／Exit／Direction／Allowed Action
















| Special Classification | Entry Condition | Exit Condition | Direction | Allowed Action |
|---|---|---|---|---|
| 左側買點 | 既有左側價格層至少1項成立，且基本面仍可長期持有，Hard Gate／Runaway Down／重大不可控Gap等安全否決未成立 | 自身價格條件不再成立，或安全／基本面條件轉為不允許；若被更高Priority分類搶占，Predicate可保留但不再是Primary | 增加曝險 | 只有`new_buy_order_permission=TRUE`且Final Deployment Gap>0時，才可依Left Overweight／九階梯分批新增 |
| 右側加碼 | 價格已離開最低點，既有右側確認訊號至少3項，且基本面／信用／流動性安全、非Runaway Down、估值未回極高區 | 右側有效訊號降至3項以下，或任一必要安全條件失效；被更高Priority分類搶占不等於自身Predicate自動消失 | 加速增加曝險 | 只有Permission通過且Final Deployment Gap>0時，才可由Right Confirmation加快完成尚未部署部位 |
| Runaway Up | 既有A價格結構至少1項＋B強勢確認至少3項，且價格未明顯跌破MA20 | A全部失效、B降至3項以下、明顯跌破MA20，或更高風險層接管正常買進Execution | 趨勢跟進／續抱 | 低配且安全、Final Deployment Gap>0才可Trend Deployment；接近／達目標則續抱，不機械超配 |
| Runaway Down | 既有A價格結構破壞至少1項＋B空方加速至少2項 | A全部失效或B降至2項以下；單純跌很多、價格反彈或低TD成熟均不等於Structural Break／Recovery | 防守／停止接刀 | 阻擋一般Base／Left／Right／Trend新增買進；重新評估或取消尚未成交的一般買單。**Runaway Down本身不自動產生Sell Intent、不自動等於Structural Break** |
| 技術減碼 | 既有技術減碼訊號**至少3項共振**；單一高TD9或RSI高檔不足 | 技術減碼有效共振降至3項以下，或更高Priority風險Execution接管 | 降低曝險 | 同一標的同一Cycle禁止再產生正常新增Buy Intent；可依既有規則分批降低衛星／高Beta，核心長期部位不因單一技術訊號全部退出 |
| 真正降低風險 | 既有投資論點、信用、流動性、重大政策、治理或中長期結構真正破壞成立；個股Structural Break／CONFIRMED Emergency依A～E／4-7D既有規則處理 | 只能依造成風險之既有正式Recovery／Resolution／Deconfirmation規則解除；價格反彈或單一好消息不得自行解除 | 最高風險降低／退出 | 停止新增Buy、取消／調整未成交Buy；Structural Break依B系列Reduction，CONFIRMED Emergency由Emergency Exit接管；不得由技術訊號建立第二套Sell Rate |
| 無特殊分類 | 六類Predicate全部False | 任一六類Predicate轉True | 正常 | Final Deployment Gap>0且Permission通過時依Base／既有Deployment Mode；Gap≤0則「本輪不新增」Execution Result |
















### 20-C｜Special Classification Primary Priority
















同一輪若多個六類Predicate同時成立，只能依以下Priority輸出一個Primary：
















| Priority | Primary Special Classification | 裁決原則 |
|---:|---|---|
| P1 | 真正降低風險 | 基本面／信用／流動性／治理／政策／長期結構風險優先於所有正常部署與一般技術訊號 |
| P2 | Runaway Down | 失速向下安全層優先於便宜、止跌確認與趨勢跟進 |
| P3 | 技術減碼 | 已成立的技術減碼方向，不得同Cycle再執行正常新增部署 |
| P4 | Runaway Up | 強勢趨勢特殊分類高於一般右側確認與左側折價分類 |
| P5 | 右側加碼 | 止跌／轉強確認高於仍可能成立的左側價格分類 |
| P6 | 左側買點 | 價格折價特殊分類 |
| — | 無特殊分類 | 只有六類全部False才顯示；不是P7、不是State |
















更高Priority只裁決Primary與Execution方向；較低Priority的Predicate可保留為Secondary Context，除非自身Entry條件因高層風險而已明確失效。
















### 20-D｜Canonical Coexistence／Mutual Exclusion Matrix
















`Primary`表示可共存時的Primary；`INVALID→SAFE`表示同一Canonical Snapshot理論上不應同時成立，若資料／時間框架錯配仍同時True，必須採安全裁決並觸發Reconciliation，不建立新Classification。
















| Pair | Coexistence | Primary／結果 | Mutual Exclusion／限制 |
|---|---|---|---|
| 左側＋右側 | 合法 | 右側加碼 | 可同時保留左側價格Context，但正常新增只能由單一Final Deployment決策產生 |
| 左側＋Runaway Up | 合法但少見 | Runaway Up | 不得同時建立Left與Trend兩筆重複Buy Intent |
| 左側＋Runaway Down | **理論互斥** | `INVALID→SAFE`：Runaway Down | 左側安全層既要求非Runaway Down；若同時True，視為判定／資料衝突，禁止新增並Reconcile |
| 左側＋技術減碼 | 合法過渡情境 | 技術減碼 | 同Cycle禁止新增Buy；不得一邊加碼一邊技術減碼 |
| 左側＋真正降低風險 | 高層風險搶占 | 真正降低風險 | 正常左側Execution失效 |
| 右側＋Runaway Up | 合法 | Runaway Up | Right只保留確認Context；若新增，統一由Final Trend／Gap決策產生 |
| 右側＋Runaway Down | **理論互斥** | `INVALID→SAFE`：Runaway Down | 右側必要條件要求非Runaway Down；禁止新增並Reconcile |
| 右側＋技術減碼 | 合法過渡情境 | 技術減碼 | 同Cycle禁止新增Buy |
| 右側＋真正降低風險 | 高層風險搶占 | 真正降低風險 | Right不得建立新增Execution |
| Runaway Up＋Runaway Down | **非法組合** | `INVALID→SAFE`：Runaway Down | 同一Canonical Snapshot不得同時作多空Runaway；禁止Trend新增，要求Same-run Data／Timeframe Reconciliation |
| Runaway Up＋技術減碼 | 合法轉折情境 | 技術減碼 | 技術減碼成立時，本Cycle不得Trend新增；Runaway Up可保留Secondary Context |
| Runaway Up＋真正降低風險 | 高層風險搶占 | 真正降低風險 | 強勢價格不得覆蓋結構風險 |
| Runaway Down＋技術減碼 | 合法 | Runaway Down | RD阻擋新增；若技術減碼亦成立，技術Sell Permission可保留，但不得創造第二套Structural／Emergency Sell Rate |
| Runaway Down＋真正降低風險 | 合法 | 真正降低風險 | RD只是市場／技術Context，風險降低Execution由既有Risk框架接管 |
| 技術減碼＋真正降低風險 | 合法 | 真正降低風險 | 技術減碼不得覆蓋、放慢或重設Structural Break／Emergency Execution |
| 任一六類＋無特殊分類 | **互斥** | 六類成立者 | 只要任一六類True，「無特殊分類」必為False |
















### 20-E｜Cross-domain Preemption Order
















Special Classification Priority與Execution Preemption是兩件事。正式Execution裁決順序：
















1. **CONFIRMED Emergency**：最高Execution Intent；`primary_special_classification=真正降低風險`，Emergency Exit直接Preempt既有Structural Break Reduction，仍共用Order Reconciliation／Confirmed AP／Active Sell Exposure／Execution Adapter。
2. **Structural Break／真正降低風險**：若一般Structural Break已成立，Risk Grade／FC／RRG與B系列Reduction維持唯一來源；Runaway Down或技術減碼只能作Context／速度既有輸入，不得創造第二套FC、RRG、Sell Rate或Clock。
3. **PENDING_VERIFICATION Emergency**：停止新的Buy Intent並取消未成交Buy；不建立Emergency Sell Rate。既有合法Structural Break Reduction依原Episode／Clock繼續。
4. **Hard Gate**：仍是Gate，不是Classification。Hard Gate ON固定使`new_buy_order_permission=FALSE`；但**Hard Gate本身不自動生成Sell Intent**。只有其底層事實另行滿足真正降低風險／Structural Break／Emergency規則時，才由相應風險Execution處理。
5. **Special Classification Arbitration**：在沒有更高風險Execution搶占正常部署時，依20-C選唯一Primary。
6. **Deployment Mode＋Final Deployment Gap**：Classification／Mode成立仍不等於一定有Order；必須在當輪Canonical Target確定後重新計算Final Deployment Gap與Permission。
















### 20-F｜Allowed Action Matrix
















| Primary／Cross-domain狀態 | New Buy | Hold | Technical Reduce | Structural Break Reduction | Emergency Exit |
|---|---|---|---|---|---|
| 左側買點 | Permission通過且Gap>0才可 | 可 | 否，除非另有更高分類 | 否 | 否 |
| 右側加碼 | Permission通過且Gap>0才可 | 可 | 否，除非另有更高分類 | 否 | 否 |
| Runaway Up | 低配＋安全＋Gap>0才可Trend | 可 | 否，除非技術減碼另成立並取得Primary | 否 | 否 |
| Runaway Down | **禁止一般新增** | 可 | 技術減碼另成立時可 | Structural Break另成立時依B系列 | Emergency另CONFIRMED時依D系列 |
| 技術減碼 | **同Cycle禁止正常新增** | 可 | 可 | Structural Break另成立時由B系列接管 | Emergency另CONFIRMED時由D系列接管 |
| 真正降低風險 | **禁止新增** | 僅在既有Risk規則允許時 | 不作第二套主Execution | Structural Break時依B系列 | CONFIRMED Emergency時依D系列最高接管 |
| 無特殊分類 | Permission通過且Gap>0可依正常Mode | 可 | 否 | 否 | 否 |
| Hard Gate ON | **FALSE** | 可／風險檢查 | 不由Gate單獨生成 | 若另有Structural Break則執行 | 若另有Emergency則執行 |
















### 20-G｜四個指定Edge Cases固定結果
















1. **Emergency + Left**
   - `CONFIRMED Emergency`：`primary_special_classification=真正降低風險`；Emergency Exit接管；左側不得產生Buy Intent。
   - `PENDING_VERIFICATION`：停止新Buy／取消未成交Buy；不產生Emergency Sell；既有合法Structural Break Reduction照原Episode／Clock繼續。
















2. **Hard Gate + Right**
   - `右側加碼`Special Classification／`Right Confirmation` Deployment Mode可以分析上成立。
   - Hard Gate仍只是Gate，但固定令`new_buy_order_permission=FALSE`。
   - 結果不得改名成WAIT；若沒有其他風險Sell規則，Execution Result只是「被Hard Gate阻擋新增買進」。
















3. **Structural Break + Runaway Down**
   - `primary_special_classification=真正降低風險`。
   - Risk Grade／FC／RRG與B系列Reduction仍是唯一Structural Break Execution來源。
   - Runaway Down保留Secondary Context，**不得因跌很多自動推導Structural Break，也不得另創Sell Rate／Deadline**。
   - 若再出現`CONFIRMED Emergency`，才由Emergency Exit Preempt。
















4. **Final Deployment Gap ≤ 0 + Right Confirmation**
   - Right Confirmation可維持有效分析結果，但在**本輪最新Canonical Target確定後**必須重新計算Final Deployment Gap。
   - 若Final Deployment Gap≤0：`new_buy_quantity=0`，Execution Result＝「本輪不新增」。
   - 不取消Right Confirmation分析結果；不建立WAIT／一般等待／第二套比例。
















### 20-H｜其他固定非法／衝突路徑
















- `Runaway Up=True AND Runaway Down=True`：同一Canonical Snapshot視為非法雙向Runaway；安全Fallback固定為Runaway Down、禁止新增、要求資料／時間框架Reconciliation。此為Diagnostic Result，不是新State或第七Classification。
- 左側或右側若與Runaway Down同時True：因自身安全條件明確要求非Runaway Down，視為Predicate／資料衝突；固定採Runaway Down安全結果。
- `primary_special_classification`任何時候不得同時輸出兩個值。
- 同一標的同一Cycle不得同時產生互相衝突的正常Buy Intent與Technical Reduce Intent；技術減碼取得Primary時，正常新增Buy Intent固定為0。
- 真正降低風險／Structural Break／Emergency一旦接管Execution，不得被估值便宜、左側價格、右側確認、Runaway Up或單一技術超賣訊號覆蓋。
















### 20-I｜Deterministic Evaluation Order
















同一輪固定依序：
















`Same-run Data Alignment`
→ `Emergency Event Aggregation`
→ `Fundamental／Structural Break Assessment`
→ `Hard Gate`
→ `6 Classification Predicates`
→ `Conflict／Mutual Exclusion Check`
→ `Primary Special Classification Priority`
→ `Deployment Mode Eligibility`
→ `Canonical Deployment Target`
→ `Final Deployment Gap`
→ `New Buy Order Permission／Reduction Intent`
→ `Order Reconciliation／Execution Adapter`
→ `Execution Result`
















任何步驟不得用後段結果反向創造前段不存在的Classification、State或Target。
















---
















## V82本次升版範圍｜2026/09/05 06:23（台灣時間）
















V82完整承接V81，但正式重構資金部署邏輯：
















1. **長期持有定位正式化**：V82不再以「等右側確認才敢買」為主要哲學；對已列入客戶長期配置的標的，預設是逐步參與市場，V82負責調整部署速度。
2. **Base Deployment／基本部署**：長期新資金在沒有Hard Gate、沒有Runaway Down、投資論點未破壞且估值非極端荒謬時，可以開始基本部署，不必永遠等下一次大跌。
3. **Left Overweight／甜甜價加速**：價格地圖越深、估值越有吸引力，在安全前提下累積部署目標越高；技術指標改為「比例調節器」，不再是第一筆買進的必要門票。
4. **Right Confirmation（Deployment Mode）重新定位**：`右側加碼`是Special Classification；KD／MACD／前低墊高等個別條件是Right-side Confirmation Signals；`Right Confirmation`是「前面已經開始買之後，證明止跌時再加快」的Deployment Mode，不再被視為所有長期資金的第一張入場許可證。
5. **Trend Deployment／強勢趨勢部署**：`Runaway Up`是Special Classification，`Trend Deployment`是Deployment Mode。Runaway Up不再只代表續抱／等待；若客戶專案目標部位仍明顯低配，且安全條件成立，才由Trend Deployment逐步提高曝險，避免長期資金永久躺在停泊資產。
6. **Actual Completion Rate正式納入**：客戶專案檔保存客戶已核准的 Project Target Position；V82以`AP ÷ Project Target Position`計算Actual Completion Rate，再與Canonical Deployment Target Rate比較，決定本次部署速度。
7. **取消WAIT／一般等待正式分類**：九階梯的Canonical Deployment Target Rate是唯一正常累積部署比例來源；若Actual Completion Rate低於當下Canonical Deployment Target Rate，仍有部署缺口，依既有Deployment Mode與技術／執行條件分批完成；若已達當下Canonical Deployment Target Rate且尚未觸發更高階梯，本輪自然不新增。此「不新增」只是Execution Result，不建立`WAIT` State／分類／Mode，也不得另生第二套Base比例。
8. **日／週／月線的角色明確化**：日線決定進退節奏；週線判斷中期修正或趨勢破壞；月線判斷長期結構。週線／月線健康時，日線甜甜價的左側部署意願可提高。
9. **母規則與回測正式分工**：V82直接定義正式部署比例與投資邏輯；`母規則回測.md`只負責公平回測、敏感度測試、PIT／T+1、成本、基準與驗證。不得由回測文件反過來創造或偷偷調整V82正式部署比例。若回測結果顯示需要修改，必須升版V82後重新完整回測。
10. **V81既有安全骨架保留**：TD9、KD、MACD、MA、EMV、RSI、成交量、ATR、Swing、Runaway Down、Hard Gate，以及基本面、估值、Macro與信用／流動性的既有安全規則均保留，除非未來另有正式版本修訂；實際是否阻斷新增或降低風險，仍依工程20 Priority、工程39 `new_buy_order_permission`與各正式Risk Owner裁決，不把不同模組概括成同一套「否決權」。
















### V82通膨模組正式強化｜2026/09/09 10:42（台灣時間）
















1. **PPI正式升級為成本端早期通膨警報器**：不再只列一個PPI數字，固定同時追蹤Headline PPI、Core PPI、月增、年增、方向、速度與是否連續2～3個月重新加速。
2. **PPI分項固定下鑽**：資料可得時至少檢查能源、原物料、運輸／物流、商品與核心服務。
3. **PPI先行時間的正式口徑**：PPI部分成本端分項可能較CPI／PCE更早反映通膨方向，但不存在固定、穩定的領先月數；實際可能同月、領先數週、數月，或未完整傳導。不得機械以固定1～3個月推算CPI／PCE。
4. **固定傳導鏈**：PPI成本端 → CPI消費端傳導 → PCE／Core PCE Fed核心壓力。
5. **PPI連續加速的風控用途**：若Headline PPI／Core PPI連續2～3個月重新加速，尤其能源、運輸／物流、原物料與核心服務同步升溫，需提高未來CPI／PCE再加速、企業毛利受壓、Fed偏鷹、實質利率與名目殖利率上行風險。
6. **部署影響**：上述風險升高時，V82 Macro Safety可降低Base Deployment／Left Overweight速度或提高折價要求。
7. **PPI不是單一Hard Gate**：單一PPI高值不得獨立構成Hard Gate，仍需與CPI／PCE、Breakeven、油價、信用、流動性與基本面交叉確認。
8. **同步修改**：Global Snapshot、T+1 Gap Recheck、Hard Gate重大事件清單與SOXX高利率敏感Macro檢查均正式納入PPI。
















### V82 Fed路徑＋股票綜合決策正式強化｜2026/09/09 12:04（台灣時間）
















1. **Fed路徑固定使用四層來源交叉確認**：
   - 第一層：CME FedWatch／Fed Funds Futures市場定價。
   - 第二層：OIS／SOFR利率市場交叉確認。
   - 第三層：大型機構最新預測，至少優先查核Goldman Sachs、JPMorgan、Bank of America、Citi、Morgan Stanley、UBS。
   - 第四層：Fed官方SEP／點陣圖／官員談話。
2. **Fed路徑固定輸出**：目前政策利率、下一次FOMC最可能升息／維持／降息的月份與預估幅度、本曆年年底利率區間、未來約6個月／12個月／18個月的市場隱含利率／區間、第一次可能政策轉向的月份／區間與幅度，以及FedWatch、OIS／SOFR、Fed官方與大型機構的主要分歧。若各來源不同步，必須明確分開寫，不得混成單一結論。
3. **Fed不是股票／股票ETF的單一買賣開關**：Fed路徑只影響折現率、資金成本、估值與風險偏好，不能單獨決定「買／等／減碼」。
4. **股票／股票ETF最終決策固定綜合以下十組因素**：
   - Fed路徑、2Y／10Y／30Y與實質利率。
   - PPI→CPI→PCE、WTI／Brent與Breakeven Inflation。
   - HY／BBB／A／IG OAS、VIX、MOVE、SOFR／OIS、Repo與整體流動性。
   - GDP、NFP、失業率、薪資、消費、企業獲利與EPS。
   - 估值：Forward PE、CAPE／ERP及標的適用估值指標。
   - 標的與產業基本面：財測、CAPEX、需求、政策、關稅、地緣政治與重大新聞。
   - V82價格地圖、Confirmed Swing High／Low與ATR。
   - 技術固定順序：高TD9→低TD9→KD→MACD→MA→EMV→RSI→成交量／量價，並檢查日線＋週線＋月線。
   - 成交量、資金流、Market Breadth與相對強弱。
   - 客戶專案中的資金期限、既有部位、目標配置與可用資金。
5. **最後一定要落地成操作**：逐檔直接給「買／等／減半／正常買／加大／暫停／反彈減碼」，並在資料足夠時列可執行價位、投入比例、金額、約略股數、掛單與取消條件。
6. **長期持有的左側原則維持**：若基本面、信用與流動性健康，正常回檔即使Fed偏鷹，仍可依V82價格折價與左側成熟度分批部署；若信用／流動性或基本面出現結構性惡化，即使Fed轉鴿或市場預期降息，也不得機械買進。
















### V82母規則／客戶專案檔分離｜2026/09/05正式定稿
















- **母規則與客戶專案資料正式拆分**：V82只保留可跨客戶、跨專案重複使用的股票／股票ETF判斷演算法、風控、技術、基本面、估值、Macro、信用／流動性、價格地圖與下單規則。
- **任何客戶專屬資料不得寫死在V82**：包含個人基本資料、目標配置比例、實際投入金額、既有庫存、特定平台資金池、某一客戶的0050階梯、NATO／SOXX配置上限、SGOV資金來源、暫時性匯率策略與特定帳戶預約單金額。
- **客戶專屬資料一律放入該客戶唯一的專案檔**，例如 `Joseph專案.md`。每位客戶只維護一份專案檔，不再拆成多個設定檔。
- **專案檔決定「這位客戶是誰、想投入多少、目前持有什麼、最多想配多少、最近有什麼特別要求」；V82決定「今天應如何判斷、是否建議執行、價格在哪、投入強度與風險」。**
- **客戶是資金的主人**：V82的Hard Gate代表顧問正式建議關閉新增Buy Permission，並重新評估／取消尚未成交的一般Buy；Hard Gate本身不等於降低風險或Sell Intent。若底層事實另行滿足Structural Break／Emergency／正式Risk Reduction，才由相應Risk Owner提出降低風險建議。AI不替客戶禁止交易；顧問應清楚且必要時反覆提醒重大風險，但最終投入金額、配置與交易決定由客戶本人決定。
















### 回測文件已正式獨立
















- V82只負責股票／股票ETF的正式分析、判斷、風控與執行母規則。
- 所有可重現回測定義、Look-ahead Bias控制、日／週／月資料時點、參數校準、敏感度分析與母規則績效驗證，一律放入獨立的 `母規則回測.md`。
- 各客戶的個人化回測條件與結果，一律放入 `xxx專案回測.md`，例如 `Joseph專案回測.md`。
- V82不得再內嵌個人回測資金、個人特殊階梯或回測專用參數。
































---
















# 執行總則｜每次分析一定要產出可下單答案
















V82不是只做方向判斷。每次分析最後必須完整回答：
















1. **標的是哪一種股性？**
2. **今日六類特殊分類是哪一類？若皆未成立，明確輸出「無特殊分類」。**
3. **目前是Base Deployment、Left Overweight、Right Confirmation、Trend Deployment，還是暫停／減碼？**
4. **目前價格落在價格地圖哪一區？**
5. **第一、第二、甜甜價、深度與極端折價區各是多少？**
6. **客戶專案目標部位是多少？**
7. **目前實際部位是多少？**
8. **Actual Completion Rate（實際目標部位完成率）是多少？**
9. **本次Canonical Deployment Target Rate應提高到哪一個九階梯累積目標？**
10. **若客戶專案檔已有預算／部位上限，要換算成實際金額與約略股數。**
11. **是否可以預掛限價單／分層GTC單？**
12. **哪些條件一出現就取消掛單／停止加碼？**
13. **下一次什麼價位或什麼訊號要重新跑V82？**
















若上述核心項目沒有回答完整，該次V82分析視為**尚未完成**。
















新增正式觀念：
















> **客戶專案檔決定終點；V82決定現在往終點走多快。**
















> **不追高，不等於永久缺席強勢趨勢。**
















## 六類特殊分類的實際執行優先順序
















當訊號互相衝突時，採下列優先順序：
















**真正降低風險  
→ Runaway Down  
→ 技術減碼  
→ Runaway Up  
→ 右側加碼  
→ 左側買點**
















原因：
















- 生存風險優先於買點。
- 明確向下失速優先於「便宜」。
- 真正強勢趨勢優先於單一過熱指標。
- 若六類特殊分類均沒有足夠證據成立，不建立額外State；輸出「無特殊分類」，資金動作仍由九階梯、部署缺口與安全條件決定。
















---
















# 標的分類總則｜V82 Asset Type／Asset Grade Canonical Contract
















每一檔股票或股票ETF，第一步必須先完成**Asset Identification**。正式分類至少分成五個不同維度，禁止再用一個欄位同時表示多種意思：
















1. `Asset Type`：標的本身是什麼結構。
2. `Asset Grade`：結構性風險／部署等級。
3. `Portfolio Role`：客戶組合內的CORE／SATELLITE角色；由客戶專案／配置層提供。
4. `Primary Valuation Class`：估值Routing；只決定估值尺，不等於Asset Type／Grade。
5. `Secondary Style Tags`：可多選的風格／風險標籤，例如`HIGH_BETA / GROWTH / AI / SEMICONDUCTOR / CONCENTRATED`。
















> **同一標的只能有一個Primary Asset Type與一個Asset Grade；Secondary Style Tags可以多個。**
















## 1. Canonical Asset Type Dictionary
















| Canonical Asset Type | 正式定義 | Required Evidence | 明確排除 |
|---|---|---|---|
| `INDIVIDUAL_STOCK` | 單一上市公司之普通股／股票權益 | 交易所／公司官方資料、券商Instrument Type、監管或公司文件 | ETF、基金、信託型ETF、其他集合投資工具 |
| `BROAD_ETF` | 跨多產業、以廣泛市場／大型核心市場曝險為主要投資目的的股票ETF | 發行人官方Factsheet、Prospectus、Index Methodology | 單一Sector／Industry／Theme；以高波動放大為主要產品設計者 |
| `SECTOR_ETF` | 主要投資目標集中於一個Sector，但不窄到單一Industry／Sub-industry | 官方投資目標／Index Methodology | Broad Market、單一Industry、跨Sector Theme |
| `INDUSTRY_ETF` | 主要投資目標集中於一個Industry／Sub-industry | 官方投資目標／Index Methodology | Broad Market、較寬Sector、跨Sector Theme |
| `THEME_ETF` | 依AI、國防、Cyber、機器人、清潔能源等跨產業主題選股；Theme是主要Index／選股方法 | 官方投資目標／Index Methodology／成分選擇規則 | 純Broad Market、純Sector／Industry且無主題選股主軸 |
| `HIGH_VOLATILITY_ETF` | 產品設計本身即以明顯放大波動、槓桿／反向、事件型或其他經正式文件證明之高波動結構為主要特性；僅最近Beta偏高或跌得多不足以成立 | 官方Prospectus／Factsheet／Index或產品結構文件 | 一般未槓桿Sector／Industry／Theme ETF僅因市場Beta偏高而被誤分類 |
| `OTHER_APPROVED_EQUITY_VEHICLE` | 已經由正式Authorized Universe核准、但不屬上述型別的股票曝險工具 | 客戶／系統Authorized Universe＋產品官方結構證據 | UNKNOWN／查不到資料；不得把Other當垃圾桶 |
















### 1.1 Primary Asset Type決策順序
















正式判斷先確認Instrument Structure，再看官方Investment Objective／Index Methodology。不得只看名稱、Ticker、近期價格波動或媒體標籤。
















固定裁決：
















1. 單一公司股票 → `INDIVIDUAL_STOCK`。
2. ETF若產品設計本身屬明顯放大波動／槓桿／反向／事件型高波動結構 → `HIGH_VOLATILITY_ETF`。
3. 否則ETF依官方主要Investment Objective判斷：Industry → `INDUSTRY_ETF`；Sector → `SECTOR_ETF`；跨Sector Theme → `THEME_ETF`；廣泛市場／大型核心 → `BROAD_ETF`。
4. 已正式核准但確實不屬以上型別 → `OTHER_APPROVED_EQUITY_VEHICLE`。
5. 證據不足 → `UNKNOWN`；不得因名稱猜測、不得自動塞入Other。
















例如一般未槓桿半導體ETF即使具有高Beta，Primary Type仍可為`INDUSTRY_ETF`，另加`HIGH_BETA` Secondary Style Tag；不得因市場波動大同時建立第二個Primary Type。
















> **Asset Type只回答產品結構，不等於Eligibility。** 被分類為`HIGH_VOLATILITY_ETF`、`THEME_ETF`或任何其他Type，都不代表自動進入Authorized Universe；是否可投資仍由既有Eligibility／客戶授權規則獨立決定。
















### 1.2 原「主框架／副框架」保留為Analysis Routing，不再充當Asset Type
















- 一檔標的可有**一個主框架＋必要時一個副框架**；若專屬框架已足以完成分析，不得為了格式硬塞副框架。
- **SOXX主框架固定為SOXX專屬半導體框架；不強制設副框架。QQQ、SOX、SMH、TSM ADR／台積電屬交叉驗證層，不是SOXX副框架。**
- 代理框架只借「股性、風險因子、分析骨架」。
- **絕不複製代理標的的實際買點價格。**
- ETF指數規則、公司商業模式或收入來源明顯改變時，必須重新做Asset Type Classification。
















## 2. Canonical Asset Grade Dictionary
















`Asset Grade`固定只有`A / B / C / D`。它是**結構性風險／部署等級**，不是品質評分、信用評等、Special Classification，也不是公司Structural Break的`company_risk_grade = NONE/R1/R2/R3`。
















| Asset Grade | Canonical意義 | 典型結構 | Deployment／風控含義 |
|---|---|---|---|
| `A` | 最核心、最分散的股票曝險 | Broad Core ETF | 相對較快的正常部署；仍受Hard Gate、專案上限、估值、Look-through與Macro限制 |
| `B` | 中度集中但仍屬核心，或大型成熟／高品質個股 | 集中型Broad ETF；大型成熟／高品質Individual Stock | 部署較A保守；提高集中度、估值與Look-through要求 |
| `C` | 產業／Sector／Theme曝險，或一般正式核准個股 | Sector／Industry／Theme ETF；一般Individual Stock | 衛星／產業級部署；較嚴格集中度、估值、資料與Position Limit檢查 |
| `D` | 高波動／事件型／高公司特有風險 | High-Volatility ETF；高Beta／事件型Individual Stock | 最保守部署；最嚴格資料、估值、集中度、Position Limit與事件／Thesis確認 |
















### 2.1 Asset Grade deterministic mapping
















1. `BROAD_ETF`：廣泛分散核心市場結構 → `A`；若正式結構顯示中度集中／成長或大型權值集中，但仍屬Broad核心曝險 → `B`。
2. `SECTOR_ETF / INDUSTRY_ETF / THEME_ETF` → `C`。
3. `HIGH_VOLATILITY_ETF` → `D`。
4. `INDIVIDUAL_STOCK`：大型成熟／高品質、公司特有風險相對較低且正式證據成立 → `B`；一般正式核准個股 → `C`；高Beta／事件型／高公司特有風險 → `D`。
5. `OTHER_APPROVED_EQUITY_VEHICLE`：必須依正式產品結構與上述最接近之風險層級，留下Grade Evidence後才可指定A/B/C/D；不可預設C或D。
6. 若Grade Evidence不足 → `Asset Grade = UNKNOWN`。
















### 2.2 Grade只可影響施工圖21指定的六個項目
















Grade只可調整：
















- `Deployment Speed`
- `Concentration Limit`
- `Valuation Requirement`
- `Look-through Requirement`
- `Position Limit`
- `Data Requirement`
















Grade不得：
















- 修改九階`10% / 20% / 30% / 45% / 60% / 75% / 85% / 95% / 100%`；
- 建立新的Deployment Stage；
- 改寫五層Price Map；
- 改寫Hard Gate、Emergency、Special Classification或20號Priority Matrix；
- 直接推導Structural Break；
- 建立新的固定持倉百分比。實際Position Limit仍以客戶專案核准目標／上限、V70上游額度與V82既有風控為準；若沒有正式數字，不得由Grade自行發明。
















## 3. Type × Grade Matrix
















`VALID`＝正式合法；`CONDITIONAL`＝必須有明確Grade Evidence；`INVALID`＝不得進入下游正式決策。
















| Asset Type | A | B | C | D |
|---|:---:|:---:|:---:|:---:|
| `INDIVIDUAL_STOCK` | INVALID | VALID | VALID | VALID |
| `BROAD_ETF` | VALID | VALID | INVALID | INVALID |
| `SECTOR_ETF` | INVALID | INVALID | VALID | INVALID |
| `INDUSTRY_ETF` | INVALID | INVALID | VALID | INVALID |
| `THEME_ETF` | INVALID | INVALID | VALID | INVALID |
| `HIGH_VOLATILITY_ETF` | INVALID | INVALID | INVALID | VALID |
| `OTHER_APPROVED_EQUITY_VEHICLE` | CONDITIONAL | CONDITIONAL | CONDITIONAL | CONDITIONAL |
















非法組合不得靠Secondary Style Tag修補。例如`BROAD_ETF + D`若真實產品其實是高波動結構，應重新判斷Primary Asset Type，而不是硬保留Broad再把Grade改D。
















## 4. Rule Applicability Matrix
















| Rule Module | Individual Stock | Broad ETF | Sector ETF | Industry ETF | Theme ETF | High-Volatility ETF | Other Approved Equity Vehicle |
|---|---|---|---|---|---|---|---|
| Eligibility／Authorized Universe | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED |
| 個股Core Investment Thesis A-series | REQUIRED | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | CONDITIONAL by structure |
| Company Risk Grade `NONE/R1/R2/R3` | REQUIRED | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | CONDITIONAL by structure |
| FC／RRG／B-series Structural Break Reduction | REQUIRED when Structural Break | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | INAPPLICABLE | CONDITIONAL by structure |
| ETF Fundamentals／Index Structure | INAPPLICABLE | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | CONDITIONAL by structure |
| ETF Holdings Look-through | INAPPLICABLE as ETF-holdings module | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | CONDITIONAL by structure |
| Valuation Routing | STOCK PATH | ETF PATH | ETF PATH | ETF PATH | ETF PATH | ETF PATH | EXPLICIT PATH REQUIRED |
| Price Map／Technical／Multi-Timeframe | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED |
| Special Classification | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED |
| Hard Gate／Permission | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED |
| 九階Deployment | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED | REQUIRED |
















> **個股Structural Break模組只適用Individual Stock。廣泛被動股票ETF及其他股票ETF不使用個股Thesis失效計分；ETF依自己的Index／成分／集中度／流動性／追蹤／政策與其他結構安全規則處理。**
















## 5. Asset Classification Status／UNKNOWN／非法組合
















正式欄位：`asset_classification_status = COMPLETE / UNKNOWN / INVALID_COMBINATION`。
















- `COMPLETE`：Primary Asset Type與Asset Grade皆有充分證據，且Type × Grade合法。
- `UNKNOWN`：Type或Grade任一缺乏足夠證據。`UNKNOWN ≠ False ≠ Zero ≠ Neutral`；不得預設A級、不得以Other代替。
- `INVALID_COMBINATION`：Type與Grade各自有值，但不符合Type × Grade Matrix。必須回到產品結構／Grade Evidence重新分類。
















`UNKNOWN`或`INVALID_COMBINATION`不是Hard Gate、Special Classification、Deployment Mode、WAIT或新的市場State；但所有**依賴Type／Grade才能正確運作的模組**不得假裝完成。可獨立確認的高優先安全事件亦不得因分類未完成而被降級或抹除。
















## 6. Downstream Contract
















完成Asset Classification後，至少向下游傳遞：
















```text
Asset
Asset Type
Asset Grade
Asset Classification Status
Portfolio Role
Primary Valuation Class
Secondary Style Tags
Sector / Industry
Type Evidence
Grade Evidence
Applicable Rule Modules
Inapplicable Rule Modules
```
















下游責任：
















- `Eligibility`：確認Authorized Universe與產品結構相容；不得自行重算Type／Grade。
- `Valuation`：依Asset Type＋Primary Valuation Class選估值路徑；Grade只提高／降低要求強度，不改估值指標的經濟意義。
- `Price Map`：使用標的自己的價格、ATR、Swing與波動；不得借其他Type／Grade的實際買點。
- `Deployment`：Grade只調整速度、集中度與Position Limit Policy；Canonical九階不變。
- `Special Classification`：與Type／Grade完全分離。同一檔A級Broad ETF仍可在某一Cycle成立Runaway Down。
- `Hard Gate`：不由Grade自動觸發；Hard Gate一旦獨立成立，所有Grade都必須遵守`new_buy_order_permission = FALSE`。
- `Structural Break`：Individual Stock走A～E／B-series；ETF走自身結構安全規則，不得互相套用。
- `Reduction`：Grade不得創造第二套FC／RRG／Sell Rate／Risk Clock。
- `Report/UI`：只顯示Canonical結果，不得以中文名稱、ETF名稱或價格表現自行重新分類。
















---
















# 部位總則｜V82長期資金部署分層
















V82不再只用「本次買剩餘部位的幾%」理解左側與右側，而是優先看：
















> **Actual Completion Rate = AP ÷ Project Target Position**
















部署的固定方向：
















- **Base Deployment／合理價**：建立基本市場參與。
- **Left Overweight／甜甜價**：累積部署應高於Base。
- **深度折價且安全**：累積部署應高於甜甜價。
- **極端折價且安全**：可進入最高左側部署區，但仍先排除Runaway Down、Hard Gate與投資論點破壞。
- **Right Confirmation**：用更高確認度加速補足前面尚未完成的部位。
- **Trend Deployment**：若市場直接強勢上行而專案仍低配，逐步向專案目標靠近。
- **已接近或達到專案目標**：續抱為主，不因強勢機械超配。
















## 不同Asset Grade的部署強弱
















> **Asset Grade只管理施工圖21允許的六類強弱：Deployment Speed、Concentration Limit、Valuation Requirement、Look-through Requirement、Position Limit、Data Requirement。它不改九階梯、不取代Asset Type、Portfolio Role或Special Classification。**
















### A級｜最核心、最分散
















原則：
















- Base可相對較積極建立基本參與。
- 甜甜價與深度折價時可較快提高Canonical Deployment Target Rate。
- 極端折價若安全層仍正常，可接近客戶專案核准目標部位。
- Right／Trend用來補足尚未完成的核心配置。
- 仍必須服從Hard Gate、V70上游額度、專案上限與Look-through。
















### B級｜中度集中核心／大型成熟個股
















原則：
















- Base仍可參與，但相較A級保留更多風險預算。
- 甜甜價與深度折價時提高部署。
- Right／Trend可逐步接近專案目標。
- Concentration／Look-through／Valuation Requirement高於A級。
- 若是Individual Stock，仍完整使用個股Thesis／公司風險模組。
















### C級｜Sector／Industry／Theme／一般個股
















原則：
















- Base參與與Deployment Speed低於A／B。
- 甜甜價與深度折價時可以提高部署，但受產業集中、Look-through、Data Requirement與專案上限更嚴格約束。
- Right／Trend不得因強勢突破Project Target Position或正式Position Limit。
- C級不代表ETF分析框架，也不代表「品質差」；Type仍獨立決定分析模組。
















### D級｜高波動／事件型
















原則：
















- Base最保守，Data Requirement、Valuation Requirement、Concentration與Position Limit檢查最嚴格。
- 只有價格顯著有吸引力、基本面／產品結構仍成立且安全層正常時，才提高左側Deployment Speed。
- 極端折價不得只因跌深重押；Individual Stock必須重新確認Core Investment Thesis，高波動ETF必須重新確認產品／Index結構與曝險。
- Right／Trend仍受專案上限與全部既有Hard Gate／安全規則約束。
















## V82正式Canonical Deployment Target Rate｜九階梯累積目標比例
















以下比例直接屬於 **V82.md 正式母規則**，Canonical Name為`Canonical Deployment Target Rate`，定義「相對於Project Target Position的當下九階梯累積目標比例」，不是Actual Completion Rate，也不是單日一次下單比例。V82採**細階梯左側部署＋保留右側確認與趨勢補足資金**。
















| 價格／Deployment Stage | Canonical Deployment Target Rate |
|---|---:|
| **一般可買／Base Deployment** | **10%** |
| **第一左側** | **20%** |
| **第二左側** | **30%** |
| **甜甜價** | **45%** |
| **左側成熟／更甜** | **60%** |
| **深跌但安全** | **75%** |
| **很深折價但仍安全** | **85%** |
| **右側確認／Right Confirmation** | **95%** |
| **趨勢重新轉強／Trend Deployment** | **100%** |
















固定解讀：
















- **一般可買10%**：長期標的通過安全層，先建立小型基本市場參與。
- **第一左側20% → 第二左側30%**：正常回檔逐層承接，不為等完美低點而完全缺席。
- **甜甜價45% → 左側成熟60%**：價格與估值吸引力提高，且安全層仍正常時，左側成為主要部署區。
- **深跌但安全75% → 很深折價但仍安全85%**：保留部分資金防止左側過早打光；只有確認屬價格修正而非投資論點破壞，才提高至75%／85%。
- **右側確認95%**：跌勢停止並出現足夠右側確認後，補足前面尚未完成的部位；若先前已達85%，原則上只再補至95%，不是重新另加95%。
- **趨勢重新轉強100%**：投資論點、安全層與趨勢條件仍成立，且客戶專案仍低配時，完成至正式目標部位100%。
















### 九階梯 × 實際部位｜唯一正常部署邏輯
















V82正常買進只使用這一套邏輯，不再另建第二套Base比例，也不建立`WAIT` State／分類／Deployment Mode：
















1. 先由價格地圖、估值、基本面、技術、Macro與安全條件判斷目前應位於九階梯哪一階。
2. `Canonical Deployment Target Amount = Project Target Position × Canonical Deployment Target Rate`。
3. `Deployment Gap`先表示`Canonical Deployment Target Amount − AP`的概念差額；Active Buy／Sell Exposure、Reserved Cash與精確Execution數學由V82系統工程36～38正式封口。
4. 部署缺口 > 0：仍有正常部署空間；技術面決定今天先補多少、後續補多快，不要求單日一次補滿。
5. 部署缺口 ≤ 0：本輪不新增，直到更高階梯正式觸發；這只是執行結果，不建立任何WAIT State／分類／Mode。
6. 實際部位高於目前階梯，不因階梯比較結果機械賣出；減碼另依技術減碼／真正降低風險規則。
7. V70.2負責上游股票戰術總額度與總體系統熔斷；其最高防守可將股票新增額度設為0%。V82只在上游允許的股票額度內決定逐檔股票／股票ETF的部署。V82仍保留個別標的Runaway Down、基本面／投資論點破壞、Look-through／專案上限等標的層安全檢查。
















> **九階梯決定現在合理持有多少；實際持倉決定還差多少；技術決定今天補多快；上游V70.2與V82標的層安全規則決定本輪能不能執行。**
















### 適用與限制
















1. 上述10%／20%／30%／45%／60%／75%／85%／95%／100%為V82的正式`Canonical Deployment Target Rate`。
2. 所有百分比都是九階梯的累積目標比例，不是Actual Completion Rate，也不是每一層再額外買該百分比；例如Actual Completion Rate為60%，進入75% Target Rate時，未考慮Active Order Exposure前的概念性缺口約為15個百分點。
3. 客戶專案檔負責決定「該標的最終目標部位是多少」，V82負責決定「目前應完成到目標部位的幾成」。
4. 專案若明確設有更低的單一標的上限、產業集中上限或特殊風控上限，仍不得突破專案上限。
5. 技術面調整**到達該累積目標的速度與單筆大小**；價格越甜且安全，左側可逐步加速，但不應在右側確認前機械把所有資金用完。
6. Hard Gate、Runaway Down與更高Priority Risk可阻斷正常新增；信用／流動性或基本面／投資論點若進一步滿足既有風險規則，才由相應Risk Owner處理Reduction／Emergency。
7. `母規則回測.md`只負責驗證這組正式比例是否有效，不得自行改寫、最佳化或替換。若未來要改比例，必須先正式升版 `V82.md`，再重新完整回測。
















## 單次下單與累積部署的差別
















提高Canonical Deployment Target Rate，不代表單日一次買滿。
















可透過：
















- 分層限價單
- GTC
- 當日多層單
- 多個交易日
- Base → Left → Right → Trend的連續部署
















逐步完成。
















## 客戶專案規則介面
















若特定專案已有：
















- 目標配置
- 梯形比例
- 單筆上限
- 總預算
- 心理承受上限
- 特殊資金來源
- 暫時性策略
















則以**客戶專案檔的實際目標與上限作為資金邊界**。
















V82負責：
















> **判斷現在應該往專案目標前進多少。**
















任何Hard Gate應被清楚提示並建議暫停新的Buy；若同時滿足Structural Break／Emergency／正式Risk Reduction，降低風險建議另由相應Risk Owner產生。最終交易決定仍屬客戶本人。
















---
















# 第0章｜適用範圍與核心目的
















V82適用於所有股票與股票ETF，包括：
















- 美國股票
- 台灣股票
- 全球股票ETF
- 大型股ETF
- 科技／AI／半導體ETF
- 製藥／醫療ETF
- 國防／航太／軍工ETF
- 中小型股ETF
- 產業ETF
- 高股息股票ETF
- 主題ETF
- 其他具有股票風險性質的市場標的
















V82不是短線抓轉折，也不是要求每筆都買在最低點。
















V82的核心目標是：
















> **讓長期資金大部分時間合理參與市場，在真正甜甜價時提高部署，在風險失控時減速或暫停，在強勢趨勢中若仍低配則逐步跟上。**
















V82每次必須回答：
















1. 這項資產是否仍適合作為客戶的長期持有標的？
2. 現在價格屬合理、甜甜價、深度折價、極端折價，還是過熱？
3. 現在應Base Deployment、Left Overweight、Right Confirmation、Trend Deployment，還是暫停？
4. 目前Actual Completion Rate是多少？
5. 本次應買多少、什麼價、幾股、是否掛單，以及什麼情況取消？
















# 第一章｜V82六類特殊分類
















每一檔股票與股票ETF分析完成後，先判斷下列六類特殊分類是否成立；資金部署另外用Base／Left／Right／Trend四段表示。若六類均未成立，輸出「無特殊分類」，不得為了湊分類另建WAIT／一般等待。
















## 1. 左側買點
















**正式型別：Special Classification。** `左側買點`不等於`Left Overweight`；後者是Deployment Mode。
















價格已進入具有合理安全邊際的折價區。
















V82正式改為：
















> **價格到位＋基本面仍值得長期持有＋Hard Gate未觸發，即可開始左側部署。**
















不再要求低TD9、KD、MACD等必須先湊滿2～3項，才准許第一筆買進。
















技術指標的角色改為：
















> **決定今天買多少、後續加多快。**
















價格越甜、估值越合理、週線／月線長期結構越健康，左側部署意願越高。
















左側仍不是「跌很多就買」；若Runaway Down、信用／流動性危機、投資論點破壞，仍暫停。
















---
















## 2. 右側加碼
















**正式型別：Special Classification。** 個別止跌／轉強條件是Right-side Confirmation Signals；`Right Confirmation`是Deployment Mode，三者不得共用同一欄位。
















右側不再是所有長期資金的第一張入場許可證。
















它的功能是：
















> **前面已經Base／Left買進，現在市場開始證明跌勢結束，因此可以再提高部署速度。**
















常見訊號：
















- 前低墊高
- KD黃金交叉
- MACD改善
- EMV轉正
- RSI回升
- 站回MA20
- 突破下降趨勢
- 突破後回踩成功
- 反彈放量
















核心：
















> 用較高的價格，換取較高的確認度，但不是等到此時才第一次參與。
















---
















## 3. Runaway Up
















**正式型別：Special Classification。** `Trend Deployment`是Runaway Up情境下可能啟用的Deployment Mode，不是Runaway Up的同義詞。
















Runaway Up代表市場處於明確強勢趨勢。
















V82不再只寫：
















> **【歷史舊敘事｜已失效｜禁止執行】** 已持有續抱；未持有永遠等回檔。
















Runaway Up成立後，必須先計算：
















> **Actual Completion Rate = AP ÷ Project Target Position**
















### 已接近或達到專案目標
















續抱為主，不因強勢機械超配。
















### 已持有但明顯低配
















在Hard Gate未觸發、基本面未重大惡化、信用／流動性安全時：
















> **啟動Trend Deployment，逐步提高股票曝險。**
















### 完全未持有
















仍不追單日極端大陽線，但不得因等待完美回檔而永久缺席。
















可在：
















- 合理整理
- MA5／MA10回踩
- 突破區回踩
- 窄幅整理
- Gap Recheck完成
- 強勢趨勢持續確認
















後分段建立部位。
















核心：
















> **不追高 ≠ 不參與強勢趨勢。**
















---
















## 4. Runaway Down
















必須有明確失速向下。
















價格結構破壞＋空方動能加速時，停止一般左側加速部署。
















即使價格很便宜，也必須先判斷：
















- 是正常修正的甜甜價
- 還是結構性失速
















---
















## 5. 技術減碼
















技術過熱與轉弱多項共振時：
















- 停止加速部署
- 高Beta／衛星可分批減碼
- 核心長期部位不因單一高TD9或RSI高就全部賣出
















---
















## 6. 真正降低風險
















只有投資論點、信用、流動性、重大政策、公司治理或中長期結構真正破壞時，才進入最高風險處理。
















可採：
















- 停止加碼
- 取消掛單
- 降低衛星／高Beta
- 分批降低股票曝險
- 個別Core Investment Thesis失效不代表自動全部退出。個別股票必須先依A系列將FAILED Thesis轉換為Risk Grade與Fundamental Cap：R1降至OTP 50%、R2降至25%、R3降至0%，再依B系列完成Structural Break Reduction。只有符合4-7D Event-specific Confirmation並正式進入CONFIRMED Emergency時，才改由Emergency Exit接管Execution。廣泛被動股票ETF不使用個股Thesis計分，仍依其自身結構安全規則處理。
















# 第二章｜V82核心六層
















## 1. 長期配置層
回答：**這項資產是否已被客戶專案選為長期持有標的？目標部位是多少？**
















V82不自行決定客戶的人生配置；客戶專案檔決定目標。**Cheap ≠ Good Asset。估值便宜不能取代長期投資資格與基本面審查。**
















## 2. Macro／信用／流動性
回答：**現在的市場環境是否適合承擔股票風險？是否已觸發Hard Gate？**
















Macro Safety先於估值與部署。即使估值非常便宜，只要Hard Gate已成立，Cheap／Deep Discount不得覆蓋Hard Gate。
















## 3. Valuation Engine｜估值層
回答：**這項資產現在貴不貴？相對自己的歷史位於哪裡？估值應加快還是放慢部署？**
















估值是部署比例調節器，不是單獨選股器，也不是單獨買賣開關。完整規則見第三十二章。
















## 4. 基本面
回答：**這項資產的長期投資論點是否仍健康、是否仍值得長期持有？**
















## 5. 價格地圖
回答：**現在價格位於合理價、甜甜價、深度折價、極端折價，還是過熱？**
















主要看近期高點與回撤、前低、ATR、MA、成交密集區、缺口、估值與基本面。
















## 6. 技術面
回答：**今天先投入多少、後續應加快還是放慢？**
















固定順序：**高TD9 → 低TD9 → KD → MACD → MA → EMV → RSI → 成交量／量價**。技術不再是所有第一筆長期買進的必要門票。
















核心分工：
> **專案決定是否列入長期投資池與目標部位。**  
> **Macro決定市場環境是否安全。**  
> **Valuation決定目前估值貴不貴並調節部署速度。**  
> **Fundamentals決定長期投資論點是否健康。**  
> **Price Map決定目前折價深度。**  
> **Technical決定今天先部署多少、後面加多快。**  
> **Hard Gate固定控制新增Buy Permission；Runaway Down與更高Priority Risk仍可依20號Priority／Work2 Permission Contract搶占正常新增，CONFIRMED Emergency則具有最高Execution Intent。**
















# 第三章｜價格地圖
















每一檔標的必須使用自己的資料重新計算。
















固定納入：
















1. 近期高點
2. 高點回撤
3. 前低
4. 前前低
5. 前前前低
6. ATR
7. MA20
8. MA50
9. MA60
10. MA200
11. 成交密集區
12. 跳空缺口
13. 歷史支撐／壓力
14. 估值
15. 基本面
16. 產業週期
















不得直接複製其他標的價格。
















---
















# 第四章｜價格地圖五層
















## 第一區｜高位／不追區
















常見：
















- 距近期高點0～3%
- 高TD9偏高
- KD高檔
- RSI高檔
- 估值偏高
- 價格遠離MA20
















通常：
















- 若六類特殊分類皆未成立，維持「無特殊分類」；若目前九階梯部署目標已完成，本輪不新增；若仍有部署缺口，依既有Deployment Mode與安全條件處理
或
- Runaway Up
















## 第二區｜淺回檔觀察區
















常見回撤：
















**約-3%～-6%**
















通常仍是正常修正。
















若：
















- 估值仍高
- KD未止跌
- MACD仍惡化
















則：
















**暫不啟動左側承接；若仍有Base Deployment缺口，依九階梯與既有安全條件另行處理。**
















## 第三區｜第一左側評估區
















常見回撤：
















**約-5%～-10%**
















但不是固定公式。
















若同時接近：
















- 前低
- MA20／MA50
- 成交密集區
- 1～2 ATR支撐
















開始啟動左側判斷。
















## 第四區｜第二左側區
















常見：
















**約-10%～-15%**
















若：
















- 基本面未惡化
- 信用未惡化
- 流動性未惡化
















可提高承接比例。
















## 第五區｜深度／極端折價區
















常見：
















**約-15%～-25%以上**
















必須先區分：
















### A. 估值修正
















可以提高承接。
















### B. 基本面惡化
















不能因跌很多而自動買。
































### 價格區間重疊判定｜百分比只作初篩
















上述回撤百分比是**初步篩選區間，不是互斥硬門檻**。若第二區與第三區等區間發生重疊，最終價格區分類依下列因素綜合決定，不得只看單一回撤百分比：
















**Confirmed Swing Low／High → 重要MA與成交密集區 → ATR與波動 → 估值 → 基本面 → 產業週期。**
















因此，同樣例如約-5%～-6%的回撤，可以因尚無重要支撐、估值仍高而維持「淺回檔觀察區」；也可以因接近Confirmed Swing Low、重要均線／成交密集區且估值合理，而升級為「第一左側評估區」。
















> **價格百分比只負責提示要重新評估；價格結構、ATR、估值與基本面共同決定真正屬於哪一區。**
















---
















# 第五章｜價格地圖是部署加速器，不是機械成交價
















第一左側、甜甜價、深度折價與極端折價區，代表：
















> **資金部署應提高的價格區。**
















價格到位後，不再因為KD／MACD尚未完全轉強就機械歸零。
















正確流程：
















1. 先確認標的仍適合長期持有。
2. 檢查Hard Gate、Runaway Down、信用／流動性與重大基本面破壞。
3. 若安全層通過，價格越深，累積部署目標原則上越高。
4. 再用技術面決定今天先完成多少、是否分單、是否等待下一層。
















價格到位後固定檢查：
















**高TD9  
→ 低TD9  
→ KD  
→ MACD  
→ MA  
→ EMV  
→ RSI  
→ 成交量／量價  
→ 日線／週線／月線  
→ Macro  
→ 信用／流動性  
→ 基本面  
→ 估值  
→ 最新重大新聞。**
















若出現：
















- Runaway Down
- 信用快速惡化
- 流動性異常
- EPS／財測重大下修
- 投資論點失效
- 重大事件Gap風險不可控
















即使很便宜：
















**仍應暫停或縮小部署。**
















核心：
















> **便宜＋安全＝買。**  
> **更便宜＋安全＝買更多。**  
> **便宜＋結構性風險＝先停。**
















# 第六章｜ATR與梯形距離
















一般原則：
















- 低波動ETF：約1～1.5 ATR
- 普通股票：約1.5～2 ATR
- 高Beta科技股：約2～3 ATR
- 重大事件型股票：必要時3 ATR以上
















ATR快速放大：
















**梯形自動拉寬。**
















不得沿用原固定距離連續接刀。
















---
































# 執行章A｜V82六類特殊分類硬判定矩陣
















本章是實際執行時的快速判定表。
















## 1. 左側買點
















V82左側採「價格主導、技術調節、安全否決」。
















### 價格層
至少1項：
- 已進入第一左側區或更深價格區
- 接近已確認Swing Low
- 接近MA50／MA60／MA200的重要支撐
- 回撤幅度已符合該股性正常修正範圍
- 估值已回到合理或較便宜區
















### 安全層
必須先排除：
- 信用Level 3
- Runaway Down
- 基本面重大破壞
- 重大尚未落地事件使Gap風險不可控
- 日圓套利風險Level 3或其他系統性去槓桿
















只要「價格層成立＋安全層未否決」，即可開始左側部署。
















### 技術層
下列訊號不再是第一筆買進的必要門票，而是決定投入強度：
- 低TD9成熟
- KD止跌／黃金交叉
- MACD空方柱縮短
- DIF上彎
- EMV改善
- RSI回升
- 價格2～3日不再破低
- 價跌量縮／止跌K
















技術越成熟，可以越快接近該價格區對應的累積部署目標。
















## 2. 右側加碼
















價格已離開最低點，但至少出現3項：
- 前低墊高
- KD黃金交叉
- MACD空方柱縮短或翻正
- DIF向上
- EMV轉正
- RSI站回50附近或持續改善
- 站回MA20
- 放量突破下降趨勢
- 突破近期壓力
- 突破後回踩成功
















且：
- 基本面未惡化
- 信用／流動性安全
- 非Runaway Down
- 估值尚未回到極高區
















## 3. Runaway Up
















必要條件A至少1項：
- 創20日收盤新高
- 突破已確認Swing High
- 明顯Higher High＋Higher Low
















再加B至少3項：
- KD高檔鈍化而非死叉崩落
- MACD多方柱擴張
- MA5 > MA10 > MA20
- EMV正值／改善
- 量價健康
- 高TD9完成後仍創高
- RSI高檔但無明顯背離
- EPS／財測未惡化
















Runaway Up成立後，先計算Actual Completion Rate；若仍低於當下合理Target且其他安全條件允許，再評估Trend Deployment。
















- 已接近專案目標：續抱，不機械超配。
- 明顯低配：在安全條件成立時啟動Trend Deployment。
- 完全未持有：不追單日極端大陽線，但可在合理整理、回踩或趨勢持續確認後分段建立。
- 不得因等待完美回檔而長期完全缺席。
















## 4. Runaway Down
















必要條件A至少1項：
- 持續破前低
- 跌破確認Swing Low
- 明顯跌破重要支撐且無法快速收復
















再加B至少2項：
- MACD空方柱擴張
- KD低檔續弱
- EMV持續惡化
- RSI續跌
- 價跌量增
- ATR快速擴張
- 跌速加快
- 反彈一次比一次弱
















成立後：
**停止一般左側接刀，先等失速停止。**
















## 5. 技術減碼
















通常需至少3項共振：
- 高TD9 8～9
- KD死亡交叉
- MACD多方柱連續縮短
- EMV轉弱
- RSI背離
- 爆量不漲
- 跌破MA10／MA20
- 突破前高失敗
- 估值極高且技術同步轉弱
















Runaway Up仍成立時，不得因高TD9或RSI>70單獨賣出。
















## 6. 真正降低風險
















以下任一類成立，即直接進入最高風險檢查：
- 投資論點被推翻
- EPS／財測結構性大幅下修
- 財務／公司治理危機
- 信用Level 3
- Treasury／Repo／美元流動性危機
- 重大政策永久改變商業模式
- 週線＋月線重大結構破壞且無快速修復
- 日圓Level 3並伴隨跨資產去槓桿
















真正降低風險可採：
- 停止加碼
- 取消掛單
- 降低衛星／高Beta
- 分批減碼
- 個別Core Investment Thesis失效不代表自動全部退出。個別股票必須先依A系列將FAILED Thesis轉換為Risk Grade與Fundamental Cap：R1降至OTP 50%、R2降至25%、R3降至0%，再依B系列完成Structural Break Reduction。只有符合4-7D Event-specific Confirmation並正式進入CONFIRMED Emergency時，才改由Emergency Exit接管Execution。廣泛被動股票ETF不使用個股Thesis計分，仍依其自身結構安全規則處理。
















---
















# 第七章｜左側買進正式條件
















V82左側正式規則：
















> **價格條件決定是否值得開始；安全條件決定是否暫停；技術條件決定買多快。**
















## A. 價格條件
















至少一項：
















- 進入第一左側／甜甜價／更深價格區
- 接近前低或Confirmed Swing Low
- 接近MA50／MA60／MA200重要支撐
- 接近成交密集區
- 回撤達該股性有意義的幅度
- 估值回到合理或便宜區間
















## B. 安全條件
















不得有：
















- HY OAS／信用快速惡化到Hard Gate
- VIX／MOVE與流動性同步失控
- Treasury／Repo／美元流動性異常
- Runaway Down
- EPS／財測重大下修
- 公司／產業基本面重大破壞
- 重大事件Gap風險尚不可控
















若A成立、B未否決：
















**左側買點成立，可以開始部署。**
















## C. 技術成熟度
















以下用來決定部署速度，不再作為第一筆硬門檻：
















- 低TD9
- KD止跌／金叉
- MACD空方柱縮短
- DIF上彎
- EMV改善
- RSI回升
- 價格不再破底
- 價跌量縮
- 長下影／止跌K
















技術越成熟：
















**越接近該價格區應有的Canonical Deployment Target Rate。**
















若技術仍弱：
















**可以分單、先完成該區目標的一部分，而不是完全零買進。**
















---
















# 第八章｜V82四段長期資金部署
















## 1. Base Deployment｜基本部署
















適用：
















- 客戶已將標的列為長期配置
- 目前低於專案目標
- 沒有Hard Gate
- 沒有Runaway Down
- 投資論點未破壞
- 估值不是極端荒謬
















此時即使沒有漂亮左側訊號：
















**也可逐步建立基本參與，不讓長期新資金永久停泊。**
















## 2. Left Overweight｜甜甜價加速
















價格進入甜甜價、深度折價或極端折價時：
















**在安全前提下，價格越低，累積部署目標越高。**
















週線／月線若仍屬長期健康，而日線只是正常修正：
















**提高左側部署意願。**
















技術改善越多：
















**加快完成該區應有部位。**
















## 3. Right Confirmation｜右側補強
















前面已經Base／Left部署後，當：
















- 前低墊高
- KD／MACD／EMV／RSI改善
- 站回重要均線
- 反彈放量
- 突破後回踩成功
















可提高部署速度。
















右側是：
















> **確認後加速。**
















不是：
















> **等到這裡才第一次允許買。**
















## 4. Trend Deployment｜強勢趨勢部署
















若市場沒有再給甜甜價，反而進入Runaway Up：
















- 先看Actual Completion Rate
- 低配者應逐步跟上
- 接近目標者續抱
- 已達上限者不因強勢超配
















核心：
















> **跌的時候敢買；止跌時加；漲起來但仍低配，要跟上。**
















# 第九章｜低TD9
















低TD9在V82中是「修正成熟度與部署速度」訊號，不再是左側第一筆買進的硬門檻。
















## 1～4
















修正仍可能在發展。
















若價格尚不夠甜：
















**不加速。**
















若價格已進入甜甜價／深度折價，且安全層正常：
















**仍可以按價格層級開始Base／Left部署，只是先分批，不必等低TD5～6才准買。**
















## 5～6
















修正成熟度提高。
















若價格到位，且KD、MACD、EMV、RSI、量價等開始改善：
















**提高左側部署速度。**
















## 7～8
















成熟度進一步提高。
基本面、信用／流動性安全時：
















**可更積極完成該折價區應有的累積部位。**
















## 9
















下跌序列高度成熟，但不是自動滿倉。
















若同時：
















- KD仍向下
- MACD空方柱擴張
- EMV惡化
- 放量破底
- ATR快速放大
















應優先檢查：
















**Runaway Down。**
















# 第十章｜右側加碼
















`Right Confirmation`是Deployment Mode，不是`右側加碼`這個Special Classification本身；它是V82的第三段正常部署模式，不是所有長期資金的第一張入場券。
















常見右側確認：
















- 前低墊高
- KD黃金交叉
- MACD空方柱縮短／翻正
- MACD金叉
- EMV轉正
- RSI站回50附近
- 重新站上MA20／MA50
- 放量突破下降趨勢
- 突破近期壓力
- 回踩突破區成功
















右側訊號越完整：
















**越可以把前面Base／Left尚未完成的部位補上。**
















若價格已回到極高估值：
















**不機械追滿。**
















若市場進一步進入強勢趨勢：
















**改檢查Runaway Up／Trend Deployment。**
















# 第十一章｜高TD9
















## 1～4
















趨勢初期。
















## 5～7
















趨勢中後段。
















提高追價警戒。
















## 8～9
















變盤警戒。
















但：
















> 高TD9=9不是自動賣點。
















若：
















- 價格持續創高
- KD高檔鈍化
- MACD多方柱擴張
- EMV健康
- 量價正常
















優先檢查：
















**Runaway Up。**
































## 高檔派發／不要搶接盤特別規則
















高TD9完成本身不是賣出訊號；但若同時出現下列多項高檔共振，必須大幅提高「高位派發／獲利了結／籌碼消化」風險權重：
















- 高TD9已完成或位於8～9
- KD位於高檔／超買區並開始轉弱
- MACD位於高位、動能成熟或多方柱明顯收斂
- EMV位於高檔後轉弱
- 高位異常爆量、爆量不漲或價跌量增
- 價格遠離重要均線、估值偏高或極高
















若上述高檔風險形成多項共振，**即使股價第一天、第二天下跌，也不得只因「已經跌了一些」就立即啟動一般左側接盤。**
















此時優先觀察：
















**低TD進度 → KD是否降溫並止穩 → MACD空方動能是否收斂 → EMV是否改善 → 成交量是否由高位爆量轉為量縮 → 價格是否停止破低。**
















只有在高檔籌碼消化開始成熟、價格結構停止惡化，且Hard Gate、信用／流動性與基本面仍安全時，才重新評估Base Deployment／Left Overweight。
















> **高TD9單獨不是賣點；高TD9＋KD／MACD／EMV高檔＋異常爆量共振時，則是「不要急著接第一、第二根下跌」的高檔風險警報。**
















---
















# 第十二章｜Runaway Up正式成立門檻
















Runaway Up也必須有最低成立標準。
















## A. 價格結構必要條件
















至少一項：
















- 創20日收盤新高
- 收盤突破前一個確認Swing High
- 維持明顯Higher High／Higher Low結構
















而且價格不得已明顯跌破MA20。
















## B. 至少3項強勢確認
















- KD高檔鈍化
- MACD多方柱擴張
- MA5 > MA10 > MA20
- EMV維持正值或持續改善
- 量價健康
- 高TD9完成9後仍創高
- RSI高檔但未形成明顯背離
- EPS／財測未惡化
















只有A＋至少3項B：
















才正式列：
















**Runaway Up。**
















---
















# 第十三章｜Runaway Up操作
















Runaway Up在V82中是：
















> **Runaway Up是Special Classification，不是Deployment Mode或獨立State；符合低配與安全條件時，才由Trend Deployment承接資金部署。**
















第一步固定計算：
















**Actual Completion Rate = AP ÷ Project Target Position**
















## 已接近或達到目標
















- 續抱為主
- 不因單日強勢機械超配
- 高TD9本身不是賣點
















## 已持有但明顯低配
















若：
















- Hard Gate未觸發
- 基本面／EPS／財測未重大惡化
- 信用／流動性安全
- 週線／月線沒有重大結構破壞
















則：
















**啟動Trend Deployment。**
















可利用：
















- MA5／MA10合理回踩
- 突破區回踩
- 窄幅整理
- Gap Recheck
- 趨勢持續確認
- 日線強＋週線健康＋月線長期結構健康
















逐步提高到更接近專案目標部位。
















## 完全未持有
















不追單日極端大陽線，但也不得無限等待原先更低的掛單價格。
















若市場持續強勢、投資論點成立、專案仍低配：
















**應在合理整理或趨勢持續確認後分段建立部位。**
















## 新進長期資金
















若新資金進入時市場已Runaway Up：
















- 不要求重新等下一次大跌
- 依Trend Deployment處理
- 先看估值、Actual Completion Rate與多時間框架
- 再決定部署速度
















核心：
















> **不追高，不等於不參與。**
















# 第十四章｜Runaway Up轉技術減碼
















需多項共振。
















例如：
















- 高TD9 8～9
- KD死亡交叉
- MACD多方柱縮短
- EMV轉弱
- RSI背離
- 爆量不漲
- 跌破MA10／MA20
- 突破前高失敗
















通常：
















**至少3項共振**
















才提高減碼可信度。
















---
















# 第十五章｜Runaway Down
















正式成立：
















## A. 價格結構破壞
















至少一項：
















- 持續破前低
- 明顯跌破重要支撐
- 破底後無法快速收復
















## B. 至少2項空方加速
















- MACD空方柱擴張
- KD低檔鈍化向下
- EMV惡化
- RSI續跌
- 價跌量增
- ATR快速擴張
- 跌速加快
- 反彈幅度縮小
















A＋至少2項B：
















**Runaway Down成立。**
















---
















# 第十六章｜Runaway Down vs 正常無新增
















## 正常無新增（非State／非分類／非Mode）
















- 目前V82九階梯累積部署目標已完成
- 尚未觸發更高一階的正式條件
- 本輪自然不新增
- 這只是執行結果，不代表自動減碼，也不得建立WAIT或第二套Base比例
- 若六類特殊分類均未成立，分類欄輸出「無特殊分類」，不得以WAIT補位
















## Runaway Down
















- 價格結構破壞
- 跌速加快
- 空方動能擴張
- ATR擴大
- 量價惡化
















核心：
















> 不是所有下跌都是Runaway Down。  
> 不是所有跌很多都叫深度折價。
















---
















# 第十七章｜Runaway Down轉真正降低風險
















若再出現：
















- EPS下修
- 財測下修
- 營收惡化
- 產業需求反轉
- HY OAS快速擴大
- Treasury／Repo異常
- 公司治理問題
- 資產負債重大惡化
















升級：
















**真正降低風險。**
















---
















# 第十八章｜KD
















固定使用：
















**KD 9,3,3**
















固定檢查：
















- K
- D
- 黃金交叉
- 死亡交叉
- <20
- >80
- 高檔鈍化
- 低檔轉強
- 背離
















KD不得單獨決定買賣。
















---
















# 第十九章｜MACD
















固定參數：
















**12,26,9**
















固定看：
















- DIF
- Signal／DEA
- Histogram
- 零軸
- 金叉
- 死叉
- 背離
















特別重視：
















**空方柱縮短**
















因為常比金叉更早反映空方動能減弱。
















---
















# 第二十章｜MA
















固定看：
















- MA5
- MA10
- MA20
- MA50
- MA60
- MA200
















跨市場：
















**MA50為主要中期均線。**
















台股或既有專案：
















**MA60作輔助。**
















MA50與MA60不能互相替代資料，也不能因方便而混用。
















---
















# 第二十一章｜EMV
















預設：
















**EMV 3,3**
















固定看：
















- 正／負
- 由負轉正
- 正值走高
- 高位轉弱
- 與價格背離
















左側：
















EMV由負往0改善：
















加分。
















右側：
















價格突破＋EMV轉正：
















加分。
















若不同平台公式略有差異：
















優先固定同一平台或自行使用同一公式計算。
















---
















# 第二十二章｜RSI
















固定：
















**RSI(14)**
















## <30
















超賣。
















## 30～50
















持續回升：
















右側改善。
















## >70
















過熱。
















Runaway Up中：
















不得因RSI>70就自動賣。
















---
















# 第二十三章｜成交量／量價
















固定比較：
















- 當日成交量
- 5日平均量
- 20日平均量
- 必要時50日平均量
















## 價漲量增
















正面。
















## 價漲量縮
















突破確認度下降。
















## 價跌量增
















賣壓增加。
















## 價跌量縮
















支撐附近可能代表賣壓衰退。
















## 爆量不漲
















高檔風險提高。
















理想左側到右側演化：
















> 大跌放量 → 後續下跌量縮 → 價格不再破低 → 反彈放量。
















---
















# 第二十四章｜ATR
















固定：
















**ATR(14)**
















用途：
















- 波動
- 梯形間距
- 突破真假
- Runaway強度
- 事件後風險重新定價
















ATR不得單獨決定買點。
















---
















# 第二十五章｜TD9正式算法
















V82固定採：
















**1～9神奇九轉／Setup式口徑。**
















不延伸至10～13。
















## 高TD9
















當日收盤價：
















**高於4個交易日前收盤價**
















且條件連續成立：
















開始由1累計至9。
















條件中斷：
















**重新歸零。**
















## 低TD9
















當日收盤價：
















**低於4個交易日前收盤價**
















且條件連續成立：
















開始由1累計至9。
















條件中斷：
















**重新歸零。**
















只計：
















**1～9。**
















高TD與低TD分開判斷。
















若使用者提供富途神奇九轉截圖：
















優先用富途標記校正。
















若有可靠OHLC：
















可自行計算。
















---
















# 第二十六章｜Swing Low正式定義
















價格地圖的：
















- 前低
- 前前低
- 前前前低
















正式以：
















**確認Swing Low**
















為主。
















## 日線Swing Low
















某一交易日Low：
















低於前2日Low，
















且低於後2日Low，
















才正式確認。
















最新低點如果尚未出現後2根K：
















只能標示：
















**暫定支撐／Provisional Low**
















不得直接算正式前低。
















## 週線Swing Low
















同樣採：
















前2週＋後2週結構確認。
















用途：
















**中期重要支撐。**
















## 月線
















主要判斷：
















**長期結構。**
















月線低點不得單獨作為短線第一買點。
















---
















# 第二十七章｜Swing High正式定義
















與Swing Low對稱。
















## 日線Swing High
















某日High：
















高於前2日High，
















且高於後2日High，
















才正式確認。
















用於：
















- 突破判斷
- Runaway Up
- 壓力區
- 右側加碼
















---
















# 第二十八章｜日線＋週線＋月線
















## 日線
















主要負責：
















**Base／Left／Right／Trend的實際進退節奏。**
















## 週線
















主要負責：
















**判斷日線下跌是正常修正，還是中期趨勢開始破壞。**
















週線仍健康時，日線進入甜甜價可提高左側部署意願。
















## 月線
















主要負責：
















**判斷長期牛熊結構與長期投資論點的價格位置。**
















月線長期健康、週線仍屬正常修正時，不得因日線短期技術尚未完全止跌而把甜甜價部署機械壓到零。
















不得只看單一日線。
















---
















# 第二十九章｜時間框架衝突
















## 日多／週空／月多
















中期弱勢中的短線反彈。
















## 日空／週多／月多
















長期多頭中的短線修正。
















## 日多／週多／月多
















多週期共振。
















右側可信度最高。
















## 日空／週空／月空
















高風險。
















優先：
















- 暫停新增左側買單
- 停止接刀
- 必要時依既有風險規則降低曝險
















---
















# 第三十章｜T+1 Gap Recheck
















適用：
















- 財報
- CPI
- PPI
- PCE
- Fed
- FDA
- M&A
- 關稅
- 戰爭
- 重大訂單
- 政策
















## Gap Up
















檢查：
















- 缺口是否守住
- 成交量是否延續
- 同產業是否同步
- 大盤是否支持
- 是否快速回補
















## Gap Down
















同樣反向檢查。
















重大事件第一天跳空：
















不得立即認定永久趨勢改變。
















若事件為PPI公布，額外固定檢查：
















- 殖利率是否同步快速上升
- DXY是否同步走強
- VIX／MOVE是否同步惡化
- 信用利差是否同步擴大
- 高估值／高Beta資產是否出現廣泛重新定價
















單一PPI數據或第一個跳空，不得直接認定永久趨勢改變。
















---

















## 30.1 T+1 Gap Recheck Canonical State Contract【工程34｜正式｜工程77封版】

本節將既有 Event Day／Gap Event／隔日確認規則工程化為唯一狀態契約；**不新增新的 Hard Gate、全域 WAIT、百分比門檻或 ATR 門檻**。原本 30 章既有事件類型、GapUp／GapDown、PPI 額外交叉確認與「單一跳空不可直接推論永久趨勢」規則全部保留。

### Canonical Fields

正式紀錄至少包含：

- `event_id`
- `asset`
- `event_type`
- `event_day`
- `event_publication_timestamp`
- `gap_event = TRUE | FALSE | UNKNOWN`
- `gap_direction = UP | DOWN | NONE | UNKNOWN`
- `gap_open_price`
- `prior_close`
- `gap_pct`
- `gap_atr_context`
- `recheck_required = TRUE | FALSE | UNKNOWN`
- `t_plus_1_status = PENDING | PASSED | FAILED | UNKNOWN`
- `next_trading_session`
- `recheck_session`
- `gap_hold_or_fill`
- `volume_follow_through`
- `sector_confirmation`
- `broad_market_confirmation`
- `event_specific_confirmation`
- `data_quality`
- `issue_codes[]`
- `reason_codes[]`

### Event Day／Next Trading Session

- `event_day` ＝該事件**第一次被市場正常交易時段價格反映的交易日**。若事件於收盤後公布，原則上以下一個正常交易日作 Event Day，而不是機械使用新聞日曆日期。
- `next_trading_session` ＝ Event Day 之後實際下一個可正常交易的交易時段，不等於曆日 T+1。遇休市、停牌或無有效交易資料時，維持 `PENDING` 或 `UNKNOWN`，不得猜測。

### State Machine

`Material Event → Gap Event? → Recheck Required? → PENDING → Next Trading Session Evidence → PASSED / FAILED / UNKNOWN`

- `PENDING`：已確認需要 T+1 Recheck，但下一正常交易時段尚未完成或必要資料尚未形成。
- `PASSED`：下一交易時段的價格行為與該事件方向具有足夠既有證據支持，且必要確認資料可用。
- `FAILED`：下一交易時段出現明確相反證據，例如快速回補、延續失敗、同產業／大盤不同步等。
- `UNKNOWN`：必要資料不足、交易時段不可比、來源衝突或不能安全判定；不得把 UNKNOWN 當 PASSED。

`t_plus_1_status` 只在 `recheck_required = TRUE` 時具有 Gate 判定意義；若 `recheck_required = FALSE`，不得用該欄阻擋或放行任何 downstream predicate，並在既有 `reason_codes[]` 記錄 `RECHECK_NOT_REQUIRED`。任何明文依賴 `event_gap_confirmed` 的 downstream predicate，在 `t_plus_1_status = PASSED` 前維持 PENDING；`FAILED` 或 `UNKNOWN` 不得解除該依賴。

### Which Gates Must Wait for T+1

只有**本來就依賴該 Event Gap 成立**的下列判斷需要先完成 T+1：

1. 以事件跳空作主要證據的 Right Confirmation。
2. 以事件跳空延續作主要證據的 Runaway Up。
3. 以該跳空宣告永久趨勢／永久結構改善的判斷。
4. 施工後續若有明確引用「事件 Gap 已確認」作為加速部署證據者。

下列情況**不得被 T+1 機械污染**：

- 與事件跳空無關、且 Data Sufficiency PASS、Hard Gate NOT_TRIGGERED、基本面／信用／流動性未惡化的 Base／Left 部署。
- 已由獨立風險證據確認的減碼、Structural Break、Emergency 或其他風險降低動作，不得為等待 T+1 而延遲。
- 若 Safety Required 資料不足，仍依第62章 Data Sufficiency Gate 處理；不得另創一個「T+1 Hard Gate」。

### Event-specific Evidence

PPI 等既有事件仍保留原本殖利率、DXY、VIX／MOVE、信用利差與高 Beta 資產是否同步重估等交叉確認；其他事件亦沿用其正式既有來源。T+1 只把這些證據整理成可追溯狀態，不改寫原策略門檻。

# 第三十一章｜IV Crush
















適用有成熟選擇權市場標的。
















例如：
















- NVDA
- AAPL
- MSFT
- META
- AMD
- TSLA
- 大型ETF
















事件後可查看：
















**Implied Volatility**
















判斷：
















事件風險溢價是否解除。
















若：
















- IV快速下降
- 股價守住缺口
- 成交量健康
- 同產業同步
















則：
















右側可信度提高。
















但：
















> IV Crush只是輔助，不是買點。
















---
















# 第三十二章｜Valuation Engine 股票／股票ETF估值引擎（正式版）
















## 32.0 模組定位
完成 Macro／信用／流動性／重大事件安全檢查後，所有準備進入V82部署判斷的股票與股票ETF必須執行 Valuation Engine。
















正式順序：**Macro Safety → Valuation Engine → Fundamentals → Price Map → Technical → Multi-Timeframe → Hard Gate／Runaway Down → Deployment**。
















若Macro已觸發Hard Gate，估值仍計算與保存，但任何 Cheap／Deep Discount 訊號不得覆蓋Hard Gate。
















> **Valuation是部署比例調節器，不是單獨選股器，也不是單獨買賣開關。**
















## 32.1 Entry Qualification｜進入資格
V82不得因「很便宜」就自動推薦。標的必須已由Mentor／客戶專案選入長期投資池，或正在接受加入長期投資池的正式基本面審查。**Cheap ≠ Good Asset。** 基本面永久惡化的公司即使估值跌至歷史低位，也不得因便宜自動取得部署資格。
















## 32.1A Formal Report Valuation Completion Gate｜正式報告估值完整度閘門
















只要本輪用途包含正式客戶報告 `CR-IMG-015`、`CR-STAGE-002` 或 `CR-STAGE-004`，估值Universe固定為：
















> **目前實際持有的股票／股票ETF ∪ 正式目標／候選股票／股票ETF，去重後全數納入。**
















不得因標的是「既有持倉但不在目標配置」就省略，也不得用上一輪「未重跑／待更新」狀態冒充本輪正式估值。正式報告前逐檔檢查：最新價格、Primary/Secondary Metric、數值、資料日期、來源、方法、估值標籤、Current Action、Key Reason、Data Quality。
















以下任一情況成立，正式估值視為**未完成**：
















- 最新Snapshot不存在；
- Universe缺任何一檔應分析股票／股票ETF；
- 標記「未重跑／待更新」；
- 關鍵資料超過既定新鮮度；
- 缺主要估值值／資料日期／來源／方法／估值結論／動作；
- `Data Quality = Insufficient` 且尚未完成合法Fallback。
















遇到未完成時，必須先重新查核最新可靠公開資料並依本章Waterfall重跑。**正式客戶頁禁止把「未重跑即時估值」「待更新」「N/A所以先略過」當成估值答案。** 若可靠資料確實不足，該輪正式報告必須停在內部待補資料狀態，不能為了出報告捏造值。
















`估值教室/活水書院估值完整教學.md` 是客戶教育／例子參考；本檔仍是股票與股票ETF正式估值、部署與Hard Gate的 Source of Truth。
















## 32.2 Asset Identification｜標的辨識
每次固定保存：`Asset`、`Asset Type`、`Asset Grade`、`Asset Classification Status`、`Portfolio Role`、`Primary Valuation Class`、`Secondary Style Tags`、`Sector / Industry`、`Type Evidence`、`Grade Evidence`、`Applicable Rule Modules`、`Inapplicable Rule Modules`、`Primary Metric`、`Secondary Metric`、`Supplementary Metrics`、`Historical Window`、`Data Date`、`Data Source`、`Methodology`。
















每個標的執行時只能有一個 **Primary Asset Type**、一個 **Asset Grade**與一個 **Primary Valuation Class**；Secondary Style Tags可有多個。`Portfolio Role`由客戶專案／配置層提供，不得由V82根據Type／Grade猜測。分類範例僅供模型辨識，不構成推薦名單。
















主要類別包括：全球股票ETF（VT、VWRA等）、美國大型核心ETF（VOO、SPY等）、科技／AI／高成長ETF（QQQ、VGT等）、台灣大型權值ETF（0050等）、製藥／醫療ETF（PPH、XLV等）、美國中小型ETF（IWM等）、半導體ETF（SOXX、SMH等）、國防／軍工ETF（NATO、ITA等）、產業／主題ETF、大型成熟／高品質個股、高Beta／事件型個股。個股執行時依公司特性指定唯一Primary Class。
















### 32.2A 不同標的必須使用不同估值尺｜基本資料契約
















V82不得把所有股票／ETF都只用P/E比較。每次依標的類型至少抓取下表主要估值尺，並以**最新可得價格＋最新財報／TTM＋最新Forward預估＋官方／高可信ETF基本面資料**重新計算：
















| 標的類型 | 主要估值尺 | 必查Context |
|---|---|---|
| 全球大型核心ETF（VT／VWRA） | 加權Forward P/E、P/B、Earnings Yield | EPS成長、ROE、區域分散、歷史估值分位 |
| 美國大型核心ETF（VOO／SPY） | Forward P/E、P/B、Earnings Yield | ROE、EPS成長、S&P500歷史估值分位 |
| 科技／高成長ETF（QQQ） | Forward P/E、EV/EBITDA／FCF Yield（可靠聚合可得時） | EPS成長、AI CAPEX、大型科技集中度、實質利率 |
| 半導體ETF（SOXX／SMH） | **Trailing P/E＋Forward P/E**，Forward為主 | EPS Revision、半導體週期、AI CAPEX、庫存、毛利率、集中度 |
| 台灣大型權值ETF（0050） | P/E、Forward P/E（可得時）、P/B | ROE、EPS成長、台積電集中度、台灣電子／半導體週期 |
| 製藥／醫療ETF（PPH／XLV） | Forward P/E、P/E、FCF Yield | 盈利穩定性、專利／藥價政策、FDA／Medicare等政策 |
| 國防／軍工ETF（NATO等） | 加權Forward P/E、EV/EBITDA、FCF Yield | 訂單／Backlog、軍費、政策、地緣政治、成分集中度 |
| 獲利型高成長股（NVDA／GOOGL／SE等） | Forward P/E、PEG、EV/EBITDA、FCF／FCF Yield | Revenue／EPS／FCF成長、Margin、EPS Revision、公司特有風險 |
| 金融股（MS／JPM等） | **P/B或P/TBV＋ROE／ROTCE為主**，Forward P/E為輔 | 信用成本、資本比率、NIM、存放款、信用循環 |
















若某一指標對該類標的經濟意義不足、資料不可比或聚合方法不可靠，必須標示 `Unavailable／Not Reliable` 並依Waterfall合法Fallback；不得為了填滿表格捏造數值。
















### 32.2B 資料新鮮度與時間戳
















每次正式估值固定保存三個時間：
















- `analysis_timestamp`：V82真正完成本輪判斷的台灣時間。
- `market_data_as_of`：本輪價格／財報／Forward預估實際截至時間。
- `macro_snapshot_timestamp`：本輪採用的V70／Macro Snapshot時間。
















若市場休市、財報未更新、Forward資料延遲或不同來源時間不一致，必須分開標示；不得把較舊資料偽裝成「今日即時」。使用者提供的較新券商截圖／報價可優先作價格校正，但估值分母與財務資料仍須保留自己的資料日期。
















## 32.3 V82 Operational Valuation Range｜指定Forward P/E操作區間
以下是V82操作性估值區間，不是ETF公司、指數公司或學術研究宣告的絕對公平價值。
















| ETF類型 | Cheap | Normal | Pricey | Expensive | Extreme Candidate |
|---|---:|---:|---:|---:|---:|
| VT／VWRA型 | `<14` | `>=14 且 <18` | `>=18 且 <20` | `>=20 且 <23` | `>=23` |
| VOO／S&P500型 | `<16` | `>=16 且 <20` | `>=20 且 <22` | `>=22 且 <24` | `>=24` |
| QQQ／Nasdaq-100型 | `<18` | `>=18 且 <24` | `>=24 且 <28` | `>=28 且 <33` | `>=33` |
| 0050型 | `<14` | `>=14 且 <19` | `>=19 且 <22` | `>=22 且 <26` | `>=26` |
| PPH／XLV型 | `<14` | `>=14 且 <19` | `>=19 且 <22` | `>=22 且 <26` | `>=26` |
| IWM型 | `<13` | `>=13 且 <18` | `>=18 且 <22` | `>=22 且 <27` | `>=27` |
















所有區間採不重疊半開區間。**本表只適用Forward P/E。** Forward P/E失效而Fallback到P/B、EV/EBITDA、FCF Yield等時，禁止套用本表；Fallback Metric只能使用自己的歷史百分位／歷史中位數，或另有正式定義的專屬Range。
















## 32.4 Valuation Expensiveness Percentile｜統一估值方向
所有估值指標最後統一轉為：**0＝歷史最便宜端；100＝歷史最昂貴端。**
















| Expensiveness Percentile | 判定 |
|---:|---|
| `<20` | CHEAP |
| `>=20 且 <60` | NORMAL |
| `>=60 且 <80` | PRICEY |
| `>=80 且 <95` | EXPENSIVE |
| `>=95` | EXTREME_CANDIDATE |
















對客戶報告，內部五級狀態可再細分成容易理解的六個中文標籤：
















- 0～<20：**便宜**
- 20～<40：**合理偏低**
- 40～<60：**合理**
- 60～<80：**合理偏貴**
- 80～<95：**偏貴**
- >=95：**很貴／極高估值警戒**
















這只是「相對自己歷史」的估值位置；最後仍必須用成長、ROE／Margin、FCF、產業週期、EPS Revision與標的品質修正，不能把百分位當成單獨買賣指令。
















Multiple型（P/E、P/B、P/S、EV/Sales、EV/EBITDA）通常數值越高越貴，Raw Historical Percentile可直接轉為Expensiveness Percentile。
















Yield型（如FCF Yield）方向相反，正式使用：`Expensiveness Percentile = 100 - Raw Yield Historical Percentile`。例如FCF Yield位於歷史第5百分位，Expensiveness＝95，屬Extreme Candidate。禁止把Yield型指標用Multiple型方向判讀。
















## 32.5 Relative-to-Historical-Median
Multiple型使用 `Current Multiple / Historical Median Multiple`：`<0.80x` Cheap；`0.80～<1.10x` Normal；`1.10～<1.25x` Pricey；`1.25～<1.45x` Expensive；`>=1.45x` Extreme Candidate。
















Yield型禁止直接套用上述Ratio；優先使用標準化Expensiveness Percentile。若未來建立Yield型Relative Ratio，必須另定反向公式並經回測驗證。
















## 32.6 Valuation Waterfall｜ETF
- 全球股票ETF：Forward P/E → Trailing P/E → CAPE → P/B → FCF Yield
- 美國大型核心ETF：Forward P/E → CAPE → Trailing P/E → FCF Yield → P/B
- 科技／AI／高成長ETF：Forward P/E → EV/EBITDA → EV/Sales → FCF Yield；PEG僅列Supplementary Metric
- 台灣大型權值ETF：Forward P/E → P/B → FCF Yield
- 製藥／醫療ETF：Forward P/E → EV/EBITDA → FCF Yield
- 美國中小型ETF：Forward P/E ex-negative EPS → Profitable Company Ratio → EV/EBITDA → P/B → FCF Yield；虧損公司比例升高時降低P/E訊號權重。
















ETF的EV/EBITDA、EV/Sales、FCF Yield若沒有可靠且一致的聚合方法，標示`Unavailable`，不得由LLM自行拼湊成分股數值。

















### 32.6A Canonical Valuation Waterfall Resolution Contract【工程28｜正式｜工程77封版】

本節把既有 32.2A、32.6、32.8～32.12 的估值路徑統一成可程式化 Resolver；**既有估值區間、百分位、Extreme 規則及各資產既有 Waterfall 順序均不改動**。

#### Step 1｜Asset Routing

Resolver 先確認：

- `asset_type`
- `valuation_class`
- `applicable_modules[]`
- `primary_candidate_path[]`
- `authorized_fallback_path[]`
- `supplementary_metrics[]`

若 Asset Type／Valuation Class 無法可靠辨識，必須輸出 `UNKNOWN / INSUFFICIENT`，不得默認套用 P/E。

#### Step 2｜Four Canonical Paths

**S｜Individual Stock**

依現有規則與標的經濟特性使用：P/E、Forward P/E、PEG、P/S、EV/EBITDA、FCF Yield、Historical Percentile。不是每一欄都強制適用：

- Semiconductor：沿用 32.8。
- Profitable Growth：沿用 32.10。
- Unprofitable Growth：沿用 32.11。
- Financial：沿用 32.12。
- 其他股票只在經濟意義成立時選用上述正式指標，不得為了湊欄位而硬算。

**B｜Broad ETF**

沿用 32.6 的底層組合型 Waterfall，以官方／高可信、同一方法可比較的 aggregate portfolio valuation 為主；若無可靠聚合方法，不得把不同日期、不同口徑數字拼成單一正式估值。

**SI｜Sector／Industry／Theme ETF**

先依其正式 Sector／Industry Waterfall；若取得可靠 sector-relative／industry-relative valuation，可作相對估值補充。不得用單一最大持股的估值代表整檔 ETF。

**Y｜Yield-oriented Asset**

沿用既有 Yield-based Framework 與 reverse-expensiveness 邏輯，不機械套用股票 P/E 區間。

#### Step 3｜Waterfall Resolver

對 `primary_candidate_path[]` 由上而下逐項檢查：

1. 該方法是否適用。
2. 方法與來源是否可靠。
3. Value／Unit／Data Date／Method 是否有效。
4. Freshness 是否符合既有資料契約。
5. PIT 是否可追溯。

第一個合法成功的 Primary 即成為 `selected_primary_metric`；這只決定Waterfall主解，**不取代32.1A或其他既有Formal Report對多個估值欄位的完整度要求**。若 Primary 不可用但已有正式授權 Fallback 可用，才可使用 Fallback，並標記 `FALLBACK_USED`、原因與來源。全部合法路徑皆不可用時，輸出 `VALUATION_DATA_INSUFFICIENT`，不得以敘事補數字。

`Historical Percentile` 與 `Sector-relative Valuation` 均可作正式補充證據，但需分欄保存，不得平均成一個無來源的神秘分數。

#### 禁止 Generic Median Fallback

若某 Asset Type 的正式 Waterfall 與已授權 Fallback 全部不可用，必須輸出 `VALUATION_DATA_INSUFFICIENT`；**不得退回跨資產、跨產業或無明確 Rule Owner 的 Generic Median 作 Fallback**。既有 32.5 `Relative-to-Historical-Median` 只能用於同一合法估值指標自身的歷史基準，不等於 Generic Median Fallback。

## 32.7 PEG使用規則
PEG只作Growth-Adjusted Supplementary Valuation Metric。若預期EPS成長<=0、成長率接近0、分析師預估劇烈變動、EPS品質不穩或一次性獲利扭曲，`PEG = NOT_RELIABLE`，不得強行計算或據此決定部署。
















## 32.8 Semiconductor｜半導體
SOXX、SMH等及NVDA、AVGO、AMD、MU、QCOM、AMAT、LRCX、KLAC、TSM等主要估值：**Forward P/E → EV/EBITDA → EV/Sales → P/S → FCF Yield**。Trailing P/E不得單獨作核心估值。Context固定加入EPS Revision、AI CAPEX、庫存、晶圓／設備需求、ASP、毛利率、產能利用率與半導體景氣循環。
















## 32.9 Defense｜國防軍工
NATO、ITA、XAR、PPA、SHLD及LMT、RTX、NOC、GD、LHX、BA等主要估值：**Forward P/E → EV/EBITDA → FCF Yield → EV/Sales**。Context加入國防預算、Backlog、營收成長、Margin、政府政策與地緣政治。
















## 32.10 Profitable Growth Stock｜獲利型成長股
一般模型：**Forward P/E → EV/EBITDA → FCF Yield → EV/Sales**；PEG為Supplementary。同步檢查EPS Growth、Revenue Growth、FCF Growth、Margin與EPS Revision。高P/E伴隨高速且可持續獲利成長時，不得機械判定為「太貴不能買」。
















## 32.11 Unprofitable／Unstable Earnings Stock
EPS無經濟意義時禁止硬算P/E。主要使用：**EV/Sales → P/S → FCF Yield（若有意義）**。Cash Runway、Burn Rate、Revenue Growth、Gross Margin、Operating Margin與獲利轉折屬Fundamental Risk Context，不是估值倍數。
















## 32.12 Financial Stocks｜金融股獨立模型
JPM、BAC、WFC、C等禁止機械使用一般工業公司的EV/EBITDA。主要：**P/TBV → P/B → Forward P/E**；Context加入ROTCE／ROE、NIM、Credit Cost、Charge-Off、Deposit Growth、Loan Growth、Capital Ratio與信用循環。
















## 32.13 Historical Window／Rolling Window
優先：**可靠10年 → 可靠5年 → 上市以來／可比較制度期間**。若重大併購、商業模式重大轉型、會計制度重大改變、重組或獲利結構永久改變，舊資料可降低權重或排除。
















依資料頻率設定Window：Daily約252／年、Weekly約52／年、Monthly 12／年、Quarterly 4／年。不得把`rolling(1260)`固定套用所有資料源。有效樣本不足則`VALUATION_HISTORY_INSUFFICIENT`。
















## 32.14 Data QA／Metric Availability／Methodology Consistency
每筆資料檢查：None、NaN、Inf、單位錯誤、日期錯置、Stale Data、Forward／Trailing混用、Corporate Action與不合理值。失效則進下一個合法Fallback；整條Waterfall失效則`VALUATION_DATA_INSUFFICIENT`，禁止猜值。
















同一ETF歷史比較優先維持相同Provider＋相同Methodology。每筆資料保存value、metric、as_of_date、published_at、source、frequency、methodology、valid_until/max_age_days、PIT_status、data_quality、fallback_level。
















## 32.15 Fallback Log｜降級紀錄
只要未使用首選Primary Metric，固定輸出：
- `Fallback Triggered: YES / NO`
- `Fallback Metric Used: None / <Metric Name>`
- `Fallback Reason: None / Missing / Stale / Invalid / Methodology Unavailable`
















後台與回測必須能追溯為何降級，不得只保存最後Valuation Level。
















## 32.16 Secondary Valuation Confirmation
第二指標應盡量提供不同資訊。Forward P/E＋Trailing P/E只能算弱確認；Forward P/E＋EV/EBITDA、Forward P/E＋FCF Yield等可視為較強補充確認。禁止「同一件事情算兩票」。固定輸出`Secondary Confirmation = STRONG / WEAK / UNAVAILABLE`。
















## 32.17 Extreme Valuation Flag｜極端估值警報
正式名稱為**Extreme Valuation Flag**，不再稱Extreme Valuation Gate。它沒有最終否決權。
















### Path A｜具有V82絕對Range
Primary Metric進入Extreme Candidate絕對區間，且至少再符合：Own-History Expensiveness Percentile >=95，或具有補充資訊的第二估值指標亦達Extreme，才判定`Extreme Valuation Flag = ON`。
















### Path B｜沒有固定絕對Range
Primary Metric Expensiveness Percentile >=95，或適用Multiple的Current/Historical Median >=1.45x，並且獨立／補充型第二估值指標確認Extreme，才判定Flag ON。
















Flag ON時：既有長期部位原則續抱，但降低追價、降低Base／Trend Deployment速度、提高新增資金折價要求；尚未持有者降低第一筆投入比例。**Extreme Valuation Flag本身沒有禁止買進權；Hard Gate可令`new_buy_order_permission=FALSE`，Runaway Down與更高Priority Risk亦可依20號Priority／Work2 Permission Contract阻斷正常新增。**
















## 32.18 Valuation Normalization｜估值正常化
昂貴估值可透過兩條路徑正常化：A. Price Correction（價格下降）；B. Earnings Catch-up（價格橫盤／緩漲但EPS／FCF快速成長，使Forward估值下降）。固定監控EPS Revision、Forward EPS、FCF Forecast、Revenue Growth與Margin。不得假設股票一定要跌才能從昂貴變正常。
















## 32.19 ETF估值計算口徑
ETF估值不是成分股P/E簡單算術平均。概念上：`ETF／Index P/E ≈ Aggregate Market Value / Aggregate Earnings`；Forward使用Aggregate Forward Earnings。不同Provider可因負EPS處理、極端值處理、Forward EPS來源、成分股日期、Rebalance與更新時間而不同，故正式輸出必須保存Provider、Methodology與Data Date。
















## 32.20 Forward Fill／Stale Data
不得用固定Row Count跨資料源Forward Fill。每筆資料保存`as_of_date`、`published_at`、`valid_until`或`max_age_days`；只有仍在有效期內才可沿用Last Known Valid Value，超過即`STALE`。
















## 32.21 PIT｜Point-in-Time防止偷看未來
Live保存Source＋Data Date＋Timestamp＋Methodology。Backtest只能使用當時已公開資料。可用時間優先Actual Publication/Filing Date → Vendor As-of/Effective Date → Official Release Date → Reporting Lag Proxy。無法證明當時可取得則`PIT_STATUS = UNVERIFIABLE`，正式回測不得使用。

















### 32.21A PIT／Freshness／Completion Canonical Contract【工程29｜正式｜工程77封版】

本節整合既有 32.2B、32.14、32.20、32.21 與第62章 Data Quality。**不新增一個全市場共用的「幾天就過期」門檻**；Freshness 仍依資料種類、頻率與原本 `valid_until / max_age` 契約判斷。

#### Required Valuation Metadata

每一個正式估值至少保存：

- `metric_name`
- `value`
- `unit`
- `point_in_time_date`
- `data_date / as_of`
- `published_at`
- `source`
- `source_type`
- `method`
- `frequency`
- `valid_until / max_age`
- `freshness = FRESH | STALE | UNKNOWN | NOT_APPLICABLE`
- `pit_status = VERIFIED | UNVERIFIABLE | NOT_APPLICABLE`
- `fallback_used`
- `fallback_reason`
- `secondary_confirmation`
- `extreme_flag`
- `data_quality`
- `issue_codes[]`

`point_in_time_date` 表示該資訊在當時是否已能被市場參與者知道；`data_date` 表示資料描述的實際期間；`published_at` 表示來源正式可取得時間。三者不得混成同一日期。

#### Freshness

- `FRESH`：符合該欄位既有頻率與有效期限。
- `STALE`：超出既有有效期限或已有更新版本但仍使用舊值。
- `UNKNOWN`：來源／時間不足以判定。
- `NOT_APPLICABLE`：該欄位不需要 Freshness 判斷。

不得自行發明統一 Age Threshold；需要的時效由正式來源契約與第62章判定。

#### Formal Completion State

`valuation_completion_state = COMPLETE | INCOMPLETE | UNKNOWN`

`COMPLETE` 僅在以下條件同時成立時成立：

1. 所有 `MODULE_REQUIRED` 欄位都有合法資料或合法 Fallback。
2. Data Quality 為 `OK` 或正式允許的 `FALLBACK_USED`。
3. Asset Routing、Primary Metric、Source、Date、Method、Freshness、PIT 狀態均可追溯。
4. 估值結論可以由相同輸入唯一重現。

`INCOMPLETE`：必要欄位缺漏、失效、過期且無合法 Fallback，或 Waterfall／Method 無法完成。

`UNKNOWN`：連「某欄是否必要」、時間點、來源衝突或適用方法都無法可靠確認。

Optional／NOT_APPLICABLE 欄位缺失不應把整份估值機械打成 INCOMPLETE；但其依賴模組須依第62章 Partial Calculation 規則傳播。

#### Formal Completion Gate

`valuation_formal_output_eligible = TRUE` 至少要求：

- `valuation_completion_state = COMPLETE`
- 第62章 `formal_output_eligible = TRUE`
- 所有該 Asset Type 在32.1A／既有正式規則中列為 `MODULE_REQUIRED` 的估值資料均須滿足；`selected_primary_metric` 只是Waterfall主解，不得取代既有多指標完整度要求
- Conclusion、Data Quality、Issue Codes 與必要 Recheck 可追溯
- 使用 Fallback 時有完整 Fallback Log
- Extreme 判斷若依賴 Secondary Confirmation，不得在 Confirmation 缺失時猜成 ON

`FALLBACK_USED` 可以完成估值；`INSUFFICIENT / UNKNOWN` 不可以用歷史舊值、跨來源平均、LLM 推估或敘事硬補成 COMPLETE。Backtest 必須使用當時已公開資料；`PIT_STATUS=UNVERIFIABLE` 時不得宣稱正式可回測。

## 32.22 Manual Override
即時實盤之外部事件旗標必須有來源、日期且可追溯；歷史回測只能使用當時已公開PIT資訊，禁止hindsight override。不可驗證則NA。
















## 32.23 Strong Typed Output
未來Python核心層使用強型別：`ValuationLevel.CHEAP / NORMAL / PRICEY / EXPENSIVE / EXTREME_CANDIDATE`、`ExtremeValuationFlag.ON / OFF`、`ContextStatus.POSITIVE / NEUTRAL / NEGATIVE`、`DataQuality.OK / FALLBACK_USED / INSUFFICIENT / UNKNOWN`。Data Quality的完整定義與Propagation以第六十二章Canonical Contract為準。Emoji只供Report/UI，不作核心程式邏輯值。
















## 32.24 Valuation Engine正式輸出＋客戶專案歷史契約
















每檔至少輸出；整輪結果必須帶時間戳追加寫入該客戶 `xxx專案.md` 的 `STOCK_VALUATION_SNAPSHOT_HISTORY`，**只追加、不覆蓋舊紀錄**：
















```text
Snapshot Type: STOCK_VALUATION_SNAPSHOT
Analysis Timestamp:
Market Data As Of:
Macro Snapshot Timestamp:
Rule Version:
Asset:
Asset Type:
Asset Grade:
Asset Classification Status:
Portfolio Role:
Primary Valuation Class:
Secondary Style Tags:
Type Evidence:
Grade Evidence:
Applicable Rule Modules:
Inapplicable Rule Modules:
Primary Metric:
Current Value:
Fallback Triggered: YES / NO
Fallback Metric Used: None / <Metric Name>
Fallback Reason: None / Missing / Stale / Invalid / Methodology Unavailable
Data Source:
Data Date:
Methodology:
V82 Operational Range:
Absolute Valuation Level:
Historical Window:
Raw Historical Percentile:
Valuation Expensiveness Percentile:
Historical Median:
Relative-to-Median:
Secondary Metric:
Secondary Confirmation: Strong / Weak / Unavailable
Supplementary Metrics:
Fundamental Context: Positive / Neutral / Negative
Extreme Candidate: YES / NO
Extreme Valuation Flag: ON / OFF
Valuation Normalization: Price Correction / Earnings Catch-up / Neither
Valuation Conclusion: Cheap / Normal / Pricey / Expensive / Extreme
Deployment Effect: Accelerate / Normal / Reduce / No Additional Valuation Adjustment
Client Valuation Label: 便宜 / 合理偏低 / 合理 / 合理偏貴 / 偏貴 / 很貴
Current Action: 由#41 `execution_action`產生；Valuation Snapshot不得另建第二套Action Enum
Key Reason:
Recheck Conditions:
Data Quality: OK / Fallback Used / Insufficient / Unknown
Data Issue Codes: None / <one or more canonical issue codes>
Formal Output Eligible: TRUE / FALSE
Reason Codes:
```
















同一輪多檔股票／股票ETF可放在同一個 `STOCK_VALUATION_SNAPSHOT` 下，但每一檔仍須保留自己的來源、資料日期、方法、結論與改判條件。HTML／圖卡只能讀取**最新一筆完整有效**的客戶Snapshot來呈現，不得在報表層臨時重新估值。
















## 32.25 與V82完整流程銜接
**Macro Safety → Valuation Engine → Fundamentals → Price Map → Technical（高TD9 → 低TD9 → KD → MACD → MA → EMV → RSI → 成交量／量價）→ Multi-Timeframe（日→週→月）→ Hard Gate／Runaway Down → Base／Left／Right／Trend Deployment → Execution（價位＋比例＋金額＋股數＋限價＋取消條件）**。
















固定六句：
> **Macro：現在的市場環境安不安全？**  
> **Valuation：這項資產現在貴不貴？**  
> **Fundamentals：這項資產還值不值得長期持有？**  
> **Price Map：現在價格位於哪一層折價？**  
> **Technical：今天先部署多少、後面加多快？**  
> **Hard Gate：目前是否必須關閉新增Buy Permission？**
















最終權限：Valuation調節部署速度；Fundamentals可破壞長期投資資格；Technical調節短期部署比例；Price Map決定折價深度；Extreme Valuation Flag只負責警報；**Hard Gate固定控制新增Buy Permission，Runaway Down與更高Priority Risk可搶占正常新增，CONFIRMED Emergency具有最高Execution Intent。**
















---
















# 第三十三章｜估值調整價格地圖
















估值是價格地圖與部署速度的修正器，不是單獨成交訊號。
















## CHEAP
















若 Hard Gate、信用／流動性與基本面安全，可提高左側部署積極度，第一層可適度前移。
















## NORMAL
















維持原價格地圖與部署節奏。
















## PRICEY
















降低第一層部署速度，要求較佳折價或較強共振。
















## EXPENSIVE
















提高折價要求，並降低追價／Base Deployment速度。
















## EXTREME_CANDIDATE
















先執行第三十二章 Extreme Valuation Flag 雙路徑確認，不得因單一估值門檻直接判定停止買進。
















- Gate OFF：仍依 V82 價格、基本面、技術與安全層執行，但降低部署速度。
- Flag ON：依 V82 Extreme Valuation Flag 規則降低追價、放慢新增部署並提高折價要求；若另有Hard Gate、Runaway Down、Structural Break／Emergency或更高Priority Risk，依各自正式Owner與20號Priority／Execution Contract處理，不把Hard Gate誤寫成唯一最高否決來源。
















---
















# 第三十四章｜個股基本面
















固定分析：
















- Revenue
- Revenue Growth
- EPS
- EPS Growth
- Guidance
- Gross Margin
- Operating Margin
- FCF
- CAPEX
- Debt
- Cash
- ROIC
- 產品週期
- 市占率
- 管理層
- 法規
- 競爭者
















必要時：
















- Backlog
- 訂單
- 庫存
- ASP
- 客戶集中度
- 供應鏈
- 地區收入
- 產品組合
















---

















## 34.1 Stock Fundamentals Canonical Data Contract【工程30｜正式｜工程77封版】

股票 Fundamentals 正式拆成「Raw Field → Derived Field → Direction → Deterioration → Missing Data」，避免同一個欄位同時混入原始數字與主觀結論。

### Canonical Field Record

每個欄位至少保存：

- `field_name`
- `field_role = RAW | DERIVED`
- `raw_value`
- `derived_value`
- `unit`
- `period`
- `as_of`
- `published_at`
- `source`
- `method`
- `input_fields[]`
- `formula`（Derived 才需要）
- `direction = IMPROVING | STABLE | DETERIORATING | UNKNOWN | NOT_APPLICABLE`
- `deterioration_evidence[]`
- `field_value_state = KNOWN | NONE | UNKNOWN | NOT_APPLICABLE`
- `data_quality`
- `issue_codes[]`
- `requirement_level`

### Required Domains

至少覆蓋施工圖與既有第34章：Revenue、Revenue Growth、EPS、EPS Growth、FCF、Margin、Guidance、CapEx、Debt、Liquidity／Cash、Competitive Position、Industry／Product Cycle；並保留 ROIC、Market Share、Management、Regulation、Competitors、Backlog、Orders、Inventory、ASP、Customer Concentration、Supply Chain、Geographic Revenue、Product Mix 等既有欄位。

### Raw vs Derived

- `RAW`：可直接從財報、公司公告／Guidance、可靠產業或市場原始來源取得。
- `DERIVED`：由一個或多個 Raw Field 依可重現公式計算，例如 Growth、Margin、Debt Ratio 等；必須保存輸入與公式。

不得把沒有可追溯輸入的「看起來成長不錯」寫成 Derived Data。

### Direction／Deterioration

Direction 依可比的 prior period、公司 Guidance、明確基準或正式產業資料判斷；**本工程不新增任何全域百分比穩定帶或惡化門檻**。若既有規則沒有數字門檻，就保存事實、方向與理由，不自行補門檻。

`deterioration_evidence[]` 只保存可追溯證據與原因，不建立第二套 Structural Break／FWL／Risk Grade；嚴重度與最終風險動作仍由既有正式模組裁決。

### Missing Data

- 應存在但取不到：`UNKNOWN` ＋ canonical issue code。
- 經濟上不適用：`NOT_APPLICABLE`，不可填 0。
- Required Field 缺失時依第62章 Requirement Level／Dependency Propagation 處理。

股票 Fundamentals 最終可形成 `fundamental_context = POSITIVE | NEUTRAL | NEGATIVE | UNKNOWN`，並輸出 evidence、missing_required_fields、Data Quality、Issue Codes、Formal Output Eligibility 與 Recheck；但 Fundamental Context 本身不得單獨創建 Structural Break 或 Emergency。

# 第三十五章｜基本面調整價格地圖
















## 改善
















可前移。
















## 持平
















維持。
















## 惡化
















後移。
















## 重大破壞
















舊價格地圖失效。
















全部重算。
















---
















# 第三十六章｜ETF基本面
















固定看：
















- 追蹤指數
- 指數規則
- 成分股
- 前十大持股
- 集中度
- 產業權重
- EPS趨勢
- Forward P/E
- 國家分布
- 費用率
- 流動性
- Bid／Ask
- NAV折溢價
- 追蹤誤差
















主題ETF：
















必須做Look-through。
















---

















## 36.1 ETF Fundamentals＋Look-through Canonical Contract【工程31｜正式｜工程77封版】

ETF 不是單一公司；本節把 ETF 自身資料與底層持股 Look-through 分開。**不得把單一公司 Fundamentals 或單一大持股的估值機械當成整檔 ETF 的 Fundamentals。** 本節也不取代 B 線基準資料工程或 C 線 Portfolio 配置決策引擎。

### ETF-level Raw Fields

至少保存：

- Index／Methodology／Rebalance Rule
- Holdings As-of
- Top Holdings／Top-10 Weight
- Sector Exposure／Country Exposure
- Company Concentration／Sector Concentration
- Weighted Fundamentals
- Expense Ratio
- AUM（可靠可得時）
- Liquidity／Bid-Ask
- NAV Premium／Discount
- Tracking Error
- Source／Method／Data Quality／Issue Codes

來源優先使用 ETF Issuer、Index Provider、交易所或其他可驗證原始資料；不同日期的 Holdings／Sector／Country 資料不得默認為同一截面。

### Concentration／Weighted Fundamentals

- Concentration 保存最大持股、Top-5／Top-10、主要產業等正式可得權重；本工程不新增新的集中度門檻。
- Weighted Fundamentals 只有在 Provider 已提供一致方法，或底層持股＋個別基礎資料具有足夠 Coverage 且公式可追溯時才可正式產出。
- 無可靠聚合方法時標記 `METHODOLOGY_UNAVAILABLE`／`PARTIAL_COVERAGE`，不得用幾個大持股的故事代表整檔 ETF。

### Look-through Output

至少包含：

- `holdings_coverage_weight`
- `missing_exposure_weight`
- `top_holdings[]`
- `sector_exposure[]`
- `country_exposure[]`
- `company_concentration`
- `sector_concentration`
- `overlap_reference_portfolio`
- `overlap_holdings[]`
- `overlap_weight`
- `weighted_fundamentals`
- `lookthrough_as_of`
- `source`
- `method`
- `data_quality`
- `issue_codes[]`

Known Coverage 只代表已被可靠看穿的權重；未知部分仍保留為 `missing_exposure_weight`，不得為了總和 100% 而按比例攤回已知項目。若沒有 comparison target，Overlap 應為 `NOT_APPLICABLE`，不是 0。

### ABC Boundary

- A／V82：回答「這一檔 ETF 本身是什麼、底層曝險如何、今天是否適合部署」。
- B：保存可重用的標的績效／曝險基準資料。
- C：未來做客戶整體 Portfolio 的配置重算與 Adjustment Loop。

A 可以消費可靠 Look-through Input，但不得在 Work1 偷做 B 的《標的績效基準資料.xlsx》或 C 的配置決策引擎。

# 第三十七章｜Macro位置＋方向＋速度
















每一項重要Macro：
















都必須看：
















## 位置
















高／中／低。
















## 方向
















上升／下降／持平。
















## 速度
















快速／緩慢。
















例如：
















10Y 4.5%
















若：
















4.8 → 4.5
















與：
















4.0 → 4.5
















市場意義完全不同。
















---

















## 37.1 V70→V82 Macro Input Contract【工程32｜正式｜工程77封版】

V82 的 Macro Safety 以同一輪最新 `V70產出-<客戶名字>.md`／未來等價結構化 Payload 為主要上游。**V82 消費 V70 Output，不在 V82 重建第二套 V70，也不重算客戶總體股票戰術預算。**

### Minimum Input Set

至少接收：

- `snapshot_timestamp`
- `upstream_snapshot_reference`（若上游已有既存識別碼則原樣保留；正式 `run_id`／Latest State Contract 留待Work6工程67）
- Fed Policy／Policy Bias
- 2Y／10Y／30Y Treasury Yield
- Real Yield
- CPI／Core CPI
- PCE／Core PCE
- GDP
- Employment
- Liquidity Regime
- Material Macro Events
- 每個欄位的 Source／As-of／Data Quality／Issue Codes

PPI、Oil、Breakeven、Consumption、Corporate Profit／EPS 等既有 Macro Safety 資料若由 V70 正式輸出，仍繼續保留；上列 Minimum Set 不得被誤解為刪除現有宏觀資料。

### Signal Shape

Macro Signal 統一保存：

`value + unit + level + direction + speed + as_of + source + data_quality + issue_codes`

`Level／Direction／Speed` 沿用 V70／既有正式定義；本工程不新增第二套宏觀閾值。

### Same-run Reuse＋Delta

- 同一份已驗證且仍 Fresh 的 V70 Snapshot，V82 直接重用其 Macro Fact，不重抓一份相互競爭的數字；若上游已有既存 correlation identifier 則原樣傳遞，但本工程不定義新的 `run_id`／Latest State Contract。
- 若 V70 Snapshot 後出現重大 Fed／Treasury／通膨／就業／地緣政治／流動性事件，V82 只補必要 `Macro Delta` 並保存新來源與時間；不得用舊 Snapshot 蓋掉新事實。
- Safety-required 欄位若缺失，依第62章 Data Sufficiency／Hard Gate UNKNOWN 契約處理；Optional 欄位缺失只影響其依賴模組。
- 缺資料不得解讀成「安全」，也不得自動解讀成「危機已觸發」。
- **Scope Guard：V70→V82 Tactical Budget、SGOV資金來源幣別、正式 `run_id`／Latest State／History-Time Contract屬Work6，不在工程32提前施工。**

# 第三十八章｜信用與流動性安全否決
















固定：
















- HY OAS
- IG OAS
- BBB OAS
- VIX
- MOVE
- Treasury流動性
- Repo
- SOFR
- SOFR-OIS
- FRA-OIS
- SRF
- RRP
















所有指標：
















一律看：
















> 位置＋方向＋速度。
















不得只看絕對值。
















---

















## 38.1 Credit／Liquidity Input Contract【工程33｜正式｜工程77封版】

既有第38～40章的信用、波動與流動性規則、區間與 Hard Gate 全部保留；本節只把資料入口統一成可程式化 Contract，**不新增新的信用危機門檻**。

### Minimum Signals

至少接收：

- HY OAS
- BBB OAS
- A OAS
- IG OAS
- VIX
- MOVE
- Treasury Market Liquidity／Function
- Repo
- SOFR
- SOFR/OIS
- Overall Liquidity Regime

既有 FRA-OIS、SRF、RRP 等欄位繼續保留；A OAS 依施工圖正式加入介面。

### Canonical Signal Record

每一訊號至少保存：

- `signal_name`
- `value`
- `unit`
- `level`
- `direction`
- `speed`
- `as_of`
- `published_at`
- `source`
- `method`
- `data_quality`
- `issue_codes[]`

`Level` 使用既有正式區間／上游 V70 定義；`Direction` 必須遵守指標經濟方向（例如 OAS 擴大與收斂不能與 VIX 上下直接混成同一「升／降=好／壞」）；`Speed` 使用既有可比頻率，不新增一個所有指標共用百分比門檻。沒有可靠 prior value 時，Direction／Speed 應為 `UNKNOWN`，不是 STABLE。

### Time-series Requirement

正式判斷至少保存 Current／Prior、comparison window／frequency 與各自 As-of。若前後資料頻率或期間不可比，標記 `FREQUENCY_MISMATCH`／相應 Issue Code，不得只留一張 Snapshot 就宣稱「快速惡化」。

Credit／Liquidity Input 是 Evidence；Hard Gate 是否觸發仍由第39／40章＋第62章既有規則裁決。Missing Data ≠ Crisis Trigger，但 Safety Required 的缺失也不能安全解除 Gate。

# 第三十九章｜核心風險區間
















## HY OAS
















### <3%
















信用非常健康。
















### 3%～5%
















普通至偏緊。
















### >5%
















信用壓力明顯提高。
















### >6%且快速擴大
















系統性風險明顯提高。
















但：
















即使只有3.6%，
















若短時間從2.8快速上升到3.6，
















也必須提高警戒。
















## VIX
















### <15
















低波動。
















### 15～25
















正常至偏高。
















### >25
















風險厭惡明顯上升。
















### >35
















高度恐慌。
















## MOVE
















### <90
















平穩。
















### 90～120
















偏高。
















### >120
















美債波動顯著升高。
















若同時：
















- Treasury流動性惡化
- Repo異常
- HY OAS擴大
















則提高整體風險等級。
















---
















# 第四十章｜信用否決層級
















## Level 0
















信用健康。
















正常執行。
















## Level 1
















信用轉弱。
















可：
















- 第一層減量
- 後移買點
- 提高右側要求
















## Level 2
















信用明顯惡化。
















停止新增高Beta。
















核心ETF降低承接速度。
















## Level 3
















信用／流動性危機。
停止接刀。
















優先：
















**保全資本。**
















---
















# 第四十一章｜Fed與利率
















### Fed路徑來源優先順序
















1. CME FedWatch／Fed Funds Futures市場定價。
2. OIS／SOFR利率市場交叉確認。
3. Goldman Sachs、JPMorgan、Bank of America、Citi、Morgan Stanley、UBS等大型機構最新預測。
4. Fed官方SEP／點陣圖／官員談話。
















每次都要重新查最新值，不能沿用舊的升降息月份。固定回答：目前政策利率、下一次FOMC最可能動作與幅度、本曆年年底利率區間、未來約6個月／12個月／18個月市場隱含利率／區間、第一次可能政策轉向的月份／區間與幅度，以及FedWatch、OIS／SOFR、Fed官方與大型機構是否分歧。
















Fed只負責股票估值與資金成本的其中一條主線；股票／股票ETF的最終買賣仍必須回到V82的基本面、估值、信用、流動性、價格地圖、技術、成交量與專案資金條件綜合判斷。
















固定：
















- Fed政策利率
- FedWatch
- FOMC
- 點陣圖
- 官員談話
- 2Y
- 5Y
- 10Y
- 20Y
- 30Y
- 10Y實質利率
- 殖利率曲線
- 期限溢價
















不能只寫：
















升息利空／降息利多。
















必須看：
















- 原本預期
- 現在改變多少
- 哪段殖利率變動
- 變化速度
- 對融資成本與估值影響
















---
















# 第四十二章｜通膨
















固定監控：
















- CPI
- Core CPI
- PCE
- Core PCE
- Headline PPI
- Core PPI
- PPI主要分項（資料可得時）
  - 能源
  - 原物料
  - 運輸／物流
  - 商品
  - 核心服務
- 5Y Breakeven
- 10Y Breakeven
- 5y5y
- WTI
- Brent
















所有通膨指標固定看：
















- 絕對位置
- 月增
- 年增
- 方向
- 速度
- 是否重新加速
















## PPI先行通膨雷達
















PPI定位為：
















> **上游／生產端成本與企業毛利壓力的早期通膨警報器。**
















PPI部分成本端分項可能較CPI／PCE更早反映通膨方向，但**不存在固定、穩定的領先月數**。
















實際可能：
















- 同月反映
- 領先數週
- 領先數月
- 或未完整傳導至CPI／PCE
















實際傳導取決於：
















- 商品／服務結構
- 終端需求
- 企業議價能力
- 企業成本轉嫁能力
- 庫存
- 能源與運輸成本
















不得機械寫：
















> **PPI一定以固定月數領先CPI／PCE。**
















固定判讀順序：
















> **PPI先看成本端  
> → CPI看消費端是否開始被轉嫁  
> → PCE／Core PCE看Fed真正關心的終端通膨壓力。**
















若Headline PPI／Core PPI連續2～3個月重新加速，尤其：
















- 能源上升
- 運輸／物流上升
- 原物料上升
- 商品價格上升
- 核心服務同步上升
















則：
















1. 提高未來CPI／PCE再加速警戒。
2. 提高企業Gross Margin／Operating Margin受壓風險。
3. 提高Fed偏鷹、延後降息或重新升息風險。
4. 提高10Y實質利率與名目殖利率上行風險。
5. 高估值、長久期、高Beta股票／ETF的估值壓力提高。
6. V82 Macro Safety應降低Base Deployment／Left Overweight速度，或提高折價要求。
















但：
















> **PPI不得單獨形成Hard Gate。**
















仍必須與下列項目交叉確認：
















- CPI
- Core CPI
- PCE
- Core PCE
- 5Y／10Y Breakeven
- 5y5y
- WTI／Brent
- HY／BBB／A／IG OAS
- VIX／MOVE
- Treasury／Repo／美元流動性
- 企業EPS／Guidance／Margin
















若PPI升溫，但：
















- CPI／PCE尚未跟進
- Breakeven仍穩定
- 信用健康
- 流動性正常
- 基本面沒有破壞
















則：
















> **列為早期通膨警戒，不直接判定通膨危機。**
















對長期左側：
















> **價格已進合理折價區＋Hard Gate未觸發時，仍可依V82進行Base Deployment／Left Overweight；PPI主要調整單筆速度與折價要求，不機械把買進歸零。**
















---
















# 第四十三章｜景氣／就業／消費
















固定：
















- GDP
- GDPNow
- NFP
- 失業率
- Initial Claims
- Continuing Claims
- JOLTS
- Average Hourly Earnings
- Labor Participation Rate
- Retail Sales
- Consumption
















IWM型：
















景氣與融資條件權重提高。
















---
















# 第四十四章｜重大政策與地緣政治
















固定：
















- Fed
- Treasury
- 關稅
- 出口限制
- 財政政策
- 補貼
- 稅制
- 法規
- 戰爭
- 制裁
- 中東
- 台海
- 能源政策
















重大政策固定回答：
















**以前多少  
→ 現在多少  
→ 何時生效  
→ 誰受影響  
→ 對Revenue／Cost／EPS／估值／價格有何直接影響。**
















---
















# 第四十五章｜股性代理總原則
















流程：
















**股性分類  
→ 主框架  
→ 副框架  
→ 專屬因子  
→ 自身資料重算。**
















核心：
















> 借股性，不借價格。
















---
















# 第四十六章｜QQQ型
















適用：
















- 科技
- AI
- 半導體
- 軟體
- 雲端
- 高成長
- 高Beta
















提高：
















- 10Y
- 30Y
- 實質利率
- AI CAPEX
- EPS
- Guidance
- GPU／ASIC需求
- 高估值
- 長久期估值敏感度
















---
















# 第四十七章｜PPH型
















適用：
















- 製藥
- 醫療
- 大型生技
- 防禦醫療
















提高：
















- FDA
- Medicare
- MFN
- 藥價
- 專利懸崖
- GLP-1
- M&A
- 臨床試驗
- Pipeline
- 訴訟
















---
















# 第四十八章｜S&P 500／VOO型
















適用：
















- 美國大型成熟企業
- 金融
- 消費
- 工業
- 廣泛大型股ETF
















S&P 500：
















**市場母體＋技術濾網。**
















VOO：
















**可交易大型股ETF代表。**
















---
















# 第四十九章｜VT／VWRA型
















適用：
















全球核心／跨國分散。
















提高：
















- 全球GDP
- Fed
- ECB
- BOJ
- 美元
- 全球估值
- 全球資金流
- 地緣政治
- 美國市場權重
- 國家集中度
















---
















# 第五十章｜0050型
































## 0050型通用執行規則｜專案價格與金額不得寫死在母規則
















0050屬台灣大型權值／半導體集中型ETF。V82只規定其**分析方法與通用執行程序**；任何客戶的實際買進價格、梯形比例、投入金額、股數與有效期間，必須放在該客戶專案檔。
















### 0050通用分析固定檢查
















1. **0050自身技術面**：高TD9→低TD9→KD→MACD→MA→EMV→RSI→成交量／量價，並檢查日線＋週線＋月線、ATR、Confirmed Swing High／Low與Runaway Up／Runaway Down。
2. **台積電／TSM ADR**：台積電2330、TSM ADR、EPS、財測、AI CAPEX、先進製程、外資與重大公司消息。
3. **半導體交叉確認**：SOXX、SOX、SMH、NVDA，以及必要時HBM、DRAM、NAND與半導體庫存循環。
4. **S&P 500大盤**：依V82技術順序與大盤狀態確認全球風險偏好。
5. **Macro／信用／流動性**：Fed政策路徑、美債殖利率、PPI／CPI／PCE通膨鏈、HY OAS、IG／BBB OAS、VIX、MOVE、Treasury市場功能、Repo／SOFR等。
6. **重大政策／新聞／地緣政治**：若足以改變台積電、半導體、台股或全球風險資產的基本面與風險溢酬，必須完成事件重估。
















### 若客戶專案採T-1預約限價模式
















- 前一交易日收盤後先依最新V82決定次一交易日哪些專案價格層取得「建議預掛」資格。
- 次日開盤前重新檢查隔夜美股、TSM ADR、SOXX／SOX／SMH／NVDA、S&P 500、Nasdaq、美債殖利率、VIX、MOVE、HY OAS、Fed路徑、美元、油價、台指期／0050期貨與重大新聞。
- 若無新增Hard Gate，前一交易日已取得建議資格的限價單可維持；若新增Runaway Down、信用／流動性惡化、台積電／半導體基本面重大破壞或重大政策／戰爭改變投資邏輯，應建議取消、減量或延後未成交單。
- 台股預約單僅對次一交易日有效時，未成交者下一交易日前必須重新跑V82；並將台股單日漲跌幅限制納入可達價位判斷。
- 已成交部位以成交當時可得資訊評估，不使用後見之明改寫。未成交的更深層掛單則持續接受最新V82安全檢查。
















### 專案價格層的恢復與失效
















- Runaway Down只代表顧問暫停機械接刀，不代表客戶專案檔中的預定額度永久消失。
- 當失速停止、價格不再持續破低，且基本面、信用與流動性沒有結構性惡化，原專案價格層可重新取得評估資格。
- 恢復時使用當下真正可成交價格重新計算股數，不得假設曾成交在已錯過的低價。
- 專案價格層若因Swing、ATR、估值、基本面或市場結構重大改變而失效，應在客戶專案檔更新版本與生效日期。
















### 0050型核心
















**價格決定是否值得重新評估；台積電、半導體、大盤、Macro、信用與流動性決定顧問是否敢建議承擔風險；0050自身技術成熟度決定當次建議投入強度。實際價格、金額、股數與梯形比例由客戶專案檔提供。**
































































適用：
















台灣大型權值／半導體集中型。
















提高：
















- 台積電
- TSM ADR
- SOX
- SOXX
- SMH
- NVDA
- 台指期
- 外資
- USD/TWD
- AI CAPEX
- HBM
- DRAM
- NAND
- 出口訂單
- 半導體庫存循環
















---
















# 第五十一章｜IWM／Russell 2000型
















定位：
















**美國中小型／內需／利率敏感型。**
















提高：
















- Fed
- 2Y／5Y
- 銀行放貸標準
- Small Business Credit
- Regional Banks
- GDP
- 消費
- 就業
- Refinancing Risk
- Floating-rate Debt
- HY OAS
- Default Rate
- Earnings Breadth
















特性：
















- 比VOO更利率敏感
- 比QQQ更依賴美國內需
- 平均信用品質較弱
- 融資環境權重更高
















---
















# 第五十二章｜國防／航太／軍工型
















定位：
















**工業＋政策＋地緣政治驅動型。**
















## 傳統軍工
















主框架：
















VOO／大型工業型。
















額外：
















- 美國國防預算
- NATO軍費
- 軍購
- Backlog
- 合約金額
- 交貨期
- 毛利率
- 原材料
- 出口限制
- 政府採購
- 地緣政治
















## 軍工科技／無人機／衛星／AI
















採：
















VOO型＋QQQ型。
















提高：
















- AI
- 半導體
- 感測器
- 無人機
- 衛星
- 資安
- 電子戰
- 高Beta
- 科技估值
















## NATO（Future of Defence UCITS ETF）正式國防代理
















目前所有正式國防／軍工ETF分析與Task，國防主標的統一採 **NATO（Future of Defence UCITS ETF，HANetf）**。
















NATO定位：
















- 愛爾蘭籍 UCITS ETF。
- 被動式、實體複製、累積型。
- NATO可依實際可交易市場與幣別分析；**客戶實際使用的平台、交易所、交易幣別與交割方式，一律由該客戶 `xxx專案.md` 決定，不得寫死於V82母規則。**
- 追蹤 **EQM NATO+ Future of Defence Index**。
- 產業定位為「全球國防／軍工＋Cyber資安＋現代國防科技」。
- 分析框架固定為 **VOO大型工業型主框架＋QQQ科技成長型副框架**。
- 額外提高 Cybersecurity、AI戰場資料、無人機／反無人機、衛星、電子戰、感測器、半導體與現代軍事通訊權重。
















NATO正式分析固定檢查：
















- NATO及盟國軍費／國防預算
- 政府軍購、合約金額、Backlog、交貨週期
- 毛利率、原物料、產能、出口限制
- 俄烏、中東、歐洲安全與戰爭升降溫
- 無人機／反無人機、衛星、電子戰、Cybersecurity、AI與半導體需求
- ETF最新持股、國家／產業權重、集中度與持股規則
- 最新P/E、P/B、獲利成長與估值中樞；官方無可靠即時值時不得捏造
- 日線＋週線＋月線、高TD9→低TD9→KD→MACD→MA→EMV→RSI→成交量／量價
- ATR、確認Swing High／Swing Low、前低／前前低／前前前低、動態價格地圖與回撤
- Macro位置＋方向＋速度、HY OAS、VIX、MOVE、利率與信用／流動性安全否決
















NATO執行原則：
















- 借股性、不借價格；所有價格地圖必須用NATO自己的價格、ATR、Swing Low、均線、估值與基本面重算。
- 價格到位代表部署強度需要重新評估；是否執行仍先看Hard Gate與投資論點，再由技術決定單筆速度與大小。
- NATO屬C級產業／衛星ETF；實際目標配置上限由各客戶專案檔決定，不得在V82母規則寫死。
- 實際交易平台、交易幣別與交割方式由各客戶專案檔記錄；不得在V82母規則假設固定平台。
- 每次出現可執行買點，應依客戶實際使用的平台查核最新佣金、交易所費用、買賣價差、稅務與匯率成本；若最低佣金使小額分批成本過高，可建議合併批次，但不得突破客戶專案檔設定的目標配置上限。
















---
















## SOXX（iShares Semiconductor ETF）專屬半導體框架
















SOXX正式納入V82股票ETF可執行與持續監控標的。
















### SOXX正式定位
















- 美國掛牌半導體產業ETF。
- 屬C級產業／衛星ETF；**C級只負責部位管理與單次投入比例，不代表SOXX的分析框架。**
- SOXX正式採 **「V82共同母規則＋SOXX專屬半導體框架」**。
- **不再套用QQQ主框架。**
- QQQ、SOX、SMH、TSM ADR／台積電及其他相關標的只作交叉驗證，不得取代SOXX自身分析，也不得直接決定SOXX買點。
- SOXX所有買點、價格地圖、ATR、Swing High／Swing Low、TD9與其他技術訊號，必須使用 **SOXX自身資料獨立計算**，不得套用QQQ、SMH、0050、NVDA或其他股票／ETF價格地圖。
















### SOXX自身價格與技術
















每次固定依V82共同順序分析：
















**高TD9 → 低TD9 → KD → MACD → MA → EMV → RSI → 成交量／量價**
















並同步檢查：
















- 日線＋週線＋月線
- ATR(14)
- Confirmed Swing High／Swing Low
- 前低／前前低／前前前低
- 近期重要高點與高點回撤
- MA20／MA50／MA60／MA200
- 成交密集區
- 跳空缺口
- 重要支撐／壓力
- Runaway Up／Runaway Down
















### SOXX專屬價格地圖
















SOXX價格地圖只能用SOXX自身資料建立。
















固定依：
















**重要Swing High／市場結構
→ 回撤幅度
→ Confirmed Swing Low
→ MA20／MA50／MA60／MA200
→ ATR／波動
→ 成交密集區／缺口
→ 歷史支撐
→ SOXX估值
→ 半導體基本面
→ 半導體景氣循環**
















建立第一左側、第二左側、深度折價與極端折價區。
















價格地圖是部署強度觸發區，不是無條件一次滿倉價。單日上漲不得追高上移；單日急跌也不得機械把買點一直下移。只有Swing、ATR、估值、半導體基本面、信用／流動性或市場結構發生實質改變時，才重新估算並說明原因。
















### SOXX半導體基本面
















固定檢查：
















- AI CAPEX
- GPU／ASIC需求
- Data Center／AI伺服器需求
- HBM
- DRAM
- NAND
- 記憶體報價與庫存循環
- 先進製程
- 晶圓代工
- 先進封裝／CoWoS等重要產能
- 半導體設備需求
- 庫存去化／補庫存
- 訂單、ASP、產能利用率
- PC／手機／伺服器／汽車半導體終端需求
















### 主要成分股與產業交叉確認
















至少交叉檢查：
















- NVDA
- AMD
- AVGO
- INTC
- MU
















必要時加入：
















- TSM ADR／台積電2330
- 其他SOXX主要權重成分股
















固定檢查Revenue、EPS、EPS Growth、Guidance、Gross Margin、CAPEX、庫存、訂單、AI需求與下一季／下一年度展望。
















若多家主要成分股同步下修財測，SOXX基本面風險必須提高；若只有單一公司個別事件，不得直接推論整個半導體循環反轉。
















### QQQ、SOX、SMH的角色
















- SOX／費城半導體指數與SMH：作半導體產業廣度、強弱與同步性驗證。
- QQQ：只作科技／成長股整體風險偏好、Nasdaq-100強弱與利率敏感度的交叉確認。
- TSM ADR／台積電：作先進製程與全球半導體需求的重要交叉確認。
















不得：
















- 套用QQQ買點
- 套用SMH買點
- 套用0050買點
- 因QQQ轉強就直接判定SOXX可以買
- 因單一半導體股票大漲就直接判定SOXX進入右側
















**SOXX的買賣決定，最後必須回到SOXX自身V82。**
















### SOXX估值
















固定檢查：
















- SOXX Forward P/E
- Trailing P/E（有意義時）
- Earnings Growth
- Earnings Yield
- 歷史估值區間／百分位
- 半導體產業歷史估值
- 主要成分股估值
- AI成長是否足以支持目前估值
















依V82客戶可讀六級分類為：**便宜／合理偏低／合理／合理偏貴／偏貴／很貴**。
















估值偏高時降低Base／左側部署速度；估值極高時要求更大折價，或等更高確認度後再加速；若獲利快速上升使Forward估值下降，可提高合理承接價格。
















### Macro／信用／流動性
















SOXX固定提高以下因子權重：
















- Fed政策路徑
- 2Y／10Y／30Y美債殖利率
- 10Y實質利率
- PPI／CPI／PCE與通膨方向；PPI作為半導體企業成本端與Fed風險的早期警報
- DXY／美元
- 美國GDP、就業與景氣
- HY OAS／IG OAS／BBB OAS
- VIX／MOVE
- Treasury流動性
- Repo／SOFR／SOFR-OIS／FRA-OIS
















尤其注意 **PPI重新加速＋實質利率快速上升＋半導體估值偏高** 的共振；即使EPS尚未立即惡化，也可能造成SOXX估值快速壓縮。
















PPI若只單月偏高而CPI／PCE、Breakeven、信用與流動性未同步惡化，屬Macro早期警戒，主要調整SOXX的Base／Left部署速度與折價要求，不直接形成Hard Gate。
















若信用／流動性進入V82 Level 3，停止SOXX一般左側接刀。
















### 半導體政策／新聞／地緣政治
















固定檢查：
















- 美國晶片出口管制
- 中國半導體政策
- 晶片關稅
- CHIPS相關政策
- AI晶片限制
- 半導體設備出口限制
- 台海風險
- 重大供應鏈中斷
















重大政策必須回答：
















**以前如何 → 現在改成什麼 → 何時生效 → 哪些SOXX成分股受影響 → 對Revenue／EPS／Margin／估值的影響。**
















### SOXX執行原則
















SOXX仍使用V82共同六類特殊分類：
















**左側買點／右側加碼／Runaway Up／Runaway Down／技術減碼／真正降低風險。**
















執行固定遵守：
















- SOXX是長期高Beta半導體衛星標的時，先看專案目標部位，再用SOXX自己的價格地圖決定部署速度。
- 正常修正且信用／流動性／半導體基本面安全、非Runaway Down時，只要價格進入SOXX自己的甜甜價／折價區，即可進入Left Overweight／左側加速部署；不再要求先湊滿2～3項技術確認才准第一筆。
- 低TD9、KD止跌／上彎、MACD空方柱縮短、DIF上彎、EMV改善、RSI回升、價格不再破低、下跌量縮或止跌K，改作**投入速度與比例加分項**。
- 價格越深、估值越合理、週線／月線仍健康且半導體基本面未壞，累積部署目標越高。
- 右側確認後可加速補足前面尚未完成的部位，但右側不是SOXX第一筆長期買進的必要門票。
- 若屬Runaway Up且專案仍低配，啟動Trend Deployment；不追單日極端大陽線，但不得因等待完美回檔而永久缺席。
- 若屬Runaway Down、信用／流動性惡化、主要半導體獲利／財測重大破壞或重大政策安全否決，暫停機械接刀。
- 若半導體產業需求結構性反轉、多家主要成分股EPS／財測大幅下修、AI CAPEX結構性下降、重大政策永久傷害主要成分股商業模式、信用／流動性危機或週線＋月線重大結構破壞，升級檢查「真正降低風險」。
















### SOXX C級部位管理
















C級只負責 **買多少**，SOXX專屬半導體框架負責 **為什麼買、何時買、哪裡買**。
















SOXX的部署固定採：
















**Base < 甜甜價 < 深度折價 < 極端折價（安全時）**
















Right／Trend確認後，可在不突破客戶專案上限的前提下，逐步接近目標部位。
















SOXX與其他股票／股票ETF的Canonical Deployment Target Rate，一律使用本檔「V82正式Canonical Deployment Target Rate｜九階梯累積目標比例」：**10%／20%／30%／45%／60%／75%／85%／95%／100%**。SOXX因高波動與產業集中，可透過單筆大小、分層速度、Hard Gate與專案上限調整風險；`母規則回測.md` **只負責驗證V82正式規則，不是部署比例來源，也不得自行創造、改寫、最佳化或替換部署比例**。
















若特定專案已有SOXX總預算、目標配置、單筆金額、梯形比例或部位上限，則專案設定優先；V82負責決定當次執行時機與投入強度。
















### SOXX核心原則
















> **SOXX有自己的V82半導體專屬框架。**
> **C級只管部位大小，不管分析方法。**
> **QQQ只做交叉確認，不是SOXX的母框架。**
> **借其他市場做驗證，但不借其他ETF的價格與買點。**
> **價格決定SOXX值得部署多少；SOXX自身技術決定今天先部署多少、後面加多快；半導體基本面決定值不值得長期持有；信用與流動性決定現在敢不敢承擔SOXX的高Beta風險。**
















---
















# 第五十三章｜主框架＋副框架
















例如：
















NVDA：
















QQQ型＋半導體專屬。
















台積電：
















0050型＋QQQ／半導體型。
















軍工AI ETF：
















VOO工業型＋QQQ型。
















中小科技：
















IWM型＋QQQ型。
















大型製藥成長：
















PPH型＋成長型。
















---
















# 第五十四章｜代理框架切換
















股性改變：
















主／副框架必須重判。
















例如：
















- 成長股成熟
- 中小企業成為大型企業
- 軍工公司科技收入大增
- 製藥核心專利失效
- ETF指數規則改變
















---
















# 第五十五章｜不得複製代理價格
















代理只借：
















- 股性
- 因子
- 風險權重
- 分析骨架
















不得借：
















**買點價格。**
















---
















# 第五十六章｜資金控管
















V82除了回答：
















能不能買，
















還要回答：
















**買多少。**
















固定：
















- 單一標的曝險
- 單一產業曝險
- 單一國家曝險
- 高Beta總曝險
- 因子重疊曝險
















---
















# 第五十七章｜單一標的上限
















不設定所有標的一律5%。
















## 核心ETF
















可較高。
















## 產業ETF
















中等。
















## 普通個股
















低於核心ETF。
















## 高Beta／事件型
















再低。
















## 小型股／生技／事件軍工
















再低。
















依：
















**標的角色＋整體組合＋重疊曝險**
















決定。
















---
















# 第五十八章｜單一產業集中度
















固定檢查：
















- 科技
- 半導體
- AI
- 醫療
- 軍工
- 金融
















若已過高：
















即使個別標的是買點：
















**也降低新增金額。**
















---
















# 第五十九章｜Look-through
















例如已有：
















- QQQ
- SOXX
- NVDA
















再買AI ETF：
















不得視為完全新分散。
















檢查：
















- 共同持股
- 共同產業
- AI因子
- 半導體因子
- 高估值因子
- 利率敏感度
















---
















# 第六十章｜個股 vs 產業ETF
















分析個股時：
















固定比較合理產業ETF替代。
















個股：
















- 高彈性
- 高超額報酬潛力
- 高公司特有風險
















產業ETF：
















- 分散公司風險
- 保留產業曝險
- 仍有產業週期
- 仍有估值風險
















---
















# 第六十一章｜重大事件後重置價格地圖
















以下可使舊價格地圖失效：
















- 財測大幅上修／下修
- EPS結構性改變
- FDA重大決定
- M&A
- 戰爭
- 政策永久改變
- 公司治理問題
- 產業需求結構改變
- ETF指數規則重大改變
















發生後：
















**重新跑V82。**
















---
































# 執行章B｜日圓／套利交易風險雷達
















日圓定位：
















**全球流動性與去槓桿放大器。**
















固定監控：
















- USD/JPY
- 日圓1日升值速度
- 日圓5日升值速度
- BOJ政策
- 日本10年期公債殖利率
- 日美利差
- CFTC日圓投機部位（可靠可得時）
- DXY
- VIX
- MOVE
- HY OAS
















## Level 0｜正常
















條件：
- 日圓波動正常
- 信用與跨資產波動正常
















操作：
- V82照原規則執行
- 買進比例 ×1.00
















## Level 1｜快速升值警戒
















觸發參考：
- 日圓1日升值約1.5%以上
或
- 日圓5日升值約3%以上
















但VIX、MOVE、HY OAS尚未同步明顯惡化。
















操作：
- 新左側買點比例 ×0.75
- 右側加碼提高確認要求
- 不因日圓單一訊號賣出僅因Runaway Up情境／Trend Deployment所建立的既有部位
















## Level 2｜套利平倉壓力
















Level 1成立，且至少1項同步：
- VIX 5日快速上升
- MOVE 5日快速上升
- HY OAS快速擴大
- 全球高Beta資產同步下跌
- 美元融資／流動性壓力升高
















操作：
- 新左側買點比例原則 ×0.50
- 高Beta／科技／半導體第一層可後移
- 右側加碼需更強確認
- 已掛高Beta買單重新檢查
















## Level 3｜嚴重去槓桿風險
















參考：
- 日圓1日升值約2.5%以上
或
- 日圓5日升值約5%以上
















且VIX、MOVE、HY OAS至少2項同步明顯惡化。
















操作：
- 一般左側買點暫停
- 高Beta右側加碼暫停
- 未成交買單取消並重新評估
- 優先檢查真正降低風險
- 等日圓速度、信用、波動與價格結構重新穩定
















核心規則：
















> **日圓本身沒有一票否決權。**
>
> **日圓急升＋信用／波動／流動性同步惡化，才是V82真正的全球去槓桿警報。**
















## 各股性敏感度
















- QQQ型：高敏感。
- 0050型：高敏感，需同步看台積電／TSM ADR／SOXX／外資／台幣。
- IWM型：高敏感，融資與風險偏好權重高。
- VT／VWRA型：中等。
- VOO型：中等。
- NATO／軍工型：中等至高。
- PPH型：相對較低，但仍屬股票，不免疫於流動性賣壓。
















---
















# 第六十二章｜Data Quality／UNKNOWN Canonical Contract
















本章是V82系統工程22正式Data Quality／UNKNOWN Contract。目的不是把「沒有資料」誤判成市場風險，也不是把「不知道」當作安全；而是讓每一個欄位、模組、Classification、Permission與正式輸出都能得到唯一、可測試、可追溯的資料狀態。
















固定最高原則：
















> **UNKNOWN ≠ False；UNKNOWN ≠ Zero；UNKNOWN ≠ Neutral；Data Insufficiency ≠ Market Risk Deterioration；Data Insufficiency ≠ Safety。**
















## A. Field Value State｜欄位值狀態
















正式列舉：
















- `KNOWN`：欄位已有可用且可解釋的正式值。
- `NONE`：已完成必要檢查，且明確知道「沒有／未成立」。
- `UNKNOWN`：資料未知、缺失、衝突、過期、無法驗證或不足以可靠判斷。
- `NOT_APPLICABLE`：此欄位／Metric對該Asset Type、Rule Module或經濟意義不適用。
















`NONE`與`UNKNOWN`不得互換；`NOT_APPLICABLE`也不得拿來掩飾應該取得但未取得的資料。
















## B. Canonical Data Quality State
















正式欄位：
















`data_quality = OK / FALLBACK_USED / INSUFFICIENT / UNKNOWN`
















- `OK`：該輸出所需資料完整、有效、在允許時效內、來源／方法可接受，可正常供該模組使用。
- `FALLBACK_USED`：Primary資料不可用，但已依該模組正式Waterfall／Fallback Contract改用合法替代資料，足以產生該模組允許的正式結果。
- `INSUFFICIENT`：已確認所需資料不足，且沒有合法Fallback足以完成該模組的Required判斷。
- `UNKNOWN`：連資料品質狀態本身、必要來源狀態或判斷邊界都無法可靠確認；不得自行猜成OK、INSUFFICIENT或其他狀態。
















`FALLBACK_USED`不是較差市場狀態，只表示資料取得路徑降級；Fallback結果仍必須保存使用的Metric、Source、Methodology與原因。
















## C. Data Issue Code｜資料問題原因
















Data Quality回答「這份資料／輸出目前能不能被使用」；Data Issue Code回答「為什麼」。兩者不得混成同一欄。Canonical Issue Code至少相容：
















- `MISSING`
- `STALE`
- `CONFLICT`
- `UNVERIFIABLE`
- `LOW_CREDIBILITY`
- `DATE_UNKNOWN`
- `FREQUENCY_MISMATCH`
- `FIELD_INCOMPLETE`
- `INVALID_VALUE`
- `METHODOLOGY_UNAVAILABLE`
- `METHODOLOGY_MISMATCH`
- `PARTIAL_COVERAGE`
- `SOURCE_UNAVAILABLE`
















同一欄／模組可同時有多個Issue Code；不得為了只留一個原因而丟失其他已確認問題。既有估值`Missing / Stale / Invalid / Methodology Unavailable`、News Search Coverage與PIT狀態均應保留其Domain-specific欄位，再映射到本章Canonical Quality，不必刪除既有專屬狀態。
















## D. Data Class與Requirement Level分離
















Data Class固定相容：
















- `HARD_DATA`：價格、OHLCV、財報、殖利率、信用利差、Broker Confirmed Position等可被直接觀察／確認的事實資料。
- `DERIVED_DATA`：由正式公式／規則從Hard Data計算出的TD9、KD、MACD、MA、ATR、估值百分位等。
- `SOFT_SIGNAL`：用於加減部署速度、確認成熟度或輔助判讀的訊號角色。
















Data Class允許多標籤；例如KD可以同時是`DERIVED_DATA + SOFT_SIGNAL`。
















Requirement Level另行固定：
















- `SAFETY_REQUIRED`
- `MODULE_REQUIRED`
- `OPTIONAL`
- `INAPPLICABLE`
















是否阻擋某項輸出，取決於Requirement Level與Dependency，不得僅因它是Hard／Derived／Soft哪一類而機械判定。
















## E. 資料新鮮度、來源與衝突
















1. 時間敏感資料依既有`as_of_date / published_at / valid_until / max_age_days`判斷，超過有效期即`STALE`。
2. Document Recency不得直接等同Assertion Validity；正式法律／監管／公司申報等Evidence仍依Event／Assertion生命週期規則。
3. 來源優先序仍依第六十三章與4-7F：PRIMARY／官方優先核對，其次可靠SECONDARY，再其次TERTIARY。
4. 多來源衝突時不得簡單平均。若較高權責來源足以裁決則採其值並記錄`CONFLICT`已解決；若衝突無法可靠裁決，受影響欄位為`UNKNOWN`，Quality至少不得是`OK`。
5. 日期不明、頻率不同步、Forward／Trailing方法混用、單位錯置與Methodology不一致均須個別留下Issue Code。
















## F. 技術資料Fallback與Partial Calculation
















若第三方沒有可靠TD9、KD、MACD、MA、EMV、RSI、ATR、成交量衍生指標，但有可靠OHLCV：
















> **優先依V82鎖定參數與公式自行計算，Data Quality可維持OK；若Primary Provider失敗但依正式替代來源／算法完成，依實際Fallback Contract標示FALLBACK_USED。**
















若OHLCV本身不足，對應Technical Field必須`UNKNOWN`，不得補值、不得用舊值冒充即時值，也不得把「未取得」算成買進或賣出確認。
















Partial Calculation固定採Dependency Propagation：
















> **只有依賴缺失／不可靠資料的輸出被污染；與該資料無依賴關係、且自身Required資料完整的模組可繼續計算。**
















例如KD為UNKNOWN，不代表Fundamentals、Valuation、Price Map一定UNKNOWN；但所有要求KD本身作必要輸入的Classification／Signal不得假裝完成。
















## G. Predicate Truth State｜三值邏輯
















凡會進入Classification、Gate、Signal、Event Predicate或Execution條件的Boolean判斷，正式使用：
















`TRUE / FALSE / UNKNOWN`
















Canonical邏輯：
















- `TRUE AND UNKNOWN = UNKNOWN`
- `FALSE AND UNKNOWN = FALSE`
- `TRUE OR UNKNOWN = TRUE`
- `FALSE OR UNKNOWN = UNKNOWN`
- `NOT UNKNOWN = UNKNOWN`
















UNKNOWN不得在程式／報告層用語言預設、空字串、0、None或False悄悄吃掉。
















### N-of-K確認門檻
















若某規則要求至少`K`個確認，令`T`為已知TRUE數、`U`為UNKNOWN數：
















- `T >= K` → Predicate=`TRUE`
- `T + U < K` → Predicate=`FALSE`
- 其他 → Predicate=`UNKNOWN`
















因此「2個TRUE＋2個UNKNOWN，門檻3」必須是UNKNOWN，不得直接判False。
















## H. Special Classification UNKNOWN Propagation
















20號既有六類Primary Priority完全不變：
















> **真正降低風險 > Runaway Down > 技術減碼 > Runaway Up > 右側加碼 > 左側買點。**
















六個Predicate各自先輸出`TRUE / FALSE / UNKNOWN`。Primary裁決時：
















1. 若最高順位已知TRUE，依20號Priority輸出該類Primary。
2. 若較低順位已知TRUE，但存在更高順位UNKNOWN且該UNKNOWN若為TRUE會搶占目前候選，則`primary_special_classification = UNKNOWN`；保留各Predicate供下游與UI解釋。
3. 只有六類全部已知FALSE，才輸出「無特殊分類」。
4. `primary_special_classification = UNKNOWN`不是第七個Classification，也不是WAIT、Deployment Mode或市場State；只是此欄目前無法完成裁決。
















## I. Hard Gate Evaluation與Data Sufficiency Gate正式分離
















新增兩個不同欄位：
















`hard_gate_evaluation = TRIGGERED / NOT_TRIGGERED / UNKNOWN`
















`data_sufficiency_gate = PASS / FAIL / UNKNOWN`
















正式語意：
















- `TRIGGERED`：已有足夠可靠資料證明既有V82 Hard Gate底層風險條件成立。
- `NOT_TRIGGERED`：已完成本輪Required安全檢查，沒有既有V82 Hard Gate底層條件成立。
- `UNKNOWN`：因重大Safety Required資料不足／衝突／無法驗證，無法可靠判斷Hard Gate究竟是否成立。
















重大安全資料缺失時可出現：
















`hard_gate_evaluation = UNKNOWN`
`data_sufficiency_gate = FAIL`
















**不得因資料不足把Hard Gate偽造為TRIGGERED；也不得把UNKNOWN當NOT_TRIGGERED。**
















### Safety Required最低範圍
















若與本次標的／市場明顯相關，至少包含：
















- 標的最新可交易價格／交易市場／報價口徑；
- 基本面是否有重大破壞、財測重大下修或投資論點失效；
- Runaway Down或重大價格結構失速所需的最低資料；
- HY OAS、VIX、MOVE與Treasury／美元資金市場是否達既有Level 3信用／流動性危機；
- 重大政策、戰爭、財報、FDA、FOMC、CPI／PPI／PCE等Material Event是否有未落地且不可控Gap風險；
- 日圓套利風險是否達既有Level 3跨資產去槓桿；
- 專案預算／部位上限／剩餘可建倉額度是否足以安全計算本輪Order Intent。
















PPI單一高值仍不構成Hard Gate；此原則不變。
















## J. New Buy Order Permission
















本節只摘要工程22的Data Sufficiency接口；`new_buy_order_permission`的唯一Canonical Owner為工程39-B。若本節摘要與工程39-B有任何文字差異，一律以工程39-B為準。

```text
new_buy_order_permission = TRUE
ONLY IF
    data_sufficiency_gate == PASS
AND hard_gate_evaluation == NOT_TRIGGERED
AND higher_priority_risk_state_allows_new_buy == TRUE
AND required_project_limits_and_execution_inputs_are_known
```

`new_buy_order_permission`只回答安全／治理上是否允許新的Buy Execution，**不得把Final Deployment Gap正負塞進Permission本身**。真正形成Executable Buy Order，才另外同時要求：

```text
new_buy_order_permission == TRUE
AND final_deployment_gap_amount > 0
AND maximum_allowed_buy_amount > 0
AND legal_order_quantity > 0
```
















若Safety Required資料不足：
















`new_buy_order_permission = FALSE`
`permission_block_reason = DATA_INSUFFICIENCY`
















若真正Hard Gate成立：
















`new_buy_order_permission = FALSE`
`permission_block_reason = HARD_GATE_TRIGGERED`
















兩者執行結果都可為「本輪不新增」，但風險語意、報告原因、後續Recheck條件必須分開保存。這不是WAIT復活。
















## K. Soft Signal缺失不自動禁止Base／Left
















高TD9／低TD9、KD、MACD、個別MA、EMV、RSI、個別量價與IV Crush等一般屬Soft Signal。若單一或少數Soft Signal為UNKNOWN，但：
















- `data_sufficiency_gate = PASS`；
- `hard_gate_evaluation = NOT_TRIGGERED`；
- 非Runaway Down；
- 基本面、信用與流動性安全；
- 價格／估值與既有Base／Left條件成立；
















則Base Deployment／Left Overweight不得只因少數Soft Signal缺失而機械歸零。技術資料越不完整，可降低單筆速度、拉寬分層、提高重新評估頻率；缺失項不得補值或當確認票。Right Confirmation、Runaway Up、Runaway Down與技術減碼若本身規定最低確認數，仍依G節三值邏輯與各自門檻判斷。
















## L. Structural Break Reduction的Safety-preserving Fallback
















Structural Break／Reduction Episode已由既有基本面規則正式成立後，技術模組只負責決定`SLOW / NORMAL / ACCELERATED`速度，不得因技術資料不足取消已確認的風險降低任務。
















若B-3所需技術群組不足以可靠成立Accelerated或Confirmed Slow：
















- `technical_data_quality = INSUFFICIENT`或`UNKNOWN`依實際狀態保存；
- 不把UNKNOWN改成Neutral／False；
- 由既有Reduction Contract採`NORMAL`作**Safety-preserving Reduction Fallback**；
- FC、RRG、Risk Clock、Hard Deadline與Execution Exception全部維持既有規則。
















這個Fallback的意思是「在缺乏足夠技術證據時，不因資料缺口延誤已確認風險降低」，不是`UNKNOWN = NORMAL`。
















## M. Formal Output Gate｜正式報告可交付性
















正式欄位：
















`formal_output_eligible = TRUE / FALSE`
















只有該正式頁／Snapshot所有Required欄位均為：
















- `Data Quality = OK`，或
- `Data Quality = FALLBACK_USED`且該Fallback已由對應Module Contract明確允許；
















才可對該頁／結論輸出`formal_output_eligible = TRUE`。
















若存在影響該正式結論的Required：
















- `INSUFFICIENT`；
- `UNKNOWN`；
- 無法裁決的重大`CONFLICT`；
- 關鍵日期／來源／方法未知；
- 必要Asset Classification／Valuation Routing無法完成；
















則`formal_output_eligible = FALSE`。內部研究、已知價格地圖、待補資料清單與Recheck Conditions仍可保存，但正式客戶頁不得以「待更新／N/A／先略過」冒充正式答案。
















## N. Data Quality不得改寫其他Canonical State
















Data Quality／UNKNOWN不得直接：
















- 修改Asset Grade A/B/C/D；
- 修改Asset Type；
- 觸發Structural Break；
- 觸發Emergency；
- 觸發Runaway Down；
- 建立第七個Special Classification；
- 建立WAIT State／WAIT Mode；
- 改寫九階Deployment Ladder、Price Map或20號Priority；
- 把資料不足推導為市場安全。
















各Business State仍必須由自己的Canonical Rule與足夠Evidence成立。
















## O. Minimum Machine-readable Output
















每個重要Required欄／模組至少可追溯：
















```text
field_or_module
field_value_state
data_quality
data_issue_codes
data_classes
requirement_level
source
as_of_date
published_at
methodology
fallback_used
fallback_reason
depends_on
formal_output_eligible
```
















若該模組會影響新增買進，再加：
















```text
hard_gate_evaluation
data_sufficiency_gate
new_buy_order_permission
permission_block_reason
```
















V82核心：
















> **有資料才知道市場是否危險；沒有資料時先誠實標UNKNOWN／INSUFFICIENT，不能把「不知道」變成「安全」或「危機」。**
















---
















# 第六十三章｜資料來源優先順序
















V82正式鎖定：
















## 第一優先
















官方／第一手資料：
















- 公司IR
- 財報
- SEC
- ETF發行商
- 交易所
- Fed
- Treasury
- BLS
- BEA
- 政府部門
- 央行
- 監管機關
















## 第二優先
















可靠市場資料供應商／大型券商。
















## 第三優先
一般第三方財經網站。
















若官方與第三方衝突：
















**優先官方。**
















技術指標若有可靠OHLCV：
















**優先自行計算。**
















---
















# 執行章B1.5｜V70產出-客戶名字.md 共用總經交接契約
















每次針對某一客戶正式執行 V82 前，固定先讀取該客戶最新：
















> **`V70產出-<客戶名字>.md`**
















例如 mou 客戶讀取 `V70產出-mou.md`。此檔由 V70.2 在同一輪 Macro 運算後產生，至少包含客戶已核准S0/B0（Strategic Risk Budget Rule Owner＝V70；現行Producer仍可能是Mentor／人工Legacy流程）、V70 原始總經數字、資料日期／來源、最近1～2日重大新聞、七群組／mSafe／CAP／bScore、T/C、今日股票／債券／`V70_ORIGINAL_DRY_POWDER`戰術額度，以及可供下游使用的補充 Macro Snapshot。
















固定規則：
















1. **V70產出是共用事實起點，不是股票逐檔結論。** V82 不得把「股票戰術總額度 X%」直接轉成「今天把股票買到 X%」。
2. V82 仍依本檔完整順序重新判斷：Macro Safety → 估值 → 基本面 → Price Map → 技術 → Multi-Timeframe → Hard Gate／Runaway Down → Deployment。
3. V70產出中已有且仍新鮮的 Macro／信用／流動性／新聞，不必每檔重抓；直接作本輪 Global Snapshot seed。
4. 若 V82 所需欄位在 V70產出缺失（例如特定產業資料、Market Breadth、標的基本面、估值、Asset Delta），V82 必須補抓。
5. 若 V70產出之後發生新的 CPI／PPI／PCE、Fed、Treasury、戰爭／政策、信用／流動性或標的重大事件，**新資料優先**；V82 必須建立 Delta 並更新判斷，不得被舊 Snapshot 綁住。
6. V70產出的等待資金固定指 `V70_ORIGINAL_DRY_POWDER`；它只是最終 SGOV 子彈的其中一個來源，不是客戶最終 `SGOV_DRY_POWDER_BUCKET`。
7. 客戶專案保存客戶已核准的長期目標、Universe、限制、授權與資金邊界；V70產出提供本輪戰術股票總額度；V82只負責在此邊界內判斷逐檔是否取得股票資格、是否部署、部署多少與何時暫停。
















> **一句話：V70 把同一輪天氣、新聞與股票總油門交給 V82；V82 再決定每一檔車今天能不能開、開多快。**
















---
















# 執行章B2｜V82 Global Snapshot＋Incremental Update
















本章為V82效能與一致性正式規則。目的不是刪除任何分析項目，而是避免同一輪分析多檔ETF時，重複查詢完全相同的Macro、信用、流動性與跨市場資料。
















## 1. 同一分析輪次只建立一次Global Snapshot
















同一輪／同一批次分析開始時，**先以該客戶最新 `V70產出-<客戶名字>.md` 作為 Global Snapshot seed**，再補齊V82需要但輸出檔尚未提供或已過期的欄位，形成一份帶有**資料時間與來源日期**的共用快照。至少依當日任務需要涵蓋：
















- Fed政策路徑／FOMC最新狀態
- 2Y／5Y／10Y／20Y／30Y美債殖利率
- 10Y實質利率與必要的期限溢價
- CPI／Core CPI／PCE／Core PCE／Headline PPI／Core PPI最新已公布值、PPI主要分項（資料可得時）與下一公布時間
- 5Y／10Y Breakeven與必要的5y5y
- HY OAS／IG OAS／BBB OAS
- VIX／MOVE
- Treasury市場功能與重大流動性異常
- Repo／SOFR／SOFR-OIS／FRA-OIS等在出現異常或標的敏感時的下鑽資料
- DXY
- USD/JPY、BOJ與日圓套利風險層級
- WTI／Brent
- S&P 500／Nasdaq等主要市場母體狀態
- 本輪真正可能影響多檔標的的重大政策、地緣政治與系統性新聞
















**同一輪中的0050、NATO、VWRA、PPH、QQQ、SOXX及其他股票／股票ETF共享這份Snapshot，不得為每一檔重複從頭查同一組Macro資料。**
















## 2. 標的層只抓Asset Delta
















每一檔標的只追加自己的增量資料：
















- 最新價格／OHLCV
- 自身TD9、KD、MACD、MA、EMV、RSI、ATR、成交量
- Confirmed Swing High／Low與價格地圖
- 自身基本面、估值、財報／財測
- 成分股／Look-through與專屬產業因子
- 標的專屬重大新聞、政策與機構展望
- Project Target Position、AP／Confirmed Position、Actual Completion Rate、剩餘可建倉額度與專案上限
















## 3. 共用資料有重大變化才刷新Snapshot
















若同一輪內出現FOMC、CPI／PPI／PCE、重大戰爭、信用利差急變、VIX／MOVE急升、Treasury／Repo異常或其他系統性事件，才刷新共用Snapshot；一般標的價格變動只更新Asset Delta。
















## 4. 效能原則
















> **共用資料只查一次；標的資料各自更新；安全資料變化時才重建共享快照。**
















---
















# 第六十四章｜價格地圖重新驗證
















每次正式分析都必須重新驗證價格地圖，但**重新驗證不等於每檔無差別重抓全部共用資料**。
















固定流程：
















1. 讀取本輪Global Snapshot。
2. 更新該標的Asset Delta：最新價格、OHLCV、技術、Swing、ATR、基本面、估值、專屬新聞與專案部位。
3. 比較目前價格地圖使用的Swing High／Low、均線、ATR、估值與基本面假設是否仍成立。
4. 若共用Macro／信用／流動性在本輪沒有重大變化，不重複抓取；直接引用帶時間戳的Snapshot。
5. 若價格結構、基本面、估值或風險環境實質改變，才重算價格地圖並說明是哪個錨點造成調整。
















若重新驗證後原價格地圖仍合理，必須寫：
















> **依最新資料以V82重新驗證後維持不變。**
















每日重算／重驗：
















**不等於每日修改。**
















---
















# 第六十五章｜掛單規則
















## 可以掛
















- 價格進入V82可部署的合理／甜甜價／更深折價區
- 信用安全
- 流動性安全
- 基本面／投資論點未破壞
- 非Runaway Down
- 重大事件Gap風險可控
- ATR若快速擴張，已反映在掛單距離與單筆大小
















技術初步止跌可提高掛單積極度，但**不再是Base／Left第一筆預掛的必要條件**。
















## 不宜掛
















- 財報前
- FOMC前
- CPI／PCE重大公布前
- Runaway Down
- 信用快速惡化
- ATR暴增
- 戰爭快速發展
- 政策快速發展
- FDA／監管結果即將公布
















---
















# 第六十六章｜掛單取消
















已掛單若出現：
















- 財測下修
- HY OAS急升
- VIX急升
- MOVE異常
- 支撐失守
- Runaway Down
- 政策重大利空
- 產業基本面惡化
- 估值假設失效
















立即：
















**取消掛單＋重新跑V82。**
















---
















# 第六十七章｜技術停利
















歸入：
















**技術減碼。**
















普通過熱：
















小幅減碼。
















高檔多項共振：
















提高減碼。
















Runaway Up仍成立：
















不得一次賣光。
















趨勢真正破壞：
















提高減碼。
















---
















# 第六十八章｜硬性停損
















歸入：
















**真正降低風險。**
















需要：
















- 投資論點失效
- 關鍵價格結構破壞
- 週／月線重大失守
- 基本面重大惡化
- 信用／流動性危機
- 公司治理／財務危機
















不得因市場雜訊頻繁停損。
















---
















# 第六十九章｜專案資金映射、Actual Completion Rate與Target Rate
















V82決定：
















- 六類特殊分類（若皆未成立則為「無特殊分類」）
- Base／Left／Right／Trend Deployment Mode
- 價格吸引力
- 訊號成熟度
- 是否需要加速或減速
- 是否出現Hard Gate
















但真正絕對金額：
















**由各客戶專案自己的配置決定。**
















固定公式：
















**專案目標部位  
− 現有部位  
＝ 剩餘可建倉部位**
















新增核心公式：
















**Actual Completion Rate  
＝ AP ÷ Project Target Position**
















V82再判斷：
















- 目前是否低配
- 目前價格／條件對應的Canonical Deployment Target Rate
- 本次預估成交後完成率（Projected；Fill後由Actual Completion Rate重算）
- 是否需要Base／Left／Right／Trend加速
















若專案已指定：
















- 預算
- 目標配置
- 部位上限
- 特殊階梯
- 單筆金額
- 可用資金來源
















直接換算：
















**金額＋股數＋預估成交後完成率；實際Fill後再以Confirmed Position重算Actual Completion Rate。**
















若專案沒有預算資料：
















不得擅自假設絕對金額。
















只能輸出：
















**相對於Project Target Position的Deployment Mode與Canonical Deployment Target Rate建議。**
















核心：
















> **專案決定終點；V82決定現在往終點走多快。**
















# Work2｜V82系統工程35～39｜Canonical Deployment × Execution Contract【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。**  
> 本段源自Work2工程35～39的工程化封口，現已由工程77納入正式SOT；不新增投資Threshold／Default／Fallback，不改20號Primary Priority，不改Structural Break／Emergency既有Business Rule Owner。

## 工程35｜九階梯累積部署 Canonical Contract

九階梯正式且唯一的`Canonical Deployment Target Rate`維持：

| Deployment Stage | Canonical Deployment Target Rate |
|---|---:|
| `STAGE_1` | 10% |
| `STAGE_2` | 20% |
| `STAGE_3` | 30% |
| `STAGE_4` | 45% |
| `STAGE_5` | 60% |
| `STAGE_6` | 75% |
| `STAGE_7` | 85% |
| `STAGE_8` | 95% |
| `STAGE_9` | 100% |

固定Invariant：

1. 九階梯是**累積目標完成率**，不是「本次再買10%／20%／45%」。
2. `Canonical Deployment Target Rate`只回答「目前合理累積到Project Target Position的多少」；`Actual Completion Rate`回答「已確認實際部位完成多少」，兩者禁止混用。
3. **五層Price Map ≠ 九階Deployment Ladder。** Price Map回答價格位於哪一層；Deployment Ladder回答資金累積應到哪一階。禁止建立固定`Layer 1→Stage 1`之類機械一對一映射。
4. Stage只能由既有V82價格、估值、基本面、技術、Macro／信用／流動性、Special Classification、Deployment Mode及專案限制共同裁決；不得由單一Price Layer自行推導Stage。
5. 舊五段／舊比例若仍存在於歷史說明，只作歷史證據；自本工程起不得進Executable Branch。
6. Stage上升只提高當下`Canonical Deployment Target Rate`；若已確認部位或有效掛單已達／超過該Target，本輪自然不新增。Stage下降本身也**不自動生成Sell Intent**。
7. `Deployment Stage`的Machine-readable名稱固定保持中性`STAGE_1`～`STAGE_9`；**不得把`Base Deployment / Left Overweight / Right Confirmation / Trend Deployment`寫進Stage Enum名稱**。Stage是累積目標層級，Mode是部署方式；Work3才負責Mode的Eligibility／Entry／Upgrade／Hold條件。

Canonical mapping：

```text
canonical_deployment_target_rate = ladder_rate(canonical_deployment_stage)
```

若`canonical_deployment_stage`為`UNKNOWN`，Target Rate也必須`UNKNOWN`；不得用前一輪Stage、0%、100%或任一Default補值。

---

## 工程36｜Execution Contract

### 36-A｜五種Domain必須分開

1. `Recommendation`：V82／LivingWaterAI的分析與正式建議。
2. `Order Intent`：已決定要建立／取消／替換訂單的內部執行意圖，但尚未等於券商訂單。
3. `Order Lifecycle State`：券商訂單生命週期。
4. `Fill`：實際成交事件。
5. `Confirmed Position`：經Confirmed Fill／券商持倉Snapshot完成對帳後的正式部位事實。

最高Invariant：

> **Recommendation ≠ Order Intent ≠ Submitted/Open Order ≠ Fill ≠ Confirmed Position。**

只有Confirmed Fill／券商確認持倉可以更新AP；Open／Pending／GTC未成交部分只能形成Active Order Exposure，不得提前改AP。

### 36-B｜Canonical Order Lifecycle State

| State | 語意 | Active Order Exposure |
|---|---|---|
| `SUBMITTED` | 已送出、尚待完整券商狀態確認；因可能成交，採有效曝險處理 | **YES**，計未成交剩餘量 |
| `OPEN` | 券商已接受且仍可成交 | **YES**，計未成交剩餘量 |
| `PARTIAL_FILL` | 已部分成交，其餘仍可成交 | **YES**，只計未成交剩餘量；已成交部分進Fill／Position Reconciliation |
| `FILLED` | 訂單全部成交 | **NO**；但必須先轉入Confirmed Fill／Position Reconciliation並納入AP後，才能重新計算Gap |
| `CANCEL_PENDING` | 已送取消、券商尚未確認取消 | **YES**；取消確認前舊單仍視為可能成交 |
| `CANCELLED` | 券商已確認取消 | **NO** |
| `REPLACE_PENDING` | 已要求替換，但舊單是否解除尚未完成確認 | **YES**；舊Live Order在解除前仍計曝險；Replace Request本身不得重複計一次 |
| `REPLACED` | 舊訂單已被替換／終止 | **NO**；新Successor Order依自己的State另計 |
| `REJECTED` | 券商拒絕訂單 | **NO** |
| `EXPIRED` | 訂單到期失效 | **NO** |

`GTC`正式屬於**Time-in-Force**，不是Order Lifecycle State：

```text
time_in_force = GTC
```

GTC只要其Lifecycle仍為`SUBMITTED / OPEN / PARTIAL_FILL / CANCEL_PENDING / REPLACE_PENDING`，未成交剩餘量就持續構成Active Order Exposure；跨日不因「已掛很久」自動歸零。

### 36-C｜Remaining Quantity與Exposure

對每一張券商訂單：

```text
remaining_qty = MAX(order_qty - confirmed_filled_qty, 0)
```

只有Lifecycle屬於Active集合時，`remaining_qty`才進Active Exposure；Terminal State固定不進。

`REPLACE_PENDING`不得把「舊單剩餘量＋尚未成為Live Order的新Replace Intent」雙算。若券商實際同時回報兩個不同Live Order ID，則依各自真實Lifecycle逐單計算，不得靠本地推測去重。

若Order State、Filled Quantity或Order ID無法可靠確認，Active Exposure不得猜0；依既有Data Sufficiency規則標`UNKNOWN`，污染依賴它的Gap／Buy Permission。

### 36-D｜State Transition與T+1邊界

- `Order Intent`只有真正送到券商後才進`SUBMITTED`。
- `PARTIAL_FILL`只把已確認成交部分更新至Fill；剩餘部分仍屬Active Exposure。
- `FILLED`／已確認的成交若尚未完成Position Reconciliation，**不得在Gap計算中同時從Active Exposure消失、又尚未進Confirmed Position**。同一run若存在這種reconciliation lag，依賴Gap的正常新增Buy Execution必須維持`UNKNOWN / blocked by data insufficiency`，直到Confirmed Fill已納入AP。
- `CANCEL_PENDING`直到券商回`CANCELLED`前，舊曝險不解除。
- `REPLACE_PENDING`直到舊單被確認`REPLACED / CANCELLED / FILLED / REJECTED / EXPIRED`等終止狀態前，不得假設舊曝險消失。
- T+1 Gap Recheck只負責重新檢查事件Gap與Permission；**不改寫券商Order Lifecycle State**。

---

## 工程37｜金額／股數／交易單位 Canonical Math Contract

### 37-A｜共同數學基準

所有Target、Confirmed Position與Active Position Exposure必須在**同一run、同一Base Currency、同一Canonical Valuation Price基準**下計算。不得把不同時間點／不同幣別／不同價格基準的金額直接相減。

正式區分：

- `canonical_valuation_price`：本輪用來把已確認股數／Active Position Exposure換成可比較部位金額的共同估值價格。
- `order_working_price`：實際Order Intent／Live Order的工作價格，用於訂單Notional、現金保留與Tick轉換。
- 兩者用途不同，禁止混用。

### 37-B｜Target Amount

```text
target_amount
= project_target_position_amount
× canonical_deployment_target_rate
```

Input：客戶專案已核准`project_target_position_amount`＋工程35 Rate。  
Formula：如上。  
Rounding：Target內部運算保持高精度；只在客戶顯示層依Base Currency格式化。  
Output：`canonical_deployment_target_amount`。

若Project Target或Rate為`UNKNOWN`，Target Amount也為`UNKNOWN`；Hard Gate不得用0取代它。

### 37-C｜Current Amount／Confirmed Amount

`Current Amount`是目前資料源觀察到的部位估值；未確認來源可供顯示／對帳，但不得直接進正式Gap：

```text
current_amount
= current_position_qty
× canonical_valuation_price
```

只有確認後的部位能進正式Gap：

```text
confirmed_amount
= confirmed_position_qty
× canonical_valuation_price

confirmed_position_amount ≡ confirmed_amount
```

若券商直接提供Confirmed Market Value，只有在可驗證其幣別、時間與本輪估值基準一致時才可直接使用；否則以Confirmed Quantity × 同一本輪Canonical Valuation Price重建可比較金額。

### 37-D｜Active Buy／Sell Position Exposure

先逐單計算Active Remaining Quantity，再用同一本輪估值價格換成「預計部位曝險」：

```text
active_buy_exposure_amount
= SUM(active_buy_remaining_qty_i × canonical_valuation_price)

active_sell_exposure_amount
= SUM(active_sell_remaining_qty_i × canonical_valuation_price)
```

它們服務Deployment Gap，不能拿Order Limit Price造成的Notional差異污染部位比較。

### 37-E｜Reserved Cash／Available Cash

若券商提供**已扣除保留款後**的正式`available_to_trade`／等價欄位，直接採該值，不得再次扣Active Buy Exposure造成Double Count。

若資料源只提供Gross Confirmed Cash，才使用：

```text
reserved_cash
= broker_confirmed_order_reservation
  OR
  SUM(active_buy_remaining_qty_i × order_reservation_price_i)
  + other_explicit_project_reservations

available_cash
= MAX(confirmed_cash - reserved_cash, 0)
```

`broker_confirmed_order_reservation`若存在且定義可信，優先於本地重算。手續費、稅費或Market Order Reservation若無可靠來源，不得自創費率；必要時使可下單金額／Permission為`UNKNOWN/FALSE`，而不是猜0成本。

### 37-F｜Maximum Allowed Buy Amount／Buy Amount

工程38先產生Final Deployment Gap；工程39再產生`new_buy_order_permission`。

在Permission為TRUE時：

```text
positive_deployment_gap = MAX(final_deployment_gap_amount, 0)

maximum_allowed_buy_amount
= MIN(
    positive_deployment_gap,
    available_cash,
    all_applicable_explicit_authorized_caps
  )

buy_amount_pre_round = maximum_allowed_buy_amount
```

`all_applicable_explicit_authorized_caps`只可使用既有已核准限制，例如客戶專案上限、V70已核准Tactical Budget、Asset Grade／Concentration／Look-through既有上限或其他明確Owner輸入；**不得在本工程創造新百分比、Default或Fallback。**

若任一「必須參與MIN」的Required Cap為UNKNOWN，本輪不得假設無上限；依Data Sufficiency處理。

### 37-G｜Sell Amount

**負的Deployment Gap本身不自動生成Sell Intent。** 正常Deployment不因高於某一階梯就機械賣回。

真正Sell Required Amount必須由既有Owner產生，例如Structural Break／Emergency／正式Risk Reduction或明確Client Autonomous Action。Work2只做淨額數學：

```text
net_new_sell_amount_pre_round
= MAX(
    owner_required_sell_amount - active_sell_exposure_amount,
    0
  )

sellable_confirmed_amount
= MAX(
    confirmed_amount - active_sell_exposure_amount,
    0
  )

maximum_allowed_sell_amount
= MIN(
    net_new_sell_amount_pre_round,
    sellable_confirmed_amount,
    all_applicable_explicit_sell_caps
  )
```

Hard Gate不得把合法Risk Reduction Sell Permission關掉；但券商持倉、Order State、Lot／Precision等Execution Safety仍必須可驗證。

### 37-H｜Shares／Fractional Shares／Minimum Lot

Buy Raw Quantity：

```text
raw_buy_qty = buy_amount_pre_round / order_working_price
```

- 支援Fractional Shares：依券商／交易所明確允許的Fractional Increment／Precision向下正規化，確保最終Buy Notional不超過`maximum_allowed_buy_amount`。
- 不支援Fractional Shares：

```text
rounded_buy_qty
= FLOOR(raw_buy_qty / minimum_lot) × minimum_lot
```

Sell Raw Quantity：

```text
raw_sell_qty = maximum_allowed_sell_amount / order_working_price
```

Sell端的合法Quantity Normalization由Execution Adapter依市場Lot／Fractional規則處理；**不得因缺少已核准Rounding Policy而自行發明「一律向上多賣」**，且最終不得超過可賣Confirmed Quantity。若無法形成合法交易單位，本輪輸出「有Gap／有Required Amount，但沒有可合法送出的新Order Quantity」，不得把Gap改寫成0。

### 37-I｜Minimum Tick／Price Rounding

```text
valid_order_price
= execution_adapter.normalize_to_tick(
    raw_order_price,
    side,
    order_type,
    execution_intent,
    minimum_tick
  )
```

V82不另造全市場通用「買單一律向下／賣單一律向上」Fallback；必須由Execution Adapter依交易市場、Order Type與原始Execution Intent產生合法價格。若Tick Rule未知，Order不得正式提交。

### 37-J｜Final Order Notional

```text
final_order_notional
= rounded_order_qty × valid_order_price
```

Buy端固定要求：

```text
final_buy_order_notional <= maximum_allowed_buy_amount
```

若因Lot／Tick／Fractional限制使最小合法Order超過Maximum Allowed Amount，本輪不送單；不得為了「湊一股／湊一張」突破Target、Cash或任何既有上限。

### 37-K｜Machine Math Matrix｜Input → Formula → Rounding → Output

| 項目 | Input | Formula／Rule | Rounding | Output |
|---|---|---|---|---|
| Target Amount | Project Target Amount、Canonical Target Rate | `project_target_position_amount × canonical_deployment_target_rate` | 內部高精度；只在顯示層做幣別格式化 | `canonical_deployment_target_amount` |
| Current Amount | Current Qty、Canonical Valuation Price | `current_position_qty × canonical_valuation_price` | 內部高精度 | `current_amount`；未確認不得進Final Gap |
| Confirmed Amount | Confirmed Qty、Canonical Valuation Price | `confirmed_position_qty × canonical_valuation_price` | 內部高精度 | `confirmed_position_amount` |
| Active Order Remaining Qty | Order Qty、Confirmed Filled Qty、Lifecycle State | Active State時`MAX(order_qty-confirmed_filled_qty,0)`；Terminal State=0 Exposure | Quantity Precision只依Execution Adapter | `active_order_remaining_qty` |
| Active Buy Exposure | Active Buy Remaining Qty、Canonical Valuation Price | `SUM(qty × canonical_valuation_price)` | 內部高精度 | `active_buy_exposure_amount` |
| Active Sell Exposure | Active Sell Remaining Qty、Canonical Valuation Price | `SUM(qty × canonical_valuation_price)` | 內部高精度 | `active_sell_exposure_amount` |
| Reserved Cash | Broker Reservation或Active Buy Remaining Qty＋Reservation Price＋明確其他保留款 | Broker正式Reservation優先；否則逐單加總，不猜費率 | 依Base Currency合法精度顯示；內部不先四捨五入 | `reserved_cash` |
| Available Cash | Broker Net Available，或Gross Confirmed Cash＋Reserved Cash | Net Available直接採；否則`MAX(confirmed_cash-reserved_cash,0)` | 內部高精度 | `available_cash` |
| Final Deployment Gap | Target、Confirmed、Active Buy／Sell | `target - (confirmed + active_buy - active_sell)` | Gap Sign用未顯示四捨五入的內部值 | `final_deployment_gap_amount` |
| Maximum Allowed Buy Amount | Positive Gap、Available Cash、所有適用且已核准Caps | `MIN(MAX(gap,0), available_cash, applicable_caps...)` | 先不做交易單位Rounding | `maximum_allowed_buy_amount` |
| Buy Shares | Maximum Allowed Buy Amount、Order Working Price、Fractional／Lot規則 | `raw_buy_qty=amount/price` | Fractional依合法Increment向下；Whole Lot=`FLOOR(raw/minimum_lot)×minimum_lot` | `rounded_buy_qty` |
| Buy Amount | Rounded Buy Qty、Valid Order Price | `rounded_buy_qty × valid_order_price` | 已完成Qty／Tick正規化 | `final_buy_order_notional`，不得超過Maximum Allowed Buy Amount |
| Owner Required Sell Amount | Structural Break／Emergency／正式Reduction Owner輸入、Active Sell Exposure | `MAX(owner_required_sell_amount-active_sell_exposure_amount,0)` | 先不做交易單位Rounding | `net_new_sell_amount_pre_round` |
| Maximum Allowed Sell Amount | Net New Sell Need、Sellable Confirmed Amount、明確Sell Caps | `MIN(net_new_sell_amount_pre_round, sellable_confirmed_amount, applicable_sell_caps...)` | 先不做交易單位Rounding | `maximum_allowed_sell_amount` |
| Sell Shares | Maximum Allowed Sell Amount、Order Working Price、Lot／Fractional Policy | `raw_sell_qty=amount/price` | 只用已核准Execution Adapter Policy；不得自行發明向上多賣Fallback | `rounded_sell_qty`或`ROUNDING_POLICY_REQUIRED/UNKNOWN` |
| Minimum Lot | Market／Broker Metadata | Constraint，不自行猜值 | 依Execution Adapter | `minimum_lot` |
| Fractional Shares | Broker Capability＋Fractional Increment／Precision | Constraint | 依明確Fractional Increment／Precision | `fractional_share_capability/rounded_qty` |
| Minimum Tick | Market／Broker Metadata、Side、Order Type、Execution Intent | `normalize_to_tick(...)` | Execution Adapter決定，不建全市場通用方向Fallback | `valid_order_price` |
| Maximum Allowed Amount | Buy或Sell Context、Gap／Owner Need、Cash／Position、核准Caps | Buy用Maximum Allowed Buy；Sell用Maximum Allowed Sell | 交易單位正規化前為高精度上限 | `maximum_allowed_amount_by_side` |

若任一Required Input為`UNKNOWN`，其依賴Output也必須沿Lineage標`UNKNOWN`；不得以0、False、前一輪值或Generic Default補齊。

---

---

## 工程38｜Deployment Target／Gap／Completion Canonical Contract

### 38-A｜Projected Position

```text
projected_position_amount
= confirmed_position_amount
+ active_buy_exposure_amount
- active_sell_exposure_amount
```

只有工程36判定為Active的訂單未成交剩餘量才進Projected Position；Terminal Order不得進。

正常Long-only V82 Deployment中，若上述投影因Active Sell／Order Reconciliation衝突而出現`projected_position_amount < 0`，不得把負值當成正常可補回的Deployment Gap；應標記`INVALID_EXECUTION_STATE / RECONCILIATION_REQUIRED`並阻擋新的正常Buy Execution，直到Order／Position Truth對帳完成。Work2不因此新增Short／Hedge規則。

### 38-B｜Final Deployment Gap

```text
final_deployment_gap_amount
= canonical_deployment_target_amount
- projected_position_amount
```

正式解讀：

- `Gap > 0`：在「已確認部位＋現有Active Orders都成交」的投影下，仍低於本階梯Canonical Target；只表示**尚有可部署需求**，不等於自動可買，仍要過Cash／Caps／Priority／`new_buy_order_permission`。
- `Gap = 0`：投影後正好達Target；本輪正常Deployment不新增。
- `Gap < 0`：投影後高於本階梯Target；**不自動賣出**。是否Sell只能由既有Structural Break／Emergency／Risk Reduction／Rebalance Owner或Client Autonomous Action決定。

Active Sell可能讓Gap轉正，但若該Sell來自Risk Reduction／Emergency，Cross-domain Priority仍可讓新增Buy Permission保持FALSE；不得邊減碼邊因數學Gap機械補回。

### 38-C｜Completion Rate必須拆成三個不同概念

```text
actual_completion_rate
= confirmed_position_amount / project_target_position_amount

projected_completion_rate
= projected_position_amount / project_target_position_amount

canonical_deployment_target_rate
= 工程35九階梯Rate
```

- `Actual Completion Rate`只看Confirmed Position。
- `Projected Completion Rate`只作Active Orders全部依現況成交後的診斷值；不得冒充Actual。
- `Canonical Deployment Target Rate`是本輪應累積到的目標階梯；不得改名成Completion Rate。
- Actual／Projected可大於100%，以保留真實超配資訊；不得靜默Clamp到100%。
- 若`project_target_position_amount = 0`是客戶專案明確事實，Target Amount可為0，但除法型Completion Rate為`UNKNOWN / not computable due zero denominator`；不得除以0。若Target本身未知，也同樣UNKNOWN。

### 38-D｜Determinism／Same-run要求

相同Input Snapshot、相同Order Lifecycle、相同Canonical Valuation Price、相同Execution Adapter規則，必須得到相同Target／Projected Position／Gap／Completion／Order Math結果。

所有公式先以高精度內部值運算，Currency Display、Lot、Tick、Fractional Rounding最後才做；不得用顯示層四捨五入值反推Gap Sign。

如果`Gap > 0`但小於最小合法Order Unit，本輪應記錄**positive non-executable residual gap**；不得把它改寫成0，也不得突破交易單位限制硬送單。

---

## 工程39｜Hard Gate Canonical Permission Contract

Hard Gate正式只控制**新的Buy Execution Permission**；不改寫客戶目標，也不自動產生Sell。

### 39-A｜六個物件必須分離

1. `Canonical Target`：由Project Target × 工程35 Rate決定；**先於Hard Gate存在**。
2. `Final Deployment Gap`：由工程38決定；Hard Gate不得把Gap改成0。
3. `new_buy_order_permission`：是否允許建立新的Buy Order Intent／Submit。
4. `risk_reduction_sell_permission`：是否允許既有Owner要求的Risk Reduction Sell進Execution；不受Hard Gate否決，但仍受Execution Safety／Position Truth限制。
5. `LivingWaterAI Recommendation`：系統可輸出買／不買／風險處理／觀察建議；不得把「分析建議」與「券商Permission」混成一個欄位。
6. `Client Autonomous Action`：客戶在完整揭露風險後自行決定的行動；必須標記為客戶自主，不能回寫成V82正式Recommendation或用來篡改Target／Gate。

### 39-B｜Canonical New Buy Permission

沿用工程22 Data Sufficiency分流與既有Hard Gate條件：

```text
new_buy_order_permission = TRUE
ONLY IF
    data_sufficiency_gate == PASS
AND hard_gate_evaluation == NOT_TRIGGERED
AND higher_priority_risk_state_allows_new_buy == TRUE
AND required_project_limits_and_execution_inputs_are_known
```

`new_buy_order_permission`只回答「安全／治理上是否允許新的Buy Execution」，**不得把Deployment Gap的正負塞進Permission本身**。真正建立新的Executable Buy Order必須另外同時滿足：

```text
new_buy_order_permission == TRUE
AND final_deployment_gap_amount > 0
AND maximum_allowed_buy_amount > 0
AND legal_order_quantity > 0
```

因此：

- `hard_gate_evaluation = TRIGGERED` → `new_buy_order_permission = FALSE`，原因=`HARD_GATE_TRIGGERED`。
- Required Safety Data不足／`data_sufficiency_gate != PASS` → `FALSE`，原因=`DATA_INSUFFICIENCY`；不得假裝市場Hard Gate已觸發。
- `Gap <= 0` → **Permission可維持TRUE，但本輪沒有正的Deployment Need，所以Execution Result＝本輪不新增**；這不是WAIT或新Classification。
- Higher-priority Risk Reduction／Emergency／Structural Break正在接管且不允許新增曝險 → `FALSE`；不得因Active Sell造成Gap轉正就機械補買。

正式欄位名稱固定使用：

```text
new_buy_order_permission
```

不得用`new_order_permission`同時含買與賣。

### 39-C｜Hard Gate不得做的事

- 不得把合理`Canonical Target`改成0。
- 不得把`Final Deployment Gap`改成0以隱藏尚未完成部位。
- 不得把`hard_gate_evaluation=UNKNOWN`偽裝成`NOT_TRIGGERED`。
- 不得只因Hard Gate ON自動生成Sell Intent。
- 不得阻擋已由Structural Break／Emergency／其他正式Risk Reduction Owner要求的必要Sell；真正Sell仍依其Owner＋工程36～37 Execution Safety執行。

### 39-D｜Recommendation與Client Autonomous Action

當`new_buy_order_permission=FALSE`時，LivingWaterAI仍可產出「不新增／風險警告／等待資料／執行既有Risk Reduction」等Recommendation；**不得產生會繞過Permission的正向Executable Buy Recommendation。**

客戶若在完整風險揭露後仍自行交易：

```text
action_source = CLIENT_AUTONOMOUS
v82_formal_recommendation_unchanged = TRUE
```

客戶自主Buy不得反向把`new_buy_order_permission`改TRUE；成交後只能依Confirmed Fill／Broker Position更新AP，再由下一輪重新計算Target／Gap／Completion。

### 39-E｜對既有下單前檢查表的Canonical解讀

既有文字「任何Hard Gate未完成：LivingWaterAI本輪不得建議、產生或執行新增買進／加碼送單」在Work2 Staging中正式解讀為：

> **不得產生或執行正向Executable Buy Recommendation／Order；但仍必須允許系統輸出『不買、警告、等待資料、取消風險掛單、必要Risk Reduction』等風險建議。**

這是語意封口，不是放寬Buy Gate。

---

## Work2｜35～39 串接總公式【正式｜工程77封版】

```text
Project Target Position
× Canonical Deployment Target Rate
= Canonical Deployment Target Amount

Confirmed Position Amount
+ Active Buy Exposure Amount
- Active Sell Exposure Amount
= Projected Position Amount

Canonical Deployment Target Amount
- Projected Position Amount
= Final Deployment Gap

Data Sufficiency / Hard Gate / Higher-priority Risk / Required Execution Inputs
→ new_buy_order_permission

Final Deployment Gap
+ new_buy_order_permission
+ Cash / Existing Caps
→ Maximum Allowed Buy Amount
→ Legal Price / Lot / Fractional Quantity
→ Order Intent
→ Submitted / Open / Partial Fill / ...
→ Confirmed Fill
→ Confirmed Position / AP
→ Next-run Reconciliation
```

固定不變量：

> **Target先算、Gap再算、Permission最後裁決。Gate只能擋新的Buy Execution，不能改Target；Order Exposure不能假裝成Position；未確認成交不能提前改AP。**

---


# Work3｜V82系統工程40～44｜Deployment Mode × Runaway Contract【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。**  
> 本段源自Work3工程40～44的工程化封口，現已由工程77納入正式SOT；承接Work2已定稿的`STAGE_1`～`STAGE_9`、Final Deployment Gap、`new_buy_order_permission`、Order Reconciliation與20號Primary Priority。**不新增投資Threshold／Default／Fallback，不改九階梯數值，不改Hard Gate、Structural Break、Reduction、Emergency既有Rule Owner。**

## Work3-A｜四種Deployment Mode共同裁決契約

正式`Deployment Mode`仍且只允許四種：

```text
Base Deployment
Left Overweight
Right Confirmation
Trend Deployment
```

`Deployment Mode`回答「正常資金如何往Canonical Target部署」；`Special Classification`回答「目前是否有左側／右側／Runaway Up／Runaway Down等特殊狀態」。兩者維持不同型別。

### A-1｜Normal Mode Selection

先完成18號／20號Special Classification Predicate與Primary Priority，再依仍有效的正常部署Context選Mode：

```text
IF runaway_up_predicate == TRUE:
    normal_deployment_mode = Trend Deployment
ELIF runaway_up_predicate == UNKNOWN:
    normal_deployment_mode = UNKNOWN
ELIF right_add_predicate == TRUE:
    normal_deployment_mode = Right Confirmation
ELIF right_add_predicate == UNKNOWN:
    normal_deployment_mode = UNKNOWN
ELIF left_buy_point_predicate == TRUE:
    normal_deployment_mode = Left Overweight
ELIF left_buy_point_predicate == UNKNOWN:
    normal_deployment_mode = UNKNOWN
ELSE:  # runaway_up / right_add / left_buy_point are all confirmed FALSE
    normal_deployment_mode = Base Deployment
```

固定規則：

1. 上述Mode選擇**不凌駕**20號Execution Priority。若真正降低風險、Runaway Down、技術減碼、Emergency／Structural Break等更高層規則已禁止正常新增Buy，Mode可保留作分析Context，但本輪正常Buy Execution仍為0；**不得因此創造第五種「Pause／WAIT Mode」**。
2. 若較高Priority Predicate為`UNKNOWN`且可能改變Mode／Execution，依22號三值邏輯令`normal_deployment_mode = UNKNOWN`，不得把UNKNOWN當FALSE後偷選較低Mode；只有`runaway_up_predicate / right_add_predicate / left_buy_point_predicate`三者都已確認為FALSE時，才可回到`Base Deployment`。
3. 若同一Snapshot非法同時出現`Runaway Up + Runaway Down`或其他20號已定義的互斥衝突，採20號安全Fallback＋Reconciliation；不得靠Mode Selection掩蓋資料衝突。
4. Hard Gate只控制`new_buy_order_permission`；**Hard Gate不得反向把Mode、Stage、Target或Gap改寫成0／NONE／WAIT。**

### A-2｜Stage Reference與Mode分離

Work2已固定中性Stage Enum。Work3只把既有九階梯語意整理成Mode的**Stage Reference**，不改Stage型別：

| 正常部署語意 | Stage Reference | 說明 |
|---|---|---|
| Base Deployment | `STAGE_1` | 基本參與層 |
| Left Overweight | `STAGE_2`～`STAGE_7` | 依既有左側成熟度／折價／安全條件共同裁決 |
| Right Confirmation | `STAGE_8` | 右側確認補強層 |
| Trend Deployment | **最高可到**`STAGE_9` | Runaway Up且仍低配、安全、估值允許時的最高正常部署層 |

這是**既有九階梯的語意對接，不是`Deployment Stage = Deployment Mode`**。此外：

- 五層Price Map不得固定映射到`STAGE_2`～`STAGE_7`；同一Price Layer仍可因估值、基本面、Asset Grade、Macro／信用／流動性與專案限制而得到不同Stage。
- 技術成熟度主要決定**當輪往該Stage Target補多少、補多快**，不得自行創造新的Canonical Target比例。
- Stage下降只改當下Canonical Target；若Projected Position已高於Target，依Work2仍是負Gap／本輪不新增，**不自動產生Sell Intent**。

---

## 工程40｜Base Deployment Canonical Contract

### 40-A｜Entry／Eligibility

`Base Deployment`是沒有Left／Right／Trend正常Mode接管時的基本參與Context。為避免把「Mode是什麼」與「現在能不能送新買單」混在一起，正式拆成兩層：

**Base Deployment Context：**
- 客戶專案已授權該標的作長期配置，Project Target Position可追溯。
- 當輪沒有更高正常部署Mode（Left／Right／Trend）接管。

**Base Execution Eligibility：**
- 投資論點／Fundamentals仍允許長期持有。
- 估值未落入既有規則明確不允許正常追價的極端狀態。
- 更高Priority Risk／Execution沒有阻斷正常新增Buy。
- Work2的`new_buy_order_permission`、Gap、Maximum Allowed Buy Amount、Legal Quantity與Reconciliation全部另外通過。

因此Hard Gate／Data Insufficiency可以令`new_buy_order_permission = FALSE`而阻斷Base新Buy，但**不必把分析上的Base Deployment Context、Canonical Target或Gap抹掉**。若左側、右側或Runaway Up Predicate成立，正常Mode依Work3-A切換到Left／Right／Trend；Base不與三者建立第二筆Buy Intent。

### 40-B｜Deployment Stage

當Base是當輪正常Mode時，Stage Reference為`STAGE_1`。最終`canonical_deployment_stage`仍須通過Work2既有Stage資料完整度與專案限制；若Required Stage Input不足，Stage＝`UNKNOWN`，不得預設`STAGE_1`。

### 40-C｜Upgrade Condition

Base不靠單一技術轉強自動升階。升級只由既有Predicate／條件成立後切換：

- 左側買點Predicate成立 → `Left Overweight`。
- 右側加碼Predicate成立 → `Right Confirmation`。
- Runaway Up Predicate成立 → `Trend Deployment`。

若多者同時成立，依20號Priority／Coexistence處理，不建立重複Buy Intent。

### 40-D｜Hold Condition

以下都可以是合法「維持Base Context但本輪不新增」：

- Projected Position已達／高於Base Canonical Target。
- Gap＝0或Gap<0。
- Minimum Lot／Precision使合法Order Quantity為0。
- Available Cash／Authorized Cap使Maximum Allowed Buy Amount為0。
- Existing Active Order已占用本輪Gap。

這些都是Execution Result，不是WAIT State，也不代表Base失效。

### 40-E｜No-New-Buy Condition

真正建立新Base Buy Order必須同時滿足Work2：

```text
new_buy_order_permission == TRUE
AND final_deployment_gap_amount > 0
AND maximum_allowed_buy_amount > 0
AND legal_order_quantity > 0
AND reconciliation_required != TRUE
```

任一不成立，本輪不建立新Base Buy Order；Gap若仍為正數要保留，不得被改寫為0。

### 40-F｜Technical Speed Adjustment

Base中的TD9／KD／MACD／MA／EMV／RSI／Volume只調整**當輪切片大小、分單節奏與後續補足速度**：

- 技術仍弱但安全層正常：可只補Canonical Target的一部分，不必把第一筆長期參與改成0。
- 技術改善：可加快向同一Canonical Target補足。
- 技術惡化到20號更高Priority分類成立：交由該分類／風險Owner接管，Base不得自行另造降速門檻。

**Work3不建立新的技術倍率、天數或百分比。**

### 40-G｜Hard Gate／Gap Interaction

- Hard Gate Triggered／Safety Data不足：關閉新的Buy Permission；Base Stage／Target／Gap保持可追溯。
- Gap>0：只表示「尚有部署需要」，不是Buy Permission。
- Gap<=0：本輪正常Base不新增，但Permission本身不因Gap正負被改寫。
- `FILLED → Confirmed Position`尚在Reconciliation空窗：依Work2暫停依賴Gap的新Buy，先完成對帳。

---

## 工程41｜Left Overweight／正式左側分類 Canonical Contract

18號語意固定：**`左側買點`＝Special Classification；`Left Overweight`＝Deployment Mode。** 左側不是Base的別名。

### 41-A｜Discount／Price Map Position

左側價格條件沿用既有V82，至少一項成立即可形成價格側證據，例如：

- 進入既有第一左側／甜甜價／更深折價語意。
- 接近前低／Confirmed Swing Low。
- 接近重要MA／成交密集區／歷史支撐。
- 回撤達該標的股性具有意義的程度。
- 估值回到合理／便宜區。

**不得在Work3新增固定回撤百分比，也不得把五層Price Map固定綁成九階Stage。** Price Map Penetration只提供價格位置證據。

### 41-B｜Oversold

Low TD9、KD低檔、RSI低檔、MACD空方動能收斂、EMV改善等Oversold／成熟訊號是**部署速度證據**，不是左側第一筆Entry的必要門票。單一Oversold也不能繞過Fundamentals、Credit／Liquidity、Runaway Down或Hard Gate。

### 41-C｜Valuation Cheap

估值合理／便宜可提高左側可信度與Stage裁決的折價證據；但Valuation Level本身不是Buy Permission。估值UNKNOWN依22號傳遞，不能自動當便宜。

### 41-D｜Fundamentals／Credit／Liquidity

左側成立的安全層沿用既有規則：

- Fundamentals／Investment Thesis仍允許長期持有。
- 不得有會阻斷正常新增Buy的信用／流動性Hard Gate。
- `Runaway Down`不得成立。
- 重大未落地事件若依工程34需要T+1 Gap Recheck，只有依賴該Event Gap的Downstream Predicate在`PASSED`後才能解除；不得用價格便宜跳過T+1。

### 41-E｜Entry

左側Predicate沿用20號：

```text
left_buy_point_predicate =
    price_condition_at_least_one == TRUE
AND fundamentals_long_term_viable == TRUE
AND left_safety_negations_absent == TRUE
```

當左側Predicate＝TRUE且沒有更高正常Mode接管時，`normal_deployment_mode = Left Overweight`。

若Price Condition已成立、但Required Safety Predicate因資料不足為UNKNOWN，Left不得被猜成TRUE；依22號三值邏輯處理。

### 41-F｜Deployment Stage／Deployment Speed

Left使用既有`STAGE_2`～`STAGE_7`左側Stage Reference。既有語意順序保持：第一左側 → 第二左側 → 甜甜價 → 左側成熟／更甜 → 深跌但安全 → 很深折價但仍安全。

| 既有左側梯形語意 | Stage Reference |
|---|---|
| 第一左側 | `STAGE_2` |
| 第二左側 | `STAGE_3` |
| 甜甜價 | `STAGE_4` |
| 左側成熟／更甜 | `STAGE_5` |
| 深跌但安全 | `STAGE_6` |
| 很深折價但仍安全 | `STAGE_7` |

固定Invariant：

1. 上述是**九階梯語意帶**，不是五層Price Map的一對一映射。
2. Stage由價格折價、估值、Fundamentals、安全層、Asset Grade、Macro／信用／流動性與專案限制共同裁決；不得只靠單一跌幅。
3. 技術成熟度不改寫該Stage的Canonical Target；只決定當輪先補多少、後面加多快。
4. Gap與Permission仍依Work2，Left不得建立第二套Gap公式或下單數學。

### 41-G｜Exit

左側Mode退出／被取代時：

- 左側價格／安全Entry條件不再成立 → 重新裁決Base／Right／Trend。
- 右側加碼成立 → `Right Confirmation`取得正常Mode。
- Runaway Up成立 → `Trend Deployment`取得正常Mode。
- Runaway Down／技術減碼／真正降低風險等更高Priority狀態成立 → 正常Buy Execution被Preempt。

**Left退出本身不產生Sell Intent。** 已成交部位保留，是否減碼仍由既有Risk Reduction Owner裁決。

### 41-H｜Base vs Left

| 面向 | Base Deployment | Left Overweight |
|---|---|---|
| 核心目的 | 建立基本長期參與 | 折價安全時提高累積部署 |
| 價格條件 | 不要求左側價格Predicate成立 | 必須有既有左側價格證據 |
| Stage Reference | `STAGE_1` | `STAGE_2`～`STAGE_7` |
| 技術角色 | 調整基本部署速度 | 調整折價區補足速度 |
| Safety | 皆受相同Hard Gate／Risk Priority | 皆受相同Hard Gate／Risk Priority |

---

## 工程42｜Right Confirmation／正式右側分類 Canonical Contract

18號語意固定：**`右側加碼`＝Special Classification；右側確認條件＝Signal；`Right Confirmation`＝Deployment Mode。**

### 42-A｜Entry／Minimum Confirmation Count

右側Predicate沿用既有正式條件：價格已離開最低點，且既有右側確認Signal至少`3`項成立，同時Fundamentals、Credit／Liquidity、安全層與估值條件允許。

三值計數固定：

```text
IF true_signal_count >= 3:
    right_confirmation_signal_state = TRUE
ELIF true_signal_count + unknown_signal_count < 3:
    right_confirmation_signal_state = FALSE
ELSE:
    right_confirmation_signal_state = UNKNOWN
```

- UNKNOWN Signal不得當FALSE，也不得偷偷算TRUE。
- 同一底層事實的別名／重複衍生不得重複計數；每個Canonical Signal最多計一次。
- 「前面通常已做Base／Left」是既有長期部署敘事，不新增成第4個硬Signal，也不把Right改成第一筆買進許可證。

### 42-B｜Technical Confirmation

可計入既有右側確認的Technical Signal包括：KD黃金交叉、MACD空方柱縮短／翻正、DIF向上、EMV轉正、RSI回到既有改善條件等。各技術欄仍遵守22～26號Completed Bar、UNKNOWN、Timeframe與Data Quality規則。

### 42-C｜Price Confirmation

既有Price Confirmation包括：

- 前低墊高／Higher Low。
- 站回MA20。
- 突破下降趨勢或近期壓力。
- 突破後回踩成功。

單一價格反彈不得自動宣告Right成立；仍需總Signal Count達正式最低確認數。

### 42-D｜Volume Confirmation

放量突破等既有Volume／Price-Volume Signal可計為其中一項；Volume缺失時該Signal＝UNKNOWN，**不得用0量或「沒有放量」假資料代替**。只要其他已知True Signal已達最低確認數，Volume UNKNOWN不必把已足夠證據的Right強制改成FALSE。

### 42-E｜Safety／Valuation

右側Entry仍要求：

- Fundamentals未惡化到阻斷正常新增。
- Credit／Liquidity安全。
- 非Runaway Down。
- Valuation未回到既有極高／不允許機械追滿的區域。
- Event-dependent Right若工程34要求T+1 Recheck，必須`PASSED`後才解除依賴該Event Gap的確認。

### 42-F｜Failed Confirmation／Exit

以下任一情況會讓Right失效／退出：

- 已知有效Signal Count降到正式最低確認數以下，且UNKNOWN也不足以改變結果 → FALSE。
- Safety／Fundamental／Valuation Entry不再成立。
- Runaway Down或更高Priority Risk成立。
- Runaway Up成立並成為更高正常Mode → 切到Trend Deployment。
- 必要資料變成UNKNOWN且可能改變Right結果 → Right＝UNKNOWN，不得沿用上一輪TRUE假裝仍有效。

Right退出本身不產生Sell Intent。

### 42-G｜Deployment Stage／Speed

Right的Stage Reference為`STAGE_8`。它的角色是**確認後補強仍存在的Final Deployment Gap**：

```text
right_buy_need = (final_deployment_gap_amount > 0)
```

真正Buy仍同時需要Work2 Permission、Maximum Allowed Buy Amount、合法Quantity與Reconciliation PASS。Right Confirmation不能自行把Target推到Trend的`STAGE_9`，也不能因確認漂亮而超過Project Target／Authorized Caps。

---

## 工程43｜Trend Deployment／Runaway Up Canonical Contract

18號關係固定：**`Runaway Up`＝Special Classification；`Trend Deployment`＝Deployment Mode。** Runaway Up描述市場強勢狀態；Trend Deployment描述低配時如何在強勢市場繼續完成長期配置。

### 43-A｜Strong Trend

沿用既有Runaway Up正式條件：

- A組Price Structure至少`1`項：創既有20日收盤新高／突破Confirmed Swing High／明顯Higher High＋Higher Low。
- B組Strong Confirmation至少`3`項：既有KD、MACD、MA Alignment、EMV、量價、高TD9後仍創高、RSI無明顯背離、EPS／財測未惡化等證據。
- 價格不得明顯低於既有MA20結構要求。

三值計數沿用與工程42相同原則：

```text
A = TRUE      if A_true >= 1
A = FALSE     if A_true + A_unknown < 1
A = UNKNOWN   otherwise

B = TRUE      if B_true >= 3
B = FALSE     if B_true + B_unknown < 3
B = UNKNOWN   otherwise
```

只有A、B與MA20要求可可靠裁決時，才正式建立Runaway Up；不得把UNKNOWN當False或沿用舊TRUE。

### 43-B｜Position Under-deployed

Work3正式把「低配」接到Work2 Execution Math：

```text
position_under_deployed = (final_deployment_gap_amount > 0)
```

`Actual Completion Rate`仍保留作已確認持倉報告，但**是否還需要新的Buy必須看已納入Active Orders的Final Deployment Gap**，避免已掛未成交單被忽略後重複追單。

### 43-C｜Acceleration

Trend加速只在以下共同成立時使用：

- Runaway Up Predicate有效。
- Position Under-deployed。
- `new_buy_order_permission = TRUE`。
- Fundamentals／Credit／Liquidity與既有Safety允許。
- Valuation Constraint未否決更積極追價。
- Project Target／Authorized Caps仍有空間。

技術強勢只加快向合法Canonical Target前進，**不創造第二套Target、不突破Maximum Allowed Buy Amount。**

### 43-D｜Chase Limit

Trend Deployment固定保留既有「不機械追單日極端大陽線」原則。合法執行優先等候／利用既有合理整理、MA5／MA10回踩、突破回測、窄幅整理或趨勢持續確認等價格結構；**Work3不新增固定追價百分比、K棒幅度或等待天數。**

若原低價GTC未成交而市場已進Runaway Up，需重新跑V82與Gap；不得因死守舊單永久缺席，也不得直接把舊掛單價機械抬高追價。

### 43-E｜Valuation Constraint

Runaway Up不凌駕Valuation／Fundamentals。估值過高時可依既有估值規則降低可接受的Stage／Execution強度或令正式Target保持較低；**不得因Trend Deployment直接強迫STAGE_9。**

### 43-F｜Maximum Stage

`Trend Deployment`的**最高正常Stage**為`STAGE_9`，且只能到Project Target Position及所有既有Authorized Caps允許的範圍。STAGE_9是上限，不是Runaway Up成立即必然滿配。

### 43-G｜Invalidation

Runaway Up／Trend至少在下列情況失效或被Preempt：

- A組Price Structure已確定全部不成立。
- B組有效Strong Confirmation降到正式最低數以下。
- 價格明顯跌回既有MA20失效條件。
- Runaway Down、技術減碼、真正降低風險或更高Execution Priority成立。
- 必要Event-dependent Trend判斷的T+1 Gap Recheck未PASSED。
- Valuation／Fundamental／Credit／Liquidity條件不再允許正常Trend新增。

### 43-H｜Cancel Condition

尚未成交的Trend Buy Order至少在以下情況重新評估／取消或替換：

- Trend／Runaway Up正式失效。
- `new_buy_order_permission`由TRUE轉FALSE／UNKNOWN。
- Final Deployment Gap已被Fill／Active Orders關閉。
- 出現Runaway Down／Higher-priority Risk。
- Order／Fill／Position Reconciliation未完成。

Cancel Pending／Replace Pending期間仍依Work2計Active Exposure，確認取消前不得當成Gap重新釋放。

---

## 工程44｜Runaway Down Canonical Contract

`Runaway Down`仍是**Special Classification**，不是Deployment Mode、不是Hard Gate本身、也不是Structural Break。

### 44-A｜Rapid Decline Detection

沿用既有正式條件：

- A組Price Structure Break至少`1`項：持續破前低／跌破Confirmed Swing Low／明顯跌破重要支撐且無法快速收復。
- B組Bearish Acceleration至少`2`項：MACD空方柱擴張、KD低檔續弱、EMV持續惡化、RSI續跌、價跌量增、ATR快速擴張、跌速加快、反彈一次比一次弱。

三值裁決：

```text
A = TRUE      if A_true >= 1
A = FALSE     if A_true + A_unknown < 1
A = UNKNOWN   otherwise

B = TRUE      if B_true >= 2
B = FALSE     if B_true + B_unknown < 2
B = UNKNOWN   otherwise

runaway_down_predicate = A AND B
```

因此**「跌很多」本身不是Runaway Down**；更不是Structural Break。

### 44-B｜Price Map Penetration

價格穿入更深Price Map Layer只代表折價加深／需重新評估。若沒有A組Structure Break＋B組Acceleration，深跌仍可能是安全左側折價；不得因「進第五層」「跌破某個百分比」單獨標成Runaway Down。

一旦Runaway Down成立，20號Priority高於左側買點，正常Left Buy被Preempt；不得同時建立左側接刀Buy Intent。

### 44-C｜ATR／Volume

- `ATR快速擴張`只作既有B組一項Bearish Acceleration Signal。
- `價跌量增`只作既有B組一項Volume／Price-Volume Signal。
- ATR或Volume單獨成立都不能建立Runaway Down。
- ATR／Volume UNKNOWN依22號三值邏輯處理，不得用0或前次舊值補成False。

### 44-D｜Credit／Liquidity Deterioration

Credit／Liquidity惡化是**Safety／Escalation Context**，不新增成Runaway Down B組計分項。若惡化已達既有Hard Gate、真正降低風險、Structural Break或其他上層Rule Owner條件，直接由其Owner處理；不得把「信用變差」重複算成新的Runaway Down訊號再Double Count。

### 44-E｜Deployment Slowdown／Buy Pause

在Runaway Down尚未成立前，既有技術轉弱可依Base／Left的Technical Speed Adjustment縮小當輪切片；**一旦Runaway Down＝TRUE：**

- Base／Left／Right／Trend的正常新增Buy全部暫停。
- 20號Higher-priority Risk使新的Buy Execution被Preempt；Work2 Permission／Execution結果同步反映。
- 未成交正常Buy Order須重新評估並依既有取消／Reconciliation規則處理。
- Canonical Target與Final Deployment Gap仍保留；Runaway Down不把Target／Gap直接改成0。
- Runaway Down本身**不產生Sell Intent**；若Fundamental／Credit／Liquidity另行惡化到Risk Reduction條件，才由其正式Owner產生Sell。

### 44-F｜Resume Condition

Runaway Down既有Exit邏輯維持：當A組Structure Break已確定全部失效，**或**B組有效Bearish Acceleration已確定降到正式最低數以下，Runaway Down可退出。

但「Runaway Down退出」**不等於自動恢復買進**。恢復正常Buy Execution還必須重新滿足：

- 20號沒有更高Priority Risk阻擋。
- Required Safety Data足夠。
- Hard Gate允許。
- `new_buy_order_permission = TRUE`。
- Final Deployment Gap > 0。
- Maximum Allowed Buy Amount > 0。
- Legal Order Quantity > 0。
- Fill／Order／Position Reconciliation已完成。
- 若某決策依賴重大Event Gap，工程34要求的T+1 Recheck已PASSED。

若A／B因Required Signal UNKNOWN而無法可靠確認Runaway Down已退出，不能把UNKNOWN當「已恢復安全」。

### 44-G｜Runaway Down ≠ Structural Break

固定最高Invariant：

> **Runaway Down回答「價格與空方動能是否正在失速下殺」；Structural Break回答「投資論點／Fundamental Cap是否已發生正式結構性破壞」。兩者可以同時存在，但任何一方都不能只因另一方成立而被自動推導。**

所以：

- 很深的價格跌幅＋加速下殺，可是Fundamentals未破壞 → Runaway Down可能TRUE、Structural Break仍FALSE。
- Fundamental Thesis正式FAILED、進入Structural Break，但價格尚未形成A＋B加速條件 → Structural Break可TRUE、Runaway Down仍FALSE。
- 同時TRUE → 依20號／Work4既有Risk Reduction Owner處理，Runaway Down只負責阻斷正常接刀，不重複建立Sell Rate。

---

## Work3-B｜跨Mode × Gap × Permission決策表

| Context | Normal Deployment Mode | Canonical Stage Reference | 新Buy Execution |
|---|---|---|---|
| 無左／右／Runaway Up特殊正常Predicate | Base Deployment | `STAGE_1` | 需Permission＋正Gap＋合法Amount／Qty |
| 左側買點TRUE、無更高正常Mode | Left Overweight | `STAGE_2`～`STAGE_7` | 同上；技術調速度 |
| 右側加碼TRUE | Right Confirmation | `STAGE_8` | 同上；至少3項確認已由Predicate保證 |
| Runaway Up TRUE | Trend Deployment | 最高`STAGE_9` | 同上；不得機械追單日大陽線 |
| Runaway Down TRUE | 正常Mode只作Context | Target保持 | **正常新Buy＝0；取消／重評未成交Buy** |
| Hard Gate TRIGGERED | Mode／Target保持可追溯 | Target保持 | `new_buy_order_permission = FALSE` |
| Gap<=0 | Mode可存在 | Target保持 | 本輪不新增；不建立WAIT |
| Reconciliation Required | Mode可存在 | Target保持 | 依賴Gap的新Buy暫停 |

## Work3-C｜工程40～44共同Invariant

1. `Deployment Stage ≠ Deployment Mode ≠ Special Classification ≠ Execution Result`。
2. 技術只調整正常部署速度；不得偷偷新建Canonical Target比例。
3. Hard Gate控制新的Buy Permission，不改Target／Gap。
4. Final Deployment Gap已含Active Buy／Sell Exposure；是否低配不得只看Raw Actual Completion。
5. Right最低確認數、Runaway Up A／B數、Runaway Down A／B數均沿用既有已批准規則；Work3沒有新增數值門檻。
6. UNKNOWN遵守22號三值邏輯，不得當False／0／Neutral。
7. `Runaway Down ≠ Structural Break`；Runaway Down本身不產生Sell Intent。
8. 左側／右側／Trend退出不自動賣；減碼仍由既有Technical Reduction／Structural Break／Emergency／Client Autonomous Owner決定。
9. `WAIT`不得復活為State／Classification／Mode；「本輪不新增」只是一個Execution Result。
10. 工程40～44只完成Staging Contract；工程45～56的Structural Break／Recovery／Episode細部不在本Work施工。

---

# Work4｜V82系統工程45～56｜Structural Break × Reduction × Emergency × Recovery Contract【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。**  
> 本段源自Work4工程45～56的工程化封口，現已由工程77納入正式SOT；承接既有個股Structural Break A～E、Work2的Order／Fill／Confirmed Position與Work3的Runaway Down邊界。**不新增新的投資Threshold／Default／Fallback，不把Candidate Parameter升格成正式執行參數。**

## Work4-A｜共同責任鏈與Scope Guard

本Work的個股風險降低責任鏈固定為：

```text
Emergency Aggregation
→ Core Thesis State
→ Structural Break Confirmation (45-C)
→ Company Risk Grade
→ Fundamental Cap (FC)
→ Confirmed Actual Position (AP)
→ Remaining Reduction Gap (RRG)
→ Initial Reduction / Risk Clock / Technical Execution Mode
→ Order Reconciliation
→ Reduction Continuity
→ Recovery / Episode Closure
```

固定Scope：

1. `Core Thesis / R1-R3 / FC / RRG / B-series / individual-stock Emergency Event Type`只適用`INDIVIDUAL_STOCK`；股票ETF不得套用個股Thesis失效計分。
2. `Structural Break Business State ≠ Reduction Episode Execution State ≠ Emergency Event State ≠ Emergency Execution State`。
3. 一般Structural Break的最終部位上限只由A系列Thesis／Risk Grade決定；技術不得改寫FC。
4. Emergency只有在獨立`Event Type × Evidence Authority × Evidence Assertion`正式確認後才接管；`R3 + FC=0`本身不是Emergency。
5. AP只認Confirmed Fill／券商確認持倉；Open／Pending Order只屬Active Exposure，不得提前改AP。
6. `RRG = MAX(AP - FC, 0)`是一般Structural Break唯一Reduction Gap公式；`FC > AP`永遠不得在本模組反向生成Buy Gap。
7. **45-C Structural Break Confirmation是live Reduction前置Gate**：FAILED Thesis／FAILED Count不得繞過45-C的獨立證據、跨Domain與交叉驗證要求，直接產生可執行FC／RRG Sell Intent。

---

## 工程45｜Structural Break Thesis Model Canonical Contract

### 45-A｜Core Thesis／Critical Thesis資料模型

正式股票池中的個股沿用既有規則：原則上建立3～7項Core Investment Theses，預設5項但不得為湊數虛構。每項Thesis至少保存：

- Thesis內容與重要性；
- `fundamental_domain`；
- 客觀`validation_metrics`；
- `normal_condition / deterioration_condition / failure_condition`；
- `required_evidence`；
- `persistence_requirement`；
- `is_critical`；
- `recovery_requirement`與Recoverable／Irreversible屬性；
- 版本、日期、變更理由與Evidence Snapshot。

Critical Thesis只能事前指定；價格下跌後不得事後新增。若真實結構改變而修改Thesis，舊版本、時間、理由與當時證據必須保留。

### 45-B｜Thesis State Machine

Canonical Thesis State只有：

```text
NORMAL / DETERIORATING / FAILED
```

`FAILED`必須同時滿足：

```text
failure_condition == TRUE
AND required_evidence_satisfied == TRUE
AND persistence_requirement_satisfied == TRUE
```

缺一時不得判FAILED；Required Evidence／Persistence無法可靠判定時，依22號資料品質規則保留UNKNOWN，不得把UNKNOWN當FALSE或TRUE。若重大事件本身一次即同時滿足三者，可由`NORMAL → FAILED`。

### 45-C｜Structural Break Confirmation

一般Structural Break確認沿用既有四項最低要求：

1. 至少2項獨立重大證據；
2. 跨至少2個Fundamental Domains；
3. 至少一項Core Thesis依事前Failure條件確認持續失效；
4. 公司資料、產業／同業與可信重大新聞／公告／監管文件交叉驗證。

同一Underlying Event被多篇媒體重複報導仍只算一個事件；同源鏡像／轉載不得偽裝成獨立證據。

### 45-D｜Recovery Requirement

- `Recoverable Thesis`：只有Failure Condition不再成立、新客觀修復證據成立、且**事前**`recovery_requirement`滿足後，才可`FAILED → DETERIORATING → NORMAL`。
- `Irreversible Thesis`：原版本永久維持FAILED；若出現全新投資理由，必須建立新版本／新完整Thesis Set，不能把舊FAILED改寫掉。
- Recoverable Thesis若缺少事前`recovery_requirement`，標示`Recovery Definition Missing`／等價治理缺口；不得臨時發明7天、30天或一季等觀察期。

---

## 工程46｜Risk Grade＋FC＋OTP／AP／RRG Canonical Contract

### 46-A｜唯一轉換鏈

**可執行前置條件：** 工程45-C的Structural Break Confirmation必須先滿足。若45-C尚未滿足，即使已有Thesis進入FAILED，也不得僅靠FAILED Count直接啟動live FC／RRG Sell Intent；應繼續完成既有Evidence、跨Fundamental Domain與交叉驗證要求。

正式鏈固定為：

```text
latest legal Thesis States
→ Critical FAILED Check
→ General FAILED Count
→ Company Risk Grade
→ Fundamental Cap (FC)
→ Confirmed AP
→ RRG = MAX(AP - FC, 0)
```

### 46-B｜Risk Grade → FC Decision Table

在非Emergency且45-C Structural Break Confirmation已滿足後：

| Company Risk Grade | 條件 | FC（相對OTP） |
|---|---|---:|
| `R1` | 1項一般Core Thesis FAILED；無Critical FAILED | 50% |
| `R2` | 2項不同一般Core Theses FAILED；無Critical FAILED | 25% |
| `R3` | ≥3項一般Core Theses FAILED，或任一Critical Thesis FAILED | 0% |
| `NONE` | FAILED=0且無Critical FAILED | Structural Break限制解除；不是新的Buy Target |

Critical FAILED優先於一般FAILED數量。Emergency雖可同樣令FC=0，但其來源與Execution Contract完全獨立，禁止互相推導。

### 46-C｜OTP／Project Target／AP分離

- `OTP (Original Target Position)`：個股正式納入股票池／Structural Break框架時確定的原始部位基準，視為100%；**不是**客戶可變動`Project Target Position`的同義詞。
- `FC`：相對OTP的基本面最大允許部位。
- `AP`：最新Confirmed Position，只由Confirmed Fill／券商確認持倉更新。
- Project Target可依客戶配置變動；不得反向改寫歷史OTP或Structural Break Risk Grade。

### 46-D｜RRG唯一公式

```text
RRG = MAX(AP - FC, 0)
```

- `RRG > 0`：存在尚需降低的Structural Break部位。
- `RRG = 0`：停止新增Structural Break Sell Intent；不代表應買到FC。
- `FC - AP`不得轉成Buy Gap；任何未來Buy必須回A-8／完整V82＋V70.2＋Deployment Gap流程。

---

## 工程47｜B-1 Initial Reduction Canonical Contract

### 47-A｜Starting Point與Pending Reduction

Structural Break首次正式確認後，若市場可合理執行，既有規則要求啟動Initial Risk Reduction；技術超賣不得把「已確認需要降低風險」變成0。每一Episode至少保存：

```text
episode_id
initial_reduction_target
initial_reduction_executed
initial_reduction_pending
latest_confirmed_ap
latest_fc
latest_rrg
execution_status
```

未完成Initial Reduction不得在下一Cycle假裝尚未執行、重新計算整筆第一刀；只能對尚未完成部分續算。

### 47-B｜既有Candidate比例表保持Candidate

既有B-1表仍保留原身分：

| Risk Grade | -2 | -1 | Base | +1 | +2 |
|---|---:|---:|---:|---:|---:|
| R1 | 15% | 20% | 25% | 32.5% | 40% |
| R2 | 25% | 30% | 35% | 45% | 55% |
| R3 | 40% | 45% | 50% | 62.5% | 75% |

以上比例皆乘「當時最新RRG」，不是OTP或總資產。FWL 0／1／2沿用0／+1／+2步調整；Technical Panic Adjustment只依既有規則降低步階，且FWL>=1時最多抵銷1步。

### 47-C｜Candidate Governance

施工圖最高Invariant：**Candidate數字不得具有正式執行效力。** 因此Work4只允許：

- 生成`candidate_initial_reduction_plan`／模擬／QA結果；
- 保存Candidate來源與版本；
- 在Candidate未經正式治理升格前，禁止僅因Candidate表直接產生live formal order quantity。

若某正式執行量必須依賴尚未升格的Candidate Parameter，Formal Runtime須明確標示規則治理未完成／正式參數不足，不得默默把Candidate當正式數字。

### 47-D｜Execution Status

沿用：`EXECUTABLE / PARTIALLY_EXECUTABLE / NOT_EXECUTABLE`。交易暫停、流動性異常、極端市場微結構等才可形成Execution Exception；單純Gap Down、正常下跌、價格難看或沒有反彈不等於NOT_EXECUTABLE。

---

## 工程48｜B-2 Risk Clock Canonical Contract

### 48-A｜既有Candidate Rate／Clock表

既有B-2仍標示為第一版Candidate：

| Mode | 每有效執行日比例（乘最新RRG） | Max Effective Execution Days |
|---|---:|---:|
| Slow | 20% | 10 |
| Normal | 35% | 5 |
| Accelerated | 60% | 3 |

Hard Deadline語意保持：在相應最後有效執行日完成當時最新RRG；Deadline Cycle不再乘Rate，直接以最新RRG作Gross Sell Target，仍受Execution Exception與Execution Adapter限制。

**上述Rate與Days不得因Work4工程化而自動升格成正式Live Execution Parameter。**

### 48-B｜Risk Clock State

至少保存：

```text
max_execution_days
elapsed_execution_days
remaining_execution_days
execution_mode
execution_status
```

Mode變快／風險惡化時只可縮短，禁止延長：

```text
new_remaining_execution_days = MIN(current_remaining_execution_days,
                                   new_mode_max_execution_days)
```

Risk Grade／FC惡化不得重置Clock取得更長期限；`elapsed_execution_days`不得歸零。

### 48-C｜Effective Execution Day

- `EXECUTABLE`：依既有B-2消耗有效執行日。
- `NOT_EXECUTABLE`：依正式Execution Exception暫停，不假裝執行。
- `PARTIALLY_EXECUTABLE`：不得僅因部分成交就自動整日凍結Clock；若現有規則不足以機械決定其精確日數歸屬，保留未解決資料／規則狀態，不得自行新增比例或天數。

### 48-D｜Rounding

Execution Adapter負責minimum lot、fractional、precision、minimum notional。若為完成RRG而因最小交易單位造成最小必要穿越FC，記錄`rounding_excess_reduction`；不得利用rounding額外超賣。

---

## 工程49｜B-3 Technical Execution Mode Canonical Contract

### 49-A｜唯一技術權責

B-3唯一輸出：

```text
SLOW / NORMAL / ACCELERATED
```

技術只決定「今天賣多少、賣多快」，不得：

- 改寫FC或Risk Grade；
- 取消Structural Break；
- 重設／延長Risk Clock；
- 建立第二套Sell Rate／Deadline；
- 把Emergency塞成第四種Mode。

### 49-B｜資料流與Episode邊界

```text
Raw Data
→ State
→ Event
→ Current Reduction Episode Event History
→ P/M/C
→ Accelerated Path A
→ Accelerated Path B
→ Confirmed Slow
→ Otherwise Normal
```

State與Crossing Event分離；歷史Event只可引用同一`episode_id`、同一`structure_id`且時間不早於`episode_started_at`者。

### 49-C｜Technical Data Quality

UNKNOWN不得當Neutral／False。Structural Break與Reduction Episode已由基本面正式成立、但B-3所需關鍵技術資料不足時，沿用既有Safety-preserving Reduction Fallback：輸出`NORMAL`並同時保存`technical_data_quality = INSUFFICIENT / UNKNOWN`與Issue Codes。這只防止已確認風險降低被技術資料缺口延誤，**不是UNKNOWN=Normal的一般規則**。

### 49-D｜既有Candidate Parameter不升格

B-3現有且僅有兩個Candidate Parameter仍保持Candidate：

1. MACD Histogram方向確認期＝連續2個已完成Bar；
2. Swing／MA Noise Band＝`0.25 × ATR(14)`。

Work4不得把它們直接升格為正式Live Execution Parameter。

### 49-E｜Slow／Accelerated邊界

- Accelerated Path A需價格結構、動能轉弱、確認層共同成立；真正強勢`VALID_BREAKOUT`不得單獨觸發Accelerated。
- Path B只讀同Episode、同structure的`RECLAIM → BREAKDOWN`客觀事件序列。
- Confirmed Slow需既有Low TD 5～9、無新的Swing／MA結構破壞Event、至少一項止跌Momentum條件、至少一項非TD確認條件。
- **Slow不是Wait。**

---

## 工程50｜B-4 Order Reconciliation Canonical Contract

### 50-A｜Rebound Window

`REBOUND_WINDOW_STATE`只有：

```text
OPEN / CLOSED
```

Window只是Execution State，不是新Technical Signal；B-3才是Accelerated唯一來源。Window不得重設Episode或Risk Clock。

持久化Window State是Source of Truth，不以`previous_mode`推測：Accelerated+CLOSED→OPEN；Accelerated+OPEN→維持；非Accelerated+OPEN→CLOSED；非Accelerated+CLOSED→維持。

資料異常另用`VALID / RECOVERED / DATA_INTEGRITY_ERROR / DATA_ACCESS_ERROR`表達，不得塞入Window業務State；>1個同Episode未closed Window或查詢失敗時不得猜測／新建重複Window。

### 50-B｜Order Reconciliation First

每個新Execution Cycle在產生新Sell前固定先辨識至少：

```text
OPEN / PARTIALLY_FILLED / FILLED / CANCELLED / REJECTED
```

- AP只由Confirmed Fill／Broker Position更新。
- Open／Pending／未成交部分只算Active Sell Exposure。
- Cancel未確認成功以前，不得假設舊Order已消失。
- Order Reconciliation未完成時，不得送出可能與舊Active Sell Exposure重疊的新Sell。

### 50-C｜Remaining Sell Target

先用最新AP／FC重算：

```text
RRG = MAX(AP - FC, 0)
```

再由B-2決定本Cycle `gross_sell_target`（Deadline Cycle＝當時最新RRG）。對與本Cycle風險降低方向相容、仍可能成交的Active Sell Exposure，Canonical剩餘新下單量為：

```text
remaining_new_sell_target = MAX(gross_sell_target - compatible_active_sell_exposure, 0)
```

不得因重複訂單、未Reconcile Active Orders或錯誤Target造成非預期超賣。最小交易單位造成的最小必要穿越FC，只依工程48既有rounding規則。

### 50-D｜Partial Fill／Cancel／Replace

Partial Fill只以Confirmed部分更新AP；未成交部分仍屬Active Sell Exposure。若FC上升導致既有Active Sell Exposure超過最新允許Reduction，必須Cancel／Resize／Replace或把其Exposure完整納入重算，直到確認安全後才可新增Order。

---

## 工程51｜B-5／B-6 Continuation＋FC Change＋Clock Inheritance Contract

### 51-A｜No-Rebound Continuation

> **No Rebound不得阻止、暫停、重設或延長Reduction Schedule。Rebound是Execution Opportunity，不是Reduction完成的必要條件。**

只要`RRG > 0`且沒有Emergency接管，Slow／Normal仍依B-2既有Schedule繼續；Slow不得變成0或WAIT。到Hard Deadline時，不論有無反彈，都處理當時最新RRG，仍受真正Execution Exception與rounding限制。

### 51-B｜同Cycle固定順序

```text
Order Reconciliation
→ Confirmed Fills / Broker Position
→ latest AP
→ latest Fundamental Evidence / Risk Grade / FC
→ RRG = MAX(AP-FC,0)
→ current B-3 Mode
→ Clock Inheritance
→ Gross Sell Target
→ Active Sell Exposure Reconciliation
→ Execution Adapter
```

禁止用舊AP＋新FC先算Target後忽略途中成交。

### 51-C｜FC Change／Episode Continuity

同一次Structural Break Reduction中R1／R2／R3互轉：

- 保留原`episode_id`、`episode_started_at`、`elapsed_execution_days`與Risk Clock歷史；
- 以最新AP與最新FC重算RRG；
- FC下降只擴大當下RRG，不建立新Episode；
- FC上升可縮小RRG或令RRG=0，但不自動買回；
- Risk Grade／FC變化本身不增加剩餘天數。

```text
remaining_after_fc_change = current_remaining_execution_days
```

若同Cycle B-3 Mode也改變：

```text
new_remaining_execution_days = MIN(remaining_after_fc_change,
                                   new_mode_max_execution_days)
```

不得另建R1／R2／R3各自Deadline，因既有母規則沒有此Existing Rule。

### 51-D｜Episode Continuity Edge

- `R1→R3 + Accelerated`：先重算RRG，再只允許`MIN(原剩餘天數, Accelerated Max Days)`；不得重開3個完整新天數。
- `R3→R2`且新FC≥AP：RRG=0，停止Reduction；不得買到FC。
- RRG回到0後，是否沿用原Episode或建立新Episode，交工程56依Structural Break解除與`episode_resolved_at`判定；不得只因FC數字變動任意新建Episode。

---

## 工程52｜FWL／Fundamental Worsening Guard Canonical Contract

### 52-A｜FWL權責

FWL只描述Risk Grade計算完成後、**尚未FAILED**之Remaining DETERIORATING Thesis額外惡化層級，用於決定是否仍有Slow資格；它不是Fundamental Severity、不是Velocity，也不決定Risk Grade／FC。

正式順序：

```text
Emergency
→ Thesis State
→ FAILED Thesis
→ Risk Grade
→ FC
→ RRG
→ 排除FAILED Thesis
→ Remaining DETERIORATING Thesis
→ FWL
→ Fundamental Worsening Guard
→ B-3 Execution Mode
```

### 52-B｜FWL Deterministic Mapping

- `FWL = 0`：排除FAILED後，沒有額外Core Thesis處於DETERIORATING。
- `FWL = 1`：有且僅有1項一般、非Critical Core Thesis DETERIORATING。
- `FWL = 2`：至少2項彼此獨立的一般、非Critical Core Theses DETERIORATING；**或任一Critical Thesis DETERIORATING**。

已FAILED且已進Risk Grade／FC的Thesis不得再次算入FWL；同一Underlying Event不得重複計數。

### 52-C｜Worsening Guard

```text
fundamental_worsening_guard = (FWL >= 1)
```

固定裁決：

1. B-3 Accelerated成立 → `ACCELERATED`；
2. 否則Confirmed Slow成立且Guard=FALSE → `SLOW`；
3. 否則Confirmed Slow成立且Guard=TRUE → Slow資格取消，輸出`NORMAL`；
4. 其餘 → `NORMAL`。

FWL**不得直接產生ACCELERATED**、不得建立第二套Rate／Deadline／Clock／Episode／Window。

### 52-D｜Critical DETERIORATING未FAILED

Critical Thesis只到DETERIORATING而未滿足FAILED三條件時：不得提前R3、FC維持現有Risk Grade結果，但`FWL=2`、Guard=TRUE，所以不能只因技術超賣／止跌而降成Slow。

---

## 工程53｜Emergency Event State Canonical Contract

### 53-A｜Event State與Execution State分離

每個`emergency_event_id`保存：

```text
NONE / PENDING_VERIFICATION / CONFIRMED / DECONFIRMED
```

Emergency Execution另存：

```text
NOT_STARTED / IN_PROGRESS / BLOCKED / COMPLETED
```

因此Event已CONFIRMED但股票停牌時，可同時是`Event=CONFIRMED`＋`Execution=BLOCKED`；不得因不可交易把Event降回PENDING。

### 53-B｜Event Types

只沿用既有四類：

```text
FRAUD_OR_UNRELIABLE_FINANCIALS
MATERIAL_DEFAULT
BANKRUPTCY_OR_RESTRUCTURING
GOING_CONCERN
```

不得新增模糊Emergency類型。

### 53-C｜Evidence Authority × Assertion

Emergency確認必須同時判斷「誰說的」與「正式主張什麼」。Official Source本身不自動等於CONFIRMED；若Assertion只是`INVESTIGATION_OPENED`，仍只能PENDING。

Evidence Authority沿用：`COURT_OR_LEGAL_RECORD / REGULATOR_FORMAL_RECORD / ISSUER_FORMAL_FILING / AUDITOR_FORMAL_STATEMENT / CONTRACTUAL_AGENT_NOTICE / EXCHANGE_FORMAL_NOTICE / RELIABLE_SECONDARY_REPORT / UNVERIFIED_SOURCE`。

Evidence Assertion沿用：`EVENT_CONFIRMED / FINANCIALS_NOT_RELIABLE / DEFAULT_EFFECTIVE / BANKRUPTCY_OR_RESTRUCTURING_ENTERED / GOING_CONCERN_EXPRESSED / INVESTIGATION_OPENED / ALLEGATION_ONLY / PROCEDURAL_ONLY / DENIAL / REVERSAL_OR_DISMISSAL`。

### 53-D｜Event-specific Confirmation

- Fraud／財報不可靠：須正式舞弊認定、正式申報財報不得再依賴、會計師撤回／否定依賴、或正式重大錯報重編等；媒體爆料／做空報告／匿名消息／僅開始調查＝PENDING。
- Material Default：義務未履行＋依契約已正式構成Default／Event of Default＋不存在仍有效Grace／Cure／Waiver。
- Bankruptcy／Restructuring：公司／債務人正式進入具有法律效力之破產／重整程序可CONFIRMED；僅債權人Petition、公司否認且法院未使程序成立＝PENDING。
- Going Concern：正式財報／審計文件明確表達重大持續經營疑慮才可CONFIRMED。

### 53-E｜Multi-Emergency Aggregation

- 任一Active Event仍CONFIRMED → `company_emergency_status = CONFIRMED`。
- 無CONFIRMED但至少一個PENDING → Company-level PENDING。
- 單一Event DECONFIRMED不得覆蓋另一個仍CONFIRMED Event。
- 只有所有支撐Emergency Exit的Confirmed Events均解除後，Company-level Emergency Execution Intent才可解除。

---

## 工程54｜Emergency Execution Canonical Contract

### 54-A｜PENDING行為

`PENDING_VERIFICATION`固定：停止新的Buy Intent、取消尚未成交Buy Orders、持續更新Evidence並重跑A系列；**不得**建立Emergency Sell Rate、Deadline、固定Pending減碼比例、新聞篇數、價格跌幅或等待天數。若既有Structural Break Reduction已成立，B系列按原Episode／Clock與最新資料繼續。

### 54-B｜CONFIRMED Emergency Preemption

`company_emergency_status = CONFIRMED`取得最高Execution Intent。固定順序：

```text
Order Reconciliation
→ Confirmed Fills / Broker Position
→ latest AP
→ Cancel Unfilled Buy Orders
→ Emergency FC = 0
→ Emergency RRG = AP
→ Active Sell Exposure
→ Compatibility Check
→ Net New Sell Target
→ Execution Adapter
```

Canonical公式：

```text
Emergency RRG = MAX(AP - 0, 0) = AP
Net New Sell Target = MAX(Emergency RRG - Compatible Active Sell Exposure, 0)
```

### 54-C｜Emergency ≠ B-3 Accelerated

Emergency固定不等待反彈、不讀B-1比例、不讀B-2 Slow／Normal／Accelerated Rate或3／5／10日Candidate Deadline、不讀B-3 Mode、不建立B-4 Window、不用FWL當減速理由。

- `EXECUTABLE`：第一個可執行Cycle處理全部可退出Net Target。
- `PARTIALLY_EXECUTABLE`：執行目前最大合法／合理量，剩餘保持Emergency Pending。
- `NOT_EXECUTABLE`：AP保持Confirmed Position，Pending RRG保留；恢復可交易後先Reconcile再續。

### 54-D｜Structural Break Episode被Emergency接管

既有Episode標記`EMERGENCY_PREEMPTED`，保存原`episode_id`、Risk Grade、FC、elapsed／remaining Risk Clock、原B-3 Mode、Window與已執行量；Emergency另建`emergency_event_id`並引用`preempted_reduction_episode_id`。

Preemption解除後只恢復**Episode identity＋尚未耗盡Clock**，不得恢復Emergency前舊RRG／舊Sell Target／舊Pending Amount；固定重新：

```text
Reconcile → Confirmed AP → latest Thesis → Risk Grade → FC → RRG → FWL → B-3 → inherited Clock
```

若`AP=0`，Episode進入`TERMINATED_NO_POSITION`，不得產生Buy Gap。

### 54-E｜DECONFIRMED與Order Safety

DECONFIRMED必須有足以推翻原Assertion之適格正式來源；一般「可能沒事」新聞不足。任何解除先Reconcile，再只解除對應Event並重新聚合。已成交部位不自動買回。

Emergency共用工程50的Order Safety：Cancel未確認前不得送出重疊新Sell；Partial Fill只用Confirmed部分更新AP；未成交部分持續算Active Sell Exposure。

---

## 工程55｜Recovery Canonical Contract

### 55-A｜Thesis Recovery唯一Owner

A-7是Thesis Recovery唯一判定來源。4-7E／Work4不得建立第二套Recovery Score、Cooldown、固定觀察天數或公司層Recovery Engine。

Recoverable Thesis合法恢復須同時具備：

```text
failure_condition no longer true
AND new objective recovery evidence valid
AND pre-defined recovery_requirement satisfied
```

才可`FAILED → DETERIORATING → NORMAL`。Irreversible Thesis原版本不得恢復。

### 55-B｜Company Risk Grade Recalculation

完成A-7後，同一Cycle依最新合法Thesis States重算：

- 任一Critical FAILED → R3／FC=0% OTP；
- 一般FAILED >=3 → R3／FC=0% OTP；
- 一般FAILED =2 → R2／FC=25% OTP；
- 一般FAILED =1 → R1／FC=50% OTP；
- FAILED=0且無Critical FAILED → `company_risk_grade = NONE`。

不新增`R0`。

### 55-C｜Recovery不等於買回

Risk Grade改善／FC上升只會縮小或清零RRG；Structural Break限制解除時的「100% OTP」只表示本模組不再施加較低FC，**不是Target Position、不是Buy Target**。不得計算`100% OTP - AP`作Buy Gap。

Emergency `DECONFIRMED`也不等於Thesis Recovery；必須重新跑A-7與完整Fundamental Assessment。

---

## 工程56｜Episode Closure Canonical Contract

### 56-A｜Business State與Execution State分離

當`FAILED=0 AND no Critical FAILED`：

```text
company_risk_grade = NONE
structural_break_status = RESOLVED
FC restriction released
RRG = 0
new_structural_break_sell_intent = 0
```

不得因仍有舊Active Sell Order就把Structural Break Business State繼續標ACTIVE。

Reduction Episode至少相容：

```text
ACTIVE
EMERGENCY_PREEMPTED
RESOLUTION_PENDING_RECONCILIATION
CLOSED
TERMINATED_NO_POSITION
```

### 56-B｜RESOLUTION_PENDING_RECONCILIATION

Structural Break已RESOLVED、RRG=0，但仍有可能造成非預期減碼之Active Reduction Sell Exposure時：

```text
reduction_episode_status = RESOLUTION_PENDING_RECONCILIATION
```

固定：停止新增Structural Break Sell Intent；執行Order Reconciliation；處理不再需要的Open／Partial Sell Orders；AP只認Confirmed Fill；取消前若舊Sell成交，只更新AP、不產生Buy Gap。此期間因RRG=0且沒有新Reduction Intent，**不消耗Effective Execution Day**。

### 56-C｜CLOSED與episode_resolved_at

只有以下全部成立才正式：

```text
structural_break_status = RESOLVED
AND RRG = 0
AND order_reconciliation_complete == TRUE
AND unexpected_active_structural_break_sell_exposure == 0
```

然後：

```text
reduction_episode_status = CLOSED
episode_resolved_at = confirmed closure timestamp
```

`episode_resolved_at`是新舊Episode的正式切線。

### 56-D｜Closure前重新成立Structural Break

若尚在`RESOLUTION_PENDING_RECONCILIATION`且`episode_resolved_at`尚未寫入前重新正式成立Structural Break：

- `structural_break_status → ACTIVE`；
- 依最新Thesis重算Risk Grade／FC／RRG／FWL／B-3；
- **沿用原episode_id、episode_started_at與尚未耗盡Risk Clock**；
- 新Mode更快時只可`MIN()`縮短Clock，不得延長；
- 先Reconcile再產生新Sell。

### 56-E｜Closure後的新Structural Break

Episode已CLOSED且已有`episode_resolved_at`後再次正式成立Structural Break：

- 建立新`episode_id`與`episode_started_at`；
- 依當時最新合法規則建立新Risk Clock；
- 以最新Confirmed AP／Thesis／Risk Grade／FC重算RRG；
- 舊Sell Target、舊Pending Amount、舊Rebound Window、舊Technical Event History不得跨Episode復活。

---

## Work4-B｜工程45～56共同狀態轉移摘要

| Situation | Business／Event State | Execution結果 |
|---|---|---|
| Thesis已FAILED但45-C四項確認尚未滿足 | Structural Break尚未正式確認 | 不啟動B系列live Sell；續做Evidence／跨Domain／交叉驗證 |
| 一般Thesis FAILED且45-C確認完成，形成R1/R2/R3 | Structural Break ACTIVE | 依FC→RRG→B系列降低風險 |
| R3／FC=0但無Emergency Event | Structural Break ACTIVE | **仍是一般R3**，不是Emergency |
| Emergency證據僅PENDING | Emergency PENDING | 關新Buy；原合法B系列照常，不建立Emergency Sell Rate |
| 任一Emergency Event CONFIRMED | Company Emergency CONFIRMED | Emergency接管；既有Reduction Episode→EMERGENCY_PREEMPTED |
| Emergency解除但仍有Structural Break RRG | Emergency解除 | 以最新AP／FC／RRG恢復原Episode＋剩餘Clock |
| 最後FAILED Thesis合法Recovery | Structural Break RESOLVED | 新Sell Intent=0；若有舊Sell Exposure先進Pending Reconciliation |
| RESOLVED但舊Sell尚未清乾淨 | RESOLUTION_PENDING_RECONCILIATION | 不消耗有效執行日；先Cancel／Reconcile |
| Reconcile完成且無殘留Exposure | Episode CLOSED | 寫`episode_resolved_at` |
| CLOSED後未來再Structural Break | 新Business Episode | 新`episode_id`＋新Clock；舊Window／Target不得復活 |

## Work4-C｜工程45～56共同Invariant

1. Individual Stock Structural Break與ETF結構安全規則分離。
2. Thesis State唯一`NORMAL / DETERIORATING / FAILED`；FAILED不得缺Evidence／Persistence。
3. Risk Grade→FC唯一映射保持R1=50% OTP、R2=25% OTP、R3=0% OTP；Recovery時NONE不新增R0。
4. `RRG = MAX(AP-FC,0)`唯一；AP只認Confirmed Fill／Broker Position。
5. 技術只改Execution Mode，不改FC。
6. Candidate Parameter保持Candidate；Work4不得把B-1／B-2／B-3候選數字升格成正式Live Execution數值。
7. Risk Clock只縮短、不因Risk Grade惡化／反彈／No-Rebound而延長或重開。
8. 每Cycle新Sell前先Order Reconciliation；Cancel未確認前不得假設Exposure消失。
9. FWL只限制Slow資格，不產生第二套Rate／Clock／Accelerated。
10. `R3 + FC=0 ≠ Emergency`；Emergency需Event-specific Confirmation。
11. PENDING Emergency不產生Emergency Sell Rate；CONFIRMED才Preempt。
12. Emergency、Recovery、FC改善、Episode解除均不得自動買回已減碼部位。
13. Structural Break Business State與Reduction Episode Execution State分離。
14. `episode_resolved_at`前重新成立沿用舊Episode／剩餘Clock；之後才建立新Episode。
15. 工程57～62的Canonical Event／Evidence Lineage／Registry／Freshness／Coverage／Cold Start不在本Work施工。
16. FAILED Thesis／FAILED Count不得繞過45-C Structural Break Confirmation Gate；45-C未滿足前不得啟動一般Structural Break的live FC／RRG Sell Intent。

---

# Work5｜V82系統工程57～62｜Event × Evidence × Freshness × Coverage × Recovery Contract【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。**  
> 本段源自Work5工程57～62的事件資料治理工程化，現已由工程77納入正式SOT；直接承接既有4-7F News Search／Source Tier／Event Dedup／Freshness母規則、Work4的Structural Break／Emergency Evidence權責，以及第62章Data Quality／UNKNOWN傳播。**不新增新的投資Threshold／Default／Fallback，不新增新的Hard Gate種類，不把Candidate Parameter升格成正式執行參數。**

## Work5-A｜共同責任鏈與Scope Guard

本Work的事件資料責任鏈固定為：

```text
Search / Retrieval Result
→ Article / Document Identity
→ Evidence Version
→ Assertion + Original Provenance / Assertion Origin
→ Evidence Lineage / Independence
→ Canonical Event Identity / Event Version
→ Active Event Registry
→ Five-way Freshness / Validity
→ Required Safety Coverage
→ Dedup / Persistence
→ Checkpoint Commit / Provider Cursor
→ Cold Start / Search Recovery
→ Existing Data Quality / Hard Gate Consumers
```

固定Scope：

1. `Article ≠ URL ≠ Evidence ≠ Assertion ≠ Canonical Event`；URL只作locator之一，不得作Event ID或唯一Dedup Key。
2. Source Tier只管理Retrieval Priority／Conflict Resolution；Event Confirmation仍由既有`Event Type × Evidence Authority × Evidence Assertion`Owner決定。
3. Same Root Cause不得作為合併Canonical Event的充分條件；實質不同正式事件必須分開建Event，再用`related_event_ids`關聯。
4. Evidence Independence依Original Provenance／Assertion Origin判斷，不依URL數、Publisher數、新聞篇數或鏡像數。
5. Active Event Registry只管理追蹤生命週期；不得建立第二套Emergency／Structural Break／Thesis Business State。
6. Search Freshness、Item Freshness、Event Validity、Evidence Validity、Assertion Validity必須分欄；任一欄不得機械推導另一欄。
7. Coverage／Checkpoint只治理資料完整度與可恢復性；若不足，映射回既有Data Quality／UNKNOWN／Hard Gate，不新增獨立投資Gate。
8. `incremental_search_overlap_window`與`cold_start_general_news_lookback_window`仍為Candidate／TBD；本Work不得填24小時、48小時、7天、30天或其他數值。

---

## 工程57｜Canonical Event Canonical Contract

### 57-A｜Identity Layers正式分離

正式資料模型至少分成五層：

```text
Article / Document
URL / Locator
Evidence Version
Assertion
Canonical Event / Event Version
```

- `Article / Document`：一份被取得、發布或更新的內容載體。
- `URL / Locator`：定位Article／Document或原始文件的方式；同一URL可在不同時間承載不同內容版本。
- `Evidence Version`：可追溯、具有來源與時間的證據版本。
- `Assertion`：Evidence內可被獨立確認、修改、撤回、取代或失效的具體主張。
- `Canonical Event`：底層真實事件的正式身份；同一事件後續重大進展用Event Version延續。

固定：

> **Article ≠ URL ≠ Evidence ≠ Assertion ≠ Canonical Event。**

### 57-B｜Canonical Event Required Fields

每一個Canonical Event至少保存／映射：

```text
canonical_event_id
root_event_id
related_event_ids[]
event_type
primary_entity
related_entities[]
event_occurred_at
effective_at
first_seen_at
last_seen_at
latest_material_update_at
event_version
tracking_status
material_update
related_evidence_ids[]
```

語意：

- `canonical_event_id`：Event Identity唯一主鍵；不得使用URL、標題或Provider ID替代。
- `root_event_id`：只能指向可識別的Canonical Root Event（即另一個`canonical_event_id`）；**不得拿Synthetic Root Group／Root Cause Group塞進此欄，也不得因此把實質不同Event合併或增加／減少Evidence Count**。若只有共同根因／故事族群、但沒有可識別的Canonical Root Event，必須為NULL／UNKNOWN，並以`related_event_ids[]`表達事件關聯。
- `related_event_ids[]`：實質不同但相關的Canonical Events；關聯不代表同一事件。
- `event_version`：同一`canonical_event_id`的可追溯版本號；Material Update建立新Event Version，舊版本保留。
- `tracking_status`：只管理Registry追蹤狀態，不取代Emergency／Structural Break業務狀態。

### 57-C｜Event Identity Decision Boundary

判定是否同一Canonical Event時，優先核對：

1. `event_type`；
2. 正式案件／程序／契約身份；
3. 權責主體；
4. 實體／公司／債務工具範圍；
5. 正式法律、監管、契約或公司事件的獨立生效狀態。

同一正式案件內合法進展可沿用同一`canonical_event_id`並增加`event_version`；若是不同法律／監管／契約／公司正式事件，即使來自同一Root Cause，也建立不同`canonical_event_id`並以`related_event_ids`關聯。

固定：

> **Same Root Cause ≠ Same Canonical Event。**

### 57-D｜Article／URL Dedup邊界

- 同一Article出現在不同URL，不得因此建立多個Event。
- 同一URL後續若`content_fingerprint`、`source_updated_at`或Assertion實質改變，必須建立新的Evidence Version。
- 今天發布的回顧文章若只是重述舊事件，不得因`published_at=today`重建新Event。
- 一篇Article可以同時連結多個Canonical Events；不得因Article ID相同而強制合併事件。

---

## 工程58｜Evidence／Assertion／Lineage Canonical Contract

### 58-A｜Evidence與Assertion正式分離

每一份Evidence至少保存：

```text
evidence_id
canonical_event_id
source_origin
source_url
source_document_id
source_tier
published_at
source_updated_at
retrieved_at
evidence_authority
content_fingerprint
supersedes_evidence_id
evidence_version
original_provenance_id
evidence_lineage_id
is_mirror
is_repost
```

每一個Assertion至少保存：

```text
assertion_id
evidence_id
canonical_event_id
assertion_type
assertion_value
assertion_origin
original_provenance_id
assertion_lineage_id
evidence_authority
evidence_assertion
assertion_validity
validity_reason
supersedes_assertion_id
assertion_version
```

`Evidence Authority`只回答「誰說的」；`Evidence Assertion`／Assertion內容回答「實際正式主張什麼」。高Authority來源若只正式主張`INVESTIGATION_OPENED`，不得跳成Emergency CONFIRMED。

### 58-B｜Original Provenance／Assertion Origin

- `original_provenance_id`：最初產生該事實／正式主張的可追溯來源身份。
- `assertion_origin`：該Assertion是來源自己產生，還是引用／鏡像／轉述其他Origin。
- 同一公司新聞稿被IR、SEC附件、新聞聚合站與媒體重刊，只要核心Assertion皆源自同一原始新聞稿，就屬同一Original Assertion Lineage。
- 同一篇Article可同時包含「引用他人原始文件的Assertion」與「作者／媒體獨立產生的新事實」；Lineage允許細到Assertion level，不強迫整篇Article只有一個Lineage。

### 58-C｜Mirror／Repost／Independent Evidence

`is_mirror`／`is_repost`是Lineage Metadata，不直接決定Credibility。Independent Evidence固定依：

```text
independent_evidence =
    different_original_provenance
AND genuinely_independent_assertion_origin
AND not merely mirror / repost / aggregation / quotation of same origin
```

因此：

- URL不同 ≠ Independent Evidence；
- Publisher不同 ≠ Independent Evidence；
- 媒體篇數增加 ≠ Independent Evidence數增加；
- 真正不同權責主體各自形成正式文件，可依既有Evidence Authority規則成為Independent Evidence。

### 58-D｜Lineage與Versioning

- Evidence更新但Original Provenance不變時，沿用Lineage並增加Evidence Version。
- Assertion被正式修改／撤回／取代時，新增Assertion Version，遞增`assertion_version`並以`supersedes_assertion_id`串接前一版，不得覆蓋歷史內容。
- `amended`只影響被修改的Assertion；不得使同一Document所有其他Assertion機械失效。
- Dedup只消除重複Evidence；不得吞掉Material Update或新Independent Evidence。

---

## 工程59｜Active Event Registry Canonical Contract

### 59-A｜Registry Purpose

Active Event Registry追蹤「仍未terminal、且仍具決策相關性」的重大事件。每輪至少分成：

```text
General News Discovery
+
Active Event Refresh
```

General News Discovery受Search Window限制；Active Event Refresh不受General Search Window限制。

### 59-B｜Registry Required Fields

每筆Registry至少保存：

```text
canonical_event_id
root_event_id
tracking_status
active_event_flag
business_state_reference
first_registered_at
last_refresh_attempt_at
last_successful_refresh_at
last_seen_at
latest_material_update_at
latest_event_version
open_material_assertion_ids[]
terminal_reason
closed_at
refresh_data_quality
issue_codes[]
```

Canonical tracking enum維持：

```text
ACTIVE / CLOSED
```

為配合施工圖中的Active／Inactive語意：

```text
active_event_flag = TRUE  <=> tracking_status == ACTIVE
active_event_flag = FALSE <=> tracking_status == CLOSED
```

`Inactive Event`只表示Registry中已不需要Active Refresh的歷史事件，不新增第三個Business State，也不得刪除歷史Event／Evidence。

### 59-C｜Material Update Lifecycle

同一`canonical_event_id`若新Evidence改變任何既有正式決策相關欄位，`material_update = TRUE`並建立新Event Version。至少包括：

- Event State；
- Evidence Assertion；
- 法律／監管／正式生效狀態；
- 規模、金額、影響範圍；
- 受影響公司／債務／市場；
- 生效日期；
- Cure／Waiver；
- Confirmation／Denial；
- Reversal／Dismissal；
- Thesis Failure／Recovery；
- Hard Gate／FC／RRG／Buy Cancellation等既有Decision結果。

只有改標題、重排文字、純轉載、無新事實評論或重新整理舊聞，原則上`material_update = FALSE`；可以更新`last_seen_at`，不得因此重建Event。

### 59-D｜Close Gate

Active Event**不得因幾天沒有新新聞而自動關閉**；本Work不新增7天、30天或任何timeout。

`tracking_status = CLOSED`只有在以下條件同時可確認時才成立：

1. 與Event連結的既有正式業務狀態已合法進入terminal／resolved／deconfirmed／superseded等可停止Active Refresh的狀態；
2. 沒有仍需追蹤的未決重大Assertion。

若上述任一條件UNKNOWN，Registry不得把Event自動CLOSED。**Persistence成功是工程61 Global Checkpoint Commit條件，不是Event Business Lifecycle的CLOSE條件**；兩者不得互相取代。

---

## 工程60｜Five-way Freshness Canonical Contract

### 60-A｜五種時效欄位正式拆分

正式拆成五個互不取代欄位：

1. `search_freshness`：本輪Search／Refresh流程最近是否成功完成；
2. `item_freshness`：Article／Document本身的發布／更新時間是否符合該Item契約；
3. `event_validity`：底層Event目前是否仍具正式狀態／決策意義；
4. `evidence_validity`：該Evidence版本目前是否仍能作為可用證據；
5. `assertion_validity`：該Evidence內特定Assertion目前是否仍能支持對應判斷。

五者不得合併成單一`freshness`欄位，也不得互相機械推導。

### 60-B｜Search／Item Freshness

`search_freshness`與`item_freshness`沿用既有Data Quality Freshness語意：

```text
FRESH / STALE / UNKNOWN / NOT_APPLICABLE
```

- 不新增全域「幾天就過期」規則；依既有資料頻率、`valid_until / max_age`或Provider Contract判定。
- Search Failure只代表Search Freshness受影響，不代表既有Event／Evidence／Assertion自動失效。
- Article很新不代表底層Event是新Event；Document很舊也不代表Assertion失效。

### 60-C｜Event／Evidence／Assertion Validity

`event_validity`、`evidence_validity`、`assertion_validity`固定相容：

```text
VALID / INVALID / UNKNOWN / NOT_APPLICABLE
```

並另外保存`validity_reason`；正式語意依既有事件狀態，例如：

```text
superseded / revoked / amended / cured / dismissed / reversed / resolved / deconfirmed
```

規則：

- 舊SEC filing、法院文件、監管命令、公司申報、審計意見、違約通知、契約通知，不得只因文件年齡判`INVALID`。
- `amended`只影響被正式修改的Assertion；其他未修改Assertion可維持VALID。
- Event已被合法terminal／resolved不等於歷史Evidence被刪除；PIT歷史仍保留。
- Validity無法可靠判定時必須`UNKNOWN`，不得用Item Freshness替代。

### 60-D｜Freshness Propagation Guard

固定禁止：

```text
item_freshness = FRESH  -> event_validity = VALID       # 禁止機械推導
item_freshness = STALE  -> assertion_validity = INVALID # 禁止機械推導
search_freshness = STALE -> event_validity = INVALID    # 禁止機械推導
```

合法行為是只污染真正依賴該欄位的下游輸出，並依第62章Dependency Propagation標記Data Quality／UNKNOWN。

---

## 工程61｜Coverage／Checkpoint Canonical Contract

### 61-A｜Required Safety Coverage與Optional Provider分離

每輪Search／Refresh至少保存：

```text
required_safety_domains[]
required_safety_domain_status[]
optional_providers[]
provider_results[]
active_event_refresh_completed
search_coverage_status
checkpoint_commit_eligible
global_checkpoint_id
global_checkpoint_at
persistence_status
issue_codes[]
```

`search_coverage_status`固定相容：

```text
COMPLETE / PARTIAL / INSUFFICIENT
```

判斷原則：

- `COMPLETE`：Required Safety Coverage與本輪要求的Search／Refresh範圍完整；
- `PARTIAL`：存在Optional Provider／非Safety Required缺口，但Required Safety Coverage與Active Material Event仍可可靠驗證；
- `INSUFFICIENT`：Required Safety Domain、Active Material Event Refresh、關鍵Event／Evidence Persistence或Recovery Safety State存在足以影響安全判斷的缺口。

Optional Provider失敗**不得單獨**把Coverage升格成INSUFFICIENT或建立Hard Gate。

### 61-B｜Coverage不足對Decision的正式影響

Coverage對Decision固定採Dependency Mapping：

| Coverage | Required Safety是否完整 | Decision影響 |
|---|---|---|
| `COMPLETE` | 是 | 依既有V82規則正常計算；不代表必然買／賣 |
| `PARTIAL` | 是 | 受影響Optional欄位標Issue；其餘Required-safe Decision可繼續 |
| `INSUFFICIENT` | 否／無法確認，**或Required Safety雖可驗證但關鍵Persistence／Recovery Safety State無法可靠保存／重建** | 受影響Event／Evidence依賴輸出＝`UNKNOWN`；新增Buy依既有Data Quality／Hard Gate處理 |

補充：

- `INSUFFICIENT`不得自動把Emergency判成CONFIRMED或DECONFIRMED，也不得把Structural Break Evidence缺口猜成已滿足。
- 既有已確認的Risk Reduction／Emergency Sell Intent若其所依賴的業務狀態仍有可靠Confirmed Evidence，不因單一Optional Provider失敗自動取消；是否可繼續依既有Execution／Data Quality依賴判定。
- 本Work不建立新的Sell Gate或新的Hard Gate種類。

### 61-C｜Global Checkpoint Commit Gate

`checkpoint_commit_eligible`與`search_coverage_status`分離。Global Checkpoint只有以下全部成立才可commit：

```text
required_safety_domains_satisfied == TRUE
AND active_event_refresh_completed == TRUE
AND event_evidence_dedup_completed == TRUE
AND event_evidence_persistence_succeeded == TRUE
```

因此`PARTIAL`仍可能`checkpoint_commit_eligible = TRUE`，前提是缺口只在Optional Provider且上述四項全部成立。

Partial／Crash期間只要四項未全部成立：

```text
checkpoint_commit_eligible = FALSE
Global Checkpoint不得前移
```

下一輪依Overlap補抓；Overlap Candidate仍為TBD。

### 61-D｜Provider Cursor與Global Checkpoint分離

每個Provider至少保存：

```text
provider_id
last_attempt_at
last_successful_retrieval_at
provider_cursor
provider_result_status
provider_issue_codes[]
```

Optional Provider失敗時：

- 不得推進該Provider的`last_successful_retrieval_at`／`provider_cursor`；
- Global Checkpoint若其他Commit條件完整，可獨立前移；
- 該Provider恢復後，必須以自己的`last_successful_retrieval_at`為Anchor做**帶重疊回看**補抓；`+ overlap`僅表示「加入Overlap機制」，**不得實作成把搜尋起點往後加時間而跳過失敗區間**；
- Canonical實作Invariant：`retrieval_start_at <= last_successful_retrieval_at`，實際回看寬度由`incremental_search_overlap_window`決定；
- `incremental_search_overlap_window = TBD`，不得自行填值。

---

## 工程62｜Cold Start／Search Recovery Canonical Contract

### 62-A｜Recovery State

Cold Start／Global Checkpoint Loss／Registry損壞等情況至少保存：

```text
recovery_state
recovery_reason
registry_recovered
snapshot_recovered
active_event_refresh_completed
general_search_completed
dedup_completed
persistence_completed
new_checkpoint_committed
recovery_data_quality
issue_codes[]
```

Recovery區塊中的簡寫欄位必須映射回工程61的Canonical Commit欄位，避免同義不同名：

```text
active_event_refresh_completed  -> 同工程61 Canonical Field
dedup_completed                 -> event_evidence_dedup_completed
persistence_completed           -> event_evidence_persistence_succeeded
new_checkpoint_committed        -> Global Checkpoint實際Commit結果（不是eligibility）
```

`recovery_state`固定相容：

```text
NOT_REQUIRED / IN_PROGRESS / COMPLETE / INCOMPLETE
```

`INCOMPLETE`等價映射既有語意`News/Event State Recovery Incomplete`；不是新的Hard Gate種類。

### 62-B｜Cold Start／Checkpoint Loss正式恢復順序

固定順序：

```text
1. Persistent Active Event Registry
2. Latest Formal V82 / Client Snapshot active-event references
3. Refresh all recovered Active Events
4. Cold-start General News Search
5. Dedup + Material Update classification
6. Persistence
7. New Global Checkpoint Commit
```

禁止只用「最近N天新聞」直接重建整個世界狀態；Active Event Recovery必須先於General Search。

### 62-C｜Recovery Incomplete

若Global Checkpoint、Active Event Registry與可用歷史Snapshot皆不足以安全重建重大事件狀態：

```text
recovery_state = INCOMPLETE
recovery_data_quality = INSUFFICIENT / UNKNOWN
```

下游處理：

- 受影響Safety-required Event／Evidence輸出標`UNKNOWN`；
- 依既有第62章Data Quality／Hard Gate阻擋受影響的新增Buy；
- 不得因資料不足自動確認Emergency／解除Emergency／確認Structural Break／宣告Recovery；
- 不新增獨立Recovery Hard Gate。

### 62-D｜Search Failure邊界

Search Failure不得一律等於Hard Gate：

- Optional Provider失敗，但Required Safety Domains與Active Material Events仍由其他可靠來源完整驗證 → 可`PARTIAL`，不單獨阻擋新增送單；
- Required Safety Domain無法驗證、Active Material Event無法完成必要Refresh、關鍵Persistence失敗，或Recovery Incomplete已影響安全判斷 → `INSUFFICIENT`並依既有Data Quality／Hard Gate處理。

### 62-E｜Candidate Parameter治理

4-7F／Work5只保留兩個未核定Candidate：

```text
incremental_search_overlap_window = TBD
cold_start_general_news_lookback_window = TBD
```

Work5禁止自行把TBD填成24小時、48小時、7天、30天或任何其他時間窗；也不新增`event_expiry_days`、`active_event_timeout`、全域`evidence_expiry_days`、`minimum_media_article_count`、`dedup_similarity_threshold`、`material_update_score`、`pending_wait_days`等假精確參數。

---

## Work5-B｜工程57～62共同狀態轉移摘要

| Situation | Event／Coverage State | 正式處理 |
|---|---|---|
| 同一新聞被多站轉載 | 同Original Assertion Lineage | Dedup；Independent Evidence不增加 |
| 同一Root Cause產生不同正式事件 | 多個Canonical Events | 以`related_event_ids`關聯，不合併Event ID |
| 同一Event出現重大新正式進展 | `material_update = TRUE` | 同Event ID建立新`event_version` |
| 同一URL內容重大更新 | 新Evidence Version | 若改變正式Event欄位，再建立Event Version |
| Active Event數日無新新聞 | `tracking_status = ACTIVE`維持 | 不用timeout自動CLOSE，持續Active Refresh |
| Event合法terminal且無未決重大Assertion | Registry可CLOSED | 保留完整歷史，不刪Evidence／Assertion |
| Article很舊但Assertion未被撤回／取代 | Item可STALE；Assertion仍可VALID | 不用Document Age機械失效Evidence |
| Optional Provider失敗、Required Safety完整 | `PARTIAL` | 可依既有Decision規則繼續；Provider Cursor不前移 |
| Required Safety缺口 | `INSUFFICIENT` | 依賴輸出UNKNOWN；新增Buy走既有Data Quality／Hard Gate |
| Global Checkpoint遺失 | Recovery IN_PROGRESS | 先Active Event Recovery，再General Search |
| Registry／Snapshot不足以重建安全狀態 | Recovery INCOMPLETE | 依賴輸出UNKNOWN；不得猜Event狀態 |

## Work5-C｜工程57～62共同Invariant

1. Search Window ≠ Event Lifetime ≠ Evidence Lifetime ≠ Assertion Lifetime。
2. Article／URL／Evidence／Assertion／Canonical Event不可混用Identity。
3. URL不得作Event ID或唯一Dedup Key。
4. Same Root Cause不等於Same Canonical Event；不同正式事件使用`related_event_ids`關聯。
5. Source Tier不得直接產生Event Confirmation；既有Evidence Authority × Evidence Assertion Owner不變。
6. Evidence Independence依Original Provenance／Assertion Origin；Mirror／Repost／Aggregator不增加Independent Evidence數。
7. Material Update不得被Dedup吞掉；歷史Event／Evidence／Assertion Version不得覆寫刪除。
8. Active Event不受General Search Window限制，也不得因固定天數無新聞自動CLOSED。
9. Search／Item／Event／Evidence／Assertion五種Freshness／Validity必須分離。
10. Old Document ≠ Invalid Evidence；Fresh Article ≠ New Event。
11. Coverage Status與Checkpoint Commit Eligibility分離；`PARTIAL`可在Required Safety完整時安全Commit。
12. Provider Cursor與Global Checkpoint分離；失敗Provider自己的Cursor不得因Global Checkpoint前移而跳過失敗期間。
13. Coverage不足採Dependency Propagation；只污染真正依賴缺失資料的Output。
14. Search Failure只有造成Required Safety／Active Material Event／Persistence／Recovery重大缺口時，才映射到既有Data Quality／Hard Gate。
15. Cold Start／Checkpoint Loss先恢復Active Events，再做General News Search。
16. `incremental_search_overlap_window`與`cold_start_general_news_lookback_window`維持TBD；Work5不得自行批准數值。
17. Provider補抓的Overlap是**往回覆蓋**而非把搜尋起點往後推；`retrieval_start_at <= last_successful_retrieval_at`。
18. 工程61／62共用欄位與Recovery簡寫必須有唯一Canonical Mapping，不得讓同義欄位並存而無明確定義。
19. 工程63以後的49 Fields／13 Outputs／Persistence跨系統正式介面不在本Work施工。

---

# Work6｜V82系統工程63～67｜Tactical Budget × Funding × 49 Fields × 13 Outputs × State Persistence Contract【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。**  
> 本段源自Work6工程63～67的跨系統介面、資金來源／幣別、49欄分析底稿、13欄正式輸出與State Persistence工程化，現已由工程77納入正式SOT。直接承接Work2的Execution／Position數學、Work3的Deployment Mode、Work4的Structural Break／Emergency／Reduction，以及Work5的Event／Coverage／Checkpoint治理。**不新增或修改任何投資Threshold、部署比例、Default、Fallback、Hard Gate種類、Candidate Parameter、Risk Clock、Emergency Rate或Search Window；不重算V70的Strategic／Tactical Budget。**

## Work6-A｜最高責任邊界

```text
V70
  └─ owns Strategic Risk Budget + Cross-asset Tactical Budget
        ↓ normalized V70→V82 Tactical Budget Contract
Client Project
  └─ owns client-authorized universe / caps / funding authorization
        ↓
V82
  └─ owns stock / stock-ETF eligibility, per-asset deployment, order recommendation
        ↓
Execution Adapter / Broker
  └─ owns order translation / broker facts / fills
        ↓
Persistence Layer
  └─ owns immutable snapshots + latest-state pointer + audit history
```

固定Invariant：

1. **V82不得越權重算Strategic Long-term Asset Allocation、S0/B0或跨資產Tactical Budget。**
2. V70提供的股票戰術總額度是V82本輪股票風險／配置的**上游總額度邊界**，不是逐檔目標、不是九階梯Stage，也不是「今天一定要全部買完」；若既有股票曝險已高於本輪總額度，Work63只把本輪新增Buy Capacity壓到0，不得因此自行推導強制賣出。
3. Client Project提供個別標的Target／Cap／Authorized Fund Source；V82不得把上游未授權資金變成可用資金。
4. Logical Funding Source、Accounting Allocation、Order Intent、Broker Reservation、Actual Holding、Actual Transaction必須分層；任何一層不得假裝另一層已經發生。
5. 所有Money必須帶Currency；不同幣別不得直接相加、相減或比較。
6. 工程65的49欄是完整分析底稿Canonical Contract；工程66的13欄是Presentation／Execution View，必須從49欄映射，不建立第二套Business Meaning。
7. `run_id`、Latest State、Append-only History與時間欄位只管理同一決策的Identity／Persistence／Audit，不得改變投資規則本身。

---

## 工程63｜V70 → V82 Tactical Budget Canonical Contract

### 63-A｜上游輸入最低集合

V82正式接收的V70 Tactical Budget Envelope至少包含：

```text
run_id
upstream_v70_snapshot_id
v70_stock_tactical_budget_amount
v70_stock_tactical_budget_currency
v70_stock_tactical_budget_status
v70_stock_tactical_budget_data_as_of
v70_original_dry_powder_amount
v70_original_dry_powder_currency
v70_budget_source_reference
v70_budget_data_quality
v70_budget_issue_codes[]
```

語意：

- `run_id`是本輪跨系統共用Identity，必須由同一輪V70結果原樣傳入V82，並供後續債券V75、客戶Latest State與報告沿用；V82不得另造不同Run ID。
- `upstream_v70_snapshot_id`是V82實際消費之V70正式Snapshot的Lineage Reference；它標識「用了哪一份V70結果」，不取代共用`run_id`。
- `v70_stock_tactical_budget_amount`是V70已產生／已核准的本輪股票戰術總額度；V82只消費，不反推S0/B0、不重算C／T。
- `v70_stock_tactical_budget_currency`必須明確；若上游只有比例，V70／Integration Layer必須同時提供其正式計算Base或直接正規化成Amount後再交V82，V82不得自行猜Base。
- `v70_stock_tactical_budget_status`只表示上游額度是否可用／完整；不得拿它替代逐檔Hard Gate、Fundamentals或Deployment Mode。

### 63-B｜V82股票總額度Ceiling與新增買進空間

V70交給V82的是**股票／股票ETF總戰術額度Ceiling**，不是一筆全新的「可新增買進現金」。因此先正規化總額度：

```text
v82_tactical_budget_ceiling
= MIN(
    normalized_v70_stock_tactical_budget_amount,
    applicable_client_stock_allocation_caps,
    applicable_global_stock_pool_caps
  )
```

其中：

- `normalized_v70_stock_tactical_budget_amount`：V70上游股票總戰術額度換成Work64指定之共同Budget Currency／共同Base後的Amount；若無需換匯則等於原Amount。
- `applicable_client_stock_allocation_caps`：只接受客戶專案已存在、且與V70總額度屬**同一Accounting Base／同一總股票配置語意**的正式股票總池上限；若不存在，不得為了湊`MIN`自行創造Default。**客戶本輪新增現金授權／可用資金不是這個欄位，不得把Incremental Funding Amount混進總配置Ceiling。**
- `applicable_global_stock_pool_caps`：只接受真正限制「股票總池」的既有全域／專案級正式Cap；不得新增百分比或自動Fallback。
- 個別Asset Cap、Concentration Cap、Look-through Cap仍屬逐檔／曝險層Constraint，**不得拿單一標的Cap去壓低整個股票總池Ceiling**；它們在逐檔Order Plan與Cross-asset Reconciliation時各自套用。

若任何**實際適用且Required**的總池Cap為UNKNOWN，`v82_tactical_budget_ceiling = UNKNOWN`；不得把UNKNOWN當無上限。不存在／不適用的Cap必須以`NONE / NOT_APPLICABLE`表達，不得因「沒有另一個Cap」把Ceiling變UNKNOWN。個別標的Cap UNKNOWN只污染其相依標的／曝險裁決，依既有Dependency規則處理，不把全市場總額度機械改成UNKNOWN。

**新增買進空間必須再扣除已占用股票總額度，不能直接等於`v82_tactical_budget_ceiling`。** Canonical Budget Occupancy至少分成：

```text
stock_budget_occupied_before_new_buy_amount
= existing_confirmed_stock_exposure
+ effective_active_buy_reservations
+ other_existing_committed_stock_exposure
- only_confirmed_released_or_reduced_exposure

preexisting_stock_overage_amount
= MAX(
    stock_budget_occupied_before_new_buy_amount
    - v82_tactical_budget_ceiling,
    0
  )

tactical_incremental_room_amount
= MAX(
    v82_tactical_budget_ceiling
    - stock_budget_occupied_before_new_buy_amount,
    0
  )

v82_incremental_buy_capacity_amount
= MIN(
    tactical_incremental_room_amount,
    available_authorized_incremental_funding_amount
  )
```

`stock_budget_occupied_before_new_buy_amount`與`available_authorized_incremental_funding_amount`都必須在同一Accounting Base／Budget Currency下，沿用Work36～38既有Position／Order／Fill數學與Work64資金授權語意：

- 既有有效Buy Order／Reservation已占用的額度不得再次當成可新增資金；
- 尚未成交的Sell／Reduction**Recommendation**不得提前當成已釋放額度；只有既有Execution Contract已確認可釋放的Reservation／Confirmed Fill／Confirmed Position更新才可降低占用；
- `available_authorized_incremental_funding_amount`不是新的配置Cap；它只是把Work37既有`available_cash`／可交易資金事實提升到跨標的Reconciliation層後，計算「Client Project已授權給股票買進、扣除有效Reservation後、並依Work64正規化到共同Budget Currency」的**本輪實際可新增買進資金**。不得假設「可賣SGOV／可換匯／可賣其他資產」就等於已可用現金；若Required Funding Fact未知，該Capacity依Dependency規則為UNKNOWN，不得猜值；
- 同一筆Cash／Order／Fill／Reservation不得在`available_cash`、`effective_active_buy_reservations`與其他Committed Exposure間重複計算。

因此本輪**新建或增加的Buy Intent／Order Plan合計**不得超過`v82_incremental_buy_capacity_amount`。若現有股票曝險已等於或高於Ceiling，則`v82_incremental_buy_capacity_amount = 0`；既有超額以`preexisting_stock_overage_amount`保留為狀態，**不得用`projected_post_execution_stock_allocation_amount <= ceiling`這種條件反推必須賣出既有部位**。是否減碼、等待或其他動作仍回到既有Work4／Execution規則；Work63不新增強制賣出規則。

### 63-C｜逐檔規劃與總額度守恆

每檔仍先依Work2～Work4計算自身Target、Gap、Permission與合法Order Quantity；Work63只做跨標的Budget Reconciliation。

固定：

- V70股票額度不直接分配成某一檔ETF比例；逐檔如何分配仍由V82既有Asset-local規則＋Client Project Target決定。
- 本輪所有逐檔**新增／增加Buy Intent**合計不得超過`v82_incremental_buy_capacity_amount`。若本輪開始前已有`preexisting_stock_overage_amount > 0`，在沒有獨立減碼規則成立時允許`STOCK_ALLOCATION_FINAL`仍高於Ceiling，但本輪不得再增加整體股票曝險。
- 每檔先套用自身Asset／Concentration／Look-through等既有Cap；若逐檔合法可買Gap合計仍超過剩餘Incremental Capacity，V82只能在既有規則／已授權Priority內縮小本輪Order Plan；不得提高Budget Ceiling。
- 若合法股票配置未使用完V70股票總戰術額度，未部署部分可形成`V82_UNDEPLOYED_TO_SGOV` Logical Output；不得為了「用滿預算」放寬價格、基本面或安全規則。
- `STOCK_ALLOCATION_FINAL`表示**本輪V82完成判斷後的股票／股票ETF最後配置狀態**，包含已存在且仍屬正式配置的Confirmed Position與本輪合法調整後結果；它不是「本輪新買Recommendation金額合計」。
- Active／Reserved／Confirmed金額的精確扣抵沿用Work36～38與Work64，避免同一筆資金、Order或Fill重複承諾／重複計算。

### 63-D｜Legacy／Migration邊界

現行`V70_2.html`尚未完整從客戶風險資料自行推導S0/B0；S0/B0的**Current／Legacy Producer仍可能是Mentor／人工既有流程**，真正Producer Migration仍屬後續V70工程。Work63只驗證「**上游已核准Tactical Budget如何被V82安全消費**」，不得假裝V70未完成的S0/B0演算法已完成。

---

## 工程64｜SGOV／資金來源／幣別 Canonical Contract

### 64-A｜五層資金語意必須分離

正式分成：

```text
1. Authorized Funding Source        客戶專案授權可用哪些來源
2. Logical Funding Bucket           會計／用途上的資金桶
3. Reserved Cash / Active Exposure  已被有效Order占用的可用資金
4. Actual Holding                   Broker確認的實際持倉
5. Actual Transaction               Broker確認的實際成交／換匯
```

最高Invariant：

> **Logical Funding Source ≠ Broker Transaction。**

因此「把未部署資金放入SGOV乾火藥桶」只是Logical Allocation；沒有Broker Fill以前，不得寫成已買入SGOV。

### 64-B｜SGOV角色分桶

SGOV至少分開記錄下列Canonical角色／事實；**沿用既有正式名稱，不再創造同義Alias**：

```text
SGOV_DRY_POWDER_BUCKET
SGOV_BOND_BUCKET
SGOV_ACTUAL_HOLDING
SGOV_ACTUAL_TRANSACTION
```

- `SGOV_DRY_POWDER_BUCKET`：最終整合後等待股票／跨系統部署的Logical Dry Powder用途；它是Integration Contract的Logical Bucket，不等於券商已買入SGOV。
- `SGOV_BOND_BUCKET`：若債券V75正式選中SGOV，屬正式債券配置；其投資規則仍由債券V75擁有。
- `SGOV_ACTUAL_HOLDING`：券商實際確認的SGOV總持倉Fact。
- `SGOV_ACTUAL_TRANSACTION`：券商實際SGOV買賣成交Fact。

同一實際SGOV持倉可以對應不同Logical Role，但必須由Allocation Tag／Lot或等價可稽核Mapping分開，且在同一幣別／估值時點下滿足`attributed_dry_powder_sgov_amount + attributed_bond_sgov_amount <= SGOV_ACTUAL_HOLDING.amount`；不得讓同一市值同時100%算進Dry Powder與Bond Allocation而重複計算。Logical Bucket大於實際SGOV持倉的部分可以仍是未執行的Logical Allocation，但不得偽裝成Actual Holding。

### 64-C｜V82未部署資金

`V82_UNDEPLOYED_TO_SGOV`必須用「V70股票總戰術額度Ceiling」減去「V82最後股票配置狀態」，而不是只減本輪新增買單：

```text
V82_UNDEPLOYED_TO_SGOV
= MAX(
    v82_tactical_budget_ceiling
    - stock_allocation_final_amount,
    0
  )
```

其中`stock_allocation_final_amount`是`STOCK_ALLOCATION_FINAL`在同一Accounting Base／Budget Currency下的總金額；它包含本輪後仍有效的既有股票／股票ETF配置與本輪合法調整後結果，並依Work36～38消除Active Order／Fill／Confirmed Position重複計算。它**不是Broker Fill本身，也不是「本輪新買Recommendation總額」**。

若現有股票曝險已高於Ceiling，`V82_UNDEPLOYED_TO_SGOV = 0`；Work64不因這個公式自動產生Sell，實際Reduction仍由既有V82規則決定。

`V82_UNDEPLOYED_TO_SGOV`固定是**未部署股票戰術配置額度的Logical Integration Output**，不是資金事實本身：

- 不等於SGOV已買入金額；
- 不等於Broker現金餘額，也**不憑空建立可交易Cash／Funding Source**；
- 不等於正式債券配置；
- 不得把`SGOV_BOND_BUCKET`回算成股票子彈；
- 不得把已被Confirmed Position／有效Order占用的股票額度再次算成Dry Powder；
- Mentor／Integration即使把它彙總進`SGOV_DRY_POWDER_BUCKET`，後續真正送出股票、SGOV或FX交易前，仍必須重新驗證Client Project授權、對應幣別、`available_cash`／Reserved Cash與Broker Fact；**Logical Budget Gap不得直接當成Executable Cash。**

### 64-D｜SGOV Dry Powder整合公式與幣別

既有Integration Contract維持：

```text
SGOV_DRY_POWDER_BUCKET
= V70_ORIGINAL_DRY_POWDER
+ V82_UNDEPLOYED_TO_SGOV
+ V75_UNDEPLOYED_TO_SGOV
```

但程式化時必須先滿足**同幣別可加總**：

```text
SGOV_DRY_POWDER_BUCKET_BY_CURRENCY[currency]
= SUM(all logical dry-powder components in the same currency)
```

若要產生單一Reporting Currency，**匯率方向必須機器可判定，禁止只留一個容易正反顛倒的裸`fx_rate`**：

```text
normalized_amount_target
= source_amount_source
× fx_rate_target_per_source
```

且每次正規化至少保存：

```text
source_currency
target_currency
fx_pair = SOURCE/TARGET
fx_rate_target_per_source
fx_data_as_of
fx_source
fx_data_quality
conversion_purpose = REPORTING_NORMALIZATION | EXECUTION_PLAN | ACTUAL_CONVERSION
```

若資料供應商只提供反向Pair，Integration／FX Adapter必須先顯式反轉並保存原始Pair／原始Rate與轉換Lineage；V82核心計算不得靠字串猜測乘或除。
`REPORTING_NORMALIZATION`只為比較／加總，**不是實際換匯**。只有`ACTUAL_CONVERSION`且有Broker／Bank確認的Fill／Transaction，才可改變實際Cash Balance。

### 64-E｜USD／TWD／Reserved Cash

每一Money Object至少：

```text
amount
currency
source_reference
as_of
status
```

固定：

- USD、TWD與其他幣別不得裸數相加。
- `authorized_fund_source`必須來自Client Project；V82不得自行決定出售哪個資產籌資。
- `reserved_cash`只反映有效Active Order／Settlement Reservation；純Recommendation尚未送單時不得假裝Broker已Reserve。
- Cancel／Reject／Partial Fill後的Reserved Cash釋放，以Execution Adapter／Broker Fact為準，不以V82文字建議自行歸零。
- FX Conversion Plan與Actual FX Transaction分離；匯率門檻、換匯授權與退出計畫若屬客戶特定條件，仍由Client Project提供。

---

## 工程65｜49欄分析底稿 Canonical Data Contract

### 65-A｜共同Field Envelope

工程65鎖定**剛好49個Top-level Canonical Fields**。每一欄除本體Value外，統一帶Work67 Metadata Envelope：

```text
field_name
value
data_type
data_as_of
source_reference
data_quality
issue_codes[]
rule_version
run_id
```

`UNKNOWN`永遠是資料／裁決狀態，不得用`0 / FALSE / NEUTRAL / empty string`偽裝。

下表中的`Enum／Range = Existing Contract`表示沿用V82既有正式Enum／Range，**本Work不建立第二套Enum或數值Threshold**。

### 65-B｜Identity／Type／UNKNOWN Registry（1～49）

|#|Canonical Field Name|中文名稱|Data Type|Enum／Range|Req／Opt|Nullable|UNKNOWN Policy|
|---:|---|---|---|---|---|---|---|
|1|`latest_price`|最新價|MoneyPerUnit|`>0`或UNKNOWN|Required|No|無可靠可交易價→UNKNOWN|
|2|`market_data_as_of`|資料日期／行情截至時間|DateTime|合法時區時間|Required|No|未知→UNKNOWN；不得用evaluated_at代替|
|3|`asset_behavior_classification`|股性分類|EnumRef|Existing Contract|Required|No|無法分類→UNKNOWN|
|4|`primary_framework`|主框架／專屬框架|RuleRef|Existing Framework Ref|Required|No|無可用Framework→UNKNOWN|
|5|`secondary_framework`|副框架／交叉驗證層|RuleRef/List|Existing Framework Ref|Optional|Yes|不適用→NULL；資料不足→UNKNOWN|
|6|`fundamental_state`|基本面|StructuredState|Existing Contract|Required|No|Required基本面缺口→UNKNOWN|
|7|`valuation_state`|估值|StructuredState|Existing Waterfall|Required|No|無合法估值法／資料不足→UNKNOWN|
|8|`td9_high_state`|高TD9|SignalState|Existing TD9 Contract|Required|Yes|不可靠→UNKNOWN；不捏造|
|9|`td9_low_state`|低TD9|SignalState|Existing TD9 Contract|Required|Yes|不可靠→UNKNOWN；不捏造|
|10|`kd_state`|KD|SignalState|Existing Contract|Required|Yes|不可靠→UNKNOWN|
|11|`macd_state`|MACD|SignalState|Existing Contract|Required|Yes|不可靠→UNKNOWN|
|12|`ma_state`|MA|StructuredSignal|Existing MA Contract|Required|Yes|缺必要均線→受影響子欄UNKNOWN|
|13|`emv_state`|EMV|SignalState|Existing Contract|Required|Yes|不可靠→UNKNOWN|
|14|`rsi_state`|RSI|SignalState|Existing Contract|Required|Yes|不可靠→UNKNOWN|
|15|`volume_price_state`|成交量／量價|StructuredSignal|Existing Contract|Required|Yes|Volume缺失只污染相依欄|
|16|`daily_timeframe_state`|日線|TimeframeState|Existing Contract|Required|Yes|Completed Bar不足→UNKNOWN|
|17|`weekly_timeframe_state`|週線|TimeframeState|Existing Contract|Required|Yes|Completed Bar不足→UNKNOWN|
|18|`monthly_timeframe_state`|月線|TimeframeState|Existing Contract|Required|Yes|Completed Bar不足→UNKNOWN|
|19|`atr_value`|ATR|Decimal|`>=0`|Required|Yes|無可靠ATR→UNKNOWN|
|20|`drawdown_from_reference_high`|高點回撤|Rate|依既有Reference High定義|Required|Yes|Reference High未知→UNKNOWN|
|21|`previous_swing_low_1`|前低|MoneyPerUnit|Existing Swing Contract|Required|Yes|資料足夠且確認不存在→NONE；資料不足／無法可靠判定→UNKNOWN|
|22|`previous_swing_low_2`|前前低|MoneyPerUnit|Existing Swing Contract|Optional|Yes|已知不存在／不適用→NONE／NULL；資料不足→UNKNOWN|
|23|`previous_swing_low_3`|前前前低|MoneyPerUnit|Existing Swing Contract|Optional|Yes|已知不存在／不適用→NONE／NULL；資料不足→UNKNOWN|
|24|`price_map`|價格地圖|StructuredPriceMap|LAYER_1～LAYER_5 Existing Contract|Required|No|Required輸入不足→UNKNOWN|
|25|`first_buy_zone`|第一買點／合理價區|PriceZoneRef|由Price Map映射|Required|Yes|無合法映射→UNKNOWN|
|26|`second_price_zone`|甜甜價／第二價格區|PriceZoneRef|由Price Map映射|Required|Yes|無合法映射→UNKNOWN|
|27|`deep_extreme_discount_zone`|深度／極端折價區|PriceZoneRef/List|由Price Map映射|Required|Yes|無合法映射→UNKNOWN|
|28|`left_buy_point_state`|左側狀態|TriState/Structured|Existing Left Predicate|Required|No|Required Predicate不明→UNKNOWN|
|29|`right_confirmation_state`|右側狀態|TriState/Structured|Existing Right Contract|Required|No|Required Predicate不明→UNKNOWN|
|30|`runaway_state`|Runaway狀態|StructuredState|Runaway Up／Down Existing Contracts|Required|No|衝突／不足→UNKNOWN或既有安全Fallback|
|31|`macro_state`|Macro位置＋方向＋速度|StructuredState|Level＋Direction＋Speed|Required|No|Safety-required缺口→UNKNOWN|
|32|`credit_liquidity_state`|信用／流動性位置＋方向＋速度|StructuredState|Level＋Direction＋Speed|Required|No|Safety-required缺口→UNKNOWN|
|33|`material_news_policy_state`|重大新聞／政策|StructuredEventState|Work5 Event Contract|Required|Yes|Coverage不足→受影響子欄UNKNOWN|
|34|`exposure_overlap`|曝險重疊|StructuredExposure|Existing Look-through Contract|Required|Yes|Coverage不足不攤回已知權重|
|35|`position_cap`|部位上限|Money/Rate Constraint|Explicit Authorized Caps only|Required|Yes|確認無額外Applicable Cap→NONE／NOT_APPLICABLE；應存在但取不到→UNKNOWN；不得假設無上限|
|36|`project_target_position`|客戶專案目標部位|Money/Rate Target|Client-approved|Required|No|未核准→UNKNOWN|
|37|`confirmed_position`|現有部位|PositionFact|Broker／confirmed source|Required|No|對帳未完成→UNKNOWN|
|38|`actual_completion_rate`|Actual Completion Rate|Rate|Work38 Existing Formula|Required|No|Target或Confirmed Position未知→UNKNOWN|
|39|`normal_deployment_mode`|Deployment Mode|Enum|Base／Left Overweight／Right Confirmation／Trend Deployment／UNKNOWN|Required|No|高順位Predicate UNKNOWN且影響Mode→UNKNOWN|
|40|`primary_special_classification`|今日特殊分類|Enum/Display|六類Existing Contract；全False顯示「無特殊分類」|Required|No|高順位UNKNOWN可令Primary=UNKNOWN|
|41|`execution_action`|今日動作|ActionState|Existing Execution Result／Risk Action|Required|No|執行裁決不足→UNKNOWN|
|42|`canonical_deployment_target_rate`|執行比例（累積部署目標率）|Rate|10/20/30/45/60/75/85/95/100% Existing Contract|Required|No|Stage／Target無法裁決→UNKNOWN|
|43|`execution_amount`|執行金額|Money|`>=0`|Required|Yes|已知本輪不執行→KNOWN 0；需執行但Price／Budget／Gap任一Required未知→UNKNOWN|
|44|`execution_quantity`|執行股數|Quantity|依lot／fractional／precision|Required|Yes|已知本輪不下單→KNOWN 0；需下單但Adapter規格或Price未知→UNKNOWN|
|45|`execution_price`|執行價格|MoneyPerUnit|合法tick／price rules|Required|Yes|已知本輪不下單→NOT_APPLICABLE／NULL；需下單但無合法Order Price→UNKNOWN|
|46|`projected_post_fill_completion_rate`|預估成交後完成率|Rate|Work65 Post-fill Projection（承接Work36～38）|Required|Yes|已知無Planned Fill→NOT_APPLICABLE／NULL；有Planned Fill但Order Plan不足→UNKNOWN；Confirmed Fill後由#37／#38重算Actual|
|47|`order_submission_plan`|是否掛單／掛單方式|StructuredOrderPlan|Existing Work36＋Adapter Contract|Required|No|完整裁決為不下單→`should_place_order=FALSE`且order mechanics為NOT_APPLICABLE；無法裁決是否下單→UNKNOWN|
|48|`cancel_conditions`|取消條件|ConditionSet|Existing Gates／Events／Order rules|Required|Yes|無Active／Planned Order且已知不需取消→NOT_APPLICABLE／NONE；有Order但條件資料不足→UNKNOWN|
|49|`reevaluation_conditions`|下一次重新評估條件|ConditionSet|Existing Trigger Types|Required|No|無法建立安全Trigger→UNKNOWN|

### 65-C｜Provenance／Derivation／Freshness Registry（1～49）

縮寫：`MD=Market Data`、`CP=Client Project`、`BR=Broker/Execution Fact`、`V70=V70 Snapshot`、`EV=Work5 Event System`、`V82=V82 Rule Engine`、`EA=Execution Adapter`。`Same-run=Y`表示必須與本輪跨系統共用`run_id`綁定；`C`表示只有在該欄被本輪Decision依賴時才要求Same-run一致性。

|#|Source|Rule Owner|Raw／Derived|Derivation Formula／Method|Derivation Owner|Freshness Requirement|Same-run|Output Order|
|---:|---|---|---|---|---|---|:---:|---|
|1|MD|V82 semantic / MD fact|Raw|Provider confirmed trade/quote|MD|Current contract-valid market fact|Y|49#1|
|2|MD|V82 semantic|Raw|行情本身as-of|MD|與#1同一行情版本|Y|49#2|
|3|Instrument metadata＋V82|V82|Derived|Existing asset-behavior rules|V82|Instrument identity current|Y|49#3|
|4|V82 rule registry|V82|Derived|Asset→Primary Framework resolver|V82|Rule-version current|Y|49#4|
|5|V82 rule registry|V82|Derived|Applicable cross-check resolver|V82|Rule-version current|C|49#5|
|6|Financial facts|V82|Derived|Work30／existing fundamentals|V82|依財報／guidance contract|Y|49#6|
|7|Valuation facts|V82|Derived|Work28／29 Waterfall|V82|PIT＋method-specific freshness|Y|49#7|
|8|OHLC|V82|Derived|Existing TD9 high|V82|Completed bars only|Y|49#8|
|9|OHLC|V82|Derived|Existing TD9 low|V82|Completed bars only|Y|49#9|
|10|OHLC|V82|Derived|Existing KD|V82|Completed bars only|Y|49#10|
|11|OHLC|V82|Derived|Existing MACD|V82|Completed bars only|Y|49#11|
|12|OHLC|V82|Derived|Existing MA set|V82|Completed bars only|Y|49#12|
|13|OHLCV|V82|Derived|Existing EMV|V82|Completed bars only|Y|49#13|
|14|OHLC|V82|Derived|Existing RSI|V82|Completed bars only|Y|49#14|
|15|OHLCV|V82|Derived|Existing volume/price logic|V82|Completed bars only|Y|49#15|
|16|OHLCV|V82|Derived|Daily aggregation|V82|Latest completed daily bar|Y|49#16|
|17|OHLCV|V82|Derived|Weekly aggregation|V82|Latest completed weekly bar|Y|49#17|
|18|OHLCV|V82|Derived|Monthly aggregation|V82|Latest completed monthly bar|Y|49#18|
|19|OHLC|V82|Derived|Existing ATR contract|V82|Same timeframe completed bars|Y|49#19|
|20|MD＋Swing|V82|Derived|Existing reference-high drawdown|V82|Reference high＋price current|Y|49#20|
|21|Swing engine|V82|Derived|Most recent Confirmed Swing Low|V82|Structure current|Y|49#21|
|22|Swing engine|V82|Derived|Second prior Confirmed Swing Low|V82|Structure current|C|49#22|
|23|Swing engine|V82|Derived|Third prior Confirmed Swing Low|V82|Structure current|C|49#23|
|24|MD＋Valuation＋Fundamentals|V82|Derived|Engineering27 five-layer map|V82|All required dependencies current|Y|49#24|
|25|#24|V82|Derived|Existing first-zone semantic mapping|V82|#24 current|Y|49#25|
|26|#24|V82|Derived|Existing second/sweet-zone mapping|V82|#24 current|Y|49#26|
|27|#24|V82|Derived|Existing deep/extreme-zone mapping|V82|#24 current|Y|49#27|
|28|#24＋Safety＋Fundamentals|V82|Derived|Work41 predicate|V82|Dependencies current|Y|49#28|
|29|Price＋Technical＋T+1|V82|Derived|Work42 predicate/count|V82|Dependencies current|Y|49#29|
|30|Price＋ATR＋Volume＋Safety|V82|Derived|Work43/44 contracts|V82|Dependencies current|Y|49#30|
|31|V70＋Macro Delta|V70 owner / V82 consumer|Derived/Consumed|Level＋Direction＋Speed|V70；V82只補Delta|Upstream fresh＋new material delta|Y|49#31|
|32|Credit/Liquidity feeds＋V70|V82 consumer|Derived/Consumed|Existing Level＋Direction＋Speed|Existing owner|Safety-required freshness|Y|49#32|
|33|EV|V82 decision owner|Derived/Consumed|Work57～62 Event→Decision mapping|V82|Active Event refresh＋coverage|Y|49#33|
|34|Holdings/Exposure data|V82|Derived|Work31 Look-through|V82|Holdings-as-of contract|Y|49#34|
|35|CP＋existing caps|CP authority / V82 consumer|Raw/Derived|MIN of applicable explicit caps only|V82 reconciliation|Authorization current|Y|49#35|
|36|CP|CP authority|Raw|Client-approved target|CP|Latest approved target|Y|49#36|
|37|BR|Broker fact authority|Raw|Confirmed position reconciliation|BR/V82 reconcile|Latest confirmed broker state|Y|49#37|
|38|#36＋#37|V82|Derived|Work38 `actual_completion_rate = confirmed_position_amount / project_target_position_amount`|V82|Same-run reconciled target/position|Y|49#38|
|39|Work40～43 predicates|V82|Derived|Tri-state priority mode selection|V82|Same-run predicates|Y|49#39|
|40|Six special predicates|V82|Derived|Existing priority arbitration|V82|Same-run predicates|Y|49#40|
|41|#39/#40＋Risk/Permission|V82|Derived|Existing Execution Priority|V82|Same-run decision state|Y|49#41|
|42|Existing 9-stage ladder|V82|Derived|Canonical stage→target rate|V82|Same-run stage|Y|49#42|
|43|Gap＋Budget＋Caps＋Order rules|V82|Derived|Work37 amount math＋Work63 ceiling|V82|Same-run all required inputs|Y|49#43|
|44|#43＋#45＋EA|V82/EA|Derived|Quantity/lot/fractional rounding|EA technical; V82 intent|Same-run executable price/rules|Y|49#44|
|45|Price Map＋EA|V82/EA|Derived|Existing order-price rules＋tick|V82 decision / EA translate|Current tradable context|Y|49#45|
|46|#36/#37＋Work38 projected position＋#41/#43 planned execution|V82|Derived|`projected_post_fill_position_amount / project_target_position_amount`；只加尚未計入Work38 Projected Position的Planned Execution Delta|V82|Same-run order plan|Y|49#46|
|47|Permission＋Order Intent＋EA|V82/EA|Derived|`should_place_order`＋order mechanics|V82 intent / EA translate|Same-run|Y|49#47|
|48|Gates＋Events＋Order state|V82|Derived|Existing cancel/invalidation rules|V82|Same-run; refresh on material event|Y|49#48|
|49|Price/Data/Event triggers|V82|Derived|Existing reevaluation trigger set|V82|Same-run; event-driven|Y|49#49|

### 65-D｜Canonical Naming與結構封口

固定：

1. #39 Canonical Name是`normal_deployment_mode`；**Pause／減碼不是第五／第六個Deployment Mode**。它們由#41 `execution_action`呈現。
2. #42雖沿用人類標籤「執行比例」，Machine Meaning固定是`canonical_deployment_target_rate`，即九階梯**累積目標完成率**，不是「今日額外投入比例」。
3. #46 Canonical Name是`projected_post_fill_completion_rate`；它只表示成交前的Projected Completion。成交確認後不得把#46預估值改名／冒充Actual，必須由#37 Confirmed Position重算#38 `actual_completion_rate`。

   #46唯一計算語意固定為：

   ```text
   planned_execution_delta_amount
   = + execution_amount   （若#41為本輪新Buy，且該Intent尚未計入Work38 projected_position_amount）
   = - execution_amount   （若#41為正式Sell／Reduction，且該Intent尚未計入Work38 projected_position_amount）

   projected_post_fill_position_amount
   = projected_position_amount
   + planned_execution_delta_amount

   projected_post_fill_completion_rate
   = projected_post_fill_position_amount
   / project_target_position_amount
   ```

   - `projected_position_amount`沿用Work38，已含Confirmed Position＋既有Active Buy－既有Active Sell；因此**已在Active Order Exposure中的訂單不得於#46再加一次**。
   - Cancel／Replace時，必須先依Work36 Order Reconciliation確定舊Active Exposure與新Successor Intent的有效狀態，再計算Delta，禁止Double Count。
   - `project_target_position_amount = 0`或Required Target未知時，沿用Work38除法安全規則輸出UNKNOWN／not computable；無Planned Fill時則為`NOT_APPLICABLE / NULL`。
4. #47是Structured Object，至少含：

```text
should_place_order
order_type
limit_price
quantity
time_in_force
scheduling_mode
broker_or_adapter_constraints
order_intent_id
```

因此工程66的「是否掛單」與「掛單方式」都映射到同一Canonical #47的不同子欄；不新增第50欄。

#47只承接Order Plan結構，不重算#44／#45：若`quantity`與`limit_price`存在，必須分別與#44 `execution_quantity`、#45 `execution_price`一致；不一致時標記Contract Conflict，不得形成兩套執行數字。

已知No-action與資料不足必須分流：若#41已完整裁決為本輪不新增／不下單，#43／#44可為**KNOWN 0**、#45／#46／#48可依語意為`NOT_APPLICABLE / NONE`、#47 `should_place_order = FALSE`；只有「本來需要裁決／下單，但Required資料不足」才輸出UNKNOWN。**不得把正常No-action誤標成Data Insufficiency，也不得把UNKNOWN偽裝成FALSE／0／不適用。**
5. 同義不同名禁止：Presentation Label可以保留中文舊稱，但Machine Field只能使用本工程Canonical Name。
6. 同名不同義禁止：不同Domain的`state`、`rate`、`timestamp`不得共用一個裸欄位名。

---

## 工程66｜13欄正式執行輸出 Canonical Mapping

### 66-A｜13欄只是一個View

13欄固定順序保留，但全部從工程65的Canonical Fields讀取：

|順序|正式輸出|Canonical Mapping|Machine／Presentation語意|
|---:|---|---|---|
|1|今日特殊分類|#40 `primary_special_classification`|六類Primary；全部False顯示「無特殊分類」；UNKNOWN不得偽裝無特殊分類|
|2|目前部署階段|#39 `normal_deployment_mode`＋#41 Context|Machine Mode只允許Base/Left/Right/Trend/UNKNOWN；若當輪被暫停／減碼，於顯示層加註#41，不把Pause／Reduce塞入Mode Enum|
|3|目標與完成率|#36 `project_target_position`＋#37 `confirmed_position`＋#38 `actual_completion_rate`|同一區塊顯示三個Canonical Facts|
|4|今日動作|#41 `execution_action`|Buy／No-new-buy／Reduce／其他既有正式Execution Result|
|5|執行比例|#42 `canonical_deployment_target_rate`|九階梯累積Target Rate；不是每層額外投入比例|
|6|執行金額|#43 `execution_amount`|本輪合法Recommendation Amount；受Work63 Budget Ceiling約束|
|7|執行股數|#44 `execution_quantity`|經EA lot／fractional／precision規則後數量|
|8|執行價格|#45 `execution_price`|合法Order Price／Price Plan|
|9|成交後完成率|#46 `projected_post_fill_completion_rate`|有Planned Fill時成交前明示「預估」；無Planned Fill顯示不適用；實際Fill後改讀#38新Actual|
|10|是否掛單|#47 `order_submission_plan.should_place_order`|TRUE／FALSE／UNKNOWN|
|11|掛單方式|#47 `order_submission_plan.{order_type,time_in_force,scheduling_mode}`|限價／GTC／預約等只是顯示組合，不把不同技術維度塞成單一Enum|
|12|取消條件|#48 `cancel_conditions`|Machine-readable條件＋Human-readable理由|
|13|下一次重新評估條件|#49 `reevaluation_conditions`|Price／Data／Event／State Trigger集合|

### 66-B｜輸出Completeness Gate

一筆正式13欄Output至少保存：

```text
run_id
asset_id
rule_version
data_as_of
evaluated_at
source_lineage
output_status
fields_1_to_13
```

`output_status`只管理輸出完整性，不建立投資State。若某個Required Canonical Field=UNKNOWN：

- 受影響輸出欄必須顯示UNKNOWN與Issue Code；
- 不得自動填0、FALSE、「無特殊分類」、「不掛」或「本輪不新增」；
- 是否阻擋新增Buy仍回到既有Data Quality／Hard Gate Dependency，不新增Output Hard Gate。

反之，若所有Required依賴都已知且#41明確裁決為正常No-action，則`execution_amount=0`、`execution_quantity=0`、`should_place_order=FALSE`是**已知結果**，order price／projected fill／cancel condition可依語意標`NOT_APPLICABLE / NONE`；這種正常No-action不得把`output_status`降成INCOMPLETE。

### 66-C｜建議、Order與Fill分離

13欄輸出是**正式V82決策／建議**；即使#10=TRUE，也不等於Broker已收到Order。正式生命週期仍為：

```text
Recommendation
→ Order Intent
→ Submitted Order
→ Broker Order State
→ Confirmed Fill
→ Confirmed Position
```

因此：

- 未送單不得更新Broker Reserved Cash；
- 未成交不得更新Confirmed Position；
- Projected Completion不得寫成Actual Completion；
- 客戶自主動作必須和V82 Recommendation分開保存。

---

## 工程67｜run_id／Latest State／Snapshot History／Time Contract

### 67-A｜Shared run_id Identity

Work67正式封口：

```text
run_id                       = V70 → V82 → 債券V75 → 客戶Latest State → Report之同一輪共用Run Identity
v82_snapshot_id              = 本次V82正式Immutable Snapshot唯一Identity
upstream_v70_snapshot_id     = 本輪實際消費之V70正式Snapshot Lineage Reference
upstream_event_checkpoint_id = Work5 Global Checkpoint Reference（若適用）
parent_v82_snapshot_id       = 前一個正式V82 Snapshot Lineage（若存在）
supersedes_v82_snapshot_id   = 同一Run內合法修訂時，被取代之V82 Snapshot（若存在）
```

最高Invariant：

> **同一輪正式決策鏈只能有一個共用`run_id`；V82必須沿用V70交付的同一`run_id`，不能自行產生另一個Run Identity。**

V82自己的不可變物件身份由`v82_snapshot_id`負責；V70的具體版本身份由`upstream_v70_snapshot_id`負責。也就是：**Run Identity共享，Module Snapshot Identity分開。**

既有「優先沿用V70 run_id」不是Legacy權宜，而是正式跨系統Contract；Work67把它工程化成可驗證的Same-run約束。若Legacy V70資料沒有`run_id`，必須由Orchestration／Integration在正式下游Commit前建立一個本輪共用`run_id`並向V82、債券V75與後續狀態／報告一致傳遞；不得由各Engine各自補一個不同ID。既有「可依台灣時間戳完成本輪」只可作為Legacy共用Run ID的產生來源／識別素材，**不得解讀成下游正式結果可以沒有`run_id`或各模組各用不同時間戳**。

### 67-B｜same_run_consistency

`same_run_consistency`至少檢查：

```text
same shared run_id
same upstream V70 snapshot reference required by this run
same captured rule_version_set / module-version lineage required by this run
same client_project_version / authorization reference
same required global safety checkpoint lineage
same currency normalization basis for fields participating in arithmetic
```

Asset Delta可以有自己的更新時間與Snapshot Reference，但若仍屬同一正式Run，必須攜帶同一`run_id`，並明確保存`delta_source_reference`／`delta_data_as_of`／lineage；若它已構成另一輪正式決策，則建立新的共用`run_id`，不得把兩輪資料靜默拼接。

同一份正式報告的逐檔49欄、13欄Output、Order Recommendation與Persistence都必須可回溯至同一`run_id`。不得把不同Run的逐檔Output拼成一份「同輪」正式報告。

若Required Same-run欄位無法證明一致：

```text
same_run_consistency = FALSE / UNKNOWN
```

受影響的正式Output不得標成COMPLETE；是否禁止Buy仍回到既有Dependency／Hard Gate，不新增新的投資Gate。

### 67-C｜Latest State與Append-only History

正式Persistence分三層：

```text
1. Working / Scratch State
2. Immutable Snapshot History
3. Latest State Pointer / Materialized Latest View
```

固定：

- `Working / Scratch State`：本Run中間計算，可重算／清空，不是正式歷史。
- `Immutable Snapshot History`：每次成功Formal Commit都Append-only；歷史Snapshot不得覆寫、改值或刪除以假裝過去知道現在資料。
- `Latest State`：只是一個指向「最近成功Formal Commit Snapshot」的Pointer／Materialized View；它可以更新指向，但**不能取代History**。
- 每一個V82 Formal Snapshot必須同時保存`run_id`與`v82_snapshot_id`，所以既能跨模組追蹤同一輪，也能唯一定位V82自身不可變物件。

Canonical Commit順序：

```text
validate same_run_consistency
→ build canonical business payload + stable payload fingerprint
→ atomically persist immutable V82 snapshot with storage-assigned persisted_at
→ verify immutable snapshot persistence success
→ conditionally advance latest_state pointer with compare-and-set / expected previous pointer
→ optionally record latest_state_updated_at outside immutable business payload
```

`persisted_at`是Immutable Snapshot**成功落盤／Commit的時間**，必須在Snapshot寫入成功時由Persistence Layer一起確定；不得先寫一份Immutable Snapshot、再事後修改同一Snapshot補`persisted_at`。若Immutable Snapshot寫入失敗，Latest State不得前移。Latest Pointer更新必須使用`expected_previous_latest_snapshot_id`／等價Revision Token做Compare-and-Set；禁止Blind Last-writer-wins。若Pointer因競爭、版本不符或其他原因更新失敗，History仍保留已成功Commit且已帶`persisted_at`的Snapshot，系統標記`LATEST_POINTER_CONFLICT / RECONCILIATION_REQUIRED`並重新讀取Current Latest後裁決，不得把新Snapshot靜默丟失，也不得讓較舊Run／Revision覆蓋較新的Latest。

### 67-D｜Idempotency、Revision與Conflict

- Canonical Payload Fingerprint固定針對**可重現的Decision Business Payload＋Required Data Lineage／Rule Version**計算；`data_as_of`與會影響判斷的Input／Output／Lineage必須進Fingerprint，但不得把`evaluated_at`、`persisted_at`、`latest_state_updated_at`等Wall-clock／Persistence時間，或其他每次重試都會改變但不改Business Meaning的metadata混入Fingerprint，否則同一重試會被誤判成新Snapshot。
- 重試同一`run_id`＋同一Canonical Payload Fingerprint：視為Idempotent Retry，回傳／重用既存正式Snapshot，不新增重複Business Snapshot，也不得改寫原Snapshot的`evaluated_at`／`persisted_at`。若需要保存Retry Attempt時間，另寫Operational Audit Log，不修改Immutable Business Snapshot。
- 同一`v82_snapshot_id`若出現不同Canonical Payload：標`SNAPSHOT_ID_PAYLOAD_CONFLICT`，不得覆寫既存Snapshot。
- 同一`run_id`在正式Commit前若因Fresh Data／合法Re-evaluation需要產生新V82 Snapshot，必須建立新的`v82_snapshot_id`並用`supersedes_v82_snapshot_id`串起Lineage；不得修改舊Snapshot。
- 另一輪正式決策使用新的共用`run_id`；新Run不得覆寫舊Run History；`parent_v82_snapshot_id`可連到上一個正式V82 Snapshot。
- V82 49欄／13欄中的`rule_version`表示**實際產生該V82結果的V82規則版本**；Formal Snapshot另保存結構化`rule_version_set`／upstream version references，記錄本輪實際消費的V70、V75（若已進入該階段）、Work5 Event Contract及其他Required Contract版本。不同模組的版號不要求字串相同，但同一份正式Run／Report必須引用同一組已捕捉的版本Lineage；不得只寫「latest」。

### 67-E｜Time Contract

所有正式Snapshot至少分開：

```text
data_as_of
evaluated_at
persisted_at
```

語意：

- `data_as_of`：**資料本身截至何時**。因不同Domain時間可不同，Canonical型別允許`AsOfMap`／field-level `data_as_of`；不得用單一模糊時間掩蓋Macro、Price、Fundamentals、News、Broker時點差異。
- `evaluated_at`：V82完成本輪決策計算的時間。
- `persisted_at`：Formal Snapshot成功寫入Persistence Layer的時間。

需要時另保留：

```text
event_occurred_at
source_published_at
source_updated_at
retrieved_at
broker_updated_at
order_submitted_at
fill_occurred_at
```

固定禁止：

- 用`persisted_at`冒充`data_as_of`；
- 用文章發布時間冒充事件發生時間；
- 用Order Submitted時間冒充Fill時間；
- 用Broker最後同步時間冒充Market Data時間；
- 把所有時間塞進單一`timestamp`後失去語意。

### 67-F｜舊欄位Canonical Mapping

既有Legacy欄位不直接刪除歷史，但新Implementation必須映射：

```text
analysis_timestamp          -> evaluated_at
market_data_as_of           -> data_as_of.market
macro_snapshot_timestamp    -> data_as_of.macro / upstream V70 snapshot time
snapshot_timestamp          -> source/upstream snapshot time（不得自動等於evaluated_at）
```

既有`STOCK_VALUATION_SNAPSHOT_HISTORY`可作Markdown時代的Append-only Logical Store；未來Database是Physical Persistence Implementation。Migration期間仍只能有一條Canonical Write Path，不得Markdown與Database各自獨立改同一Latest Business State。

---

## Work6-B｜工程63～67共同資料流

```text
Client Project Authorization
+ V70 Tactical Budget Envelope
+ V70 Macro Snapshot / Delta
+ V82 Asset-local Facts / Events / Positions
        ↓
Currency Normalization (no implicit FX transaction)
        ↓
V82 Tactical Budget Ceiling
        ↓
49-field Canonical Analysis Record per asset
        ↓
Cross-asset Budget Reconciliation
        ↓
13-field Formal Execution View
        ↓
Order Recommendation / Intent (still not a fill)
        ↓
Immutable Snapshot History
        ↓
Latest State Pointer
```

## Work6-C｜工程63～67共同Invariant

1. V70是Strategic／Cross-asset Tactical Budget Owner；V82不得重算S0/B0或跨資產總額度。
2. V70股票戰術額度是總額度Ceiling，不是逐檔Target，也不是今日必須用滿的Quota；既有曝險高於Ceiling時只把新增Buy Capacity壓到0，不自行生成Sell。
3. Client Project未授權的資金來源不得被V82自行啟用。
4. Logical Funding Bucket、Reserved Cash、Actual Holding、Actual Transaction四者不得混寫；新增現金授權不得混成總配置Cap。
5. SGOV沿用既有`SGOV_DRY_POWDER_BUCKET`與`SGOV_BOND_BUCKET`正式名稱分桶；實際持倉需可稽核分配，禁止重複計算與另造同義Alias。
6. 不同幣別不得裸加總；FX方向固定為`fx_rate_target_per_source`；Reporting FX Normalization不等於Actual FX Conversion。
7. `V82_UNDEPLOYED_TO_SGOV`是Logical Integration Output，不等於SGOV已成交。
8. 49欄Top-level Canonical Field數固定為49；#47用Structured Order Plan承接「是否掛單＋掛單方式」，不得為了拆UI欄位偷增第50欄。
9. #39只表示四種正常Deployment Mode＋UNKNOWN；Pause／Reduce屬Execution Action，不得復活WAIT或新Mode。
10. #42是九階梯累積Canonical Target Rate，不是今日額外投入比例。
11. #46固定名為`projected_post_fill_completion_rate`且成交前只能是Projected Completion；Confirmed Fill後由#37／#38重算Actual；No-order時可為NOT_APPLICABLE。
12. 13欄Output全部映射工程65 Canonical Fields，不建立第二套計算公式。
13. 同一輪`run_id`由V70→V82→債券V75→客戶Latest State→Report共用；V82自身物件Identity由`v82_snapshot_id`分離管理。
14. Same-run正式報告不得拼接不同`run_id`的逐檔Output。
15. Immutable History append-only；Latest State只是指標／View，不得覆寫歷史；Pointer更新必須Compare-and-Set，禁止Blind Last-writer-wins。
16. Immutable Snapshot不得覆寫；同一Snapshot ID＋不同Payload必須Conflict/Reconciliation，同一Run合法修訂必須建立新`v82_snapshot_id`與supersedes lineage。
17. `data_as_of`、`evaluated_at`、`persisted_at`必須分開；Canonical Business Fingerprint排除純Wall-clock／Persistence時間，但保留會改變Decision Meaning的Data Lineage。
18. Work6不新增投資Threshold、比例、Default、Fallback、Hard Gate種類或Candidate Parameter。
19. 工程68以後未施工。

---

# 執行章C｜V82下單前最後檢查表
















任何「買進／加碼」在送單前，先完成Hard Gate，再檢查Soft Signal。
















## A. Hard Gate｜全部必須通過
















- [ ] 已確認標的、交易所／市場與最新可交易價格口徑
- [ ] 已確認基本面無重大破壞／投資論點未失效
- [ ] 已確認非Runaway Down或其他重大價格結構失速
- [ ] 已檢查HY OAS／VIX／MOVE／Treasury流動性，無Level 3危機
- [ ] 已檢查日圓套利風險，未達Level 3跨資產去槓桿
- [ ] 已檢查重大新聞／政策／事件Gap風險
- [ ] 已確認專案預算、部位上限、剩餘可建倉額度與Look-through重疊曝險
- [ ] 有專案預算時已能正確換算金額與股數
















**任何Hard Gate未完成：LivingWaterAI本輪不得建議、產生或執行新增買進／加碼送單。**
















客戶本人仍保有最終交易決策權；若客戶在已收到完整風險警告後仍自行交易，紀錄必須標示：
















> **客戶自主決策｜非V82正式建議。**
















## B. Soft Signal｜依可取得資料完成，不得捏造
















固定技術順序仍為：
















**高TD9 → 低TD9 → KD → MACD → MA → EMV → RSI → 成交量／量價**
















並同步檢查：
















- [ ] 日線／週線／月線
- [ ] ATR
- [ ] Confirmed Swing Low／High
- [ ] 個別均線與量價結構
- [ ] 必要時IV Crush／事件後輔助
















若有可靠OHLCV，優先自行計算；若單一Soft Signal仍無法取得，標示「未取得可靠最新值」，不把它算入確認數。
















**單一Soft Signal缺失本身，不構成自動不送單。**
















- Base／Left：價格與安全層成立即可部署；技術資料不足時縮小單筆、拉寬分層，不把第一筆硬性歸零。
- Right／Runaway Up／Runaway Down／技術減碼：若該分類本身有最低確認數，仍照正式門檻判定。
- 高Beta／事件型標的以較低部署速度、較深價格要求、較嚴格Hard Gate與較小專案上限控風險，不回到「一定湊滿2～3項技術訊號才准第一筆」的舊邏輯。
















## C. 下單輸出
















- [ ] 已計算本次投入比例
- [ ] 已寫明執行價格／限價
- [ ] 已寫明是否掛單與掛單方式
- [ ] 已寫明取消條件
- [ ] 已寫明下一次重新評估條件
















---
















# 第七十章｜V82正式報告最低欄位
















**定位：以下49項為完整分析底稿必備欄位；最終對外／執行摘要使用後續「最終正式輸出格式」的13項欄位。兩者不可互相取代。**
















每一檔至少列：
















1. 最新價
2. 資料日期
3. 股性分類
4. 主框架／專屬框架
5. 副框架／交叉驗證層（若適用）
6. 基本面
7. 估值
8. 高TD9
9. 低TD9
10. KD
11. MACD
12. MA
13. EMV
14. RSI
15. 成交量／量價
16. 日線
17. 週線
18. 月線
19. ATR
20. 高點回撤
21. 前低
22. 前前低
23. 前前前低
24. 價格地圖
25. 第一買點／合理價區
26. 甜甜價／第二價格區
27. 深度／極端折價區
28. 左側狀態
29. 右側狀態
30. Runaway狀態
31. Macro位置＋方向＋速度
32. 信用／流動性位置＋方向＋速度
33. 重大新聞／政策
34. 曝險重疊
35. 部位上限
36. 客戶專案目標部位
37. 現有部位
38. Actual Completion Rate
39. Deployment Mode（Base／Left／Right／Trend；暫停／減碼另由今日動作／Execution Action表達）
40. 今日特殊分類（六類之一；若皆未成立則寫「無特殊分類」）
41. 今日動作
42. 執行比例
43. 執行金額
44. 執行股數
45. 執行價格
46. 預估成交後完成率（Projected Post-Fill Completion Rate；實際成交後回到Actual Completion Rate）
47. 是否掛單／掛單方式
48. 取消條件
49. 下一次重新評估條件
















---
















# 第七十一章｜最終正式輸出格式
















最後不得只寫：
















- 偏多
- 偏空
- 可觀察
- 接近買點
- 小心
















固定輸出13項：
















## 1. 今日特殊分類
















例如：左側買點／Runaway Up；若六類皆未成立，明確寫「無特殊分類」。
















## 2. 目前部署階段
















Base／Left／Right／Trend；若本輪被暫停新增或要求減碼，另在「今日真正動作」標示，不把暫停／減碼塞進Deployment Mode。
















## 3. 專案目標與Actual Completion Rate
















列出：
















- 客戶專案目標部位
- 現有部位
- Actual Completion Rate
















## 4. 今日真正動作
















例如：
















- Base參與
- 甜甜價加速部署
- 右側補強
- Trend Deployment
- 本輪不新增
- 減碼
















## 5. 執行比例
















相對Project Target Position，使用V82正式Canonical Deployment Target Rate：10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%；它是九階梯累積目標比例，不是Actual Completion Rate，也不是每層額外投入比例。若客戶專案另有更低上限或特殊風控邊界，仍不得突破該專案上限。
















## 6. 執行金額
















若有預算則直接算。
















## 7. 執行股數
















依執行價換算。
















## 8. 執行價格
















明確列出。
















## 9. 成交後完成率
















有Planned Fill時，成交前列出**預估成交後完成率**；實際成交確認後，改以Confirmed Position重新計算Actual Completion Rate。若本輪無下單／無Planned Fill，顯示不適用，不得誤標UNKNOWN。
















## 10. 是否掛單
















是／否。
















## 11. 掛單方式
















限價／GTC／預約／不掛。
















## 12. 取消條件
















明確列出。
















## 13. 下一次重新評估條件
















例如：
















- 到下一價格區
- 財報公布
- CPI公布
- 信用升級
- KD／MACD改善
- 跌破支撐
- Runaway狀態改變
















正式輸出順序鎖定：
















> 今日特殊分類  
> → Deployment Mode（暫停／減碼另列今日動作）  
> → Project Target Position＋Actual Completion Rate  
> → 今日真正動作  
> → 執行比例  
> → 執行金額  
> → 執行股數  
> → 執行價格  
> → 成交後完成率（成交前Projected；Fill後Actual）  
> → 是否掛單  
> → 掛單方式  
> → 取消條件  
> → 下一次重新評估條件。
















---
















# 第七十二章｜V82完整決策流程
















**先讀取客戶專案檔**
















↓
















**確認：長期持有標的／Project Target Position／AP或Confirmed Position／Actual Completion Rate／可動用資金／近期特殊要求**
















↓
















**最新價格＋重大新聞**
















↓
















**資料來源驗證**
















↓
















**股性分類**
















↓
















**主框架／專屬框架＋必要時副框架／交叉驗證層**
















↓
















**基本面**
















↓
















**估值**
















↓
















**產業週期**
















↓
















**高TD9**
















↓
















**低TD9**
















↓
















**KD**
















↓
















**MACD**
















↓
















**MA**
















↓
















**EMV**
















↓
















**RSI**
















↓
















**成交量／量價**
















↓
















**日線＋週線＋月線**
















↓
















**ATR**
















↓
















**確認Swing Low／Swing High**
















↓
















**前低／前前低／前前前低**
















↓
















**高點回撤**
















↓
















**動態價格地圖**
















↓
















**Macro位置＋方向＋速度**
















↓
















**信用／流動性位置＋方向＋速度**
















↓
















**Hard Gate／安全否決**
















↓
















**六類特殊分類（若皆未成立則輸出「無特殊分類」，不得建立WAIT）**
















↓
















**部署階段：Base／Left／Right／Trend；暫停／減碼另列Execution Action**
















↓
















**T+1 Gap Recheck／必要時IV Crush**
















↓
















**Look-through＋產業集中**
















↓
















**專案資金映射＋Actual Completion Rate**
















↓
















**套用V82正式Canonical Deployment Target Rate 10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%，並檢查客戶專案特殊上限／特殊風控邊界**
















↓
















**比例＋金額＋股數＋價格＋預估成交後完成率（Fill後更新Actual Completion Rate）**
















↓
















**掛單／取消**
















↓
















**今日真正操作**
















---
















# 第七十三章｜V82最高原則
















> 借股性，不借價格。
















> 借分析骨架，不複製買點。
















> 每一檔標的都必須使用自己的價格、ATR、Swing Low、基本面、估值與技術資料重新計算。
















> 第一買點、甜甜價、深度折價區是部署強度觸發區，不是無條件一次滿倉價。
















> 低TD9不是第一筆長期買進的門票；價格已甜且安全時可以先部署，低TD成熟與止跌共振用來提高投入速度。
















> 高TD9=9不是自動賣點，先排除Runaway Up。
















> Runaway Up必須有價格結構＋至少3項強勢確認。
















> Runaway Down必須有價格結構破壞＋至少2項空方加速確認。
















> Runaway Down停止機械接刀。
















> 一般停利歸入技術減碼。
















> 投資論點失效與硬性停損歸入真正降低風險。
















> 所有Macro、信用與流動性指標必須看位置＋方向＋速度。
















> 價格決定值得部署多少；技術決定今天先部署多少、後面加多快；基本面、信用與流動性決定現在是否敢承擔風險。
















> ATR快速擴張時，梯形必須拉寬。
















> 基本面改善，價格地圖可前移。
















> 基本面惡化，價格地圖後移。
















> 基本面結構性改變，舊價格地圖失效。
















> 新增部位前必須檢查標的、產業、國家與Look-through重疊曝險。
















> 專案配置決定最多能買多少；V82決定現在應該動用多少。
















> 有可靠OHLCV時，技術指標優先自行計算；資料不足不得捏造。
















---
















































# 執行章B｜個股 Structural Break 後的 Fundamental Cap 與 Reduction Execution
















> 本章只適用於**個別股票**的基本面結構性破壞（Structural Break）後風險降低。廣泛被動股票ETF不使用個股 Thesis 失效計分；ETF僅依其結構安全規則處理。🚨 Emergency Exit 另由後續獨立規則處理，不與一般 Structural Break Reduction 混用。
















## B-0｜責任鏈與核心變數
















- `OTP (Original Target Position)`：投資前／正式股票池納入時確定的原始目標部位，視為100%。
- `AP (Actual Position)`：以券商確認持倉／已確認成交結果為準的最新實際部位。
- `FC (Fundamental Cap)`：基本面結構性破壞後允許保留的最大部位上限。
- `RRG (Remaining Reduction Gap)`：`MAX(AP - FC, 0)`。
- `Reduction Episode`：同一次 Structural Break Reduction 的生命週期；R1／R2／R3變化不得任意重開Episode。
















固定責任鏈：
















> **A決定最多允許留多少 → B-1決定第一輪先降多少 → B-2決定速度與最晚期限 → B-3決定今天Slow／Normal／Accelerated → B-4管理反彈窗口與安全下單 → B-5規定沒有反彈仍須繼續 → B-6管理中途FC／R級變化時的Reduction continuity。**
















基本面決定最終最多能留多少；技術只決定今天賣多少、賣多快。
















---
















## B-A｜Core Investment Thesis、Structural Break與Fundamental Cap
















### A-1～A-4｜Thesis預先定義與R級
















正式股票池中的個股原則上建立3～7項Core Investment Theses，預設5項，但不得為湊數而虛構。每項Thesis必須在投資前／正式納入股票池時定義，至少包含：Thesis內容、重要性、Fundamental Domain、客觀驗證資料、Normal／Deterioration／Failure條件、Required Evidence、Persistence Requirement，以及是否為Critical Thesis。
















Critical Thesis只能事前指定；其永久失效單獨即足以使整體投資理由失效。價格下跌後不得事後新增Critical Thesis。若因真實結構變化需要修改Thesis，必須保留舊版本、日期、理由與當時證據。
















Structural Break確認至少需要：
1. 至少2項獨立重大證據；
2. 跨至少2個Fundamental Domains；
3. 至少一項Core Investment Thesis已依事前Failure條件確認持續失效；
4. 公司資料、產業／同業與可信重大新聞／公告／監管文件交叉驗證。
















同一底層事件被大量媒體重複報導仍只算一個事件。
















在非Emergency情況下：
















| Risk Grade | 條件 | Fundamental Cap（相對OTP） |
|---|---|---:|
| R1 | 1項一般Core Thesis FAILED；無Critical FAILED | 50% |
| R2 | 2項不同一般Core Theses FAILED；無Critical FAILED | 25% |
| R3 | ≥3項一般Core Theses FAILED，或任一Critical Thesis FAILED | 0% |
















🚨 Emergency（重大舞弊／財報不可靠、重大違約、破產／重整、Going Concern等永久資本損失風險）最終上限同為0%，但退出速度與例外由Emergency Exit獨立規則處理，不等同一般R3。
















### A-5～A-7｜Thesis資料與狀態
















每項Thesis至少保存：`thesis_id`、`thesis_name`、`thesis_statement`、`why_it_matters`、`fundamental_domain`、`is_critical`、`validation_metrics`、`normal_condition`、`deterioration_condition`、`failure_condition`、`required_evidence`、`persistence_requirement`、`thesis_status`、`last_evaluated_at`、`failure_confirmed_at`、`created_at`、`effective_from`、`version`、`change_reason`、`evidence_snapshot`。
















Thesis狀態只有：`NORMAL / DETERIORATING / FAILED`。`FAILED`必須同時滿足Failure Condition、Required Evidence、Persistence Requirement；缺一不得判FAILED。重大事件若一次即滿足三者，可由NORMAL直接進FAILED。
















每項Thesis建立時另標示Recoverable或Irreversible。Recoverable Thesis只有在Failure Condition不再成立、新客觀修復證據成立，且另行事前定義的`recovery_requirement`滿足後，才可`FAILED → DETERIORATING → NORMAL`。Irreversible Thesis原版本永久維持FAILED；新投資理由必須建立新版本／新完整Thesis Set。
















Critical Thesis優先於一般FAILED數量：Emergency先判；Irreversible Critical FAILED維持R3；Recoverable Critical在recovery_requirement完成前維持R3；只有不存在Critical FAILED時才計算一般FAILED Thesis數量。
















### A-8｜FC恢復不等於買回
















FC上升只代表基本面天花板重新打開。固定重新計算：
















`RRG = MAX(AP - new_FC, 0)`
















若RRG=0，停止Structural Break Reduction；但`new_FC > AP`不得產生Buy Gap，不得自動恢復舊九階梯位置，也不得買回先前風險減碼部位。任何新增買進必須重新執行：
















> **最新完整V82 → 當下九階合理部署位置 → Fundamental Cap → V70.2新增股票資金容量 → Deployment Gap。**
















---
















## B-1｜Initial Risk Reduction
















Structural Break首次確認後必須立即啟動Initial Risk Reduction；正常可交易且具合理流動性時，不得因技術超賣把首輪減碼降為0。
















第一版候選離散表（仍屬Candidate Parameter，待B組整體驗證後升格）：
















| Risk Grade | -2 | -1 | Base | +1 | +2 |
|---|---:|---:|---:|---:|---:|
| R1 | 15% | 20% | 25% | 32.5% | 40% |
| R2 | 25% | 30% | 35% | 45% | 55% |
| R3 | 40% | 45% | 50% | 62.5% | 75% |
















上述比例皆乘以當時最新RRG，不是OTP或總資產。B-1不再使用未定義的Fundamental Deterioration Velocity（FDV）；基本面持續惡化一律改讀4-7C正式定義的Fundamental Worsening Level（FWL）。FWL不是整體Fundamental Severity，也不是惡化速度。於Initial Reduction步階介面中，FWL=0／1／2分別對應基本面步階調整0／+1／+2；技術恐慌仍只依既有Technical Panic Adjustment降低執行步階，且FWL>=1時最多只可抵銷1步，不得完全抵銷基本面惡化所帶來的加速。若證據已使Risk Grade升級，先更新R／FC／RRG，再計算FWL與步階。Emergency直接轉Emergency規則。
















Execution Status至少分`EXECUTABLE / PARTIALLY_EXECUTABLE / NOT_EXECUTABLE`。交易暫停、流動性異常、極端市場微結構等才可形成Execution Exception；單純Gap Down、正常下跌或價格難看本身不等於NOT_EXECUTABLE。未完成Initial Reduction必須保存Initial Reduction Target／Executed／Pending，下一Cycle不得把已執行部分當作從未執行而重算整筆第一刀。
















---
















## B-2｜Reduction Rate、Effective Execution Days與Hard Deadline
















第一版Candidate：
















| Mode | 每有效執行日比例（乘最新RRG） | Max Effective Execution Days |
|---|---:|---:|
| Slow | 20% | 10 |
| Normal | 35% | 5 |
| Accelerated | 60% | 3 |
















比例採最新RRG的幾何遞減；Hard Deadline負責最晚完成。Slow前9個有效執行日依20%，第10日完成當時剩餘RRG；Normal前4日依35%，第5日完成；Accelerated前2日依60%，第3日完成。Deadline Cycle不再乘Rate，直接以當時最新RRG作Gross Sell Target，仍受Execution Exception與Execution Adapter限制。
















Risk Clock以有效執行日預算保存：`max_execution_days`、`elapsed_execution_days`、`remaining_execution_days`。Mode切換只可縮短，不得延長：
















`new_remaining_execution_days = MIN(current_remaining_execution_days, new_mode_max_execution_days)`
















風險惡化不得重置Risk Clock取得更長退出期限。Execution Adapter處理碎股、最小交易單位、quantity precision與minimum notional。若為完成RRG而因最小交易單位產生最小必要穿越FC，必須記錄`rounding_excess_reduction`，不得利用rounding額外超賣。
















AP每次只以已確認Fill／券商最新確認持倉更新；每次Fill後重新計算`RRG = MAX(AP-FC,0)`，不得沿用舊RRG。
















---
















## B-3｜Technical Signal Normalization與Execution Mode
















B-3只決定今天`SLOW / NORMAL / ACCELERATED`，不得改FC、取消Structural Break、重設Hard Deadline或建立第二套Sell Rate。V82原本「技術減碼通常至少3項共振」屬一般技術主動減碼觸發規則，不直接移植到Structural Break後的B-3速度判斷。
















資料流固定：
















`Raw Data → State → Event → Current Reduction Episode Event History → P/M/C → Accelerated A → Accelerated B → Confirmed Slow → Otherwise Normal`
















State與Event必須分離；持續處在某State不得每天重複產生Crossing Event。引用過去Event時，只能使用同一`episode_id`且同一`structure_id`、事件時間不早於`episode_started_at`的事件；Episode以前舊事件不得參與。
















既有技術參數沿用V82：TD9 1～9、KD 9,3,3與20／80、MACD 12,26,9、MA5／10／20／50／60／200、EMV 3,3、RSI(14)與30／50／70、ATR(14)、Confirmed Swing High／Low前2＋後2 Bar。
















B-3暫保留且僅保留兩個Candidate Parameter：
1. MACD Histogram方向確認期＝連續2個已完成Bar；
2. Swing／MA Noise Band＝`0.25 × ATR(14)`。
















MACD Histogram至少標準化為：`BELOW_ZERO_CONTRACTING / BELOW_ZERO_EXPANDING / ABOVE_ZERO_EXPANDING / ABOVE_ZERO_CONTRACTING / MIXED / UNKNOWN`。Volume第一版只使用`ABOVE_MA20 / AT_OR_BELOW_MA20 / UNKNOWN`並與價格方向組合，不建立額外「正常量帶」或爆量倍數。
















Swing與MA各自保存State與Crossing Event；Swing可有`VALID_BREAKOUT / VALID_BREAKDOWN / NONE`，MA可有`RECLAIM / BREAKDOWN / NONE`。`VALID_BREAKOUT`本身不得被解讀為反彈失敗或Accelerated。RSI可由既有70門檻直接推導`EXIT_OVERBOUGHT`（前一完成Bar>70且本Bar≤70）。資料不足使用`UNKNOWN`，UNKNOWN不得視為Neutral或False。若P全部UNKNOWN、KD與MACD全部UNKNOWN、或C全部UNKNOWN而Structural Break／Reduction Episode已由既有基本面規則正式成立，依第六十二章L節採`NORMAL`作Safety-preserving Reduction Fallback，同時保留`technical_data_quality = INSUFFICIENT / UNKNOWN`與Issue Codes；此Fallback只防止已確認風險降低被資料缺口延誤，絕不表示UNKNOWN=Normal。
















Accelerated Path A必須由價格結構、動能轉弱與確認層共同成立；價格結構第一版只使用Swing High `WITHIN_BAND`或本Reduction Episode內既定MA曾`RECLAIM`且目前不在其`BELOW` State。Path B只使用同Episode、同structure先有RECLAIM、後有BREAKDOWN的客觀事件序列。真正強勢`VALID_BREAKOUT`不得單獨觸發Accelerated。
















Confirmed Slow必須有Low TD 5～9、沒有新的Swing／MA結構破壞Event、至少一項止跌Momentum條件，以及至少一項非TD確認條件。Slow不是Wait。
















---
















## B-4｜Rebound Window與Order Reconciliation
















Rebound Window是Execution State，不是新的Technical Signal。是否Accelerated每Cycle唯一由B-3決定。Window只防止同一段連續Accelerated被每天當成新的反彈事件；任何Window開關不得重設Reduction Episode或Risk Clock。
















`REBOUND_WINDOW_STATE`只有`OPEN / CLOSED`。Window生命週期的Source of Truth是持久化Window State，不是previous_mode：Accelerated+CLOSED→開新Window；Accelerated+OPEN→延續；非Accelerated+OPEN→關閉；非Accelerated+CLOSED→不動。資料讀取異常不塞入Window業務State；以`VALID / RECOVERED / DATA_INTEGRITY_ERROR / DATA_ACCESS_ERROR`處理。恢復時，同Episode恰1個未closed Window→OPEN；0個→CLOSED；>1個→DATA_INTEGRITY_ERROR；查詢失敗→DATA_ACCESS_ERROR。後兩者不得猜測或新建重複Window。
















每個新Execution Cycle在產生新Sell Order前，必須先Reconcile本Episode相關Active Orders與真實成交狀態，至少辨認`OPEN / PARTIALLY_FILLED / FILLED / CANCELLED / REJECTED`。AP只能由Confirmed Fills／券商確認持倉更新；Pending／Open Order不得提前扣減AP。仍可能成交的Active Sell Quantity必須被取消、修改／替換，或計入本Cycle Sell Exposure；Order Reconciliation未確認時，不得送出可能與舊單重疊的新Sell Order。
















每Cycle依最新AP、FC重算RRG；Gross Sell Target依B-2當日Mode Rate，Deadline Cycle則為全部最新RRG。New executable sell quantity不得忽略Existing Active Sell Quantity。不得因重複訂單、未Reconcile Active Orders或錯誤Sell Target造成非預期超賣；若Execution Adapter最小交易單位／精度造成最小必要穿越FC，僅能依B-2 rounding規則並記錄`rounding_excess_reduction`。
















FC改變時B-4只重算RRG；Risk Clock inheritance交B-2／B-6，B-4不得reset、restart或extend remaining_execution_days。
















---
















## B-5｜No-Rebound Continuation Rule
















> **No Rebound不得阻止、暫停、重設或延長B-2既定Reduction Schedule。Rebound是Execution Opportunity，不是Reduction完成的必要條件。**
















RRG>0且沒有Accelerated Rebound Window時，Normal依B-2 Normal Rate、Slow依B-2 Slow Rate持續減碼；Slow不得變成0或Wait。EXECUTABLE正常消耗有效執行日；PARTIALLY_EXECUTABLE不得僅因部分成交就自動整天凍結Risk Clock，依B-2既定可執行程度規則處理；NOT_EXECUTABLE才依正式Execution Exception暫停。正常下跌、Gap Down、價格難看或沒有反彈不得被誤判為NOT_EXECUTABLE。
















到Hard Deadline時，不論Slow／Normal、有無反彈，都完成當時最新RRG，仍受Execution Exception與rounding規則約束。中途若B-3轉Accelerated，轉交B-4 Window流程，但Episode與Risk Clock不重設。基本面進一步惡化時是否仍具Slow資格，依4-7C Fundamental Worsening Guard處理；4-7C不得直接產生Accelerated。R1→R2→R3的Clock inheritance交B-6。
















---
















## B-6｜Reduction Continuity、FC變化與Risk Clock Inheritance
















B-6只管理Reduction continuity，不是雙向Position Controller。FC改善可以停止部分或全部Reduction，但不得產生自動買回。
















### B-6.1 同一Cycle固定順序
















`Order Reconciliation → Confirmed Fills／Broker Position → latest AP → latest Fundamental Evidence／Risk Grade／FC → RRG = MAX(AP-FC,0) → current B-3 Mode → Clock Inheritance → Gross Sell Target → Active Sell Exposure Reconciliation → Execution Adapter`
















不得用舊AP＋新FC先算Sell Target後再忽略途中成交。
















### B-6.2 Episode與狀態轉移
















只要仍屬同一次Structural Break Reduction，R1／R2／R3互轉均保留原`episode_id`、`episode_started_at`、已經過的`elapsed_execution_days`與既有Risk Clock歷史。Risk Grade變化不得因RRG擴大而建立新Episode。
















| 轉移 | FC方向 | RRG處理 | Episode | 買回 |
|---|---|---|---|---|
| R1→R2 | 50%→25% | 依最新AP重算，通常擴大 | 保留 | 禁止 |
| R2→R3 | 25%→0% | 依最新AP重算，通常擴大 | 保留 | 禁止 |
| R1→R3 | 50%→0% | 依最新AP重算，通常擴大 | 保留 | 禁止 |
| R3→R2 | 0%→25% | 依最新AP重算，縮小或歸0 | 保留至RRG=0 | 禁止 |
| R2→R1 | 25%→50% | 依最新AP重算，縮小或歸0 | 保留至RRG=0 | 禁止 |
| R3→R1 | 0%→50% | 依最新AP重算，縮小或歸0 | 保留至RRG=0 | 禁止 |
| 同級但FC依正式規則改變 | 依新FC | 依最新AP重算 | 保留 | 禁止 |
















若FC上升後`RRG=0`，Structural Break Reduction停止；`FC-AP`永遠不得在B-6轉成Buy Gap。後續買進只能回A-8完整V82流程。
















### B-6.3 Clock Inheritance Formula
















目前正式母規則與已封A／B-1／B-2中**沒有R1／R2／R3各自獨立Maximum Completion Days的Existing Rule**。因此B-6不得自行創造第二套R級Deadline。
















Risk Grade／FC改變本身不增加剩餘天數：
















`remaining_after_fc_change = current_remaining_execution_days`
















若同一Cycle B-3 Execution Mode亦改變，再套用B-2既定公式：
















`new_remaining_execution_days = MIN(remaining_after_fc_change, new_mode_max_execution_days)`
















`elapsed_execution_days`保留，不歸零。若同Cycle R1→R3造成RRG大幅增加而當時只剩1個有效執行日，仍只剩1個有效執行日；Deadline Cycle依B-2完成當時最新RRG。這可能造成較大的最後減碼，但它是「風險惡化不得延長退出期限」的直接結果，而不是新Missing Rule。若市場實際不可合理執行，使用既有Execution Exception，不以重開Clock解決。
















因此目前不新增R級Deadline Candidate。
















### B-6.4 Active Orders與FC變化
















FC下降／上升後，在產生新Sell Target前必須重新Reconcile Active Sell Exposure。FC下降造成RRG擴大時，只增加最新計算後仍需要的Sell Exposure，不得重複計入既有Active Orders；FC上升造成RRG縮小時，若既有Active Sell Quantity超過最新允許Reduction，需要依Execution Adapter取消／修改／替換，避免非預期超賣。未確認Cancel成功前不得假設舊單已消失。
















Partial Fill時，只有Confirmed Fill改變AP；未成交部分只作Active Sell Exposure。
















### B-6.5 同Cycle Edge Cases
















- `R1→R2`且Mode仍Normal：RRG用新FC重算，Risk Clock剩餘天數不變，依Normal Rate／Deadline執行。
- `R1→R3`且Mode同時Accelerated：先重算RRG，再`MIN(原剩餘天數, Accelerated Max Days)`；不得重新取得3個完整新天數。
- `R3→R2`且新FC≥AP：RRG=0，停止Reduction；不得買到FC。
- FC下降且已有Partial Fill／Active Orders：先Reconcile Fill與Active Exposure，再以最新AP／FC／RRG計算新增可執行量。
- FC上升且舊Active Sell Orders會使Projected Position非預期穿越最新FC：先Cancel／Modify／Replace或納入Exposure後重新計算；rounding例外仍只依B-2。
- RRG=0後若未來又因同一尚未解除的Structural Break證據惡化而重新>0，是否沿用原Episode或建立新Episode必須依Structural Break解除／重新成立的正式生命週期定義；不得僅因FC數字變動就任意新建Episode。
















### B-6.6 Candidate Parameter
















B-6新增Candidate Parameter：**0個**。
















---
















## B組整體一致性檢查｜B-1～B-6
















1. **單一FC來源**：A／Fundamental State決定FC；B-1～B-6不得另建第二個基本面上限。
2. **單一RRG公式**：全組只用`MAX(AP-FC,0)`；AP只認Confirmed Fill／Broker Position。
3. **單一Rate／Deadline來源**：B-2是Slow／Normal／Accelerated Rate與Hard Deadline唯一來源；B-3～B-6不得另創Rate或Deadline。
4. **單一Mode來源**：B-3唯一輸出Slow／Normal／Accelerated；B-4 Window不是第二個Technical Signal。
5. **No Rebound不延長**：B-5只補continuation invariant，不建立Wait。
6. **Risk Grade不重開Clock**：B-6保留Episode與Clock；FC惡化只重算RRG，Mode改變才依B-2 `MIN()`縮短剩餘天數。
7. **改善不買回**：FC上升最多讓RRG縮小／歸0；任何Buy Gap必須回A-8完整V82流程。
8. **Order Safety**：每Cycle先Reconcile Active Orders與Confirmed Fills；舊單不得與新Sell Target重複曝險。
9. **Rounding一致**：不得因重複訂單／錯誤Target非預期超賣；最小交易單位造成的最小必要穿越FC只依B-2並記錄`rounding_excess_reduction`。
10. **Emergency分離**：一般R3與🚨 Emergency雖皆可FC=0，但Emergency退出速度／例外不由B組一般流程冒充。
11. **B-3 Candidate最小化**：目前僅MACD Histogram連續2完成Bar、0.25×ATR(14) Noise Band；B-4／B-5／B-6均新增0個Candidate。
12. **無新增R級Deadline**：目前沒有Existing Rule支持R1／R2／R3各自獨立完成天數，因此不建立第二套Clock。
















B組整體責任鏈至此封閉；4-7C只處理「基本面持續惡化時是否仍具有Slow資格」，不得回頭複製B組已存在的Rate、Clock、Window或Order Reconciliation。
















---
















## 4-7C｜Fundamental Worsening Level（FWL）與Fundamental Worsening Guard
















### C-1｜FWL權責與非權責
















> **FWL不是整體Fundamental Severity，不是Fundamental Deterioration Velocity，也不決定R1／R2／R3或Fundamental Cap。FWL只描述Risk Grade計算完成後，尚未FAILED之DETERIORATING Thesis所形成的額外基本面惡化層級，用於判定Structural Break Reduction是否仍具有Slow資格。**
















4-7C不得建立第二套Execution Mode Generator、Sell Rate、Hard Deadline、Risk Clock、Reduction Episode或Rebound Window。`SLOW / NORMAL / ACCELERATED`最終Execution Mode仍只能由B-3輸出。
















正式資料順序固定為：
















`Emergency → Thesis State → FAILED Thesis → Risk Grade → FC → RRG → 排除FAILED Thesis → Remaining DETERIORATING Thesis → FWL → Fundamental Worsening Guard → B-3 Execution Mode`
















若Evidence已使Risk Grade／FC改變，必須先依A系列更新Risk Grade、FC與`RRG = MAX(AP-FC,0)`，再計算FWL；不得用FWL取代Risk Grade。
















### C-2｜FWL deterministic definition
















- `FWL = 0`：Risk Grade計算完成並排除所有FAILED Thesis後，沒有額外Core Thesis處於`DETERIORATING`。
- `FWL = 1`：有且僅有1項一般、非Critical Core Thesis處於`DETERIORATING`。
- `FWL = 2`：有至少2項彼此獨立的一般、非Critical Core Theses處於`DETERIORATING`；**或任何Critical Thesis處於`DETERIORATING`**。
















已`FAILED`且已用於R1／R2／R3與FC計算的Thesis，不得再次計入FWL。
















同一Underlying Event不得因多篇新聞、重複證據、同源資料或實質重複Thesis重複計數；是否獨立仍依A系列既有Thesis／Evidence與Fundamental Domain規則判定。
















### C-3｜Fundamental Worsening Guard
















唯一derived state：
















`fundamental_worsening_guard = (FWL >= 1)`
















Guard只限制Slow資格，不直接產生Accelerated：
















1. B-3 Technical Accelerated Path A／B成立 → `ACCELERATED`。
2. 否則B-3 Confirmed Slow成立，且`fundamental_worsening_guard = FALSE` → `SLOW`。
3. 否則B-3 Confirmed Slow成立，且`fundamental_worsening_guard = TRUE` → Confirmed Slow資格失效，輸出`NORMAL`。
4. 其餘 → `NORMAL`。
















因此4-7C不得直接把任何FWL狀態轉為`ACCELERATED`，也不得因此開啟B-4 Rebound Window。B-4只接受B-3最終輸出的Accelerated。
















### C-4｜Critical Thesis DETERIORATING但未FAILED
















若Critical Thesis已進入`DETERIORATING`但尚未同時滿足Failure Condition、Required Evidence與Persistence Requirement：
















- 不得提前判定R3；
- FC維持依目前Risk Grade所得結果；
- Critical Thesis因仍未FAILED而可進入Remaining DETERIORATING集合；
- `FWL = 2`；
- `fundamental_worsening_guard = TRUE`；
- 因此不得只因技術超賣／止跌而把Structural Break Reduction降成Slow。
















這不改寫A系列Critical Thesis的FAILED門檻，也不以FWL預先偷判Structural Break升級。
















### C-5｜與B-1 Initial Reduction的一致性修補
















B-1原本使用未定義的`Fundamental Deterioration Velocity`屬程式化Blocking Bug。自本版起停止使用FDV，B-1只讀本節FWL。
















- B-1既有R1／R2／R3比例表、Initial Reduction架構與Technical Panic Adjustment不重開。
- Initial Reduction基本面步階調整固定使用：`FWL 0 / 1 / 2 → 0 / +1 / +2 step`。
- 若`FWL >= 1`，Technical Panic Adjustment最多抵銷1步，不得完全抵銷基本面惡化所帶來的步階提高。
- Risk Grade若先升級，仍先更新R／FC／RRG，再重新計算FWL；不得把同一FAILED Thesis同時計入Risk Grade與FWL。
















### C-6｜Candidate Parameter
















4-7C新增Candidate Parameter：**0個**。
















`FWL = 0 / 1 / 2`屬deterministic business state；`fundamental_worsening_guard`屬derived boolean state，均不是市場校準參數。
















### C-7｜4-7C一致性不變量
















1. Risk Grade／FC仍只由A系列FAILED Thesis與Emergency規則決定。
2. FWL只讀尚未FAILED的Remaining DETERIORATING Thesis，不與FAILED重複懲罰。
3. 同一Underlying Event不得重複計數。
4. B-3仍是唯一Execution Mode Source。
5. 4-7C不直接產生Accelerated，不建立第二套Rate／Deadline／Clock／Episode／Window。
6. Critical Thesis僅DETERIORATING時不提前判R3，但Guard必為TRUE。
7. Emergency仍轉4-7D，不由4-7C冒充Emergency Exit。
















---
















## 4-7D｜Emergency Exit｜Event Confirmation、Preemption與Execution Contract
















### D-1｜權責與最高優先不變量
















4-7D只處理個別股票之正式Emergency Event確認與Emergency Exit。廣泛被動股票ETF不使用個股Emergency Event Type，仍依其自身結構安全規則處理。
















固定不變量：
















1. `R3 + FC=0`不等於Emergency；Emergency必須由獨立Event Confirmation成立。
2. Emergency不是B-3的`ACCELERATED`，也不是B-3第四種Mode；Emergency不得開啟B-4 Rebound Window。
3. `Official Source ≠ Emergency automatically CONFIRMED`。必須同時判斷`Event Type × Evidence Authority × Evidence Assertion`。
4. `INVESTIGATION_OPENED`／調查中不等於舞弊或其他Emergency Event已成立。
5. `PENDING_VERIFICATION`不得自行建立Emergency Sell Rate、Emergency Deadline、新聞篇數、價格跌幅或等待天數。
6. 若PENDING之前已有合法Structural Break Reduction，原B系列Reduction繼續，不因Pending無理由停止、重設或延長。
7. 只有`CONFIRMED` Emergency才由Emergency Exit接管Execution Intent。
8. Emergency Exit雖接管Execution Intent，仍共用既有Order Reconciliation、Confirmed AP、Active Sell Exposure與Execution Adapter安全骨架。
9. Emergency解除、翻案或證據撤回後，不得自動買回已成交部位；後續買進重新回完整Fundamental Assessment、V82與A-8。
10. 4-7D新增Candidate Parameter：**0個**。
















### D-2｜Emergency Event State與Execution State分離
















每一個獨立`emergency_event_id`保存自己的Event State：
















`NONE / PENDING_VERIFICATION / CONFIRMED / DECONFIRMED`
















狀態語意：
















- `NONE`：目前沒有足以形成該Emergency Event的有效證據。
- `PENDING_VERIFICATION`：已出現與Emergency Event Type相符的重大訊息，但尚未滿足Event-specific Confirmation。
- `CONFIRMED`：Event Type、Evidence Authority與Evidence Assertion已同時滿足該Event Type的正式確認規則。
- `DECONFIRMED`：先前已CONFIRMED之Event，後續被具有適格權限且足以推翻原Assertion的正式證據撤回、駁回或否定。DECONFIRMED保留歷史，不刪除原事件紀錄。
















Emergency Execution另存：
















`NOT_STARTED / IN_PROGRESS / BLOCKED / COMPLETED`
















因此Event已`CONFIRMED`但市場停牌時，可同時為：
















`emergency_event_status = CONFIRMED`
`emergency_execution_status = BLOCKED`
















不得因不可交易而把Event降回PENDING。
















### D-3｜Multi-Emergency Event Aggregation
















公司可同時存在多個`emergency_event_id`，每個Event各自保存`NONE / PENDING_VERIFICATION / CONFIRMED / DECONFIRMED`。
















公司層derived state固定為：
















1. 只要**任何一個Active Emergency Event仍為`CONFIRMED`**，則`company_emergency_status = CONFIRMED`，Emergency Exit不得因其他Event被DECONFIRMED而解除。
2. 若沒有任何CONFIRMED Event，但至少一個Event為`PENDING_VERIFICATION`，則`company_emergency_status = PENDING_VERIFICATION`。
3. 只有所有足以支持Emergency Exit的Confirmed Events都已不再CONFIRMED，且沒有其他Confirmed Event存在時，Company-level Emergency Execution Intent才可解除，之後重新跑完整Fundamental／Structural Break判斷。
4. `PENDING_VERIFICATION`不得覆蓋、降級或取消另一個`CONFIRMED` Event。
















例：
















`Fraud = DECONFIRMED + Bankruptcy = CONFIRMED`
→ `company_emergency_status = CONFIRMED`
















### D-4｜Event Type
















4-7D只承接V82既有Emergency語意，不額外發明模糊類型：
















| Event Type | 正式語意 |
|---|---|
| `FRAUD_OR_UNRELIABLE_FINANCIALS` | 重大舞弊已成立，或正式財報／審計資訊已不能合理信賴 |
| `MATERIAL_DEFAULT` | 重大付款或契約違約已依適用法律／契約正式生效，且沒有已生效之Cure／Waiver解除 |
| `BANKRUPTCY_OR_RESTRUCTURING` | 公司正式進入破產、司法重整或具有法律效力之重整程序 |
| `GOING_CONCERN` | 正式財務／審計文件明確指出持續經營存在重大疑慮 |
















### D-5｜Evidence Authority與Evidence Assertion
















Evidence Authority至少分類為：
















- `COURT_OR_LEGAL_RECORD`
- `REGULATOR_FORMAL_RECORD`
- `ISSUER_FORMAL_FILING`
- `AUDITOR_FORMAL_STATEMENT`
- `CONTRACTUAL_AGENT_NOTICE`
- `EXCHANGE_FORMAL_NOTICE`
- `RELIABLE_SECONDARY_REPORT`
- `UNVERIFIED_SOURCE`
















Evidence Assertion至少分類為：
















- `EVENT_CONFIRMED`
- `FINANCIALS_NOT_RELIABLE`
- `DEFAULT_EFFECTIVE`
- `BANKRUPTCY_OR_RESTRUCTURING_ENTERED`
- `GOING_CONCERN_EXPRESSED`
- `INVESTIGATION_OPENED`
- `ALLEGATION_ONLY`
- `PROCEDURAL_ONLY`
- `DENIAL`
- `REVERSAL_OR_DISMISSAL`
















`Evidence Authority`只回答「誰說的」；`Evidence Assertion`回答「該來源實際正式主張什麼」。高Authority來源若Assertion僅為`INVESTIGATION_OPENED`，仍不得判Emergency CONFIRMED。
















### D-6｜Event-specific Confirmation
















#### D-6A｜FRAUD_OR_UNRELIABLE_FINANCIALS
















可形成CONFIRMED的正式基礎包括：
















- 監管機關／法院正式認定重大舞弊；
- 公司正式申報先前財報不得再依賴；
- 會計師正式撤回審計意見，或正式表示相關財報不可合理依賴；
- 公司正式確認重大錯報且需重大重編。
















媒體爆料、做空報告、匿名消息、吹哨者指控、傳票或監管機關僅宣布開始調查，均只可進`PENDING_VERIFICATION`，不得直接CONFIRMED。
















#### D-6B｜MATERIAL_DEFAULT
















必須同時成立：
















1. 付款／契約義務確實未履行；
2. 依適用契約已正式構成Default／Event of Default；
3. 沒有仍有效之Grace Period、Cure或Waiver使違約尚未生效或已解除。
















適格證據可來自Issuer Formal Filing、Contractual Agent Notice、Court／Legal Record或其他具法律效力之正式紀錄。
















#### D-6C｜BANKRUPTCY_OR_RESTRUCTURING
















- 公司／債務人自行正式向法院提出破產或正式重整申請，且申請已成為正式法律程序紀錄 → `CONFIRMED`。
- 僅由債權人提出非自願破產Petition、公司否認且法院尚未使程序成立 → `PENDING_VERIFICATION`。
- 媒體稱公司「考慮破產／探索重整選項」 → 不得CONFIRMED。
















#### D-6D｜GOING_CONCERN
















只有正式財報／審計文件明確表達持續經營重大疑慮，才可`CONFIRMED`。一般現金流緊張、融資需求、管理層稱營運環境困難，不足以形成Going Concern Emergency。
















### D-7｜PENDING_VERIFICATION正式行為
















PENDING固定行為：
















1. 停止新的Buy Intent。
2. 取消尚未成交Buy Orders。
3. 持續更新Evidence並重新跑A系列Thesis State。
4. 不建立Emergency Sell Rate、Emergency Deadline或固定Pending減碼比例。
5. 若原本已有合法Structural Break Reduction，B系列按原Episode、原Clock與最新A／B／C資料繼續執行。
6. 若Pending Evidence本身已足以使某Thesis依A系列進入DETERIORATING或FAILED，照A→FC→RRG→C→B處理，不得因尚未Emergency Confirmed而忽略已成立的普通Structural Break Evidence。
















### D-8｜CONFIRMED Emergency完整Execution Algorithm
















`company_emergency_status = CONFIRMED`後固定順序：
















1. `Order Reconciliation`
2. `Confirmed Fills / Broker Position`
3. 取得最新`AP`
4. 取消所有未成交Buy Orders
5. `FC = 0`
6. `Emergency RRG = MAX(AP - 0, 0) = AP`
7. 讀取`Active Sell Exposure`
8. 判斷既有Sell Orders是否與Emergency Exit Intent相容
9. `Net New Sell Target = MAX(Emergency RRG - Compatible Active Sell Exposure, 0)`
10. 送交Execution Adapter
















Execution Status處理：
















- `EXECUTABLE`：第一個可執行Cycle以最新全部剩餘AP為Emergency RRG，執行全部可退出的Net Target。
- `PARTIALLY_EXECUTABLE`：執行目前最大可合法／合理執行量，剩餘保持Emergency Exit Pending。
- `NOT_EXECUTABLE`：不得假裝成交；AP維持Confirmed Broker Position，Pending RRG保留，恢復可交易後下一Cycle重新Reconcile並繼續。
















Emergency Exit固定：
















- 不等待反彈；
- 不讀B-1 Initial Reduction比例；
- 不讀B-2 Slow／Normal／Accelerated Rate或3／5／10日Deadline；
- 不讀B-3 Mode；
- 不建立B-4 Rebound Window；
- 不讀FWL作為Emergency減速理由。
















每次Confirmed Fill後更新AP。`AP > 0`繼續Emergency Execution；`AP = 0`則`emergency_execution_status = COMPLETED`並取消任何殘留Sell Orders，避免Short。
















### D-9｜既有Structural Break Reduction Episode被Emergency接管
















若CONFIRMED Emergency發生時已有合法Structural Break Reduction Episode：
















原Episode狀態標記為`EMERGENCY_PREEMPTED`，保存：
















- `episode_id`
- Risk Grade
- FC
- elapsed execution days
- remaining Risk Clock
- 原B-3 Mode
- Rebound Window state
- 已執行量
















Emergency另建立`emergency_event_id`並引用`preempted_reduction_episode_id`。Emergency取得最高Execution Intent。
















#### D-9A｜Emergency Preemption解除後
















> **Emergency Preemption解除後，只恢復原Reduction Episode的episode identity與尚未耗盡的Risk Clock；所有交易目標必須重新依最新Confirmed AP、最新Thesis State、最新Risk Grade、最新FC重新計算RRG，不得恢復Emergency前的舊RRG、舊Sell Target或舊Pending Reduction Amount。**
















正式順序：
















`Order Reconciliation`
→ `Confirmed Fills`
→ latest `AP`
→ latest Evidence／Thesis States
→ latest Risk Grade
→ latest `FC`
→ `RRG = MAX(AP-FC,0)`
→ latest `FWL`
→ B-3
→ 原Episode尚未耗盡的Risk Clock
→ B-2／B系列後續Execution
















若`RRG = 0`，不得因原Episode曾存在Reduction Gap而繼續賣。
















若`AP = 0`，不得產生Buy Gap或自動買回，Episode進入`TERMINATED_NO_POSITION`。
















Emergency期間已成交之減碼永久反映在latest AP；不得以「恢復Episode」回復Emergency前的部位或Reduction Target。
















### D-10｜Active Orders、Partial Fill與Cancel-Replace
















Emergency共用B系列Order Safety，不建立第二套Order Engine。
















1. 每Cycle先Reconcile。
2. Existing Sell Order若仍與Emergency Exit Intent相容，保留並計入`Active Sell Exposure`。
3. 若Existing Sell Order與Emergency Exit Intent不相容，可Cancel-Replace。
4. **Cancel尚未確認成功以前，不得另送出可能與原Active Sell Exposure重疊、造成超賣的新Sell。**
5. Partial Fill只以Confirmed Fill更新AP，未成交部分仍屬Active Sell Exposure。
















例：原AP=100；舊Sell 40已成交15、尚有25 Active。最新Confirmed AP=85；Emergency RRG=85；Active Sell Exposure=25；Net New Sell Target=60，不得再送85。
















### D-11｜DECONFIRMED、撤回、法院駁回或判斷錯誤
















個別Event只有在具有能力推翻原Assertion之適格正式來源出現`REVERSAL_OR_DISMISSAL`等明確證據時，才可由`CONFIRMED → DECONFIRMED`。一般新聞「可能沒事」不足以解除。
















單一Event DECONFIRMED時：
















1. 先`Order Reconciliation → Confirmed Fills → latest AP`。
2. 只解除該`emergency_event_id`。
3. 重新依D-3聚合所有Emergency Events；若仍有其他CONFIRMED Event，Company-level Emergency仍為CONFIRMED，Emergency Exit繼續。
4. 只有所有足以支持Emergency Exit的Confirmed Events都已解除，才停止新增Emergency-only Sell Intent。
5. 可取消尚未成交、純粹由已解除Emergency產生且已無其他合法Reduction依據之Sell Orders；Cancel仍需遵守D-10防重複。
6. 已成交部位不得自動買回。
7. 重新跑完整Fundamental Assessment、A系列、4-7C、B系列與完整V82；若仍有Structural Break RRG，依D-9A用最新AP／FC重新計算後繼續。
8. 若AP=0，不建立自動Buy Gap；任何未來買進重新走A-8完整流程。
















### D-12｜十個Edge Cases固定結果
















| # | Case | 正式結果 |
|---|---|---|
| 1 | 媒體爆料CEO造假，沒有正式確認文件 | `PENDING_VERIFICATION`；停止新Buy、取消Buy；不產生Emergency Sell |
| 2 | 監管機關正式公告「已展開調查」 | 仍為`PENDING_VERIFICATION`；Official Authority不代表Event已成立 |
| 3 | 會計師正式表示先前財報不得再依賴／撤回審計意見 | `FRAUD_OR_UNRELIABLE_FINANCIALS = CONFIRMED`；Emergency Exit接管 |
| 4 | 公司開盤前自行正式向法院申請破產，股票仍可交易 | `BANKRUPTCY_OR_RESTRUCTURING = CONFIRMED`；第一個可執行Cycle以最新全部AP為Emergency RRG |
| 5 | 債權人提出非自願破產Petition，公司否認、法院尚未使程序成立 | `PENDING_VERIFICATION`；若後續法院駁回，該Event轉NONE／DECONFIRMED，不得全賣 |
| 6 | 公司未付利息，但契約仍在有效Grace Period | 尚未CONFIRMED；Grace屆滿且正式Event of Default成立、無Waiver／Cure後才CONFIRMED |
| 7 | 正式審計財報明確表達Going Concern重大疑慮 | `GOING_CONCERN = CONFIRMED`；Emergency Exit接管 |
| 8 | Critical Thesis正式FAILED，R3、FC=0，但無Emergency Event | 一般R3，不是Emergency；走B系列Reduction |
| 9 | Bankruptcy已CONFIRMED但股票停牌 | Event=`CONFIRMED`、Execution=`BLOCKED`；AP保留，恢復可交易後Reconcile再退出 |
| 10 | 原R2 Normal已在減碼，舊Sell Partial Fill；Emergency Confirmed後其中一個Emergency Event被正式推翻 | 先依Confirmed AP＋Active Sell Exposure算Emergency Net Target；翻案只解除該Event。若另有CONFIRMED Event則Emergency繼續；若全部解除，依D-9A以最新AP／FC／RRG與原剩餘Clock恢復同Episode，不恢復舊Target、不買回已售部位 |
















### D-13｜舊「投資論點失效時直接退出」之正式替代語意
















> **個別Core Investment Thesis失效，不代表自動全部退出。個別股票必須先依A系列將FAILED Thesis轉換為Risk Grade與Fundamental Cap：R1降至OTP 50%、R2降至25%、R3降至0%，再依B系列完成Structural Break Reduction。只有符合4-7D Event-specific Confirmation並正式進入CONFIRMED Emergency時，才改由Emergency Exit接管Execution。廣泛被動股票ETF不使用個股Thesis計分，仍依其自身結構安全規則處理。**
















### D-14｜Candidate Parameter與一致性不變量
















4-7D新增Candidate Parameter：**0個**。
















新增者皆為deterministic categorical／derived states或必要記錄欄位，不是市場校準參數：
















- `emergency_event_id`
- `emergency_event_type`
- `emergency_event_status`
- `evidence_authority`
- `evidence_assertion`
- `confirmation_basis`
- `company_emergency_status`
- `emergency_execution_status`
- `preempted_reduction_episode_id`
















一致性不變量：
















1. A系列仍是一般Thesis State／Risk Grade／FC唯一來源；4-7D只增加Emergency Event Confirmation與Emergency Execution。
2. R3 FC=0與Emergency FC=0不得互相推導。
3. B-3仍是一般Structural Break唯一`SLOW / NORMAL / ACCELERATED` Mode Source；Emergency不屬B-3。
4. C系列FWL只處理一般Structural Break Slow資格，不能延遲Emergency Exit。
5. Emergency Preemption解除後只能恢復Episode identity與尚未耗盡Clock，所有RRG／Sell Target必須以最新AP／FC重算。
6. 任一Active Emergency Event仍CONFIRMED，公司Emergency仍CONFIRMED。
7. PENDING不建立Emergency賣出比例／天數。
8. Emergency不得因Gap Down、價格難看或沒有反彈而等待；只有真正Execution Exception可造成BLOCKED／Partial。
9. Active Orders／Partial Fill／Cancel-Replace必須遵守Order Reconciliation與防超賣規則。
10. DECONFIRMED不自動買回。
































## 4-7E｜Company-level Risk Grade Recovery、Structural Break Resolution與Reduction Episode Closure
















### E-1｜權責邊界
















4-7E不建立第二套Thesis Recovery。**A-7仍是Thesis Recovery唯一判定來源**；4-7E只承接A-7已完成之最新Thesis States，重算公司層Risk Grade／Fundamental Cap，並定義Structural Break business state與Reduction Episode execution state的解除生命週期。
















固定順序：
















`Emergency Aggregation → A-7 Thesis State Update → Critical FAILED Check → General FAILED Count → Company Risk Grade → FC → RRG → Remaining DETERIORATING / FWL → B-series Execution`
















Risk Grade必須依A-7完成後的最新合法Thesis States在**同一Cycle**重算，不另加公司層Recovery Score、Cooldown、固定觀察天數或第二套Recovery Engine。
















### E-2｜Company Risk Grade Recovery deterministic mapping
















完成A-7後，以最新Thesis States固定重算：
















- 任一Critical Thesis仍`FAILED` → `R3`，`FC = 0% OTP`。
- 無Critical FAILED，且一般FAILED Thesis數量>=3 → `R3`，`FC = 0% OTP`。
- 一般FAILED Thesis數量=2 → `R2`，`FC = 25% OTP`。
- 一般FAILED Thesis數量=1 → `R1`，`FC = 50% OTP`。
- `FAILED = 0 AND no Critical FAILED` → `company_risk_grade = NONE`。
















不新增`R0`。
















當`company_risk_grade = NONE`時：
















- `structural_break_status = RESOLVED`；
- Structural Break之Fundamental Cap限制解除，可記為`FC restriction released = 100% OTP`；
- 此100% OTP**只表示Structural Break模組不再施加更低Fundamental Cap**，不是Target Position、不是Buy Target；
- `RRG = MAX(AP - FC, 0) = 0`；
- 立即停止新增Structural Break Sell Intent。
















### E-3｜FC限制解除不等於買回
















Structural Break解除後不得計算：
















`100% OTP - AP = Buy Gap`
















不得自動買回先前已減碼部位，不得恢復舊九階部署位置，不得把FC改善視為新的Target Position。
















任何新增買進仍必須重新執行：
















> **latest full V82 → current reasonable nine-stage target → Fundamental restriction → V70.2新增股票資金容量 → Deployment Gap**
















A-8之「FC恢復不等於買回」全部持續有效。
















### E-4｜Structural Break business state與Reduction Episode execution state分離
















`structural_break_status`與`reduction_episode_status`是兩個不同生命週期，不得混用。
















當`FAILED = 0 AND no Critical FAILED`成立時，基本面Business State在同一Cycle立即：
















- `company_risk_grade = NONE`
- `structural_break_status = RESOLVED`
- Fundamental Cap restriction released
- `RRG = 0`
- `new_structural_break_sell_intent = 0`
















**不得因券商仍有舊Active Sell Order，就把Structural Break繼續標成ACTIVE。**
















Reduction Episode則仍需完成Execution收尾。既有Episode狀態至少相容：
















`ACTIVE / EMERGENCY_PREEMPTED / RESOLUTION_PENDING_RECONCILIATION / CLOSED / TERMINATED_NO_POSITION`
















既有`EMERGENCY_PREEMPTED`與`TERMINATED_NO_POSITION`語意不改。
















### E-5｜RESOLUTION_PENDING_RECONCILIATION
















當Structural Break已`RESOLVED`、`RRG=0`，但仍存在可能造成非預期減碼之Active Reduction Sell Exposure時：
















`reduction_episode_status = RESOLUTION_PENDING_RECONCILIATION`
















此狀態固定：
















1. 不再產生新的Structural Break Sell Target或Sell Intent。
2. 必須依B-4執行Order Reconciliation。
3. 對不再需要的`OPEN / PARTIALLY_FILLED` Reduction Sell Orders進行Cancel／Resize／Replace或依正式Exposure規則處理。
4. Pending／Open Order不得提前當成成交；AP仍只認Confirmed Fill／券商確認持倉。
5. 若取消確認前舊Sell Order發生成交，成交永久反映在latest AP；不得因此產生Buy Gap或自動買回。
6. 因此時`RRG=0`且沒有新的Reduction Execution Intent，**RESOLUTION_PENDING_RECONCILIATION期間不消耗Effective Execution Day**。
















### E-6｜Episode正式CLOSED與episode_resolved_at
















只有在以下條件全部成立後，Reduction Episode才可正式關閉：
















- `structural_break_status = RESOLVED`；
- `RRG = 0`；
- Order Reconciliation完成；
- 不再存在未處理、仍可能造成非預期Structural Break減碼之Active Sell Exposure。
















成立後：
















`reduction_episode_status = CLOSED`
















並寫入：
















`episode_resolved_at`
















`episode_resolved_at`是判斷未來重新成立Structural Break時，沿用舊Episode或建立新Episode的正式切線。
















### E-7｜episode_resolved_at之前重新正式成立Structural Break
















若Structural Break已`RESOLVED`、Episode仍處於`RESOLUTION_PENDING_RECONCILIATION`，且在`episode_resolved_at`寫入之前，公司又依A系列最新合法Thesis States重新正式成立Structural Break：
















1. `structural_break_status → ACTIVE`。
2. 重新依最新Thesis States計算Risk Grade、FC、RRG、FWL與B-3 Mode。
3. **沿用原`episode_id`、原`episode_started_at`與原尚未耗盡Risk Clock**；不得建立新Episode、不得取得新Clock。
4. 若新B-3 Mode之Max Effective Execution Days更短，只能依B-2：
















`new_remaining_execution_days = MIN(current_remaining_execution_days, new_mode_max_execution_days)`
















只能縮短，不得延長。
5. 在產生任何新Sell前，必須先完成當下Order Reconciliation與Active Sell Exposure重算。
















此規則防止利用短暫Resolution／Cancel-Reconcile期間反覆洗出新的Risk Clock。
















### E-8｜episode_resolved_at之後重新正式成立Structural Break
















若Reduction Episode已`CLOSED`且已有`episode_resolved_at`，之後公司再次依A系列完整條件正式成立新的Structural Break：
















- 建立新的`episode_id`；
- 建立新的`episode_started_at`；
- 依當時Risk Grade／B-2正式規則建立新的Risk Clock；
- 以當時最新Confirmed AP、最新Thesis States、最新Risk Grade、最新FC重新計算RRG；
- 舊Sell Target、舊Pending Reduction Amount、舊Rebound Window、舊Technical Event History不得復活或跨Episode沿用。
















### E-9｜Recovery Evidence與Observation Duration
















Observation Duration不建立公司層固定7天／30天／一季參數。
















每一個Recoverable Thesis仍完全由A-7事前定義之`recovery_requirement`負責。只有Failure Condition不再成立、新客觀修復證據成立，且該`recovery_requirement`已滿足，才可依A-7合法`FAILED → DETERIORATING → NORMAL`。
















- Emergency `DECONFIRMED`本身不等於Thesis Recovery，不得直接修改Risk Grade／FC。
- Irreversible Thesis不得因短期改善恢復；原版本永久維持FAILED。
- Recoverable Thesis若沒有事前定義`recovery_requirement`，不得事後臨時發明7天／30天或其他觀察期使其恢復；必須標記`Recovery Definition Missing`／治理缺口，正式補正前不得用臨時條件把FAILED降級。
















### E-10｜三個固定State Boundary Edge Cases
















**A｜最後FAILED恢復，但舊Sell Order取消尚未確認**
















- `Structural Break = RESOLVED`
- `company_risk_grade = NONE`
- FC限制解除、`RRG=0`
- 停止新Sell Intent
- Episode → `RESOLUTION_PENDING_RECONCILIATION`
- Reconcile／Cancel舊Sell；確認無未處理Active Sell Exposure後才`CLOSED`並寫`episode_resolved_at`
- 取消前若意外成交，只更新latest AP，不產生Buy Gap
















**B｜Structural Break已RESOLVED、Episode仍在Reconciliation期間，公司重新正式成立Structural Break**
















- `Structural Break → ACTIVE`
- 依最新Thesis重新算Risk Grade／FC／RRG／FWL／B-3
- 沿用原`episode_id`與原剩餘Risk Clock，不取得新Clock
- 新Mode更快時只依B-2縮短Clock，不得延長
- 先Order Reconciliation，再產生新Sell
















**C｜Episode已正式CLOSED並寫episode_resolved_at，數月後再次Structural Break**
















- 建立新`episode_id`
- 建立新Risk Clock
- 以最新AP／Risk Grade／FC／RRG重新執行
- 舊Sell Target、舊Pending Amount、舊Window與舊Episode Event History不得復活
















### E-11｜Candidate Parameter與一致性不變量
















4-7E新增Candidate Parameter：**0個**。
















一致性不變量：
















1. A-7是Thesis Recovery唯一來源。
2. Risk Grade依A-7完成後最新Thesis States同Cycle重算。
3. `FAILED=0 AND no Critical FAILED`時Risk Grade為`NONE`，不新增R0。
4. Structural Break business state與Reduction Episode execution state分離。
5. FC限制解除不是Buy Target，不形成Buy Gap。
6. Episode未CLOSED前重新成立Structural Break，不得取得新Risk Clock。
7. Risk Clock只能依既有B-2規則縮短，不得延長。
8. `RESOLUTION_PENDING_RECONCILIATION`期間不消耗Effective Execution Day。
9. Emergency DECONFIRMED不等於Thesis Recovery。
10. 不新增Recovery Score、Cooldown或固定Observation Duration。
















---
















## 4-7F｜News Search Time Window／Source Credibility Tiers／Event Deduplication／Freshness
















### F-1｜權責邊界：Search Window、Event Lifetime、Evidence／Assertion Lifetime分離
















4-7F只負責新聞／事件／證據的搜尋、來源分層、事件身份、去重、更新與時效治理，不建立新的投資判斷系統，不改寫A～E既有Thesis／Risk Grade／Structural Break／Emergency權責。
















正式分離三種生命週期：
















1. **Search Window**：本輪一般新聞Discovery要往回搜尋多遠。
2. **Event Lifetime**：底層真實事件目前是否仍需追蹤、是否已進入既有terminal state。
3. **Evidence／Assertion Lifetime**：某份證據中的特定Assertion目前是否仍可支持既有事件判斷。
















V70／V82既有「最近1～2日重大新聞」只屬**General News Discovery Seed**，不得解釋成事件、證據或Assertion在1～2日後自動失效。
















固定不變量：
















> **Search Window ≠ Event Lifetime ≠ Evidence／Assertion Lifetime。**
















### F-2｜Document Recency ≠ Assertion Validity
















`published_at`、`retrieved_at`、文件距今多久，只描述Document／Item Recency；不得機械等同Assertion Validity。
















- 市場價格、殖利率、估值、經濟統計、週期性營運資料等本身具有時間敏感性的資料，可依既有`max_age_days`／`valid_until`判斷是否STALE。
- SEC filing、法院文件、監管命令、正式公司申報、審計意見、違約通知、契約通知等正式事件證據，不得只因文件年齡自動失效。
- 正式事件Evidence之Assertion Validity主要依其事件語意判斷，例如：`superseded / revoked / amended / cured / dismissed / reversed / resolved`，並受4-7D既有Evidence Authority／Evidence Assertion／Event-specific Confirmation規則約束。
- `amended`只影響被正式修改的Assertion，不得機械使整份歷史文件全部失效；未被修改部分仍保留其PIT歷史與相應證據效力。
















因此固定：
















> **Old Article／Old Document ≠ Invalid Evidence。**
















### F-3｜Source Tier只管理Retrieval Priority／Conflict Resolution
















V82既有資料來源優先順序正式映射為：
















- `PRIMARY`：官方／第一手／正式權責來源。
- `SECONDARY`：可靠市場資料商、大型券商、主要新聞通訊社或可驗證二手來源。
- `TERTIARY`：一般第三方財經網站、聚合／轉載等輔助來源。
- 無法可靠分類時：`UNCLASSIFIED`。
















Source Tier只回答「搜尋／取證時先看誰、來源衝突時優先核對誰」，**不得直接產生Event Confirmation**。
















4-7D權責維持不變：
















`Event Type × Evidence Authority × Evidence Assertion → Event-specific Confirmation`
















因此：
















> **Official／PRIMARY Source ≠ Automatic CONFIRMED。**
















### F-4｜Article、URL、Evidence、Canonical Event正式分離
















正式身份模型不得混用：
















> **Article ≠ URL ≠ Evidence ≠ Canonical Event。**
















每一個底層事件建立`canonical_event_id`；每一份可追溯證據建立`evidence_id`。URL只作locator之一，不得直接作Event ID或唯一Dedup Key。
















Canonical Event至少應能保存／映射：
















- `canonical_event_id`
- `event_type`
- `primary_entity`
- `related_entities`
- `event_occurred_at`
- `effective_at`
- `first_seen_at`
- `last_seen_at`
- `latest_material_update_at`
- `event_version`
- `tracking_status`
- `related_evidence_ids`
- `related_event_ids`
















Evidence至少應能保存／映射：
















- `evidence_id`
- `canonical_event_id`
- `source_origin`
- `source_url`
- `source_document_id`
- `published_at`
- `source_updated_at`
- `retrieved_at`
- `evidence_authority`
- `evidence_assertion`
- `evidence_lineage_id`
- `content_fingerprint`
- `supersedes_evidence_id`
















### F-5｜Canonical Event Boundary：Same Root Cause ≠ Same Event
















同一根本原因、同一新聞故事或同一公司，不代表必須合併為一個Canonical Event。
















同一正式案件／程序／契約事件內的合法進展，可沿用同一`canonical_event_id`並增加`event_version`；但實質不同的法律、監管、契約或公司正式事件，即使由同一Root Cause造成，也必須建立不同`canonical_event_id`，再以`related_event_ids`連結。
















Event Identity優先依下列可識別邊界判斷：
















- Event Type；
- 正式案件／程序／契約身份；
- 權責主體；
- 實體／公司／債務工具範圍；
- 正式法律或公司事件的獨立生效狀態。
















例：同一會計問題同時引發SEC調查與銀行宣布債務違約，應為兩個related canonical events，不得因根因相同而過度Dedup。
















### F-6｜Evidence Lineage與Independent Evidence
















Evidence Independence依**Original Provenance／Assertion Origin**判定，不依URL數、Publisher數、轉載網站數或媒體篇數。
















- 轉載、鏡像、聚合、引用同一原始文件，不增加Independent Evidence數。
- 公司同一新聞稿出現在IR、SEC附件、Yahoo、MSN或其他媒體時，若Assertion皆源自同一原始新聞稿，應屬同一Original Assertion Lineage。
- 不同權責主體各自獨立形成的正式文件，例如公司正式公告、獨立審計師正式意見、法院文件、監管機關正式文件，可依A系列既有規則判斷是否為真正Independent Evidence。
- Evidence Lineage判斷單位允許到**Assertion level**；同一篇Article若同時包含引用他人原始文件與作者／媒體獨立產生的新事實，可形成不同Assertion Lineage，不強迫整篇Article只有一個Lineage。
















同一Underlying Event不得因多篇新聞／重複Evidence／同源資料重複計數。
















### F-7｜Dedup與Material Update
















Dedup的目標是消除重複報導，不得把同一事件後續重大新進展一起刪除。
















同一`canonical_event_id`若出現實質新資訊，建立新的`event_version`；只要新Evidence改變下列任一正式決策相關欄位，即視為`material_update = TRUE`：
















- Event State；
- Evidence Assertion；
- 法律／監管／正式生效狀態；
- 事件規模、金額或影響範圍；
- 受影響公司／債務／市場；
- 生效日期；
- Cure／Waiver；
- Confirmation／Denial；
- Reversal／Dismissal；
- Thesis Failure／Recovery判斷；
- Hard Gate／FC／RRG／Buy Cancellation等正式決策結果。
















只有改標題、換句話說、純轉載、無新事實的評論或今日重新整理昨日內容，原則上`material_update = FALSE`。
















同一URL亦不得作為「必然重複」的判斷：若`content_fingerprint`、`source_updated_at`或Evidence Assertion有實質變化，必須建立新的Evidence Version；若符合上述條件，再建立新的Event Version。
















固定：
















> **Today Article ≠ New Event。**
















### F-8｜Active Event Registry
















正式建立Active Event Registry，用於追蹤所有尚未terminal、且仍具決策相關性的重大事件。
















每輪新聞處理至少分成兩條路徑：
















`General News Discovery + Active Event Refresh`
















General News Search受Search Window限制；Active Event Refresh**不受General Search Window限制**。
















Registry只管理追蹤生命週期，不建立第二套Emergency／Structural Break／Thesis Business State。至少相容：
















`tracking_status = ACTIVE / CLOSED`
















Active Event不得因「幾天沒有新新聞」自動關閉，不新增7天、30天或其他timeout。只有當與該事件連結的正式業務狀態依既有規則進入合法terminal／resolved／deconfirmed／superseded等狀態，且沒有仍需追蹤的未決重大Assertion時，才可CLOSED。
















### F-9｜Freshness正式拆分
















Freshness固定拆為：
















1. **Search Freshness**：本輪搜尋／Refresh流程最近是否成功完成。
2. **Item Freshness**：Article／Document何時發布或更新。
3. **Event Validity**：底層事件目前是否仍具正式狀態／決策意義。
4. **Evidence／Assertion Validity**：特定Evidence中的Assertion目前是否仍能支持判斷。
















四者不得互相推導。Article很新不代表Event很新；Document很舊也不代表Assertion失效。
















### F-10｜Required Safety Coverage、Search Coverage Status與Checkpoint Commit
















Search Checkpoint能否前移，不以「每一個Provider是否成功」判斷，而以**Required Safety Coverage**是否完整判斷。
















`search_coverage_status`固定相容：
















- `COMPLETE`
- `PARTIAL`
- `INSUFFICIENT`
















`checkpoint_commit_eligible`與`search_coverage_status`分離；允許Optional Provider失敗造成`PARTIAL`，但Required Safety Coverage仍完整時Global Checkpoint安全前移。
















Global Checkpoint只有下列條件全部成立才可commit：
















1. Required Safety Domains satisfied；
2. Active Event Refresh completed；
3. Event／Evidence Dedup completed；
4. Event／Evidence Persistence succeeded。
















Partial／crash期間若上述條件未全部成立，不得推進Global Checkpoint，下一輪依overlap補抓。
















Provider cursor與Global Checkpoint必須分離。Optional Provider失敗時：
















- 不得推進該Provider自己的`last_successful_retrieval_at`／retrieval cursor；
- 下次恢復時由該Provider自己的`last_successful_retrieval_at + overlap`補抓；
- 不得因Global Checkpoint已前移而永久跳過該Provider失敗期間。
















### F-11｜Cold Start／Checkpoint Loss Recovery
















Cold Start或Global Checkpoint遺失時，不得只靠「最近N天新聞」重建世界狀態。
















正式恢復順序：
















1. 讀取持久化Active Event Registry；
2. 讀取最近正式V82／客戶Snapshot中仍Active的重大事件；
3. Refresh所有Active Events；
4. 執行Cold-start General News Search；
5. Dedup與Material Update判定；
6. Persistence成功後建立新的Global Checkpoint。
















若Global Checkpoint、Active Event Registry及可用歷史Snapshot皆不足以安全重建重大事件狀態，標記`News/Event State Recovery Incomplete`。是否阻擋新增送單仍依既有V82 Data Quality／Hard Gate規則判斷，不新增獨立Hard Gate系統。
















### F-12｜Search Failure與Hard Gate邊界
















Search Failure不得一律等於Hard Gate。
















第三方／Optional Provider失敗，但Required Safety Domains與Active Material Event仍可由其他可靠來源完整驗證時，可標記`PARTIAL`，不得單獨阻擋新增送單。
















只有當搜尋／Refresh失敗造成以下任一重大安全缺口時，才依既有V82 Data Quality／Hard Gate進入`INSUFFICIENT`並阻擋新增送單：
















- Required Safety Domain無法驗證；
- Active Material Event無法完成必要Refresh；
- 關鍵Event／Evidence persistence失敗導致狀態無法可靠保存；
- Recovery Incomplete已足以影響重大安全判斷。
















此規則不建立新的Hard Gate種類，只把新聞／事件資料品質映射回既有Data Quality／Hard Gate框架。
















### Candidate Parameter
















4-7F最終只保留兩個Candidate Parameter：
















1. `incremental_search_overlap_window`
2. `cold_start_general_news_lookback_window`
















兩者目前皆為**TBD**。現有正式規則沒有足夠依據支持24小時、48小時、7天、30天或其他具體數值，程式化前不得自行填入。
















4-7F不新增：
















- `event_expiry_days`
- `active_event_timeout`
- 全域`evidence_expiry_days`
- `news_source_score`
- `minimum_media_article_count`
- `dedup_similarity_threshold`
- `material_update_score`
- `pending_wait_days`
- 其他以媒體篇數、固定等待天數或假精確分數取代既有Evidence／Event語意的參數。
















### 固定Edge Cases
















1. **90天前SEC正式文件今天仍未撤銷／取代**：Document Recency可很舊，但相關Assertion不得只因年齡失效。
2. **一般第三方News Feed失敗，但Required Safety Domains與Active Event Refresh完整**：`search_coverage_status = PARTIAL`可成立；Global Checkpoint在Commit Gate全部通過後仍可前移；失敗Provider自己的cursor不得前移；不因該Optional Provider單獨Hard Gate。
3. **同一會計問題同時造成SEC調查與債務違約**：建立兩個不同`canonical_event_id`，以`related_event_ids`關聯，不得過度合併。
4. **同一公司新聞稿同時出現在IR／SEC附件／多家媒體，之後審計師另出正式意見**：前一群組若皆源自同一原始新聞稿，維持同Original Assertion Lineage；審計師獨立形成之正式意見可成為新的Independent Evidence。
5. **同一URL午後重大更新**：URL相同不得直接Dedup；Evidence Version更新，若改變正式Event／Assertion狀態則`material_update = TRUE`。
6. **今天文章回顧三週前事件**：`published_at=today`不得重建新Canonical Event。
7. **一篇文章同時描述兩個獨立正式事件**：Article可同時連結兩個Canonical Events，不得因Article ID相同而合併。
8. **同一全球事件影響多個股票／ETF**：維持一個Global canonical event，再連結多個Asset Delta，不因每個標的重複建立事件。
















### 4-7F一致性不變量
















1. Search Window不決定Event Lifetime。
2. Document Recency不決定Assertion Validity。
3. Article／URL／Evidence／Canonical Event分離。
4. 同一Underlying Event不得靠媒體篇數、URL數、Publisher數重複計數。
5. Source Priority／Source Tier不得直接產生Event Confirmation。
6. 4-7D之Evidence Authority × Evidence Assertion × Event-specific Confirmation權責維持不變。
7. Same Root Cause不等於Same Canonical Event；不同正式事件以`related_event_ids`連結。
8. Evidence Independence依Original Provenance／Assertion Origin判斷，允許Assertion-level lineage。
9. Material Update必須保留，不得被Dedup吞掉。
10. Active Event不受General Search Window限制，也不得因固定天數無新聞自動關閉。
11. Global Checkpoint Commit看Required Safety Coverage＋Active Event Refresh＋Dedup＋Persistence，不看每個Provider是否成功。
12. Optional Provider自己的retrieval cursor不得因Global Checkpoint前移而越過失敗期間。
13. Search Failure只有在造成重大安全資料域／Active Material Event無法可靠驗證時，才映射到既有Data Quality／Hard Gate阻擋新增送單。
14. Cold Start／Checkpoint Loss先恢復Active Events，再做General News Search。
15. 4-7F只有兩個Candidate Parameter，兩者均維持TBD，不新增假精確時間窗、篇數門檻或可信度分數。
















---
















# 第七十四章｜客戶資金來源、幣別與債券停泊之分離原則
















V82是**股票／股票ETF母規則**，不寫死任何客戶的美元資金池、SGOV部位、複委託交割方式、匯率目標或資金來源。
















固定原則：
















- 客戶是否以SGOV、現金、定存、債券或其他來源作為股票建倉彈藥，屬於**客戶專案檔**。
- SGOV與其他債券／債券ETF本身的買賣判斷，使用最新版**債券V75**。
- USD/TWD等匯率若會影響客戶實際換匯、海外ETF成本或提款需求，分析時可作為V82的Macro／執行成本輸入，但客戶特定匯率門檻、退出計畫與交割方式放在客戶專案檔。
- V82只需要知道「本次可動用資金上限」與「客戶專案檔授權的資金來源」，不得反推或要求知道客戶全部財產。
















---
















# 第七十五章｜股票ETF GTC／預約限價單通用模組
















## 定位
















本章把V82判斷轉成可執行的股票ETF限價單／GTC／預約單建議。**不綁定IBKR、不綁定特定ETF、不綁定固定資金池。**
















每一檔股票ETF都必須使用自己的價格、ATR、Confirmed Swing High／Low、估值、基本面、波動、技術與專案部位上限重新計算，不得借另一檔ETF的實際價格或比例。
















## 建議預掛前固定檢查
















至少整合：
















**價格地圖 → 高TD9 → 低TD9 → KD → MACD → MA → EMV → RSI → 成交量／量價 → ATR → 日／週／月線 → 基本面 → 估值 → Macro位置＋方向＋速度 → 信用／流動性 → 重大新聞／政策 → Look-through曝險。**
















並確認：
















- 客戶專案檔提供的本標的目標配置與剩餘可建倉額度。
- 本次可動用資金上限。
- 實際平台是否支援GTC、碎股、盤前盤後、預約單與取消機制。
- 佣金、交易所費用、買賣價差、稅務與匯率成本是否合理。
















## 每次固定輸出
















| 標的 | V82狀態 | 預約／GTC價 | 本層建議投入 | 股數 | 動作 |
|---|---|---:|---:|---:|---|
| 股票／股票ETF | 依最新V82 | 依自身價格地圖 | 依專案額度與V82強度 | 依價格換算 | 預掛／不掛／取消／調整 |
















每一筆還必須明確寫出：
















- 取消／暫停條件
- 下一次重新評估條件
- 成交後該標的剩餘可建倉額度
- 成交後本輪可動用資金剩餘額度
- 若需要籌資，只能引用客戶專案檔已指定的資金來源，不得自行替客戶決定賣哪一項資產
















## 預掛與取消原則
















- **建議預掛**：價格進入合理／甜甜價／更深折價區，基本面與估值可接受，且Macro、信用與流動性沒有Hard Gate時，即可依該價格區的部署目標提出分層限價單；技術成熟度主要決定單筆大小與分層速度。
- **不預掛**：Runaway Down、基本面重大惡化、估值／價格地圖失效、信用／流動性Hard Gate或重大事件尚待T+1 Gap Recheck時，不因價格便宜而機械掛單。
- **取消／調整**：預掛後若出現重大財測下修、政策／地緣政治衝擊、信用／流動性惡化、Runaway Down或其他Hard Gate，顧問應明確建議重新評估、減量或取消未成交單。
- **未成交不機械追單日大陽線**：若原低價單未成交而市場轉強，重新跑V82；若已進Runaway Up且專案仍明顯低配，改用Trend Deployment，不得因死守原掛單而永久缺席。
- **已成交不後見之明改寫**：依當時可得資訊與正式建議成交的部位，不因之後市場下跌而事後假定原成交無效。
- **客戶保有最終決策權**：顧問可強烈且反覆提醒風險，但預掛、取消、調整與成交的最終決定屬於客戶本人。
















## 本章核心
















**客戶專案檔提供／保存客戶已核准的「最多能買多少、可用什麼資金、哪些限制與授權」；V82決定「現在是否值得建議買、價格在哪、建議投入強度、何時取消」；Execution Adapter只負責把已核准的Order Intent轉成符合券商規格的「實際如何下單」。**
















---
















































# 執行章C3｜客戶專案 Latest State＋run_id 寫回契約
















每次對單一客戶正式執行 V82 時，必須沿用同一輪 `V70產出-<客戶名字>.md` 的共用 `run_id`。若Legacy V70資料沒有`run_id`，可使用原有台灣時間戳等穩定Legacy識別素材，由Orchestration／Integration先正規化產生**一個全鏈共用`run_id`**再進行正式Commit；不得讓V82、債券V75或Report各自用不同時間戳充當自己的Run ID。
















V82 本輪需產生兩個客戶專案整合欄位：
















- `STOCK_ALLOCATION_FINAL`：本輪股票／股票ETF最後可採用的配置結果與逐檔金額／比例。
- `V82_UNDEPLOYED_TO_SGOV`：V70給予股票戰術額度中，本輪經 V82 判斷後尚未部署的部分；V82只擁有此輸出值。此值交給 Mentor／Integration Layer，與V70／V75各自已算好的輸出依固定Integration Contract加總；客戶專案只保存最終正式整合結果。
















固定關係：
















```text
SGOV_DRY_POWDER_BUCKET
= V70_ORIGINAL_DRY_POWDER
+ V82_UNDEPLOYED_TO_SGOV
+ V75_UNDEPLOYED_TO_SGOV
```
















V82 不得把 `V82_UNDEPLOYED_TO_SGOV` 誤記為正式債券 SGOV，也不得自行把 `SGOV_BOND_BUCKET` 納入股票子彈。
















### 本輪暫存與正式化
















- 計算中的逐檔候選金額、Actual Completion Rate／Canonical Deployment Target Rate中間值、未部署暫算值可寫入客戶專案 `## 本輪暫存／運算區`；這是 RAM／scratch，Run 完成可清空，不建立暫存歷史。
- V82 的永久判斷依據仍追加到 `STOCK_VALUATION_SNAPSHOT_HISTORY`，並在客戶專案 `## 歷史決策與市場判斷紀錄` 留下本 Run 的股票判斷摘要。
- Mentor／Integration Layer依正式Integration Contract整合V70、V82、債券V75與現金的既有輸出；客戶專案只保存整合後的 `## 最新正式配置狀態`，報告只讀標記為「正式」的最新狀態。
- 每個正式欄位至少保留：金額、占可投資資產%、資料時間、資料來源、狀態；每個正式Run**必須**保存共用`run_id`，V82正式Snapshot另保存`v82_snapshot_id`。
















### 建議 ≠ 實際成交
















V82 的買進方案、GTC／限價建議、預掛單都只是決策／建議資料。只有客戶明確回報成交，或未來券商 API 確認成交，才追加到：
















> `客戶名稱股債交易紀錄.md`
















實際成交後，再同步客戶專案目前持倉與現金；不得把尚未成交的建議寫成 transaction。
































# 結語章D｜V82一句話總結
















**先確認這是不是客戶要長期持有的標的，再用它自己的價格、ATR、Swing Low、估值與基本面建立價格地圖；價格越甜且基本面、Macro、信用與流動性越安全，部署越積極；技術面負責決定今天先買多少、後面加多快；若市場直接進入Runaway Up而專案仍低配，啟動Trend Deployment；最後依Project Target Position、Actual Completion Rate、Canonical Deployment Target Rate、部位上限與Look-through曝險換算實際金額與股數。**
















---
















# 結語章E｜V82最終操作口訣
















**先確認是長期要持有的好資產，再畫自己的價格地圖。**
















**合理價先參與，甜甜價多部署，深度折價且安全時更積極。**
















**價格決定值得買多少；技術決定今天先買多少、後面加多快。**
















**右側確認是加速，不是第一筆買進的門票。**
















**跌的時候敢買；止跌時加；漲起來但仍低配，要跟上。**
















**Runaway Up不機械追單日大陽線，但低配時要Trend Deployment。**
















**Runaway Down不接刀。**
















**Hard Gate觸發時，正常新增Buy Permission關閉；真正降低風險另由Structural Break／Emergency等正式Risk Owner決定。**
















**投資論點失效，真正降低風險。**
















**專案決定最多要持有多少；V82決定今天往目標走多快。**
















**最後一定回答：現在買不買、屬哪個Deployment Mode／Stage、買多少、什麼價、幾股、預估成交後完成率（若有Planned Fill）、掛不掛單、何時取消；實際成交後再更新Actual Completion Rate。**
















**借股性，不借價格；借分析骨架，不複製買點。**
















# 附錄｜版本修訂紀錄
















## 2026/09/19 14:30｜V82系統工程20 全域Priority／Coexistence／Preemption deterministic化｜v1.13.0
















- 六類Special Classification正式建立唯一Primary Priority：`真正降低風險 > Runaway Down > 技術減碼 > Runaway Up > 右側加碼 > 左側買點`；六類皆False才顯示「無特殊分類」。
- 正式新增Coexistence／Mutual Exclusion／Preemption／Allowed Action Matrix；保留多個Predicate作Secondary Context，但同一輪只允許一個`primary_special_classification`。
- Hard Gate維持Gate；Structural Break／Emergency維持各自Business／Event State；Deployment Mode維持`Base / Left Overweight / Right Confirmation / Trend Deployment`，均不得混入Special Classification Enum。
- `CONFIRMED Emergency`取得最高Execution Intent；一般Structural Break依A／B／C／E與既有FC／RRG／Clock處理；`PENDING_VERIFICATION`只停新Buy／取消Buy，不建立Emergency Sell Rate。
- `Runaway Up + Runaway Down`、`Left/Right + Runaway Down`等同一Snapshot非法組合固定採安全Fallback並要求Reconciliation，不建立新State。
- `Final Deployment Gap <= 0 + Right Confirmation`固定輸出`new_buy_quantity=0`與「本輪不新增」Execution Result；WAIT不得復活。
- 技術減碼既有「通常至少3項共振」正式收斂為同輪`>=3`有效既有訊號；技術減碼取得Primary時，同Cycle正常新增Buy Intent固定為0。
- 九階梯、五層Price Map、Hard Gate核心、Structural Break／Reduction／Emergency既有數值均未修改；V82 Python／Tests仍凍結至79+。
















## 2026/09/18 03:03｜Debug第5題：舊版部署比例與失效規則全文一致性清掃｜v1.10.0
















- 直接複用既有canonical Structural Break文字，清除舊的一刀切Thesis退出語意；個別Thesis FAILED必須依Risk Grade → Fundamental Cap → Structural Break Reduction，只有`CONFIRMED Emergency`才由Emergency Exit接管。
- 正式英文Deployment Mode統一為`Base Deployment / Left Overweight / Right Confirmation / Trend Deployment`；清除舊Left英文別名作為第二正式名稱的殘留。
- 兩處裸「等待」改為可執行結果：淺回檔只暫不啟動左側承接且不抹除Base Deployment／Deployment Gap；日／週／月全空時暫停新增左側買單，但不因此新增Hard Gate。
- 舊五階梯完整數值只保留一份唯一歷史紀錄，其餘重複位置改引用；WAIT保留正式禁止規則與一份必要完整歷史，其餘重複歷史改引用，降低RAG／Engine誤讀。
- 正式九階梯、Hard Gate、Deployment Gap、Base／Left／Right／Trend權責均未重新設計。
- `v82_engine.py`與`test_v82_engine.py`仍暫停，本輪未修改。
















## 2026/09/18 01:40｜第3題最終收斂：取消WAIT／一般等待正式State｜v1.9.0
















- 正式取消`WAIT／一般等待`作為State、分類、Deployment Mode與硬判定矩陣節點；不得再以WAIT補足分類數量。
- 原七分類正式收斂為六類特殊分類：左側買點、右側加碼、Runaway Up、Runaway Down、技術減碼、真正降低風險。
- 六類皆未成立時，分類欄輸出「無特殊分類」；這不是第七種State。
- 九階梯與Base／Left／Right／Trend繼續負責部署；部署缺口>0依既有Mode與技術／執行條件補足，部署缺口≤0時本輪自然不新增。
- 「本輪不新增」只是一個執行結果，不得另建WAIT比例、WAIT Mode或WAIT State；Hard Gate／Runaway Down／基本面破壞造成的0新增仍依各自安全規則標示。
- `v82_engine.py`與`test_v82_engine.py`本輪仍暫停，未同步本次v1.9.0。
















## 2026/09/19｜V82系統工程18 Canonical Terminology＋Data Dictionary正式化｜v1.11.0
















- 正式建立State／Special Classification／Deployment Mode／Signal／Gate／Permission／Recommendation／Execution Result／Order State／Position State語意邊界。
- 正式裁決：`左側買點`＝Special Classification、`Left Overweight`＝Deployment Mode；`右側加碼`＝Special Classification、右側確認條件＝Signal、`Right Confirmation`＝Deployment Mode；`Runaway Up`＝Special Classification、`Trend Deployment`＝Deployment Mode。
- 正式拆分`Actual Completion Rate = AP ÷ Project Target Position`與九階梯`Canonical Deployment Target Rate`；兩者不得再共用「完成率」機器欄位。
- 正式區分Project Target Position與Structural Break的`OTP (Original Target Position)`；`RRG`全名固定為`Remaining Reduction Gap`。
- 正式建立Candidate／TBD／Tentative／Provisional／UNKNOWN／NONE治理；未批准Candidate／TBD不可Executable，`UNKNOWN ≠ False ≠ Zero ≠ Neutral`。
- 明確例外：`EXTREME_CANDIDATE`是正式ValuationLevel列舉；`Provisional Low`是技術價格結構名詞，兩者不套一般治理字面義。
- 正式鎖定`Recommendation ≠ Order Intent ≠ Submitted/Open Order ≠ Fill ≠ Confirmed Position`；AP只由Confirmed Fill／Broker Confirmed Position更新。
- 本版只做18號語意工程化，不修改九階梯比例、Hard Gate、Structural Break／Reduction／Emergency數值或投資哲學；Python／Tests留待V82系統工程79+依最終封版施工。
















## 2026/09/18｜4-7F News Search／Source Tier／Event Dedup／Freshness deterministic化｜v1.8.0
















- 正式拆分Search Window、Event Lifetime與Evidence／Assertion Lifetime；V70／V82「最近1～2日重大新聞」只作General News Discovery Seed，不是事件失效期限。
- 正式鎖定Document Recency ≠ Assertion Validity；時間敏感資料才以`max_age_days / valid_until`作主要時效判斷，法律／監管／公司申報／審計／契約事件Evidence依superseded／revoked／amended／cured／dismissed／reversed／resolved等正式語意管理；Amendment只影響被修改Assertion。
- Source Tier只管理Retrieval Priority／Conflict Resolution；4-7D的Evidence Authority × Evidence Assertion × Event-specific Confirmation權責不變。
- 正式分離Article／URL／Evidence／Canonical Event；新增`canonical_event_id + event_version + material_update`語意，Same Root Cause不等於Same Event，不同正式事件以`related_event_ids`關聯。
- Evidence Independence依Original Provenance／Assertion Origin判定，允許Assertion-level lineage；轉載、鏡像與同源新聞稿不得增加獨立Evidence數。
- Active Event Registry正式納入；Active Event不受General Search Window限制，也不得因固定天數無新聞自動關閉。
- Freshness拆為Search Freshness、Item Freshness、Event Validity、Evidence／Assertion Validity。
- Checkpoint Commit Gate改看Required Safety Coverage＋Active Event Refresh＋Dedup＋Persistence；`search_coverage_status = COMPLETE / PARTIAL / INSUFFICIENT`與`checkpoint_commit_eligible`分離。Optional Provider失敗時不得推進該Provider自己的retrieval cursor。
- Cold Start／Checkpoint Loss先恢復Active Events，再做General News Search；Search Failure只有造成重大安全資料域／Active Material Event無法可靠驗證時，才依既有Data Quality／Hard Gate阻擋新增送單。
- 4-7F最終只保留兩個Candidate Parameter：`incremental_search_overlap_window`、`cold_start_general_news_lookback_window`；兩者均TBD，不自行填24小時／48小時／7天／30天，也不新增事件到期日、媒體篇數門檻、可信度分數或Dedup假精確閾值。
































## 2026/09/17｜4-7E Company-level Recovery與Episode Closure deterministic化｜v1.7.0
















- A-7維持Thesis Recovery唯一來源；4-7E只承接最新Thesis States重算公司層Risk Grade／FC與解除生命週期。
- 正式新增`company_risk_grade = NONE`；`FAILED=0 AND no Critical FAILED`時同Cycle將`structural_break_status = RESOLVED`、解除Structural Break FC限制並令RRG=0。
- 明確區分Structural Break business state與Reduction Episode execution state；基本面恢復不得被券商舊Active Sell Order污染。
- 新增Episode收尾狀態`RESOLUTION_PENDING_RECONCILIATION`：RRG=0後停止新Sell，先清理舊Active Sell Exposure；確認收尾後才`CLOSED`並寫`episode_resolved_at`。
- `episode_resolved_at`以前重新成立Structural Break沿用原Episode與原剩餘Risk Clock；之後才建立新Episode與新Clock。Clock只能依B-2縮短、不得延長。
- `RESOLUTION_PENDING_RECONCILIATION`因無新Reduction Intent且RRG=0，不消耗Effective Execution Day。
- FC restriction released＝100% OTP只代表Structural Break不再額外限制FC，不是Target Position／Buy Target；不得形成Buy Gap或自動買回。
- Emergency DECONFIRMED不等於Thesis Recovery；Irreversible Thesis不恢復；缺少事前`recovery_requirement`時標記`Recovery Definition Missing`，不得臨時發明固定觀察天數。
- 4-7E新增Candidate Parameter為0；A／B／C三個State Boundary Edge Cases正式固定。
































## 2026/09/17｜4-7D Emergency Exit deterministic化｜v1.6.0
















- 新增Emergency Event State：`NONE / PENDING_VERIFICATION / CONFIRMED / DECONFIRMED`，並與Execution State `NOT_STARTED / IN_PROGRESS / BLOCKED / COMPLETED`分離。
- 正式鎖定`Event Type × Evidence Authority × Evidence Assertion`共同決定Event-specific Confirmation；Official Source不等於自動CONFIRMED，調查中不等於舞弊成立。
- 新增四類既有Emergency Event Type：重大舞弊／財報不可靠、重大違約、破產／重整、Going Concern；不新增新聞篇數、價格跌幅、等待天數或Emergency Sell Rate。
- PENDING固定停止新Buy／取消未成交Buy，但不建立Pending Sell Rate；既有合法Structural Break Reduction依原Episode與Clock繼續。
- CONFIRMED Emergency不是B-3 Accelerated或第四種Mode；直接Preempt一般Structural Break Execution，第一個可執行Cycle以最新全部AP為Emergency RRG，且共用Order Reconciliation／Confirmed AP／Active Sell Exposure／Execution Adapter安全骨架。
- 新增Existing Structural Break Episode之`EMERGENCY_PREEMPTED`生命週期；Preemption解除後只恢復原episode identity與尚未耗盡Risk Clock，所有RRG／Sell Target依最新AP、Thesis State、Risk Grade、FC重算，禁止恢復舊Target。
- 新增Multi-Emergency Event Aggregation：任何一個Active Event仍CONFIRMED，公司Emergency仍CONFIRMED；單一Event DECONFIRMED不得解除其他仍CONFIRMED Event。
- DECONFIRMED後停止無其他合法依據的Emergency-only Sell，但已成交部位不自動買回；後續買進重新走完整Fundamental Assessment、V82與A-8。
- 正式替換舊「投資論點失效時直接退出」：一般Thesis失效先依A系列R1／R2／R3與B系列Reduction；只有CONFIRMED Emergency才進Emergency Exit。
- 4-7D新增Candidate Parameter為0，並加入10個固定Edge Cases作程式化驗證基準。
















## 2026/09/17｜4-7C Fundamental Worsening Guard deterministic化｜v1.5.0
















- 正式停止使用未定義的Fundamental Deterioration Velocity（FDV），避免以Thesis數量冒充惡化速度。
- 新增Fundamental Worsening Level（FWL）0／1／2：只描述Risk Grade計算後、尚未FAILED的DETERIORATING Thesis額外惡化層級；不決定Risk Grade或FC。
- 新增`fundamental_worsening_guard = (FWL >= 1)`；Guard只取消Confirmed Slow資格，使Mode最低回Normal，不直接產生Accelerated。
- Critical Thesis處於DETERIORATING但未FAILED時，不提前判R3；FWL=2、Guard=TRUE。
- 已FAILED且已用於Risk Grade／FC的Thesis不得再次計入FWL；同一Underlying Event不得因重複新聞／證據重複計數。
- B-1窄幅一致性修補：FDV介面改讀FWL；FWL 0／1／2對應0／+1／+2 Initial Reduction基本面步階；既有比例表與Technical Panic Adjustment不重開。
- 4-7C新增Candidate Parameter為0；B-3仍是唯一Execution Mode Source，4-7C不得建立第二套Rate／Deadline／Clock／Episode／Rebound Window。
















## 2026/09/17｜個股 Structural Break Fundamental Cap＋Reduction Execution 正式化｜v1.4.0
















- 新增個股Core Investment Thesis／Critical Thesis、Structural Break、R1／R2／R3 Fundamental Cap與Recovery防呆。
- 新增B-1～B-6 Reduction Execution：Initial Reduction、Slow／Normal／Accelerated、Effective Execution Days、Hard Deadline、B-3技術Normalization、Rebound Window、No-Rebound Continuation、Reduction Episode Continuity與Order Reconciliation。
- 明確規定FC恢復只停止Reduction，不自動買回；任何重新買進必須重新跑最新V82九階梯＋V70.2容量。
- 明確規定Risk Grade／FC惡化不得重開Episode或延長Risk Clock；目前不新增R1／R2／R3獨立Deadline。
- B-3暫保留兩個Candidate：MACD Histogram連續2完成Bar、0.25×ATR(14) Noise Band；B-4～B-6不新增Candidate。
- 每個Execution Cycle必須先Order Reconciliation；AP只認Confirmed Fill／Broker Position；不得因舊Active Orders與新單重疊造成非預期超賣。
















## 2026/09/17｜第二題＋第三題合併：九階梯唯一部署邏輯【歷史中間版本；WAIT語意已由2026/09/18 v1.9.0取代】
















- 正式確認九階梯 **10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%** 為V82唯一正常累積部署比例來源。
- 【歷史中間版本；已失效】當時曾將「一般等待／WAIT」保留為九階梯目標完成後的「不新增」執行結果；2026/09/18 v1.9.0已進一步取消WAIT作為任何正式State／分類／Mode，現行僅保留「本輪不新增」這個自然執行結果。
- 若實際完成率低於目前累積目標，代表仍有部署缺口；技術只調整今天補多少與補足速度。
- 實際部位高於目前階梯不代表自動賣出；減碼仍須符合V82技術減碼或真正降低風險規則。
- 上游 `V70_2.html` 已正式負責股票戰術總額度與總體系統熔斷；最高防守時股票新增額度可為0%。V82不重複建立總體股票資金總閘門，只保留逐檔標的安全判斷與執行。
















## 2026/09/12 07:30｜V82一致性與版本管理修訂
















本次只做一致性與可程式化修訂，不改變V82長期持有 × 動態資金部署的核心哲學：
















- 新增「高檔派發／不要搶接盤」規則：高TD9＋KD／MACD／EMV高檔＋異常爆量共振時，不急接第一、第二根下跌。
- NATO母規則移除固定IB平台／交易口徑，實際平台、交易所、幣別與交割方式回歸客戶 `xxx專案.md`。
- Hard Gate明確區分LivingWaterAI建議權與客戶最終決策權；客戶逆Hard Gate自行交易須標示「客戶自主決策｜非V82正式建議」。
- Fed路徑改用相對時間軸：本曆年年底＋未來6／12／18個月，不再把2026／2027寫死在永久母規則。
- PPI改為「可能較早反映成本端壓力，但不存在固定穩定的領先月數」。
- 價格地圖重疊區增加Swing／MA／ATR／估值／基本面／產業週期的優先判定。
- 【歷史引用；WAIT語意已失效】舊「一般等待」語意及其中間演進詳見前述「2026/09/17｜第二題＋第三題合併」歷史紀錄；現行依2026/09/18 v1.9.0，不建立WAIT／一般等待State、Classification或Deployment Mode。
- 【歷史引用｜已失效舊版】舊五階梯已失效；完整歷史數值詳見本附錄「2026/09/12 08:01｜V82部署比例舊規則清理」。現行唯一正式準據為九階梯：10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%；客戶專案若有更低上限或特殊風控邊界，仍以專案邊界為上限。
















## 2026/09/05 06:27｜V82一致性稽核修訂
















本次為V82升版後的正式一致性稽核，只修正與已確認長期投資哲學互相衝突的殘留文字，沒有改回舊版波段邏輯。
















修正重點：
















- **【歷史表述｜已失效｜禁止執行】** 當時曾寫「Runaway Up統一稱為強勢趨勢部署」；現行正式型別必須分離：`Runaway Up`＝Special Classification，`Trend Deployment`＝Deployment Mode。
- 【歷史紀錄；已被目前正式母規則取代】當時曾採較粗舊五階梯；完整舊版數值詳見本附錄「2026/09/12 08:01｜V82部署比例舊規則清理」。現行唯一正式準據為九階梯：**10%／20%／30%／45%／60%／75%／85%／95%／100%**；`母規則回測.md`始終只負責驗證，不是部署比例來源。
- 【歷史引用；WAIT語意已失效】當時曾以「一般等待」描述部分不新增情境；完整歷史演進詳見前述「2026/09/17｜第二題＋第三題合併」。現行僅保留「本輪不新增」Execution Result，不建立WAIT State。
- Soft Signal缺失與高Beta規則不再把2～3項技術確認變回第一筆長期左側買進門檻。
- 預掛規則不再強制要求技術先止跌；技術改為調整單筆大小與分層速度。
- 最高原則修正為「價格決定值得部署多少；技術決定部署速度」。
- 完整底稿由44項更新為49項；最終執行摘要由10項更新為13項。
- 完整決策流程改為先讀客戶專案檔，再套V82母規則。
































## 2026/09/12 08:01｜V82部署比例舊規則清理
















- 清除「精確部署比例由母規則回測／已驗證校準值提供」的殘留文字。
- 【唯一完整歷史紀錄｜已失效舊版｜僅供歷史追溯｜禁止執行】2026/09/12 08:01曾將正式執行比例寫為：**一般可買20% → 第一層回檔40% → 甜甜價70% → 深度折價90% → 極端便宜100%**；此五階梯已於2026/09/12 08:21由九階梯正式取代。現行唯一正式累積部署完成率為：**10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%**。
- `母規則回測.md`只負責公平驗證、敏感度測試與比較，不得創造、替換或最佳化V82正式部署比例。
- 客戶專案檔只負責目標部位、資金邊界、個別上限與特殊風控；若專案上限低於V82部署目標，採較低上限。
















## 2026/09/12 08:21｜V82細階梯左側部署正式定稿
















- 正式取代前述已失效舊五階梯；完整舊版數值詳見本附錄「2026/09/12 08:01｜V82部署比例舊規則清理」。
- 新正式累積部署完成率：**10% → 20% → 30% → 45% → 60% → 75% → 85% → 95% → 100%**。
- 結構定位：左側採細階梯逐步承接；深跌但安全可提高至75%／85%；右側確認補至95%；趨勢重新轉強且仍低配時完成至100%。
- 全部比例均為相對客戶專案目標部位的**累積完成率**，不是每層額外投入比例。
- **【歷史簡寫｜已失效｜禁止直接執行】** 當時曾把Hard Gate、Runaway Down、信用／流動性與投資論點破壞概括寫成「具有否決權」；現行必須依工程20 Priority、工程39 `new_buy_order_permission`與Work4正式Risk Owner分流：Hard Gate關閉新增Buy Permission，Runaway Down／更高Priority Risk可搶占正常新增，真正Reduction／Emergency須由各自正式Owner確認後執行。
- `母規則回測.md`僅負責公平驗證，不得反向決定或最佳化V82正式部署比例。
































## 2026-08-30｜文件一致性修訂
















本次修訂屬於**文件結構、名詞與輸出欄位一致性整理**：
















- 【歷史紀錄】當時曾統一七分類標準術語；現行已於2026/09/18 v1.9.0收斂為六類特殊分類。
- 【歷史紀錄】當時曾建立七分類判定矩陣；現行已於2026/09/18 v1.9.0改為六類特殊分類硬判定矩陣。其餘日圓套利風險雷達、下單前檢查表與結語章節識別仍保留。
- **【歷史紀錄｜已失效｜禁止執行】** 當時曾區分「44項完整分析底稿」與「10項最終執行摘要」；現行已由工程65／66正式改為**49欄Canonical分析底稿＋13欄正式執行輸出**。
- **【歷史紀錄｜已失效｜禁止執行】** 當時曾在10項輸出補回「掛單方式」；現行掛單計畫統一由工程65 #47 `order_submission_plan`承接，正式執行輸出依工程66 **13欄View**。
- **V82保留TD9、KD、MACD、MA、EMV、RSI、ATR、Swing、Runaway Down、Macro、信用／流動性與日圓風險核心算法；正式改變的是長期資金部署哲學、左側買進門檻、右側定位、Runaway Up／Trend Deployment與目標部位完成率。**

# Work7｜V82系統工程68～72｜全文一致性 Final Audit【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。** 本段源自Work7工程68～72全文一致性清掃，現已由工程77納入正式SOT；仍維持不得新增或修改投資Threshold、部署比例、Default、Fallback、Hard Gate種類、Candidate Parameter、Risk Clock、Emergency Rate或Search Window的原施工邊界。

## Work7-A｜工程68 Candidate／TBD全文清掃

正式規則只有一條：**未批准Candidate／TBD／Tentative／Provisional數值不得進入Executable Rule。** 若一個正式Order／Reduction／Search Window必須依賴尚未批准參數，該依賴輸出必須維持治理未完成／不可執行，不得由LLM、Adapter或報表層自行猜值補上。

本輪保留且明確標記為**非Executable**的既有未批准項目只有：

1. Work4 B-1 Initial Reduction Candidate離散表（R1／R2／R3各候選Reduction比例）。
2. Work4 B-2 `SLOW / NORMAL / ACCELERATED` Candidate每日減碼比例與Candidate最大執行日數。
3. Work4 B-3兩個Candidate：MACD Histogram連續完成K棒數、`ATR(14)`乘數。
4. Work5 `incremental_search_overlap_window`與`cold_start_general_news_lookback_window`兩個TBD時間窗。

`EXTREME_CANDIDATE`與`Provisional Low`為既有正式Enum／狀態名稱，不代表待批准參數；`INTRADAY_PROVISIONAL`／`td9_provisional_*`及Confirmed／Provisional Swing結構則是尚未完成確認的觀察資料狀態，依既有規則不得覆寫Confirmed或觸發正式輸出。上述均不得因字面含Candidate／Provisional而誤刪，也不得被誤當成Provisional Rule／Value。

## Work7-B｜工程69 數字與公式全文一致性

以下公式／數字Owner維持既有正式唯一來源，本Work不重算、不建立第二套：

- 九階梯Canonical Deployment Target Rate：`10 / 20 / 30 / 45 / 60 / 75 / 85 / 95 / 100%`。
- `actual_completion_rate`：由Work38依Confirmed Position／Project Target計算；不得用Planned Fill冒充Actual。
- `projected_position_amount = confirmed_position_amount + active_buy_exposure_amount - active_sell_exposure_amount`。
- `final_deployment_gap_amount = canonical_deployment_target_amount - projected_position_amount`。
- `RRG = MAX(AP - FC, 0)`；不得改成Required Reduction Gap的其他公式。
- `projected_post_fill_completion_rate`只加入**尚未被Active Exposure計入**的Planned Execution Delta，禁止Double Count。

**Permission與Gap正式分離：** `new_buy_order_permission`只由Data Sufficiency、Hard Gate、更高Priority Risk與必要Execution Inputs是否完整裁決，不把Gap正負塞進Permission。只有Permission通過後，才再與正的Final Deployment Gap、Cash及Caps共同計算Maximum Allowed Buy Amount。

Candidate數值即使出現在全文，也不因重複出現而升格成正式數字；只有其Candidate治理狀態是正式的。

## Work7-C｜工程70 State／Priority全文一致性

1. 六類Special Classification仍依工程20 Canonical Priority Matrix裁決Primary；`WAIT／一般等待`不是第七類。
2. `Hard Gate`是Gate，固定控制`new_buy_order_permission`，不是Special Classification、Deployment Mode或Sell Intent。
3. `Runaway Down`可依Priority／Execution Contract搶占正常Buy，但不自動等於Structural Break或Sell。
4. `CONFIRMED Emergency`具有最高Execution Intent；Emergency／Structural Break／Reduction仍由既有Owner處理。
5. 正常Deployment Mode只允許`Base Deployment / Left Overweight / Right Confirmation / Trend Deployment / UNKNOWN`；Pause／Reduce／No-new-buy由`execution_action`呈現。
6. 同輪高Priority Predicate為UNKNOWN且可能改變結果時，不得把UNKNOWN當FALSE向下選低Priority State／Mode。

## Work7-D｜工程71 資料結構全文一致性

- 工程65的49個Top-level Canonical Fields維持唯一名稱、順序與Metadata契約；不得建立第50欄同義Business Meaning。
- 工程66的13欄正式輸出全部映射49欄；不得另造第二套Action／Completion／Order語意。
- `run_id`為V70→V82→債券V75→Client Latest State→Report同輪共用Identity；V82 Immutable Object另以`v82_snapshot_id`辨識。
- `rule_version`表示實際V82規則版本；正式Snapshot另保存`rule_version_set`／upstream version lineage，不要求不同Module版本字串相同。
- `UNKNOWN`只表示資料／裁決不足；正常No-action使用已知`0 / FALSE / N/A`，不得濫用UNKNOWN。
- Event ID／Episode ID／Order ID／Snapshot ID保持各自Domain；不得用名稱相似欄位互相代替。

## Work7-E｜工程72 失效舊規則與歷史文字清掃

現行可執行語意已清除下列失效用法：

- `WAIT／一般等待`作為正式State、Classification或Deployment Mode。
- 舊五階梯作為現行部署比例；舊五階梯只允許留在明確標示「歷史／已失效／禁止執行」的歷史紀錄。舊的`Runaway Up＝強勢趨勢部署`同義化文字也只能以同等歷史失效標記保留，現行不得把Classification與Deployment Mode合併。
- `Wait-for-discount／等回檔／暫不追`作為Valuation Snapshot自建Action Enum；Current Action統一回到#41 `execution_action`。另對正文與歷史段落保留的舊「永遠等回檔」敘事，必須明確標示為**歷史／已失效／禁止執行**。
- 「Hard Gate是唯一／最高暫停或否決來源」的舊簡寫，以及把Hard Gate／Runaway Down／信用／流動性／投資論點破壞概括成單一「否決權」的歷史簡寫；現行依工程20／Work2／Work3／Work4的Gate、Priority、Permission與Risk Owner契約解讀。
- Thesis Broken直接退出捷徑；真正Reduction／Emergency仍依Work4既有Confirmation、FC／RRG、Execution與Preemption鏈。
- Generic Median Fallback或其他未授權Valuation Fallback作為現行估值補值方式。

歷史段落若保留舊規則，必須可由同段文字明確辨識為**歷史／已失效／禁止執行**，不得被程式當Current Rule解析。

## Work7-F｜本Work封口

本Work只做全文一致性與機器實作歧義清掃；**沒有批准任何Candidate／TBD、沒有新建State／Threshold／Formula、沒有改變任何投資哲學或客戶配置規則。** 工程73～76已由Work8完成，並與本段一併由工程77正式封版。

# Work8｜V82系統工程73～76｜Cross-Section＋Machine-Readable Final Audit【正式｜工程77封版】

> **工程77正式封版狀態：FORMAL。** 本段源自Work8工程73～76最終跨章節／機器可讀稽核，現已由工程77納入正式SOT；仍維持未新增或修改投資Threshold、部署比例、Default、Fallback、Hard Gate種類、Candidate Parameter、Risk Clock、Emergency Rate或Search Window。

## 工程73｜Cross-Section Edge Cases Canonical Outcomes

本工程只把既有章節組合後的**唯一合法結果**寫死，不建立新Rule Owner。相同`run_id`、相同Canonical Snapshot與相同合法Input，必須先依既有Priority、Dependency、UNKNOWN、Order Reconciliation與Execution Owner裁決，再產生唯一Final Output；不得因章節讀取順序不同得到第二答案。

| # | Cross-Section Input | 唯一Canonical Result | Execution／禁止事項 |
|---|---|---|---|
| 1 | Hard Gate + Left | Hard Gate已TRIGGERED時，`left_safety_negations_absent=FALSE`，因此正式`left_buy_point_predicate=FALSE`；左側價格／折價Context可保留，但不得形成左側Buy Classification／Intent | `new_buy_order_permission=FALSE`；不得用「便宜」繞過Hard Gate；Hard Gate本身不產生Sell Intent |
| 2 | Hard Gate + Right | `右側加碼`／`Right Confirmation`可維持已成立的分析結果；Hard Gate不回寫Mode／Stage／Target／Gap | `new_buy_order_permission=FALSE`，本輪不得新增Buy；不得改名WAIT；若無其他Risk Owner，不產生Sell |
| 3 | R3 + Emergency PENDING | R3 Structural Break既有Episode／FC=0／RRG／B系列仍是有效Reduction Owner；Emergency仍只是`PENDING_VERIFICATION` | 停新Buy／取消未成交Buy；**不得**建立Emergency Sell Rate；既有合法B系列依原Episode／Clock與最新資料續行 |
| 4 | Emergency CONFIRMED + Active Sell | `CONFIRMED Emergency`取得最高Execution Intent；先Reconcile、Confirmed Fill、latest AP，再計`Emergency RRG=AP`與Active Sell Exposure | `Net New Sell Target = MAX(Emergency RRG - Compatible Active Sell Exposure, 0)`；不相容舊Sell先Cancel／Replace，Cancel未確認前不得重疊新Sell |
| 5 | Recovery + Active Sell | Thesis／Structural Break已正式Recovery時：`company_risk_grade=NONE`、Structural Break=`RESOLVED`、RRG=0、新Structural Break Sell Intent=0；舊Active Sell尚未清除則Episode=`RESOLUTION_PENDING_RECONCILIATION` | 先Cancel／Resize／Replace／Reconcile；途中Confirmed Fill只更新AP；清理完成前不CLOSED、不自動買回 |
| 6 | Gap = 0 + Right Confirmation | Right分析結果與Mode可保留；Final Deployment Gap=0不改寫Right | `new_buy_quantity=0`、本輪不新增；Permission與Gap仍分離；不得建立WAIT或第二套比例 |
| 7 | Gap < 0 + Runaway Up | Runaway Up／Trend Deployment可維持分析Classification／Mode；負Gap表示Projected Position已高於當下Canonical Target | 正常新增Buy=0；**負Gap本身不自動產生Sell**，不得另造「超配就賣」規則；真正Sell仍需既有Risk Owner |
| 8 | Event Search STALE + Evidence VALID | `search_freshness=STALE`與Evidence／Assertion Validity維持不同Domain；既有Evidence可繼續`VALID` | 禁止`STALE → INVALID`機械推導；只有真正依賴新Search／Coverage的Downstream欄位依工程60～62轉UNKNOWN／PARTIAL／INSUFFICIENT；Required Safety不足時才依既有Data Sufficiency／Permission Contract阻擋新增 |
| 9 | FC改善 + Active Sell | 先Reconcile → Confirmed Fill → latest AP → latest Risk Grade／FC → 重算`RRG=MAX(AP-FC,0)` | 若舊Active Sell會超過最新允許Reduction，Cancel／Modify／Replace；未確認Cancel前仍計Exposure；FC改善不得自動買回 |
| 10 | Structural Break + Runaway Down | `primary_special_classification=真正降低風險`；Structural Break的Risk Grade／FC／RRG／B系列為唯一Sell Owner；Runaway Down僅保留Secondary Context | 不得因Runaway Down另加第二套Sell Rate／Deadline；只有CONFIRMED Emergency可再Preempt |
| 11 | UNKNOWN Valuation + Technical Confirmation | Valuation仍為`UNKNOWN`；Technical Confirmation可獨立為TRUE，不得用技術訊號替估值補值 | 任何**明確依賴估值條件**的Downstream Predicate／Mode／Stage依工程22三值邏輯維持UNKNOWN／不可形成正向Executable Buy；不依賴估值的獨立欄位照其Owner正常裁決 |
| 12 | Price Map Layer 1 + Deployment Stage 6 | **合法跨維度組合**；Price Map＝價格位置，Stage＝授權Target累積部署程度，沒有`Layer 1→Stage 1`固定映射 | 兩者各自保留；實際Buy仍由Target／Gap／Permission／Cash／Caps／Execution共同決定 |
| 13 | Price Map Layer 5 + Deployment Stage 2 | **合法跨維度組合**；深價格層不自動把Deployment Stage推高 | 不得機械升到Stage 5／6／7；Stage只依既有多因子Owner裁決；Price Layer只提供其既有價格／折價證據 |
| 14 | Partial Fill + Replace | Confirmed Fill只更新已成交AP；舊單未成交部分在Cancel確認前仍是Active Exposure；Replace Request本身不是第二筆Live Exposure | Cancel未確認前不得重複釋放Gap或送出重疊新Order；若Broker真的同時回報兩個不同Live Order ID，依真實Lifecycle逐單計Exposure |
| 15 | Emergency + Hard Gate | CONFIRMED Emergency是最高Execution Intent；Hard Gate仍只關閉新增Buy Permission | Emergency必要Sell不得被Hard Gate阻擋；`new_buy_order_permission=FALSE`；不得把Hard Gate誤當Emergency Sell Owner |

### 73-A｜Cross-Section Invariant

1. **Owner不重複**：同一Business Meaning只能由既有Canonical Owner產生；Context不得升格為第二Owner。
2. **Priority不因章節順序改變**：Emergency／真正降低風險／Runaway Down／技術減碼／Runaway Up／Right／Left依既有契約裁決；Gate與Mode保持不同Domain。
3. **Permission／Gap／Sell Intent分離**：Hard Gate不等於Sell；Gap≤0不等於Sell；Sell必須由正式Risk Owner產生。
4. **UNKNOWN不補值**：較高Priority或Required Dependency為UNKNOWN且足以改變結果時，Downstream依工程22傳遞UNKNOWN，不得以較低層TRUE訊號繞過。
5. **Order Exposure先Reconcile**：Partial Fill、Cancel、Replace、Active Order與Emergency／Recovery／FC變動的組合，全部先以Broker Fact／Confirmed Fill重建Exposure，再計下一個Intent。

## 工程74｜Machine-Readable Audit／Determinism Contract

核心問題固定為：**兩個互不溝通的工程師，只讀此最新版Staging V82.md，拿到完全相同Canonical Input，是否能得到完全相同程式結果？** Work8依下列九維度逐項審查，答案均必須為YES；任一項不是YES即不得Work8 PASS。

| Audit Dimension | 唯一依據 | Deterministic Requirement | Work8結果 |
|---|---|---|---|
| Input | 工程22～34、57～67 | 欄位名稱、型別、as-of／source／quality／run identity可辨識；Required缺失不得自動補值 | PASS |
| Enum／State | 工程18～20、39～44、45～62、65 | State／Classification／Mode／Gate／Permission／Event／Episode不得以自由文字另造同義狀態 | PASS |
| Formula | 工程35～38、46～56、63～67、69 | 同一公式只有一個Owner；AP／FC／RRG、Target／Gap／Completion、FX／SGOV不得有反向或第二公式 | PASS |
| Threshold／Parameter | 工程22～35、45～62、68 | Formal Threshold與Candidate／TBD分離；未批准Candidate不得被Runtime採用 | PASS |
| Priority／Preemption | 工程20、39～56、70、73 | 高Priority Risk／Emergency／Hard Gate／Special Classification之Domain與搶占順序唯一 | PASS |
| UNKNOWN Handling | 工程22、29、32～34、39～44、57～62、65～67 | UNKNOWN不等於FALSE／0／Neutral；只沿真正Dependency傳遞，不污染無關欄位 | PASS |
| State Transition | 工程34、36、40～44、45～62、67、73 | Entry／Exit／Pending／Confirmed／Recovery／Closure／Conflict path具有唯一合法轉移與安全Fallback | PASS |
| Output | 工程65～66 | 49欄Canonical Analysis Contract → 13欄Execution View；同Business Meaning不得再造第50欄或第14個正式輸出 | PASS |
| Failure Mode | 工程22、34、36～39、50、57～62、67、73 | 缺資料→UNKNOWN／INCOMPLETE／INSUFFICIENT；非法組合→既有Safe Fallback／Reconciliation；Order衝突→不得Double Count／Overlap | PASS |

### 74-A｜Deterministic Tie-break Rules

同一Snapshot如有多個合法訊號同時存在，固定順序：

1. 先確認Input Identity／`run_id`／PIT／Freshness／Required Data Sufficiency。
2. 再依工程20與各Domain Owner計算Predicate／Risk／Gate，**不得用Output反推Input**。
3. 較高Priority且可裁決者先決定Primary Execution；較高Priority若為UNKNOWN且可能改變結果，依工程22阻止向下偷選。
4. Hard Gate只裁決新Buy Permission；Target／Gap／Mode仍保留可追溯值；Sell只能由既有Sell Owner產生。
5. 所有Order／Fill／Position先Reconcile，再計Target／Gap／RRG／新Intent；舊Active Exposure不因本地Request自動消失。
6. 最後才由工程65／66組成Canonical 49欄與13欄View；正常No-action使用已知`0 / FALSE / N/A`，資料不足才使用UNKNOWN。

> **Machine-Readable Audit結論：PASS。** Work8沒有新增第二套Execution Pipeline；工程73僅將既有Cross-Section組合的唯一結果明文化，工程74只把既有Owner／Priority／UNKNOWN／State Transition／Output關係收斂成Determinism Contract。

## 工程75｜相依正式文件一致性＋Work9／工程77同步清單

本工程只做盤點、Staging同步與77號清單；**不修改Legacy工程紀錄、ABC共享治理檔、正式根目錄SOT或`所有活水AI檔案說明書.md/.pdf`。** Work9必須重新Fresh Read Google Drive最新正式版本，不能把本Checkpoint的Source Snapshot當成當日正式Drive替代品。

### 75-A｜Dependency／Impact Check

- `V82股票操作白皮書.md`：Work8已在Workspace同步工程73～76的人類可讀摘要；與V82保持Companion，不建立第二Rule Owner。
- Legacy `系統工程/工程紀錄.md`：已檢查角色與Deferred治理相容；Work8保持只讀，**不修改**。Work9封案時依最新治理Fresh Read後再處理必要A線正式紀錄。
- `活水AI 系統程式化工程規劃書.md`：現有「V82先封版→Implementation Blueprint→Greenfield Implementation」與施工圖77→78→79+一致；**已檢查，相容，不需修改**。
- `V82.md系統工程化施工圖_v1.4.0.md`：工程73～76／77流程與本Work一致；**byte-identical，不需修改**。
- File Registry／Dependency Map Legacy治理參考：現有A／B／C邊界與本Work相容；Work8不修改。Work9 Formal Commit若造成正式版本／SHA／依賴Metadata改變，只整理成「應登記治理事項」交由`🎯ABC大工程規劃`統一落盤共享治理。
- `檔案管理.md`：Source Snapshot所載治理已明確規定22～76一般V82工程化變更`Deferred to V82系統工程77`；Work8不修改共享治理。Work9開始前仍須Fresh Read最新版本。
- `所有活水AI檔案說明書.md/.pdf`：本Checkpoint未攜入正式本體，且治理明定Work8只盤點；**不重產、不推測版本**。Work9在Formal Commit後一次同步最新MD，再由同版MD重產PDF並做渲染／可讀性QA。

### 75-B｜22～74 Deferred總清單的唯一處理原則

工程22～27已屬歷史正式成果，但其總說明書同步依治理自22號起Deferred；工程28～74則為本9-Work制度下累積Workspace成果。**兩者都必須在Work9／工程77對最新Drive狀態做一次完整Diff／Impact Check後，再決定總說明書與必要A線相依檔的正式同步內容。** 逐工程清單存於本Checkpoint：`Work_Change_Log/Work8_工程75_22-74_Deferred_to_77同步清單_*.md`。

### 75-C｜Work9必做事項

1. Fresh Read最新Google Drive：`檔案管理.md`、正式`V82.md`、正式`V82股票操作白皮書.md`及必要A線相依檔。
2. 比較最新Drive正式SOT／Work1前Source Snapshot／Work8 Workspace Final Working，做Final Conflict Check。
3. 正式Commit前依治理Backup原檔，不得直接覆寫。
4. Commit工程28～76累積Working；工程73～76不得遺漏。
5. Formal Read-back後重跑全域QA、工程73 15組Edge Cases與工程74 Machine-Readable Audit。
6. 依22～74 Deferred清單一次同步`所有活水AI檔案說明書.md`，再由同版MD重產PDF並做完整渲染／可讀性QA。
7. 更新必要A線正式工程紀錄／Checkpoint；共享治理檔若需登記正式版本、SHA、狀態或Dependency Metadata，只提交「應登記治理事項」給`🎯ABC大工程規劃`，A線不得直接寫共享治理。
8. Work9／工程77 CLOSED與28～76 Formal Commit必須為同一完成點；完成前不得宣告V82程式化前正式封版。

## 工程76｜最終全文一致性清掃

Work8最後一次掃描下列類型：`Duplicate Rule / Contradiction / Orphan Rule / Undefined Field / Undefined State / Wrong Cross-reference / Invalid Historical Reference / Numeric Conflict / Formula Conflict / Ambiguous Word / Missing Dependency / Broken Priority / Missing UNKNOWN Handling`。

### 76-A｜本輪實際修正

1. 發現2026-08-30歷史段落仍以未標記的Current-looking句型保留「44項完整分析底稿／10項最終執行摘要」與「最終10項輸出補回掛單方式」。這與工程65／66現行**49欄Canonical底稿＋13欄正式執行輸出**可能造成Parser／RAG歧義。本輪已改成**歷史／已失效／禁止執行**並直接指向現行#47 `order_submission_plan`與13欄View。
2. **FINAL RECHECK修正：** 較早J節的Current Permission摘要仍把「Final Deployment Gap允許」列入`new_buy_order_permission=TRUE`必要條件，與工程39-B「Permission與Gap分離」的Canonical Contract衝突。現已把J節收斂為工程39-B的摘要／引用：Permission唯一由Data Sufficiency、Hard Gate、更高Priority Risk與Required Project／Execution Inputs裁決；`final_deployment_gap_amount > 0`只在形成Executable Buy Order時另外檢查，不再污染Permission本身。

### 76-B｜Final Sweep結論

- Duplicate Rule：沒有發現需要建立第二Owner的重複Current Rule；跨章節重述保留為Reference／Summary時均回指Canonical Owner。
- Contradiction／Numeric／Formula Conflict：FINAL RECHECK另抓到J節Permission／Gap舊摘要與工程39-B衝突，已收斂為工程39-B唯一Owner；九階梯、Target／Gap／Completion、AP／FC／RRG、49／13、FX／SGOV其餘核心公式未發現新的Current衝突。
- Undefined Field／State：Work8未新增Canonical Field／State；工程73只引用既有欄位與狀態。
- Wrong Cross-reference／Invalid Historical Reference：上述44／10歷史殘留已修正；Work7既有失效舊WAIT／Hard Gate／Runaway alias隔離保持有效。
- Missing Dependency／Broken Priority／UNKNOWN：工程73與74已把跨章節Dependency、Priority與UNKNOWN傳遞補成唯一結果，沒有建立新門檻。

> **Work8封口（工程77正式化）：** 工程73～76只做跨章節唯一結果、機器可讀Determinism、相依文件盤點與最後一致性修補；**沒有新增或修改任何投資Threshold、部署比例、Default、Fallback、Hard Gate種類、Candidate Parameter、Risk Clock、Emergency Rate或Search Window。上述成果已由工程77完成Formal Commit並納入本正式SOT。**

