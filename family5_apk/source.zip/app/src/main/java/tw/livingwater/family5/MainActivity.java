package tw.livingwater.family5;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.webkit.WebView;

import com.chaquo.python.AndroidPlatform;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONObject;
import java.io.File;

/** Android 14-item native menu. Python and SQLite run only in the app sandbox. */
public class MainActivity extends Activity {
    private static final long SESSION_MS = 4L * 60 * 60 * 1000;
    private static final String[] ICONS = {"🌱","📋","🧭","🎇","⚖️","💰","🌐","📰","🔎","🌿","📝","📑","📑","🔐"};
    private static final String[] LABELS = {
        "第一次建倉", "查看我的資料與持倉", "檢視與調整目標配置", "尋找新標的物",
        "評估現在各標的物投入速度", "安排新增投資資金", "查看目前總體經濟情況",
        "查看今日重大財經新聞", "查看我的投資標的相關新聞", "更新生活狀況與投資需求",
        "記錄交易與資金變動", "查看上次我的配置報告", "產生我的最新配置報告", "帳號：登出／修改密碼"
    };
    private static final int BG = Color.rgb(248,249,248), DARK = Color.rgb(31,45,40), GREEN = Color.rgb(40,112,78);
    private LinearLayout page;
    private ScrollView scroll;
    private PyObject engine;
    private String dbPath, owner = "第五位家人";
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(234,240,235));
        getWindow().setNavigationBarColor(Color.rgb(235,238,236));
        prefs = getSharedPreferences("family5_local_session", MODE_PRIVATE);
        try {
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            engine = Python.getInstance().getModule("family_offline");
            dbPath = getDatabasePath("livingwater_family5.db").getAbsolutePath();
            JSONObject init = invoke("init", "{}");
            if (!init.optBoolean("ok")) throw new IllegalStateException(init.optString("error"));
            owner = init.optString("owner", "第五位家人");
            if (!init.optBoolean("pin_set")) setupPin();
            else if (prefs.getLong("until", 0) > System.currentTimeMillis()) menu();
            else login();
        } catch (Exception ex) { errorPage("初始化失敗：" + ex.getMessage()); }
    }
    private JSONObject invoke(String operation, String json) {
        try { return new JSONObject(engine.callAttr("api", dbPath, operation, json).toString()); }
        catch (Exception ex) { JSONObject result = new JSONObject(); try {result.put("ok", false); result.put("error", ex.getMessage());} catch(Exception ignored){} return result; }
    }
    private JSONObject perform(String operation, JSONObject input) {
        JSONObject out=invoke(operation,input.toString());
        if (!out.optBoolean("ok")) {
            new AlertDialog.Builder(this).setTitle("資料檢查提醒").setMessage(out.optString("error","操作失敗"))
                .setPositiveButton("確認",null).show();
        } else { showResult(out, operation); }
        return out;
    }
    private void showResult(JSONObject value,String action) {
        if (value.has("html")) showHtml(value.optString("html"),value.optString("text","本機報告"));
        else textPage(LABELS[matchAction(action)], value.optString("text","操作完成"));
    }
    private int matchAction(String action) {
        switch(action) {
            case "first_allocation":return 0; case "read_portfolio":return 1;
            case "adjust_target":case "targets":return 2;
            case "research_candidates":case "candidates":return 3;
            case "deployment_pace":return 4; case "new_funding":return 5;
            case "update_profile":case "profile":return 9;
            case "record_event":case "events":return 10;
            case "previous_report":return 11; case "generate_report":return 12;
            default:return 13;
        }
    }
    private int dp(float n) {return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private void newPage(String heading) {
        scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        page = new LinearLayout(this); page.setPadding(dp(18),dp(22),dp(18),dp(26)); page.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(page); setContentView(scroll);
        TextView head=new TextView(this);head.setText("🏞️  "+heading);head.setTextSize(24);head.setTextColor(DARK);
        head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.setPadding(0,dp(8),0,dp(15));page.addView(head);
    }
    private TextView paragraph(String s) {
        TextView v=new TextView(this);v.setText(s);v.setTextColor(DARK);v.setTextSize(17);
        v.setLineSpacing(dp(4),1.0f); v.setPadding(dp(10),dp(8),dp(10),dp(12));page.addView(v);return v;
    }
    private Button button(String title, Runnable task) {
        Button b=new Button(this);b.setText(title);b.setTextSize(17);b.setTextColor(DARK);
        b.setAllCaps(false);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START); b.setPadding(dp(17),0,dp(10),0);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(237,240,238)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.setMargins(0,dp(4),0,dp(6)); page.addView(b,lp);
        b.setOnClickListener(v->task.run());return b;
    }
    private void menu() {
        if (!validSession()) {login();return;}
        newPage(owner+" 的活水AI");
        paragraph("單機版・單人使用｜Python＋SQLite\n您的專屬本機投資資料選單");
        for(int i=0;i<14;i++) {
            final int selection=i+1;
            button(ICONS[i]+"  "+String.format(java.util.Locale.US,"%02d",selection)+"  "+LABELS[i]+"  ›",()->choose(selection));
        }
        paragraph("本機資料保存在 Android App 私有儲存空間。07～09 開啟外部網站時需網路。\n05 與 13 為本機成本摘要，正式 V82／W5 投資分析尚待接線。");
    }
    private void textPage(String heading,String content) {
        newPage(heading); button("← 返回14項主選單",this::menu);paragraph(content);
    }
    private void showHtml(String html,String heading) {
        newPage(heading);button("← 返回14項主選單",this::menu);
        WebView web=new WebView(this); web.getSettings().setJavaScriptEnabled(false);
        web.loadDataWithBaseURL("about:blank",html,"text/html","UTF-8",null);
        page.addView(web,new LinearLayout.LayoutParams(-1,dp(650)));
    }
    private void errorPage(String s) {newPage("啟動狀態"); paragraph(s);}
    private boolean validSession() {return prefs.getLong("until",0)>System.currentTimeMillis();}
    private void newSession() {prefs.edit().putLong("until",System.currentTimeMillis()+SESSION_MS).apply();}
    private void logout() {prefs.edit().remove("until").apply(); login();}
    private interface FormHandler {void submit(String[] values);}
    private void form(String title,String[] labels,String[] defaults,boolean[] secrets,FormHandler cb) {
        LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);fields.setPadding(dp(18),dp(8),dp(18),0);
        EditText[] edits=new EditText[labels.length];
        for(int i=0;i<labels.length;i++) {
            TextView t=new TextView(this);t.setText(labels[i]);t.setTextSize(15);t.setTextColor(DARK);fields.addView(t);
            EditText e=new EditText(this);e.setText(defaults[i]);e.setTextSize(17); e.setSingleLine(true);
            if(secrets!=null&&secrets[i])e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
            fields.addView(e);edits[i]=e;
        }
        ScrollView wrapped=new ScrollView(this);wrapped.addView(fields);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(wrapped)
            .setNegativeButton("取消",(d,w)->{}).setPositiveButton("儲存",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String[] values=new String[edits.length]; for(int i=0;i<edits.length;i++) values[i]=edits[i].getText().toString().trim();
            cb.submit(values);dialog.dismiss();
        })); dialog.show();
    }
    private JSONObject payload(String... pairs){JSONObject o=new JSONObject();try{for(int i=0;i<pairs.length;i+=2)o.put(pairs[i],pairs[i+1]);}catch(Exception ignored){}return o;}
    private void setupPin() {
        newPage("初次啟用｜設定本機密碼");
        paragraph("只需在這台手機設定一次。登入後有效4小時，資料留在本機。\n第五位家人資料尚未匯入，此版本從空白本機資料庫開始。");
        button("設定密碼並啟用",()->form("初始化帳號",new String[]{"顯示名稱","密碼（4～64字元）"},new String[]{"第五位家人",""},new boolean[]{false,true},v->{
            JSONObject o=invoke("pin_setup",payload("owner",v[0],"pin",v[1]).toString());
            if(o.optBoolean("ok")){owner=v[0].trim().isEmpty()?"第五位家人":v[0].trim();newSession();menu();}
            else new AlertDialog.Builder(this).setMessage(o.optString("error")).setPositiveButton("確認",null).show();
        }));
    }
    private void login() {
        newPage(owner+"｜本機登入");paragraph("請輸入您的活水AI本機密碼。登入有效4小時。");
        button("輸入密碼",()->form("解鎖本機資料",new String[]{"密碼"},new String[]{""},new boolean[]{true},v->{
            JSONObject o=invoke("pin_login",payload("pin",v[0]).toString());
            if(o.optBoolean("ok")){newSession();menu();}
            else new AlertDialog.Builder(this).setMessage("密碼不正確").setPositiveButton("重試",null).show();
        }));
    }
    private void openUrl(String url) {
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch(Exception e){textPage("外部網站", "目前找不到瀏覽器："+url);}
    }
    private void choose(int n) {
        if(!validSession()){login();return;}
        switch(n){
            case 1: form("第一次建倉",new String[]{"ETF／股票代號","股數","每股購入成本","幣別（USD／TWD）"},
                new String[]{"VT","1","100","USD"},null,v->perform("first_allocation",payload("symbol",v[0],"qty",v[1],"price",v[2],"currency",v[3])));break;
            case 2: perform("read_portfolio",new JSONObject());break;
            case 3: newPage("目標配置");button("查看目前目標",()->perform("targets",new JSONObject()));
                button("調整單一標的比例",()->form("調整目標",new String[]{"標的代號","目標比例 %（0表示刪除）"},
                    new String[]{"VT","50"},null,v->perform("adjust_target",payload("symbol",v[0],"pct",v[1]))));
                button("← 主選單",this::menu);break;
            case 4: newPage("候選標的筆記");paragraph("離線版保存您的研究筆記；即時標的資料需要另外接上合法資料來源。");
                button("查看候選",()->perform("candidates",new JSONObject()));
                button("新增／修改候選",()->form("研究候選",new String[]{"標的代號","研究備註"},
                    new String[]{"SOXX",""},null,v->perform("research_candidates",payload("symbol",v[0],"note",v[1]))));
                button("← 主選單",this::menu);break;
            case 5: perform("deployment_pace",new JSONObject());break;
            case 6: form("新增資金",new String[]{"金額","幣別","備註"},new String[]{"10000","TWD",""},null,
                v->perform("new_funding",payload("amount",v[0],"currency",v[1],"note",v[2])));break;
            case 7: openUrl("https://happihelp.com/");break;
            case 8: openUrl("https://news.google.com/search?q="+Uri.encode("財經 金融市場 台灣 美國")+"&hl=zh-TW&gl=TW&ceid=TW:zh-Hant");break;
            case 9: form("搜尋投資標的新聞",new String[]{"請輸入股票／ETF代號"},new String[]{"VT"},null,
                v->openUrl("https://news.google.com/search?q="+Uri.encode(v[0]+" ETF 股票")+"&hl=zh-TW&gl=TW&ceid=TW:zh-Hant"));break;
            case 10: newPage("生活狀況與投資需求");button("查看現有備註",()->perform("profile",new JSONObject()));
                button("更新本機備註",()->form("生活與投資需求",new String[]{"文字記錄（單行，最多3000字）"},
                    new String[]{""},null,v->perform("update_profile",payload("note",v[0]))));
                button("← 主選單",this::menu);break;
            case 11: eventMenu();break;
            case 12: perform("previous_report",new JSONObject());break;
            case 13: perform("generate_report",new JSONObject());break;
            case 14: accountMenu();break;
            default:menu();
        }
    }
    private void eventMenu() {
        newPage("交易與資金變動");
        button("查看最近30筆",()->perform("events",new JSONObject()));
        for(String type: new String[]{"buy","sell","dividend","deposit","withdrawal"}) {
            String label=type.equals("buy")?"買入":type.equals("sell")?"賣出":type.equals("dividend")?"配息":type.equals("deposit")?"入金":"出金";
            button("新增"+label,()->{
                if(type.equals("buy")||type.equals("sell"))form("記錄"+label,new String[]{"標的代號","股數","成交價","幣別","備註"},
                    new String[]{"VT","1","100","USD",""},null,v->perform("record_event",payload("kind",type,"symbol",v[0],"qty",v[1],"price",v[2],"currency",v[3],"note",v[4])));
                else form("記錄"+label,new String[]{"標的（配息時填寫）","金額","幣別","備註"},
                    new String[]{type.equals("dividend")?"VT":"","100","USD",""},null,
                    v->perform("record_event",payload("kind",type,"symbol",v[0],"amount",v[1],"currency",v[2],"note",v[3])));
            });
        }
        button("← 主選單",this::menu);
    }
    private void accountMenu() {
        newPage("本機帳號");paragraph("解鎖有效4小時。忘記密碼需透過事先保存的備份復原；刪除App將失去本機資料。");
        button("變更密碼",()->form("修改本機密碼",new String[]{"舊密碼","新密碼"},new String[]{"",""},new boolean[]{true,true},v->{
            JSONObject o=invoke("pin_change",payload("old",v[0],"new",v[1]).toString());
            if(o.optBoolean("ok")){logout();}else new AlertDialog.Builder(this).setMessage(o.optString("error")).setPositiveButton("確認",null).show();
        }));
        button("登出",this::logout);button("← 主選單",this::menu);
    }
    @Override public void onBackPressed() { if(validSession())menu();else login(); }
}
