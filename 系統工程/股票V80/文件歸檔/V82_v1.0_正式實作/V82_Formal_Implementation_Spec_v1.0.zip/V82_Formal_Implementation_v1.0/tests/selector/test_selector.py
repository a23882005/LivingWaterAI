import unittest
from selector import evaluate,CUTS
class CandidateTests(unittest.TestCase):
 def run_case(self,c,p,v,d=1,metric='TRAILING_PE',mv=10,entry=True,legal=True):return evaluate(c,entry,legal,d,p,v,metric,mv,absolute_range_applicability=(CUTS[c] is not None))
 def test_all_classes_all_left_stages(self):
  for c in CUTS:
   for p,v,stage in [(0,90,2),(75,59,3),(75,39,4),(90,39,5),(90,19,6),(97.5,19,7)]:
    with self.subTest(c=c,stage=stage):self.assertEqual(self.run_case(c,p,v,metric='FORWARD_PE',mv=(CUTS[c][0]-1 if CUTS[c] else 10))['candidate_stage'],stage)
 def test_six_absolute_boundaries(self):
  for c,cut in CUTS.items():
   if cut:
    with self.subTest(c=c):
     self.assertEqual(self.run_case(c,100,0,metric='FORWARD_PE',mv=cut[1])['candidate_stage'],2)
     self.assertEqual(self.run_case(c,100,0,metric='FORWARD_PE',mv=cut[0])['candidate_stage'],5)
     self.assertEqual(self.run_case(c,100,0,metric='FORWARD_PE',mv=cut[0]-1)['candidate_stage'],7)
 def test_base_not_created(self):
  for c in CUTS:self.assertIsNone(self.run_case(c,100,0,entry=False)['candidate_stage'])
 def test_stage2_not_blocked_by_history(self):
  for c in CUTS:self.assertEqual(self.run_case(c,None,None,d=0)['candidate_stage'],2)
 def test_unknown_does_not_choose_lower_bound(self):
  for c in CUTS:self.assertEqual(self.run_case(c,None,None)['status'],'UNKNOWN')
 def test_no_depth_no_left_overweight(self):
  for c in CUTS:self.assertEqual(self.run_case(c,100,0,d=0)['candidate_stage'],2)
 def test_invalid_domains(self):
  for x in [-1,101,float('nan'),float('inf'),True]:self.assertEqual(self.run_case('GLOBAL_EQUITY_ETF',x,0)['status'],'UNKNOWN')
 def test_bad_pe_not_cheap(self):
  for x in [-1,0,None,float('inf')]:self.assertEqual(self.run_case('GLOBAL_EQUITY_ETF',100,0,metric='FORWARD_PE',mv=x)['status'],'UNKNOWN')
 def test_range_unknown_is_not_na(self):
  r=evaluate('GLOBAL_EQUITY_ETF',True,True,1,100,0,'FORWARD_PE',10)
  self.assertEqual(r['status'],'UNKNOWN')
 def test_nonvaluation_ratio_rejected(self):
  with self.assertRaises(ValueError):self.run_case('US_SMALL_MID_CAP_ETF',100,0,metric='PROFITABLE_RATIO')
if __name__=='__main__':unittest.main()
