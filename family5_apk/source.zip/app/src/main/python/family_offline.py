"""LivingWaterAI Android single-device reference core.

This is a genuinely local Python + SQLite runtime. It deliberately does not
represent V82/V75/W5 recommendations: those engines require validated dated
market inputs and approved adapters which are outside this APK starter.
"""
from __future__ import annotations
import hashlib
import html
import json
import secrets
import sqlite3
from contextlib import closing
from datetime import datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

TAIPEI = timezone(timedelta(hours=8))
SCHEMA = 1
FAMILY_SCOPE = "FAMILY5_STANDALONE"
DEFAULT_OWNER = "第五位家人"


def now():
    return datetime.now(TAIPEI).isoformat(timespec="seconds")


def dec(raw, name, allow_zero=False):
    try:
        value = Decimal(str(raw))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(name + " 必須填數字")
    if not value.is_finite() or (value < 0 if allow_zero else value <= 0):
        raise ValueError(name + (" 不得是負數" if allow_zero else " 必須大於零"))
    return value


def num(d):
    return format(d.normalize(), 'f') if d != 0 else '0'


def ident(s, max_len=24):
    s = str(s or "").strip().upper()
    if not s or len(s) > max_len or any(ch not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_' for ch in s):
        raise ValueError("標的代號只能使用英文、數字、. - _")
    return s


def safe(s):
    return html.escape(str(s or ""), quote=True)


def connect(path):
    target = Path(path)
    if not target.is_absolute():
        raise ValueError("DB_ABSOLUTE_PATH_REQUIRED")
    target.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(target), timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA journal_mode=DELETE")
    db.executescript('''
        CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, val TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS positions (
            symbol TEXT PRIMARY KEY, qty TEXT NOT NULL, cost_basis TEXT NOT NULL,
            currency TEXT NOT NULL DEFAULT 'USD');
        CREATE TABLE IF NOT EXISTS targets (
            symbol TEXT PRIMARY KEY, target_pct TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL,
            symbol TEXT NOT NULL DEFAULT '', qty TEXT NOT NULL DEFAULT '0',
            price TEXT NOT NULL DEFAULT '0', amount TEXT NOT NULL DEFAULT '0',
            currency TEXT NOT NULL DEFAULT 'USD', note TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS candidates (
            symbol TEXT PRIMARY KEY, note TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS profile (
            id INTEGER PRIMARY KEY CHECK(id=1), note TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            title TEXT NOT NULL, html TEXT NOT NULL);
    ''')
    if db.execute("SELECT val FROM app_meta WHERE key='schema'").fetchone() is None:
        db.execute("INSERT INTO app_meta VALUES('schema',?)", (str(SCHEMA),))
    scope = db.execute("SELECT val FROM app_meta WHERE key='family_scope'").fetchone()
    if scope is None:
        db.execute("INSERT INTO app_meta VALUES('family_scope',?)", (FAMILY_SCOPE,))
    elif scope['val'] != FAMILY_SCOPE:
        db.close()
        raise ValueError('PERSONAL_DATABASE_SCOPE_MISMATCH')
    db.commit()
    return db


def getmeta(db, name, default=''):
    row = db.execute("SELECT val FROM app_meta WHERE key=?", (name,)).fetchone()
    return row['val'] if row else default


def setmeta(db, name, value):
    db.execute("INSERT INTO app_meta(key,val) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET val=excluded.val", (name, str(value)))


def pin_hash(pin, salt):
    return hashlib.pbkdf2_hmac('sha256', pin.encode('utf-8'), bytes.fromhex(salt), 250_000).hex()


def check_pin(pin):
    if not 4 <= len(pin) <= 64:
        raise ValueError('密碼長度須為4～64字元')


def portfolio(db):
    rows = db.execute('SELECT * FROM positions ORDER BY symbol').fetchall()
    if not rows:
        return '目前尚無本機持倉。請選 01 或 11 新增實際持倉／交易。'
    lines = ['本機持倉（成本口徑，非即時市值）']
    totals = {}
    for r in rows:
        qty, basis = Decimal(r['qty']), Decimal(r['cost_basis'])
        lines.append(f"{r['symbol']}｜{num(qty)} 股｜總成本 {num(basis)} {r['currency']}｜每股均成本 {num(basis / qty) if qty else '0'}")
        totals[r['currency']] = totals.get(r['currency'], Decimal(0)) + basis
    lines.append('各幣別總成本：' + '；'.join(f'{num(v)} {k}' for k, v in sorted(totals.items())))
    lines.append('資料僅儲存在這台裝置，報表不含即時行情。')
    return '\n'.join(lines)


def set_target(db, symbol, pct):
    pct = dec(pct, '目標比例', True)
    if pct > 100:
        raise ValueError('單一目標比例不可超過100%')
    all_targets = {r['symbol']: Decimal(r['target_pct']) for r in db.execute('SELECT * FROM targets')}
    all_targets[symbol] = pct
    if sum(all_targets.values()) > Decimal(100):
        raise ValueError('全部目標比例合計不可超過100%，請先調低其他項目')
    if pct == 0:
        db.execute('DELETE FROM targets WHERE symbol=?', (symbol,))
    else:
        db.execute('INSERT INTO targets VALUES(?,?) ON CONFLICT(symbol) DO UPDATE SET target_pct=excluded.target_pct',
                   (symbol, num(pct)))
    return target_text(db)


def target_text(db):
    all_targets = db.execute('SELECT * FROM targets ORDER BY symbol').fetchall()
    total = sum((Decimal(r['target_pct']) for r in all_targets), Decimal(0))
    result = ['本機目標配置：'] + [f"{r['symbol']}：{r['target_pct']}%" for r in all_targets]
    result.append(f'目標合計：{num(total)}%；尚未指定：{num(Decimal(100)-total)}%')
    return '\n'.join(result)


def register_event(db, kind, symbol='', qty='0', price='0', amount='0', currency='USD', note=''):
    kind = str(kind).strip().lower()
    if kind not in ('buy', 'sell', 'dividend', 'deposit', 'withdrawal'):
        raise ValueError('事件類型只接受 buy/sell/dividend/deposit/withdrawal')
    currency = str(currency or 'USD').strip().upper()
    if currency not in ('TWD', 'USD', 'EUR', 'GBP', 'JPY'):
        raise ValueError('請選擇受支援的幣別：TWD/USD/EUR/GBP/JPY')
    if kind in ('buy', 'sell', 'dividend'):
        symbol = ident(symbol)
    else:
        symbol = ''
    if kind in ('buy', 'sell'):
        q, p = dec(qty, '股數'), dec(price, '成交單價')
        amt = q * p
        row = db.execute('SELECT qty,cost_basis,currency FROM positions WHERE symbol=?', (symbol,)).fetchone()
        if kind == 'buy':
            if row and row['currency'] != currency:
                raise ValueError('同一標的不能混用幣別')
            nq = Decimal(row['qty']) + q if row else q
            nc = Decimal(row['cost_basis']) + amt if row else amt
            db.execute('INSERT INTO positions VALUES(?,?,?,?) ON CONFLICT(symbol) DO UPDATE SET qty=excluded.qty,cost_basis=excluded.cost_basis',
                       (symbol, num(nq), num(nc), currency))
        else:
            if row is None or row['currency'] != currency or Decimal(row['qty']) < q:
                raise ValueError('本機股數不足，或幣別不同，請核對交易資料')
            oldq, oldcost = Decimal(row['qty']), Decimal(row['cost_basis'])
            leftq = oldq - q
            if leftq == 0:
                db.execute('DELETE FROM positions WHERE symbol=?', (symbol,))
            else:
                db.execute('UPDATE positions SET qty=?,cost_basis=? WHERE symbol=?',
                           (num(leftq), num(oldcost * leftq / oldq), symbol))
    else:
        q, p, amt = Decimal(0), Decimal(0), dec(amount, '金額')
    if len(str(note)) > 500:
        raise ValueError('備註長度最多500字')
    db.execute('INSERT INTO events(at,kind,symbol,qty,price,amount,currency,note) VALUES(?,?,?,?,?,?,?,?)',
               (now(), kind, symbol, num(q), num(p), num(amt), currency, str(note)))
    return f'已記錄 {kind}：{symbol}，金額 {num(amt)} {currency}。' + ('\n\n' + portfolio(db) if kind in ('buy','sell') else '')


def exposure(db):
    """Informative *cost-basis* drift only; never call it a current valuation."""
    positions = db.execute('SELECT * FROM positions ORDER BY symbol').fetchall()
    if not positions:
        return '本機尚無持倉，請先建立持倉。'
    currencies = {r['currency'] for r in positions}
    if len(currencies) > 1:
        return '目前有多種幣別；本機尚未提供可靠即時匯率，請先提供換匯資料，再做跨幣別比例比較。\n正式 W5／V82 投入速度判斷尚待接線。'
    total = sum((Decimal(r['cost_basis']) for r in positions), Decimal(0))
    targets = {r['symbol']:Decimal(r['target_pct']) for r in db.execute('SELECT * FROM targets')}
    lines = ['參考投入分布（依歷史投入成本，並非現價市值）']
    for row in positions:
        pct = Decimal(row['cost_basis']) / total * 100 if total else Decimal(0)
        goal = targets.get(row['symbol'])
        lines.append(f"{row['symbol']}：投入成本比 {pct:.2f}%｜目標 {str(goal)+'%' if goal is not None else '未設定'}" +
                     (f"｜差距 {pct-goal:+.2f} 個百分點" if goal is not None else ''))
    lines.append('正式買入速度須另接通 W5＋V82＋最新總經／行情，這裡不產生交易建議。')
    return '\n'.join(lines)


def build_html(db, title):
    ts = now()
    holdings = list(db.execute('SELECT * FROM positions ORDER BY symbol'))
    goals = list(db.execute('SELECT * FROM targets ORDER BY symbol'))
    profile = db.execute('SELECT note FROM profile WHERE id=1').fetchone()
    def table(headers, values):
        return ('<table><tr>' + ''.join('<th>'+safe(h)+'</th>' for h in headers)+'</tr>'+
                ''.join('<tr>'+''.join('<td>'+safe(c)+'</td>' for c in row)+'</tr>' for row in values)+'</table>')
    html_out = ('<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<style>body{font-family:sans-serif;color:#223;line-height:1.6;padding:22px;max-width:850px;margin:auto}h1{color:#235c48;font-size:24px}h2{font-size:20px;margin-top:26px}table{border-collapse:collapse;width:100%;font-size:15px}td,th{border:1px solid #aaa;padding:9px}th{background:#eaf2ee}.note{padding:12px;background:#fff4dc}</style>'
                f'<title>{safe(title)}</title><h1>{safe(title)}</h1><p>建立日期：{safe(ts)}</p><p class="note">本機離線資料摘要。持倉以歷史成本呈現，不含即時市值、V82、V75或正式買賣建議。</p>'
                '<h2>實際持倉（成本）</h2>'+
                table(['標的','股數','總成本','幣別'],[(r['symbol'],r['qty'],r['cost_basis'],r['currency']) for r in holdings])+
                '<h2>目標配置</h2>'+table(['標的','目標比例'],[(r['symbol'],r['target_pct']+'%') for r in goals])+
                '<h2>個人需求備註</h2><p>'+safe(profile['note'] if profile else '未填寫')+'</p></html>')
    return html_out


def run(db, action, payload):
    if action == 'init':
        return {'pin_set':bool(getmeta(db,'pin_hash')), 'schema':SCHEMA,
                'owner':getmeta(db,'owner',DEFAULT_OWNER)}
    if action == 'pin_setup':
        if getmeta(db, 'pin_hash'):
            raise ValueError('已設定密碼，請使用修改密碼功能')
        pin = str(payload.get('pin',''))
        check_pin(pin)
        salt = secrets.token_hex(16)
        setmeta(db,'pin_salt',salt)
        setmeta(db,'pin_hash',pin_hash(pin,salt))
        setmeta(db,'owner',str(payload.get('owner',DEFAULT_OWNER)).strip()[:60] or DEFAULT_OWNER)
        return {'text':'本機登入密碼設定完成。'}
    if action == 'pin_login':
        pin = str(payload.get('pin',''))
        stored = getmeta(db,'pin_hash')
        if not stored or not secrets.compare_digest(pin_hash(pin,getmeta(db,'pin_salt')),stored):
            raise ValueError('密碼不正確')
        return {'text':'登入成功'}
    if action == 'pin_change':
        old = str(payload.get('old',''))
        new = str(payload.get('new',''))
        if not secrets.compare_digest(pin_hash(old,getmeta(db,'pin_salt')),getmeta(db,'pin_hash')):
            raise ValueError('原密碼不正確')
        check_pin(new)
        salt = secrets.token_hex(16)
        setmeta(db,'pin_salt',salt)
        setmeta(db,'pin_hash',pin_hash(new,salt))
        return {'text':'密碼更新完成'}
    if not getmeta(db,'pin_hash'):
        raise ValueError('請先設定本機密碼')
    if action == 'read_portfolio':
        return {'text':portfolio(db)}
    if action == 'first_allocation':
        return {'text':register_event(db,'buy',payload.get('symbol'),payload.get('qty'),payload.get('price'),currency=payload.get('currency','USD'),note='第一次建倉')}
    if action == 'adjust_target':
        return {'text':set_target(db, ident(payload.get('symbol')),payload.get('pct'))}
    if action == 'targets':
        return {'text':target_text(db)}
    if action == 'research_candidates':
        symbol=ident(payload.get('symbol'))
        note=str(payload.get('note','')).strip()
        if not note or len(note)>500:
            raise ValueError('研究備註須填寫且最多500字')
        db.execute('INSERT INTO candidates VALUES(?,?,?) ON CONFLICT(symbol) DO UPDATE SET note=excluded.note,updated_at=excluded.updated_at',
                   (symbol,note,now()))
        return {'text':'已儲存本機研究候選：'+symbol+'（不含市場資料研究）'}
    if action == 'candidates':
        rows=db.execute('SELECT * FROM candidates ORDER BY updated_at DESC').fetchall()
        return {'text':'\n'.join(f"{r['symbol']}：{r['note']}" for r in rows) if rows else '尚無候選記錄'}
    if action == 'deployment_pace':
        return {'text':exposure(db)}
    if action == 'new_funding':
        return {'text':register_event(db,'deposit',amount=payload.get('amount'),currency=payload.get('currency','TWD'),note=str(payload.get('note','')))}
    if action == 'update_profile':
        note = str(payload.get('note','')).strip()
        if len(note)>3000:
            raise ValueError('文字最多3000字')
        db.execute('INSERT INTO profile VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET note=excluded.note,updated_at=excluded.updated_at',
                   (note,now()))
        return {'text':'生活狀況及投資需求已存至本機資料庫。'}
    if action == 'profile':
        row=db.execute('SELECT note FROM profile WHERE id=1').fetchone()
        return {'text':row['note'] if row else '目前尚無生活狀況備註'}
    if action == 'record_event':
        return {'text':register_event(db,**{k:payload.get(k,default) for k,default in
            [('kind','buy'),('symbol',''),('qty','0'),('price','0'),('amount','0'),('currency','USD'),('note','')]})}
    if action == 'events':
        rows=db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 30').fetchall()
        return {'text':'\n'.join(f"{r['at']}: {r['kind']} {r['symbol']} {r['qty']} × {r['price']}；金額 {r['amount']} {r['currency']} {r['note']}" for r in rows) or '尚無紀錄'}
    if action == 'previous_report':
        row=db.execute('SELECT created_at,title,html FROM reports ORDER BY id DESC LIMIT 1').fetchone()
        return {'html':row['html'], 'text':row['title']+'｜'+row['created_at']} if row else {'text':'尚無本機報告，請先使用13產生。'}
    if action == 'generate_report':
        title = getmeta(db,'owner',DEFAULT_OWNER) + ' 的活水AI本機資料報告'
        value = build_html(db,title)
        db.execute('INSERT INTO reports(created_at,title,html) VALUES(?,?,?)',(now(),title,value))
        return {'html':value,'text':'已保存新的本機資料報告（不含正式投資規則建議）。'}
    raise ValueError('UNKNOWN_ACTION:'+action)


def api(db_path, action, payload_json='{}'):
    """Single JSON string API for Chaquopy Java bridge."""
    try:
        data=json.loads(payload_json)
        if not isinstance(data,dict):
            raise ValueError('payload 必須是物件')
        with closing(connect(db_path)) as db:
            with db:
                result=run(db,str(action),data)
        return json.dumps({'ok':True,**result},ensure_ascii=False)
    except (ValueError, sqlite3.Error, OSError) as exc:
        return json.dumps({'ok':False,'error':str(exc)},ensure_ascii=False)
