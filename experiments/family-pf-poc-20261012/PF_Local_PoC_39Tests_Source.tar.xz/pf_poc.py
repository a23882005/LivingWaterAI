"""Family PF security feasibility prototype: synthetic-only, local-only.
This is NOT an MCP server and does NOT assert ChatGPT Project can supply a trusted ID.
The test issuer simulates a separate trusted OAuth/identity provider; it is not
acceptable as a real production issuer. No real customer records.
"""
from __future__ import annotations
import os, sqlite3, json, base64, hashlib, hmac, secrets, time
from contextlib import contextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

class Store:
    def __init__(self, path: str, signing_key: bytes):
        if len(signing_key)<32: raise ValueError('signing_key requires at least 32 bytes')
        self.path=path;self.key=signing_key
        self.initialize()
    @contextmanager
    def db(self, write=False):
        con=sqlite3.connect(self.path, timeout=5, isolation_level=None)
        con.row_factory=sqlite3.Row
        try:
            con.execute('PRAGMA foreign_keys=ON'); con.execute('PRAGMA busy_timeout=5000')
            if write: con.execute('BEGIN IMMEDIATE')
            yield con
            if write: con.execute('COMMIT')
        except BaseException:
            if write and con.in_transaction: con.execute('ROLLBACK')
            raise
        finally: con.close()
    def initialize(self):
        with self.db(True) as db:
            db.execute('CREATE TABLE IF NOT EXISTS bindings (project TEXT PRIMARY KEY, client TEXT NOT NULL UNIQUE)')
            db.execute('CREATE TABLE IF NOT EXISTS profile (client TEXT PRIMARY KEY, amount INTEGER NOT NULL CHECK (amount>=0), version INTEGER NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS proposal (token_hash TEXT PRIMARY KEY, client TEXT NOT NULL, actor TEXT NOT NULL, before_amount INTEGER NOT NULL, after_amount INTEGER NOT NULL, expected_version INTEGER NOT NULL, expires INTEGER NOT NULL, status TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT NOT NULL, actor TEXT NOT NULL, before_amount INTEGER NOT NULL, after_amount INTEGER NOT NULL, version INTEGER NOT NULL, event_type TEXT NOT NULL, created INTEGER NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS revoked (jti TEXT PRIMARY KEY)')
            # Fixtures are deliberately synthetic; no Joseph/mou/etc.
            for p,c in [('PF_TEST_PROJECT_A','PF_TEST_CLIENT_A'),('PF_TEST_PROJECT_B','PF_TEST_CLIENT_B')]:
                db.execute('INSERT OR IGNORE INTO bindings(project,client) VALUES (?,?)',(p,c))
                db.execute('INSERT OR IGNORE INTO profile(client,amount,version) VALUES (?,?,?)',(c,1000,1))
    def issue_for_test(self, *, project, client, actor='TEST_ACCOUNT', ttl=600, jti=None):
        """Only used in pytest fixtures; backend-owned, not an HTTP route."""
        payload={'iss':'PF_TEST_IDP','aud':'PF_LOCAL_POC','project':project,'client':client,'sub':actor,'exp':int(time.time())+ttl,'jti':jti or secrets.token_hex(12)}
        b=base64.urlsafe_b64encode(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).rstrip(b'=')
        signature=hmac.new(self.key,b,hashlib.sha256).hexdigest().encode()
        return b.decode()+'.'+signature.decode()
    def identity(self, token):
        try:
            b,s=token.split('.')
            expected=hmac.new(self.key,b.encode(),hashlib.sha256).hexdigest()
            if not hmac.compare_digest(s,expected): raise ValueError()
            p=json.loads(base64.urlsafe_b64decode(b+'='*((-len(b))%4)))
            if p.get('iss')!='PF_TEST_IDP' or p.get('aud')!='PF_LOCAL_POC' or p['exp']<=int(time.time()): raise ValueError()
            if not all(isinstance(p.get(k),str) and p[k] for k in ('project','client','sub','jti')): raise ValueError()
        except (ValueError, KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError):
            raise HTTPException(401,'invalid_identity')
        with self.db() as db:
            match=db.execute('SELECT client FROM bindings WHERE project=?',(p['project'],)).fetchone()
            if not match or match['client']!=p['client'] or db.execute('SELECT 1 FROM revoked WHERE jti=?',(p['jti'],)).fetchone():
                raise HTTPException(403,'project_client_denied')
        return p

class ProposalInput(BaseModel):
    requested_client_id: str
    after_amount: int = Field(ge=0,le=10**12)
    expected_version: int = Field(ge=1)

class ConfirmInput(BaseModel):
    requested_client_id: str
    confirmation_token: str

class CancelInput(BaseModel):
    requested_client_id: str
    confirmation_token: str

def make_app(store: Store) -> FastAPI:
    app=FastAPI(title='Family PF local synthetic PoC', docs_url=None,redoc_url=None,openapi_url=None)
    def auth(authorization):
        if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'missing_auth')
        return store.identity(authorization[7:])
    def check(p,requested):
        if requested!=p['client']: raise HTTPException(403,'client_mismatch')
    @app.get('/health')
    def health(): return {'status':'up','scope':'SYNTHETIC_LOCAL_ONLY'}
    @app.get('/v1/profile')
    def read(requested_client_id:str, authorization:str|None=Header(None), x_project_id:str|None=Header(None)):
        p=auth(authorization);check(p,requested_client_id)
        if x_project_id and x_project_id!=p['project']:raise HTTPException(403,'header_project_mismatch')
        with store.db() as db:
            row=db.execute('SELECT amount,version FROM profile WHERE client=?',(p['client'],)).fetchone()
        if row is None: raise HTTPException(404,'not_found')
        return {'client_id':p['client'],'amount':row['amount'],'version':row['version']}
    @app.post('/v1/propose')
    def propose(req:ProposalInput, authorization:str|None=Header(None)):
        p=auth(authorization);check(p,req.requested_client_id)
        token=secrets.token_urlsafe(32); token_hash=hashlib.sha256(token.encode()).hexdigest()
        with store.db(True) as db:
            row=db.execute('SELECT amount,version FROM profile WHERE client=?',(p['client'],)).fetchone()
            if row['version'] != req.expected_version:raise HTTPException(409,'stale_version')
            db.execute('INSERT INTO proposal VALUES (?,?,?,?,?,?,?,?)', (token_hash,p['client'],p['sub'],row['amount'],req.after_amount,row['version'],int(time.time())+90,'pending'))
        return {'before':row['amount'],'after':req.after_amount,'impact':req.after_amount-row['amount'],'expected_version':row['version'],'confirmation_token':token,'expires_seconds':90}
    @app.post('/v1/confirm')
    def confirm(req:ConfirmInput, authorization:str|None=Header(None)):
        p=auth(authorization);check(p,req.requested_client_id)
        h=hashlib.sha256(req.confirmation_token.encode()).hexdigest()
        with store.db(True) as db:
            q=db.execute('SELECT * FROM proposal WHERE token_hash=?',(h,)).fetchone()
            if not q or q['client']!=p['client'] or q['actor']!=p['sub'] or q['status']!='pending' or q['expires']<int(time.time()):raise HTTPException(409,'confirmation_unavailable')
            current=db.execute('SELECT amount,version FROM profile WHERE client=?',(p['client'],)).fetchone()
            if current['version'] != q['expected_version'] or current['amount']!=q['before_amount']:raise HTTPException(409,'stale_version')
            new_version=current['version']+1
            db.execute('UPDATE profile SET amount=?,version=? WHERE client=?',(q['after_amount'],new_version,p['client']))
            db.execute("UPDATE proposal SET status='committed' WHERE token_hash=?",(h,))
            db.execute('INSERT INTO events(client,actor,before_amount,after_amount,version,event_type,created) VALUES (?,?,?,?,?,?,?)', (p['client'],p['sub'],q['before_amount'],q['after_amount'],new_version,'confirmed_change',int(time.time())))
        return {'client_id':p['client'],'amount':q['after_amount'],'version':new_version,'committed':True}
    @app.post('/v1/cancel')
    def cancel(req:CancelInput, authorization:str|None=Header(None)):
        p=auth(authorization);check(p,req.requested_client_id)
        h=hashlib.sha256(req.confirmation_token.encode()).hexdigest()
        with store.db(True) as db:
            res=db.execute("UPDATE proposal SET status='cancelled' WHERE token_hash=? AND client=? AND actor=? AND status='pending'",(h,p['client'],p['sub']))
            if res.rowcount!=1: raise HTTPException(409,'confirmation_unavailable')
        return {'cancelled':True}
    return app
