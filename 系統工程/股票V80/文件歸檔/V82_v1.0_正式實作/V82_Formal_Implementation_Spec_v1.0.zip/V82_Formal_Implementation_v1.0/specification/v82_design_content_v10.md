# V82 三層量化規則正式實作規格

Eric 指揮官核准　正式實作版本 1.0　核准時間 2026年10月28日 04:27 台灣時間

本版把「共用決策引擎、十一類估值模板、每個標的自身事實」接成正式工程實作規格。內容包括十一類的價格估值階梯、技術訊號公式與事件壽命、宏觀信用和基本面風險、四模式與九階、正常買入切片、資金限制、資料時間與驗收案例。數字與語意按本版鎖定，不能交由 AI 臨場挑買點或調參。

**核准與效力：使用者已明確批准 v0.4 全部新增規則，並要求改為正式實作規格。本版 1.0 的狀態為 APPROVED_FOR_IMPLEMENTATION。** 本文新增公式、參數、方法、窗口、事件狀態機、路由與 Stage／速度映射均已獲採用，可由 Codex 直接實作、測試及整合至正式 V82 對應 Owner；這些規則不需要再次逐項請准。本文補充第9章固定版本 S1，並取代 v0.4 對同一批新增規則的審閱及研究限定狀態；既有正式規則維持效力，只有本文明列的補充或覆蓋項依本版執行。

**已核准的補充與明示整合差異：** PV2至PV4A 的十一類價格估值、品質門檻與有限路由；第3章 W 及其同資產個股適用性；第4章全部 P 算法、種子、容差、事件與 applicability；第5章宏觀信用操作化、ETF viable、新聞 7／365 天攝取窗口、Trend Stage、正常 Buy slice、追價條件及跨資產分配，全部採本版原有數學定義。PV4 6 明示以比例節點作成分證據、不作 qV Primary；CMR 5.3 以核准窗口補足 S1 的兩項 TBD；CMR 9.1 將核准日切片作具名 slice cap 納入既有 MIN，保留 37-F 公式。本文未採用的舊 Work7／B 系列參數與不支援產品仍不在本次採用範圍。

**工程指令：** 不得因 v0.4 舊標籤、P 來源標記或尚無績效實證，繼續把已核准公式視為無定義。例如正式 `ma20_ok` 在真實輸入合法且實作驗證後，必須依 `C_t≥0.99MA20_t`（MA20>0）計算；不得只因舊 Candidate 身分保持 UNKNOWN。真正缺資料、來源衝突、不支援方法或尚未完成實作驗證，仍須如實記錄並按相依性處理。

**證據與交易邊界：** 規則批准不等於程式已部署、真實 PIT 重播已完成或投資效力已驗證。第8章既有測試證據維持原範圍，未執行者仍為 NOT_RUN。本次文件採用不解除任何現存生產操作限制，不授權自動對券商送單、買賣、撤單或換匯。

### 閱讀順序

決策審閱先讀第1章與第2章的階梯，再讀第5章的模式、速度與資金效果。工程實作依第2至5章建立具名輸入、公式及依賴圖，再以第6至7章驗收。第8章說明既有資料及原型證據的真實範圍；來源集中於第9章。

| 章節 | 內容 | 主要使用者 |
|---|---|---|
| 1 | 架構、權威、三值與執行邊界 | 決策與工程共同 |
| 2 | 十一類路由、估值與Stage 2至7完整規則 | 估值與Stage實作 |
| 3 | 同資產總報酬及公司行動方法 | 價格資料實作 |
| 4 | 技術primitive、32槽位與完整事件定義 | 技術訊號實作 |
| 5 | Macro、風險、模式、Stage、速度與金額 | 決策與執行實作 |
| 6 | 研究評估、版本發布與證據分層 | 研究與治理 |
| 7 | 全域驗收案例及跨類追溯 | 測試與獨立驗收 |
| 8 | 已取得資料與已執行測試的範圍 | 證據核對 |
| 9 | 正式規則與外部方法來源 | 來源核查 |

本文PV、TECH、CMR、VAL、QA為本文件章內定位前綴；不新增正式Canonical欄位或業務Enum。公式、case ID與profile ID依所屬命名空間辨識。


<!-- PAGEBREAK -->

## 1 架構與不可越過的邊界

### 1.1 三層的權責

| 層 | 負責內容 | 不能做 |
|---|---|---|
| 第一層 共用引擎 | 三值、風險優先、模式、Stage、目標、速度與資金上限 | 不能用便宜抵銷風險，不能以Gap反推Stage |
| 第二層 類別模板 | 唯一主估值類別、合法Waterfall、subtype與核准規則 | 不能只以類別名稱硬套同一PE或假稱全類已校準 |
| 第三層 標的事實 | 自身價格、估值史、成分、財務、公司行動及事件 | 不能借別檔補洞或為單一標的在線最佳化 |

每個資產只有一個Primary Valuation Class；Asset Type、Asset Grade、Portfolio Role、Company Risk Grade各自保存，不互相推導。專屬正式規則優先，零個或多個合法匹配必須按本包路由契約處理，不能first-match。

### 1.2 固定核心與核准補充

正式九階累積比例為10、20、30、45、60、75、85、95、100%，分母是Project Target Position。Base對應Stage1，Left為Stage2至7，Right參考Stage8，Trend最高Stage9。Stage不是本輪新增比例；Stage下降本身不自動賣出。

FORMAL或F表示第9章S1等既有正式來源；P表示本版新增且已核准採用的定義，authority＝APPROVED_SUPPLEMENT，approval_status＝APPROVED_FOR_IMPLEMENTATION。F與P區分來源，不區分能否實作。M只表示歷史producer證據，不代替資料來源驗證。INPUT_REQUIRED表示必須由合法事實或事前投資契約提供的輸入，不能由AI虛構。實作、測試、資料與實證狀態分開記錄，不再將本版新規則列為待批准。

僅對本文明確採用的同一批規則，舊程式或歷史檔案中的 research、candidate 名稱只保留作相容識別及版本追溯，不能作執行禁令；本文未採用的舊Work7／B系列維持原狀。正式業務 Enum `EXTREME_CANDIDATE` 完全不變。採用本版時，manifest 必須記 spec_version＝1.0、上述核准時間與本文件 hash；歷史方法 ID 不等於現行核准狀態。

完整規格必須有可達的正向路徑及全部邊界；單純寫「未知就不買」不能代替缺失的策略設計。個別公司Thesis、客戶Project Target、券商現金和法定事件是具型別的必要輸入，不是可任意補的全市場常數；缺這些真實輸入時，依本包確定的三值與拒絕行為處理。

### 1.3 三值與局部未知

沿正式強Kleene三值：FALSE AND UNKNOWN為FALSE；TRUE AND UNKNOWN為UNKNOWN；TRUE OR UNKNOWN為TRUE；FALSE OR UNKNOWN為UNKNOWN；NOT UNKNOWN仍UNKNOWN。去重後T為TRUE槽位數、U為UNKNOWN槽位數，N-of-K在T≥K時TRUE、T+U<K時FALSE，否則UNKNOWN。

只有未知仍能改變該輸出，該輸出才UNKNOWN；保留被短路的未知理由。適用性UNKNOWN不是N/A，OPTIONAL缺失不是一律通過或全局阻斷。空條件集不得利用all([])通過投資判斷；只有已明定不適用且容許中性的子句才省略。

### 1.4 單向資料流程

1 鎖定同輪asset、snapshot、決策cutoff、資料版本與規則版本；只取當時已可靠可得的資料。
2 驗證資產身份、唯一類別、subtype、單位、來源方法、freshness、PIT與合法適用性。
3 分別計算原生技術事實、價格估值特徵、基本面及風險證據；依具名Registry去重。
4 裁定安全與風險、各市場Predicate、正常Mode及合法Stage，再計Target和Final Gap。
5 分開計Permission、正常速度、正常slice、Cash、Caps與合法數量；不能把上限誤稱今天應全買。
6 保存分析、阻擋原因、版本與證據；診斷sidecar不增加Canonical欄位。驗證後的規則結果交對應正式Owner消費，不對券商自動送單。

依賴圖不得有Stage→Target→Gap→Stage或Permission→Safety循環，不以昨日值、猜Stage9或迭代至穩定補解。V70管總額度天花板，V82消費而不重算S0／B0；預算空間不等於可交易現金。

Hard Gate對Left與Right不是同一效果：Left安全否決使當輪Left Predicate為FALSE，仍留價格估值context；當輪Right自身依賴仍合法時，可依正式例外保留分析並關閉新Buy Permission。不能一律清零，也不能沿用昨日Left冒充當輪結論。

正式仍49欄Canonical及13欄Execution View。規則profile、診斷界與測試狀態只進sidecar或Owner已允許的nested evidence，不造第50欄或第14欄。


<!-- PAGEBREAK -->

## 2 十一類估值與價格階梯

### PV1 核准架構與版本邊界


來源優先序：S1既有正式規則及合法專屬規則保留原效力；本版已核准補充規則在其明列適用域生效。本文明列的新增定義或覆蓋差異按1.0執行；其他衝突仍須具名記錄，不以較有利結果任意替代。

第一層共用程序：資產身份 → 唯一路由 → PIT資料驗證 → 價格與估值特徵 → 各階三值條件 → 唯一選階結果與證據。第二層保存各類正式Waterfall、合法Forward PE區間及所需證據。第三層使用每個資產自己的價格、公司行動、成分、估值史、財務與事件，不借別檔價格或把指數偽裝ETF。

本版採用「跨類共同切點」：沿用原全球ETF版本的數字以減少自由參數，但不沿用其實證適用性結論。十一類本版規則的採用狀態均為APPROVED_FOR_IMPLEMENTATION；各類未完成校準或樣本外驗證的事實另記EMPIRICAL_VALIDATION_NOT_COMPLETED，不能把未驗證誤寫成未批准。

同一qP門檻不等於同一原始跌幅：每檔以自己的總報酬、高點、峰值波動及歷史壓力排序；同一qV門檻不等於同一PE：每檔依自己合法指標的可比歷史排序。這只使尺度可比，不證明不同類別具有相同風險、報酬或足夠獨立樣本。

### PV2 全部類別共用的確定性輸入與計算

#### PV2 1 身份與時間
每筆資料必有 asset_id、share_class/listing（適用時）、field_id、value、unit、provider、method_id/version、as_of、available_at、retrieved_at、revision_id、source_hash、freshness及PIT狀態。每輪鎖定run_id、snapshot_id、t_decision、rule_version_set及profile_version。只選available_at不晚於決策時點的合法版本；retrieved_at不能替代available_at；修訂另存，不改寫已出具的決策。

身份、分類或profile有零個／多個合法匹配，返回ROUTE_UNRESOLVED及匹配清單，不以first-match決定。數值計算使用來源精度與Decimal；顯示四捨五入不參與比較。

#### PV2 2 選定主估值
依各類正式順序檢查：經濟適用性、來源與聚合可靠性、值／單位／方法、日期、freshness、PIT。只跳過已證實不可用或不可靠的方法並記理由；適用性UNKNOWN不是N/A。若前順位是否可用仍足以改變主解，主解UNKNOWN，不把疑問當成合法Fallback。

倍數的分母須具經濟意義；非正或無意義PE不分類Cheap。ETF的PE不是成分PE算術平均；EV/EBITDA、EV/Sales、FCF Yield須來源提供可靠一致聚合，不能以最大持股代替整檔。FCF Yield為負可保存，但是否有經濟意義須依正式方法判定，不能截零。PEG只能補充，不能作本版qV主指標。

當主指標合法但歷史不足，保留主指標及已知絕對分類，qV返回UNKNOWN；不能為算出分位換主指標。合法Fallback必須同時切換至新指標自己的歷史與合法range，不能跨metric接續歷史。

#### PV2 3 估值分位qV
原生daily/weekly/monthly估值每完成曆月取該期當時已發布且freshness合法的最後snapshot；quarterly每完成曆季取一筆。其他頻率返回UNSUPPORTED_CADENCE。不跨期複製舊值，不以重抓或修訂增加樣本數。生產來源的時區／期末calendar尚未核定時返回CALENDAR_UNRESOLVED，不能把研究UTC排程當生產排程。

歷史窗依可靠10年 → 可靠5年 → 上市以來／事前批准可比較制度期間。本版已核准的共用預設為：有效期數／應有期數至少90%，連續缺期不超過2期，可比span至少2年；這些為本版適用域內的正式品質門檻，不代表已完成實證驗證。current不進reference；全同值、零有效樣本、口徑混用或PIT不可證時，qV為UNKNOWN。

<equation id="RANK">raw percentile</equation>
合法Multiple：qV = raw_rank(current)。合法Yield：qV = 100 − raw_rank(current)。
qV越低越便宜。純成分比例、成長率、風險分數、PEG及新聞狀態不得送進這個估值分位器。

#### PV2 4 價格壓力qP
wealth沿第3章的同資產、同listing、同幣別PIT方法：
<equation id="WEALTH">wealth</equation>
C為原始未調整市場完成收盤；k為新股／舊股；d_old為每舊股gross現金。除息日收盤統計再投資、不重複在付款日加息；第一個合法close seed為100且首日報酬不存在。僅支援已核實純拆併股及單純固定非選擇性現金分派；複雜權利、跨幣別或無事件coverage證據返回UNSUPPORTED_EVENT或EVENT_COVERAGE_UNKNOWN，不只計算容易部分。此方法延伸至個股亦已隨本版核准，適用限制見第3章。

缺預期bar、必要calendar或事件證據即斷鏈；不forward-fill、不跨段連接高點／波動。已調整close禁止再次加息或拆股；若另採adjusted方法，須獨立方法版本及驗證。

H_t為含最新完成日t的最近252個本交易所session最高W；同高取最後日h。σ_h為截至h的63個一日log return之sample標準差，ddof=1，並凍結為高點當時可取得的版本。
<equation id="DD">drawdown</equation>
<equation id="Z">stress</equation>
每完成月末的Z_j均用該月末當時的高點及峰值波動獨立生成。qP = raw_rank(Z_t)，reference不含current；歷史窗及資料可靠度沿上述規則，價格reference為monthly。

W非正／非有限、必要bar或公司行動不一致、σ非正、PIT不合法、reference不足或全同值時qP為UNKNOWN。若D已知為0，Stage3至7的新增價格條件確定FALSE；不把未知σ改成0。高點退出視窗須記anchor_changed，不能當成復甦證據。

252、63、再投資法、midrank、品質門檻均已核准為本版預設；不同類別的實證效力仍須驗證。原生OHLCV、ATR、Swing、TD9及Price Map繼續由原模組產出，本wealth不替換它們。

### PV3 完整的共同Stage映射

L_price是正式工程41既有price_condition_at_least_one，不改其OR。V_current_legal僅表示當前Primary已通過正式估值驗證；不是正式報告齊全、基本面安全或可下單。B2 = L_price AND V_current_legal。

以下百分比仍是正式Project Target Position累積目標，不是當輪買入比例：
Stage 2，20%：B2；不新增qP、qV或絕對PE門票。
Stage 3，30%：B2 AND D>0 AND qP>=75 AND qV<60 AND A_normal。
Stage 4，45%：B2 AND D>0 AND qP>=75 AND qV<40 AND A_normal。
Stage 5，60%：B2 AND D>0 AND qP>=90 AND qV<40 AND A_normal。
Stage 6，75%：B2 AND D>0 AND qP>=90 AND qV<20 AND A_cheap。
Stage 7，85%：B2 AND D>0 AND qP>=97.5 AND qV<20 AND A_cheap。

A_normal、A_cheap的完整定義：先執行版本化range resolver，輸出absolute_range_applicability＝TRUE／FALSE／UNKNOWN、range_id/version、來源條文、產品型別證據、effective_from／until及snapshot。class_id相符本身不證明range適用；必須核對正式指定型別及當輪資產方法。
• selected_primary不是Forward PE：這兩個本規格PE子句明示N/A，在AND省略；不需要用未知PE range阻擋其他合法metric。
• selected_primary是合法Forward PE且applicability＝TRUE：分別比較PE < 該range的Normal上界、PE < 該range的Cheap上界；range缺失、版本／snapshot不合法或邊界不完整時為UNKNOWN，不用class預設值補洞。
• selected_primary是合法Forward PE且applicability＝FALSE：只有已有證據確認本型別無適用固定range，才明示N/A省略這兩個子句。
• selected_primary是合法Forward PE且applicability＝UNKNOWN：A_normal與A_cheap均UNKNOWN，不當FALSE或N/A；其他已FALSE子句仍依法短路。
以上不會刪除整個V或P。專屬range override必須有正式來源、合法匹配、版本與有效期；零／多個適用override或未支援的override返回RANGE_RESOLUTION_UNAVAILABLE，不能臨場套其他類range。此規格保留override介面，但目前純reference selector只驗證registry已列的六組range，不宣稱已實作專屬override解析；其輸入出現override要求時應明確拒絕／UNKNOWN，而非靜默忽略。

本次十類的Forward PE閘值，全部衍生自既有正式估值區間；以下只有當range resolver的applicability＝TRUE時可用，六類canonical合成fixture明示假定TRUE。把區間配到Stage本身是本次已核准新政策：
美國大型核心ETF：A_normal PE<20；A_cheap PE<16。
科技／AI／高成長ETF：A_normal PE<24；A_cheap PE<18。
台灣大型權值ETF：A_normal PE<19；A_cheap PE<14。
製藥／醫療ETF：A_normal PE<19；A_cheap PE<14。
美國中小型ETF：A_normal PE<18；A_cheap PE<13。
半導體ETF、國防／軍工ETF、一般產業／主題ETF及兩類個股：本版登錄表未訂類別固定range；確認無適用專屬range時applicability＝FALSE，上述子句N/A。是否有適用專屬range尚未核定時仍為UNKNOWN；不虛構PE門檻。

比較嚴格依上述>=與<：等於40不屬qV<40，等於PE上界不通過A；不加epsilon。

三值及選階：FALSE AND UNKNOWN為FALSE，TRUE AND UNKNOWN為UNKNOWN。最高TRUE之上的各階均FALSE，才有唯一選階結果；更高階有可能改變結果的UNKNOWN時，選階結果UNKNOWN，附已證下界／可能上界，不執行下界。無TRUE不捏造下界；全FALSE返回NO_STAGE_SUPPORTED_BY_THIS_PROFILE，不自判Base。深階TRUE而應含的淺階FALSE時返回NESTING_OR_INPUT_CONFLICT並阻止選階。

每輪輸出各階所有子句、原值、三值、source_id、method、range_id及缺失原因。APPROVED_FOR_IMPLEMENTATION、IMPLEMENTATION_NOT_VERIFIED、DATA_UNAVAILABLE、METHOD_UNSUPPORTED與一般市場條件FALSE分開記錄；診斷不新增正式canonical enum。不得對本版已核准規則產生「尚未批准」阻擋理由。

### PV4 十一類資料方法與特別驗收

以下資料項先依第5章具名契約標記SAFETY_REQUIRED、MODULE_REQUIRED、OPTIONAL或INAPPLICABLE；不能把所有context機械改為所有Base的通用入場門票。每類均套PV2與PV3完整規則，再保留下列差異。

#### PV4 1 全球股票ETF GLOBAL EQUITY ETF

正式路徑：Forward PE → Trailing PE → CAPE → PB → FCF Yield。合法Forward PE之A_normal為PE<18，A_cheap為PE<14；selected metric非Forward PE時，不能套用這兩個PE數字。

全球規則承接歷史GLOBAL_EQUITY_ETF_PV_RESEARCH 0.2.0-candidate的公式，現行採用版本為1.0，採PV2與PV3相同自身歷史公式和Stage2基線。VT與VWRA各自確認法定基金、share class、ISIN、listing、報價幣別、配息／累積、發行人和方法，不因同為全球ETF而互借價格、估值或上市前歷史。

資料包括PIT國家、產業、Top5／10權重、成分及加權基本面、費用、AUM、NAV折溢價、流動性／價差與tracking error。成分coverage與missing exposure分開；不將未知權重重攤，不把不同日期當同截面；無comparison target的overlap是N/A而非0。

特別驗收：VT／VWRA高度重疊只能驗兩條資料接線，不當充分獨立市場證據。Trailing PE不能標Forward PE；歷史EPS成長不能標預測EPS；current來源合法不等於歷史PIT已證明。兩檔既有有限來源證據見第8章。

#### PV4 2 美國大型核心ETF US_LARGE_CORE_ETF
正式路徑：Forward PE → CAPE → Trailing PE → FCF Yield → PB。
資料：同ETF估值及其歷史；PIT成分／權重、ROE、EPS成長、S&P500歷史估值context及集中度。指數估值只能按正式context用途，不代替ETF的歷史qV或價格。
可確定項：合法路由、既有range、qV方向、核准條件及缺值傳播。
須實證項：同指數基金的經濟重疊、集中度改變及利率／獲利制度轉換下的規則穩健性。
特別驗收：PE→CAPE→Trailing PE的切換順序正確；每次切換使用自己的歷史，不繼承PE range；重疊ETF不被計為獨立外推證據。

#### PV4 3 科技／AI／高成長ETF TECH_AI_HIGH_GROWTH_ETF
正式路徑：Forward PE → EV/EBITDA → EV/Sales → FCF Yield；PEG僅補充。
資料：可靠組合聚合、EPS成長／修訂、AI CAPEX、主要權重集中度及實質利率的PIT版本；成分改編與科技子產業曝險。
可確定項：禁用PEG當Primary、合法倍數與yield方向、既有QQQ/Nasdaq-100型range的適用性檢查。
須實證項：成長轉折、長久期估值、權重更替與單一大型科技曝險；共同qP/qV切點未獲本類驗證。
特別驗收：聚合不可得時不拼成分倍數；高成長不自動抵銷風險；QQQ不能替SOXX作主profile。

#### PV4 4 台灣大型權值ETF TAIWAN_LARGE_CAP_ETF
正式路徑：Forward PE → PB → FCF Yield。
資料：本地上市／幣別／calendar、股息與拆併股、成分與權重、ROE、EPS成長、台積電集中度、電子／半導體周期；各自發布時點。
可確定項：正式0050型Forward PE range及方法切換；台灣交易日與美國資訊的可得時間分離。
須實證項：權值集中、周期及本地公司行動是否令qP或qV失真；不可把美股日期當台灣交易完成日。
特別驗收：同資產本幣價格重播、股息／拆股不產生假跌幅；集中於同一底層公司之基金不假裝獨立樣本。

#### PV4 5 製藥／醫療ETF PHARMA_HEALTHCARE_ETF
正式路徑：Forward PE → EV/EBITDA → FCF Yield。
資料：盈利穩定性、子產業與成分權重、專利及到期事件、藥價政策、FDA／Medicare等事件之正式狀態及發布／生效日。
可確定項：PPH/XLV型range的適用性、事件生命週期、合法聚合及核准公式。
須實證項：成熟藥廠、醫療服務、器材與研發型曝險的差異；若需新增subtype，先登記分類依據，不依事後績效分群。
特別驗收：政策／試驗風險不被低PE抵銷；不把研發公司負EPS硬塞PE；事件失敗的查詢不當成事件消失。

#### PV4 6 美國中小型ETF US_SMALL_MID_CAP_ETF
正式序列：Forward PE（排除負EPS） → 獲利公司比例 → EV/EBITDA → PB → FCF Yield。
獲利公司比例是FUNDAMENTAL_COMPOSITION_RATIO，不是估值倍數；不能對它做「越低越便宜」qV。
本版已核准的adapter解釋：比例節點只產生成分證據，不終止估值搜尋；若Forward PE不能合法作Primary，保留比例證據後繼續正式序列中的下一個合法估值metric。本版run採此adapter，保存selected Primary、相容鍵research_selected_primary及逐節點軌跡，經實作驗證後接入正式resolver。這是明示整合差異：若舊resolver曾把比例當Primary，須按本契約修正，不將比例送入qV。若呼叫者直接把該比例送入qV而未執行本adapter，返回NONVALUATION_PRIMARY_UNSUPPORTED，不偷換輸入metric。
資料：負EPS排除政策、PIT成分與獲利狀態、比例分子／分母、未知成分及其權重、加權／家數口徑。來源未說明家數或權重時比例UNKNOWN；不得混接兩種歷史。
已核准比例證據producer：先固定profit_definition_id（EPS口徑、共同預測／報告期、正EPS才算獲利）、合資格成分全集及PIT權重。家數比例與權重比例是不同欄，不混接歷史。若全集家數N可證、已知獲利家數K、未知獲利狀態家數U，報區間[K/N, (K+U)/N]；只有U＝0才報完整點比例。若合資格總權重W可證、已知獲利權重Wp、未知獲利狀態權重Wu，報[Wp/W, (Wp+Wu)/W]；只有Wu＝0且權重coverage完整才報完整點比例。未知成分存在時，已知獲利分子／全部分母只是下界，不冒充完整比例；缺全集、分母／權重或profit_definition_id則相應比例UNKNOWN。不得將未知權重攤回已知、以缺列自動當負EPS或未核定的剩餘權重推算完整性。比例／區間不是新的Stage加減分，也永不送入qV。
特別驗收：PE看似便宜但負EPS占比擴大時保留兩個事實與風險context；不得只看獲利公司分位掩蓋組合損失；ratio永不流入qV，fallback到PB不帶PE門檻。

#### PV4 7 半導體ETF SEMICONDUCTOR_ETF
正式路徑：Forward PE → EV/EBITDA → EV/Sales → PS → FCF Yield；Trailing PE不得獨立作核心。無本類正式固定PE range。
資料：EPS Revision、庫存、ASP、毛利率、利用率、晶圓／設備需求、AI CAPEX、集中度；SOXX還須沿專屬overlay及主要成分交叉查核。
周期PE處理：分母非正、口徑不一致、聚合失效，或具PIT依據的方法判定明確NOT_RELIABLE，才沿合法路徑Fallback。不能因PE很低／很高或主觀認為景氣見頂就換metric；正PE處於周期高點可同時保留「估值便宜」及「EPS修訂／庫存惡化」兩個事實。若經濟意義仍待判定，主解UNKNOWN；若只屬context未知，按該context的正式consumer傳播，不任意全局否決。
特別驗收：周期盈餘翻負、EPS修訂及重整均按當時available_at；不得用事後正常化EPS重寫當年PE；SOXX自身價格不得被QQQ／SOX／SMH替代。

#### PV4 8 國防／軍工ETF DEFENSE_MILITARY_ETF
正式路徑：Forward PE → EV/EBITDA → FCF Yield → EV/Sales。無本類固定PE range。
資料：PIT訂單／backlog、合約簽訂及撤銷、交付期、國防預算、軍購、利潤率、出口限制、政策／地緣事件、成分集中；NATO等專屬規則保留。
可確定項：傳統軍工與軍工科技／衛星／Cyber等分析框架的域差異；借VOO／QQQ分析框架不繼承其絕對PE區間。
須實證項：長交付期、政府預算延遲、戰爭事件與成分制度改變對規則的影響。
特別驗收：預算提案、法定預算、合約授予、backlog及確認營收分成不同事件／欄位，不將新聞金額直接當營收或增加多票。

#### PV4 9 產業／主題ETF SECTOR_THEME_ETF
正式路徑：依真實投資目標／指數方法匹配所屬Sector/Industry正式Waterfall；不存在通用PE順序或range。
正式路由行為：唯一有正式方法且適用的產業profile → 用該profile；多個正式合法匹配 → PROFILE_CONFLICT。S1沒有既定方法但身份與分類已知時，使用本版已核准的PV4A subtype registry。已屬半導體／國防專屬Primary Class，不再增加第二主類別。
資料：產品結構、指數規則、歷次成分及產業權重、該產業合法估值／context；主題名稱本身不作分類證據。
可確定項：相同normalized規則、下方有限built-in方法與所有UNKNOWN行為；合法資料可計算選階結果，無經濟意義的方法仍不得強行給數字答案。
已核准適用範圍：下方有限方法可直接實作及接線；超出有限支援域的產品仍須另建method/profile，不能冒稱已覆蓋所有產業工具。
特別驗收：無路由與複合主題衝突不被first-match吞掉；相對同業估值只補充，最大持股不代表整檔。

#### PV4 10 大型成熟／高品質個股 LARGE_MATURE_HIGH_QUALITY_STOCK
正式路由由產業與財務subtype唯一解析，不從「高品質」推導PE或Grade。
已定subtype：金融P/TBV → PB → Forward PE；獲利成長Forward PE → EV/EBITDA → FCF Yield → EV/Sales；無意義／不穩定EPS用EV/Sales → PS → 有意義時FCF Yield；半導體與國防沿專屬路徑。S1的OTHER沒有通用順序；本版採用PV4A的有限sector／財務subtype registry補足，不把新generic方法冒稱S1既有獲利成長規則。
資料：原始財報與修訂、指引、股本／負債／現金、合法估值史、公司行動、事前Core Investment Theses及各項Normal／Deterioration／Failure條件。金融另需ROE/ROTCE、NIM、信用成本、charge-off、存放款、資本及信用周期；只對適用subtype要求。
可確定項：subtype路由、分位方向、核准條件及事前Thesis規則消費；不把低估值等同公司論點有效。
須策略選擇項：每項Thesis的具體可檢驗條件及持續期，須事前批准，不能回測後補寫。
特別驗收：金融股不走工業EV/EBITDA；非經常損益／收購／分拆造成方法斷點時不跨制度拼接；公司論點失效不能被qV補償。

#### PV4 11 高Beta／事件型個股 HIGH_BETA_EVENT_STOCK
估值subtype路由同上，但Beta或事件本身不是估值方法；不因股價波動大就自動視為正式HIGH_VOLATILITY_ETF或調換Primary Class。
資料：自身波動／價格、稀釋與融資、cash runway／burn rate、營收及margin、獲利轉折、事件underlying_event_id、原始發布／修訂、Active/Pending/Resolved狀態及事前Thesis。
可確定項：無意義EPS禁PE，runway是風險context而非倍數；事件按canonical identity去重，失敗查詢不存成「零風險」。
須實證項：跳空、停牌、退市、失敗融資、增發及不可成交尾部；普通日線回測不替代事件執行驗證。
特別驗收：高qP不等於低風險；重大事件與流動性禁買沿原Owner優先；複雜公司行動無受支持wealth方法時qP明確UNKNOWN，不跨事件補線。

### PV4A 新增有限產業路由表

SUBTYPE_RESEARCH_ROUTES 為保留的相容識別碼；本版規則版本為1.0、APPROVED_FOR_IMPLEMENTATION，承接歷史0.1.0-proposed且不改方法名稱與順序。它補足S1未定的方法，不是MSCI／S&P推薦的估值模型。既有正式專屬方法仍優先。本表與共同Stage映射經實作驗證後接入正式Primary與Stage流程。

支援域：有可核實上市身份的普通股，以及未槓桿、非反向、非衍生品主導的股票ETF。排除域：債券／商品／期權策略、槓桿／反向、未上市股權、沒有可核實權益單位的產品；這些返回OUTSIDE_CANDIDATE_SCOPE，不聲稱支援。pre-revenue公司若所有合法估值分母皆無經濟意義，返回VALUATION_DATA_INSUFFICIENT，不發明便宜分數。

有限分類集合：Energy、Materials、Industrials、Consumer Discretionary、Consumer Staples、Health Care、Financials、Information Technology、Real Estate、Communication Services、Utilities，以及BLENDED_EQUITY與UNKNOWN。名稱參照官方GICS分類，只用作分類鍵，不自行從新聞、ticker或價格推分類。輸入須有PIT taxonomy_provider/version及issuer/index classification evidence；如用其他taxonomy，須有版本化且唯一的crosswalk。官方分類來源：[MSCI來源](https://www.msci.com/indexes/index-resources/gics) 。分類來源只支持分類架構，不為以下估值順序或Stage切點背書。

唯一解析程序依序執行：
R1 具正式來源、有效版本且唯一適用的專屬instrument／subtype路由，優先；正式合法路由彼此衝突時PROFILE_CONFLICT，不由新增generic規則裁決。
R2 無適用正式方法時，Financials／已核實mortgage-finance型走FINANCIAL_CANDIDATE；不得因EPS轉負改走工業公司EV。
R3 非金融普通股先作明確sector dispatch。已核准earnings_subtype_basis固定為最新PIT可得的原生reported diluted EPS TTM（同provider／會計方法）；不可得時UNKNOWN，不以Forward EPS、最新單季或未核定的四季簡單加總替代。這項已核准分流基準不改其他正式EPS欄位定義。EPS_NOT_MEANINGFUL／UNSTABLE_EARNINGS必有具名正式producer、有效rule版本及三值狀態；空查詢不證明否定判定不存在。
R3a 已核實Real Estate營運／equity property型先走REAL_ESTATE_OPERATING_CANDIDATE；這個已核准專屬方法優先於一般EPS正負分流，避免因物業折舊下的負EPS直接改成EV/Sales路徑。mortgage-finance在R2已先分走。property／mortgage身份不明時ROUTE_UNRESOLVED。
R3b 其餘非金融普通股：若已發布同方法EPS非正，或已有正式有效EPS_NOT_MEANINGFUL／UNSTABLE_EARNINGS判定，走LOSS_NONFINANCIAL_GENERIC。若EPS為正且沒有上述有效否定判定，Health Care走HEALTHCARE_GENERIC，其餘下表列出的非金融sector走PROFITABLE_NONFINANCIAL_GENERIC。
R3c EPS缺失／非有限或必要財務subtype判定未知時，earnings_state＝UNKNOWN，route返回EARNINGS_SUBTYPE_UNKNOWN；不因落入otherwise就宣稱公司盈利。金融／非金融或sector分類未知時ROUTE_UNRESOLVED，不能誤用EV。這是資料未知的明確結果，非用新的盈利預設補洞。
R4 股票ETF：官方投資目標／指數納入規則只指向一個已知sector，就依本表唯一dispatch：Financials走FINANCIAL_CANDIDATE，Real Estate依property／mortgage證據走REAL_ESTATE_OPERATING_CANDIDATE或FINANCIAL_CANDIDATE，Health Care走HEALTHCARE_GENERIC，其餘列出的非金融sector走PROFITABLE_NONFINANCIAL_GENERIC（路由名稱不代表ETF全部成分盈利）；明示跨sector、或該期可核實成分分類含多sector且沒有唯一單sector目標，走BLENDED_EQUITY_CANDIDATE。不用自造權重占比門檻決定主業，不以最大持股決定sector。分類證據不足仍UNKNOWN。
R5 只在R1至R4均無合法匹配且已確認scope外時返回OUTSIDE_CANDIDATE_SCOPE；不是scope外而是資料缺失時返回ROUTE_UNRESOLVED。不能以「未找到」假稱N/A。

built-in方法表：
FINANCIAL_CANDIDATE：P/TBV → PB → Forward PE。限TBV／book及股本定義可核實的銀行、保險與其他金融業；不同金融subindustry分開保存context。ETF只有provider能提供可靠同口徑portfolio P/TBV時才用，否則合法轉PB；不手拼持股PTBV。
PROFITABLE_NONFINANCIAL_GENERIC：Forward PE → EV/EBITDA → FCF Yield → EV/Sales。用於Energy、Materials、Industrials、Consumer Discretionary、Consumer Staples、Information Technology、Communication Services、Utilities中沒有專屬正式方法的普通股／sector ETF。這是已核准的固定規則，不代表各行業已同質或已驗證；sector鍵與context仍保留，不把這些sector合成一個獨立樣本。
HEALTHCARE_GENERIC：Forward PE → EV/EBITDA → FCF Yield。普通股若符合R3的無意義EPS條件，改用LOSS_NONFINANCIAL_GENERIC；醫療ETF依合法聚合處理，不因單一負EPS持股將整檔改路由。
REAL_ESTATE_OPERATING_CANDIDATE：EV/EBITDA → PB → FCF Yield。只接受明確定義且可比的operating/property企業或equity property trust數據；mortgage-finance回R2。不得把FFO／AFFO／NOI冒稱EBITDA或FCF；需要這些專屬metric但無已定方法時，相應規則不可算，不以會計PE硬補。本表沒有宣稱實作所有REIT專屬估值。
LOSS_NONFINANCIAL_GENERIC：EV/Sales → PS → FCF Yield（只在經濟意義成立時）。禁止以負EPS算PE；沒有營收時EV/Sales及PS不可用，不將0分母視為無限便宜。
BLENDED_EQUITY_CANDIDATE：Forward PE → Trailing PE → PB → FCF Yield。只接受provider可核實portfolio方法及負EPS／負book處理；不在金融與工業混合組合使用通用EV/EBITDA。每個method若無可靠聚合就沿本表明示後續順序；全失敗返回VALUATION_DATA_INSUFFICIENT。

以上所有新方法不建立新的絕對PE區間；已證實沒有正式且適用的range時，absolute_range_applicability＝FALSE，而A子句為N/A並在AND中中性省略；絕不是A＝FALSE。適用性未知時A＝UNKNOWN。不能從方法名借用ETF既有range。多個generic鍵最終若映射同一路徑，仍保留原sector與匹配證據；若產出不同合法路徑且無上述唯一分支，PROFILE_CONFLICT。

所有metric共同可測防護：價格、股數及分母身份一致，倍數必須有限且其分母為正；PB/PTBV的book/TBV為正；EV倍數要求其來源定義的EV與正分母可比，EV非正不能在本版當Cheap；yield依正式可用性判定，不任意改符號。公司non-GAAP指標必須保存原名、GAAP reconciliation／來源方法及版本；FFO不是現金流、EBITDA也不是現金流，不把不同定義混接歷史。原始企業公告示例支持這項不混用原則：https://www.sec.gov/Archives/edgar/data/1031316/000110465926087553/fsp-20260728xex99d2.htm 。該來源不替本版路由的投資效力背書。

可用資料的確定性含義：scope、分類、方法與資料全部通過時，每個built-in都得到唯一Primary、qV或有明確原因的歷史不足，再套相同Stage公式；不是「每個投資工具無條件都能產生數字Stage」。沒有可用經濟指標時拒絕給分，是完整規則的一個合法終態，不應偽報已取得估值。

### PV5 Context與風險證據的操作定義

Context producer只提供可重播事實，不自創安全加權分數：
• 同口徑可比數字x_t、x_prev可得時，delta=x_t−x_prev；方向為正、零、負。任一缺失或口徑不可比則方向UNKNOWN。比較基準期間必須出自對應rule contract，不能臨場挑前季或前年度。
• 成長率只在其正式方法分母合法時算；EPS穿越零點保留原值及符號轉換，不把負基期百分比稱高速成長。
• EPS Revision使用同公司、同預測期、同provider／方法的前後可得forecast；不能把下一財年的預測當作同年度上修。
• 事件狀態取PIT合法revision鏈及正式事件生命週期；沒有資料不表示已解除。backlog、預算、合約、收入及新聞轉載各保留真實類型，不相加成一個「利多數」。
• context是否Positive/Negative及是否限制Stage，只由已有具名Owner規則消費。僅對本版未另行量化、且適用範圍外的原Owner context，若仍只寫「持續改善」「權重提高」等未量化詞，producer輸出原值與delta，consumer返回RULE_NOT_SPECIFIED；不以本版規格偷偷補成「連續三期」或「加十分」。

這些情況的返回行為已完整定義；它們不是已完成原Owner量化的宣稱。要完成正式端到端系統，仍須把相應Owner的政策補成具有輸入、比較子、期間、失效與reset的版本化規則。


<!-- PAGEBREAK -->

## 3 同資產總報酬與公司行動契約

本章狀態為APPROVED_FOR_IMPLEMENTATION，research_only＝false；W是正式策略特徵方法，不是帳戶實際報酬。W_method_id保留OWN_FUND_RAW_CLOSE_GROSS_CASH_EXDATE_CLOSE_REINVEST；本版方法契約為1.0，承接歷史0.1.0-candidate且數學不變。基金使用同基金、share class、listing及報價幣別；個股適用性按PV2及本章末段。不以NAV、指數、另一ETF或上市前歷史補洞。

### 確定的遞迴與事件基準

在同一cutoff T合法選取資料後，對相鄰完成交易session p、t：

<equation id="WEALTH">W_t = W_p × (k_t × C_t + d_old,t) / C_p</equation>

分式為總報酬倍率G；以G減1得簡單報酬R，以G自然對數得log return r。C必須有限正數、同報價基本單位、RAW_UNADJUSTED市場完成收盤，不能只因欄名Close就認證。已拆股／股息／總報酬調整或mixed／unknown口徑拒絕，不再加息或乘拆股；改用adjusted series須另method驗證。

k是每一股p日舊股於t日收盤對應的新股數，即new／old；2拆1為2，1併4為0.25。d_old是每一舊股的同報價幣別gross現金，逐事件核實權利基準：每舊股乘1，每最終新股才乘已核實k；多筆獨立事件分別轉舊股再求和。基準／時序不明則UNKNOWN，不從價格跳動猜。

只支援已驗證的純拆併股與單純固定非選擇性現金分派；同日兩者須有明確權利時序。不支援分拆、實物／選擇性權利、重整、換listing、幣別改制或不明cash-in-lieu等複雜事件；有不支援事件不只算容易部分。跨幣別UNKNOWN；cents轉基本幣單位不是FX。

### 統計再投資不代表現金可用

假設除息日收盤以C_t將應收款全數再投資，容許分數股；不代表已付款、交割或可下單現金，pay date不再加一次。新再投資股不重領同筆股息。使用宣布給shareholder的gross分派，不扣投資人稅、佣金、價差或再投資費；基金內費用已反映，不再扣年費或虛加回底層稅負。

k＝1、d＝0只可由同listing、事件種類全集及該步區間完整有效coverage證明；空查詢、累積型名稱或普通股息表都不等於全公司行動無事件。事件按穩定underlying_event_id及核定來源優先序去重，依T前合法revision鏈選有效版本；重抓不加權、更正不新舊相加、衝突不交LLM選值。

### Seed 斷鏈與凍結版本

第一個合法完成close設W＝100與segment_id，首日無前值報酬不是0。預期開市缺bar、必要事件或calendar不明即斷鏈，不forward-fill、不跳接。修復另建snapshot／vintage；未修復可顯式新段seed100，但不跨段保留高點、波動或reference。252高點與峰前63 returns須在同一可靠段；峰值在窗首時最多需315個levels，不一律把315當最低。

所有close、事件、calendar、coverage依同一T選版本；available_at、經濟as_of及retrieved_at分開。current W／H用T，歷史月末Z用其T_j，峰值σ用高點當時T_h獨立曲線；新更正不可倒灌舊決策，已知錯誤anchor標失效，不偷偷用今日σ。保存AS_KNOWN_AT_T與新RESTATED版本。採Decimal至少50位、ROUND_HALF_EVEN及來源precision，保存runtime／hash。

本W是自定義同資產特徵方法，不複製FTSE或S&P完整官方指數規則；再投資方法可能不同。[S&P方法參照](https://www.spglobal.com/spdji/en/documents/methodologies/methodology-index-math.pdf)　[FTSE方法參照](https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/ftse-global-equity-index-series-guide-to-calc.pdf)

本版PV2把相同計算流程延伸至同資產個股；這項適用性已隨1.0正式採用。個股的特殊權利與重整仍按不支援事件明確斷鏈，不跨事件補線。


<!-- PAGEBREAK -->

## 4 技術訊號完整契約

**結論：本稿已把原五向量32個槽位、MA20保護、離開最低點、技術減碼9項、左側成熟度8項及日／週／月趨勢，逐一寫成可實作／可驗收的實作定義，不再以「持續、明顯、快速、健康」留空。**

狀態：`APPROVED_FOR_IMPLEMENTATION / IMPLEMENTATION_VERIFICATION_REQUIRED / NOT_BACKTESTED`。本章P定義已由使用者核准，工程可按稿實作並接入正式Classification、Mode、Stage、Permission、Execution的對應依賴；不得再以研究限定阻擋。技術模組只產自身事實與predicate，最終欄位仍由各Owner按本文件完整依賴裁決。文件更新本身沒有修改正式程式、資料庫或券商狀態，也不宣稱接線或測試完成。

日期：2026-10-27 UTC。適用：有可靠交易日曆、同listing OHLCV及公司行動證據的上市股票／股票ETF。核准參數不是已證實跨資產通用常數。價格以自身資料運算；不從VT、QQQ或指數借價格替其他標的補洞。ETF的C8適用性另見TECH 7，不偽造「ETF公司EPS」。

**股性與參數的明確分界**：下列1%、0.5%、20%、1.5倍、期間等是`technical_baseline_profile_v1.0`的已核准固定預設，**不是已證實適用所有股票／十一類的共用有效閾值，也不等於已完成逐股校準**。相同算法使用各標的自己的OHLCV、Swing及ATR，但原生自有資料不會自動使固定百分比完成波動適配。每輪在開始前解析並鎖定`class_profile_id + instrument_profile_id + technical_parameter_version + effective_from + hash`：已有事前核准登記的override才覆蓋指定P參數；否則明示`APPROVED_BASELINE_NOT_EMPIRICALLY_VALIDATED`使用本稿確定預設。F參數不可override。不得當輪看訊號好壞自動調band、以AI主觀股性換閾值、或回測後改參數沿用舊version；任何新profile需另樣本外／敏感度驗證。本版baseline採用批准已完成；資料、實作及整合須驗證，計算結果不等於交易授權。

### TECH 0. 來源、標記與優先序

- **F＝正式繼承**：正式V82主規則 v1.21.0，SHA256 `392e54808c33cce99e3567f0e8942650ad50b382d9fc87acbbe20f012b568372`。本輪直接讀工程23–26、42–43、原特殊分類清單、原26／27章Swing、B-3與Work7治理；行號以原檔為準。
- **P＝本稿新增且已核准的實作定義**：新增算法、種子、窗口、容差、對應或有效期；每列保留P作來源標記。其採用權威來自本次使用者批准，不冒稱S1早已具備同一數學定義。
- **M＝已存在候選producer的證據**：2026年10月21日技術來源映射候選，SHA256 `076fa4ddf9be1d529622893264737d86b2f95974b26f160bbc33dc4cc31e6461`；其中Yahoo候選producer不是已核准正式來源。M不等於F。
- 既有15組量化提案在本稿被整合及補完；本版新增內容以1.0及對應method_id為正式實作依據。與S1既有規則的差異按本文件明列範圍處理，不概括覆寫S1。
- `Work7-A/B-3`的**MACD連續2個完成Bar、0.25×ATR noise band仍不啟用**。本稿其他新期間／百分比以已核准P定義生效，不借B-3名稱混入。

| 正式來源 | 此稿承接的確定內容F | 本版新增且已核准的內容P |
|---|---|---|
| 工程23，原行412–633、635–799 | TD9日線；Close與t−4比較；9封頂；同向不重複事件；最低13根計當前count；Low分數及×4 | 冷啟動事件可辨識細節、C6事件壽命／創高基準 |
| 工程24，原行236–311 | KD9,3,3及20/80；MACD12,26,9及DIF−DEA；MA5/10/20/50/60/200；交叉不等式 | KD平滑／零range、EMA與RSI種子、敘事持續期 |
| 工程25，原行136–181 | EMV3,3、RSI14及30/70、量與5/20均量比較、局部UNKNOWN | EMV3,3具體算法；量能分母是否含當根；量能倍數與「健康」 |
| 工程26，原行63–109 | 三週期角色、四種已命名組合、same-run alignment | Bullish/Bearish數值分類器及聚合週界細節 |
| 原分類清單，原行7750–8110；工程42/43，原行27923–28065 | Right≥3；Up價格≥1＋強勢≥3＋MA20；Down價格≥1＋加速≥2 | 「明顯／快速／持續／附近」的具體實作門檻及生命期 |
| 原26／27章，原行12900–13480 | Swing High/Low前2＋後2、嚴格比較；未確認不使用 | 擺動串正規化、配對窗口、同bar雙pivot處理 |

### TECH 1. 完整資料與時間契約

#### TECH 1.1 指數、型別、局部缺值

`τ`是本輪知識截止UTC時間；`t`是該timeframe預期最新**已收市且正式Close可靠可用**的完整bar；`p=t−1`。所有加減以交易session／完成週／完成月索引，不是日曆天。`C,H,L,O,V`屬同instrument、listing、currency、price_basis、volume_unit、calendar_version及snapshot_vintage。價格有限且>0；`L≤min(O,C)≤max(O,C)≤H`；V有限且≥0。O缺失不污染只需Close的TD9；H/L缺失不污染MA、RSI、MACD。任何依賴的值或口徑無法核對，只讓該輸出UNKNOWN。

布林採Kleene三值：`FALSE AND UNKNOWN=FALSE`，`TRUE AND UNKNOWN=UNKNOWN`，`TRUE OR UNKNOWN=TRUE`，`FALSE OR UNKNOWN=UNKNOWN`；NOT UNKNOWN仍UNKNOWN。完整資料下不符合公式才FALSE。無合格比較對、必要歷史不滿、沒有可靠來源，均非0／FALSE。事件尚待觀察是PENDING／UNKNOWN，不先當成功。

**P數值運算**：來源數值以十進位字串讀入；Decimal精度50、ROUND_HALF_EVEN；公式內不做展示四捨五入；逐步按所列遞迴順序計算；比較以運算值，不加未登記epsilon。只有展示層按來源精度／顯示精度格式化。division by zero、NaN、Infinity→UNKNOWN＋reason。記錄runtime及decimal context以便重播。

#### TECH 1.2 價格與公司行動

**F**技術用核對後Canonical Close，不可把Adj Close或總報酬曲線W偷偷換進來。**P核准預設**選`CANONICAL_CLOSE_VERIFIED_RAW_SEGMENTED_V1`：以經來源核證的未調整OHLC及實股量運算；拆併股、換listing、幣別改制、實物分拆、無法確定的權利事件處切斷價格／量能可比段。事件當日若新口徑資料合法可開新segment，但不得把舊segment價格／EMA／Swing搬過來。一般同幣別現金除息保留其市場價格缺口並標記事件，不擅自抹去；本稿不聲稱除息跳空就是基本面惡化。若正式Owner核准另一套split-adjusted Canonical Close，必須另method_id、完整PIT調整因子與數值對照，不與本預設混算。

公司行動「無事件」必須由完整有效coverage證明；空查詢不是無事件。原producer的`auto_adjust=False`只是一個請求參數，不足以認證實際raw／split語義。OHLCV任一欄不得跨不同調整基準拼接。

#### TECH 1.3 PIT、缺bar、修訂與冷啟動

每筆保存`economic_as_of, available_at, retrieved_at, revision_id, source_digest`。只用`available_at≤τ`有效版本；retrieved_at不是歷史available_at。當日收盤已發生但正式Close尚未可靠發布，該session不成立Completed Bar；保留WAITING_OFFICIAL_CLOSE，不冒用盤中價。來源聲稱已發布卻缺資料，當前依賴UNKNOWN/STALE；不得把前日值改日期。

預期開市但缺必要bar不得forward-fill、跳接或將V補0。每個primitive依其依賴建立連續segment；例如缺V只中斷量能與EMV，不中斷完整Close的MA／TD9。遞迴從固定`seed_session`開始；同一次方法不任意改拉取起點來改結果。可靠state cache須保存方法hash、segment、last_session、所有遞迴state與來源vintage。更正建立RESTATED新版本；原AS_KNOWN_AT_τ輸出不可被新資料回填。歷史錯誤可註記，但不偽造當時可知。

#### TECH 1.4 日／週／月完成bar（F角色＋P確定聚合）

| timeframe | 完整bar及聚合算法 | 價格／量與可用時點 | 歸屬 |
|---|---|---|---|
| DAILY | 主上市市場交易session；半日市依官方calendar正式收盤；排除盤前盤後 | 使用官方session O/H/L/C/V；available_at為各必要欄實際可靠可得時點 | F只用Completed；P欄級completion實作 |
| WEEKLY | **P**交易所本地日期週一00:00至下一週一00:00；以該週calendar最後一個開市session為週終。該週預期session全部結束且必要資料齊全才完成；週五休市可週四完成 | O=首session O；H=max H；L=min L；C=末session C；V=sum V；availability=max必要成分available_at及calendar可用時點 | F週獨立；P聚合界線／算法 |
| MONTHLY | **P**交易所本地曆月；最後開市session完成且整月必要成分齊全才完成；月底假日不延伸至下一月 | 同上；不能用今天未完成的月K取代上月已完成K | F月獨立；P聚合界線／算法 |

一週／一月若完整calendar證明全無交易session則不產bar，不捏造0成交。IPO首個不完整週／月、資料起點在週月中間、斷鏈／公司行動跨越期間：P排除該週月聚合，下一個完整可比期間才開新段。停牌日須有官方session處理契約；未取得則該period UNKNOWN，不猜「休市」。跨DST依calendar時區轉UTC，不寫固定16:00UTC。

週月指標在聚合後獨立運算、獨立seed；日RSI不可週末改標Weekly。**正式TD9只DAILY**；週／月TD9輸出N/A_NOT_IN_V82_TD9_CONTRACT，不產數值或票。日週月各自as_of不同屬正常，但同一run_id／τ／vintage不可拼接未來值。

### TECH 2. Primitive公式、seed、warm-up與邊界

共同：`SMA_N(X)_t=(Σ_{i=t−N+1}^t X_i)/N`，必須N個連續合法值；不足UNKNOWN，不縮窗口。`EMA_{α,m}`從第一個合法值x_s設e_s=x_s，其後`e_i=αx_i+(1−α)e_(i−1)`；內部自s開始更新，但至少m個連續值才對外發布。缺值重開segment而不skipna。

| ID／數值 | 完整實作算法與首次合法點（segment index從0） | 正式繼承F／新增P |
|---|---|---|
| B01 TD9 | `h_i=(C_i>C_(i−4))`,`l_i=(C_i<C_(i−4))`；h真→High=min(9,priorHigh+1)、Low=0；l真對稱；相等兩側0。count0/1..8/9對應INACTIVE/COUNTING/COMPLETED；當前count需13 closes，i≥12。可直接由最近最多9個同向比較的連續run長度封頂算count，不能用未知prior=0假裝已知。 | F方向、比較、reset、封頂、13根；P可直接run-length實作 |
| B02 TD9首次9 | `first_high9_i=(High_i=9 AND High_(i−1)<9)`，Low對稱；同方向9後不再事件。無cache一般需14 closes才同時確定兩個count；若已有可證明reset亦可更早辨識，但不得推測。13根只能確定當前9，不能普遍斷言「今天首次9」。 | F首次事件不重複；P冷啟動事件可辨識規則 |
| B03 KD | `HH9=max(H_(i−8:i))`,`LL9=min(L_(i−8:i))`; range>0時`RSV=100(C−LL9)/(HH9−LL9)`；range=0且OHLC合法時**P RSV=50**。`K=SMA3(RSV)`,`D=SMA3(K)`；RSV首i8、K首i10、D首i12；需要前值cross首i13（14 OHLC bars）。 | F9,3,3；P明選兩層SMA，**本版指定SMA，不聲稱等同另一平台遞迴KD，也不追溯宣稱S1原已指定此平滑**；M既有候選producer亦用SMA |
| B04 MACD | `EMA12=EMA_(2/13,12)(C)`、`EMA26=EMA_(2/27,26)(C)`；`DIF=EMA12−EMA26`自i25合法；`DEA=EMA_(2/10,9)(DIF)`從i25首DIF作seed，i33首合法；`Hist=DIF−DEA`，i33首合法，cross首i34（35 closes）。 | F12,26,9及Hist不乘2；P遞迴seed與發布屏蔽，M與adjust=False目標相容但尚非逐值核驗 |
| B05 MA | `MA_N=SMA_N(C)`，N∈{5,10,20,50,60,200}；首i=N−1；cross需N+1 closes | F期間、SMA及完整N根 |
| B06 EMV3,3 | 中點`M_i=(H_i+L_i)/2`；`rawEMV_i=(M_i−M_(i−1))*(H_i−L_i)*100000000/V_i`；V_i>0；若range=0且V>0，rawEMV=0；V=0→UNKNOWN。`Efast=SMA3(rawEMV)`，`E=SMA3(Efast)`。raw首i1、fast首i3、E首i5（6 HL/V bars），相鄰比較需7 bars。所有本稿E只指此第二層輸出。 | F僅3,3與正負／升降；**P整個`EMV_ARMS_SMA3_SMA3_SCALE1E8`定義**，不是找回了未取得的官方公式；不將emv_14更名 |
| B07 RSI14 | Δ_i=C_i−C_(i−1)，g=max(Δ,0)，d=max(−Δ,0)；`G=EMA_(1/14,14)(g)`,`Dloss=EMA_(1/14,14)(d)`；從首Δ_i1種子，14個Δ後i14首合法（15 closes）。G,Dloss>0→`100−100/(1+G/Dloss)`；G>0,Dloss=0→100；G=0,Dloss>0→0；兩者0→50。 | F14、30/70及數值保留；P此EWMA首觀察種子／全平50，不冒稱SMA-seeded Wilder完全等價 |
| B08 ATR14 | i0處`TR_0=H_0−L_0`；其後`TR_i=max(H_i−L_i,abs(H_i−C_(i−1)),abs(L_i−C_(i−1)))`；`ATR=EMA_(1/14,14)(TR)`，首i13（14 bars）。 | F ATR14；P seed=首TR、首bar TR採range，不能與其他seed混用 |
| B09 Volume | `VolMA_N=SMA_N(V)`、`ratio_inclusive_N=V/VolMA_N`，N=5,20，50在需要時；均量0→ratio UNKNOWN。另定義`B_i=SMA20(V)_(i−1)`、`q_i=V_i/B_i`，需21 bars且B_i>0。 | F5/20、需要時50；P正式未明示分母納入t，本稿明定inclusive供基礎比較、exclusive q供實作門檻；兩者不同欄名 |
| B10 Return | `r_i=C_i/C_(i−1)−1`；首i1；不混總報酬W，百分點差用0.01表示1個百分點 | P明選raw市場收盤簡單報酬 |
| B11 Swing | Low pivot i：`L_i<min(L_(i−2),L_(i−1),L_(i+1),L_(i+2))`；High反向嚴格>。最早第5根bar完成時確認第3根pivot。`confirmed_at=max`五根必要欄及calendar可靠可用時點；i+2完成前不能使用。 | F前2後2及strict；P欄級availability記帳 |

**表列「cross首／需要N+1根」指前後兩根全部輸入首次齊全，不是強制在此之前一律UNKNOWN。** 仍須用TECH 1.1三值短路：例如首個合法MA當根C=MA，reclaim及breakdown的當根嚴格不等式已FALSE，即使前MA未知仍可FALSE；first9當根已知count<9也可FALSE。

P warm-up到表列首次合法點即可給**正式計算**數值，沒有偷偷另加「200根趨穩」規則。遞迴早期值明標seed_sensitive；統計比較必須使用同seed/vintage。若正式Owner要SMA-seeded Wilder或其他平滑，另version後重算全部衍生，不只換最後一個數值。

#### TECH 2.1 基礎狀態及Cross（每列F，除列明的P邊界）

| 數值 | TRUE公式／狀態列舉 | 邊界 |
|---|---|---|
| KD golden/death | `K_p≤D_p AND K_t>D_t`／`K_p≥D_p AND K_t<D_t` | 當根相等沒有cross；前根相等可cross；資料缺則三值 |
| KD range/direction | oversold=`K<20 OR D<20`；overbought=`K>80 OR D>80`；rising雙線相較p皆>，falling皆< | P雙線均=前值列FLAT；其餘非升非降列MIXED，不捏UNKNOWN；20/80不算超買賣 |
| MACD cross | golden=`DIF_p≤DEA_p AND DIF_t>DEA_t`；death反向 | Hist由≤0到>0是同一golden事件別名，不另投票 |
| MACD zero | ABOVE_ZERO=DIF>0且DEA>0；BELOW_ZERO兩者<0；異號STRADDLING_ZERO | P任一恰0另列ON_ZERO，不誤列多空 |
| MACD histogram | 正負同號且abs增／減→EXPANDING／CONTRACTING；反號／從0進非0先列DIRECTION_SWITCH | P同值FLAT；當根0列AT_ZERO。H即Hist，避免與High混淆 |
| MA | ABOVE/AT/BELOW按C與同根MA比較；reclaim=`C_p≤MA_p AND C_t>MA_t`；breakdown=`C_p≥MA_p AND C_t<MA_t` | F5線bull=5>10>20>50>200，bear反向；MA60不塞入鏈 |
| EMV | POSITIVE E>0、NEGATIVE E<0；RISING E_t>E_p、FALLING反向；轉正=`E_p≤0 AND E_t>0` | P零值ZERO、相等FLAT；絕對值不能跨平台／volume unit比較 |
| RSI | OVERSOLD <30；LOW_MID 30≤RSI≤50；MID_HIGH 50<RSI≤70；OVERBOUGHT >70；EXIT_OVERBOUGHT=`RSI_p>70 AND RSI_t≤70` | F30/70與exit；P完整互斥range命名；50屬LOW_MID |
| Volume quadrant | 價向=C_t對C_p；量向=V_t對VolMA20_t。正負組成四象限；任一恰相等列FLAT並保留兩個子方向 | F四象限；P本稿量方向選inclusive MA20及「無實質方向」採精確相等，不猜噪音帶 |

**TD9高／低歧義的裁決**：本案母規則已明文High=Close高於四根前、Low反向，不是「今天High更高／Low更低」，不對調為買／賣名稱，也不是完整DeMark Countdown 13／price-flip／perfection算法。第三方只叫TD9的值不可盲接。若使用者原先口語「高低TD9」想表達別種公式，另列新候選，不改F。**S1未指定的EMV3,3算法由本版已核准P方法補足，依B06實作；不聲稱與其他歷史producer逐值相容，該相容性須另測。**

### TECH 3. 結構選擇器與事件狀態機（全部新增處標P）

#### TECH 3.1 支撐／壓力與擺動串

- `latestHighAt(s,w)`：在s時已confirmed且可用、pivot index∈[s−w,s]的最近一個High pivot；按pivot index最大選取；Low對稱。**P w=20日**；不存在可比pivot→UNKNOWN/NO_ELIGIBLE_REFERENCE，不設0。
- 交叉在t使用`latestHighAt(p,20)`固定P；`C_p≤P AND C_t>P`。支撐跌破對稱`C_p≥P AND C_t<P`。p時尚未confirmed的pivot即使t確認，也不能反推昨天已知level。
- **P normalized swing sequence**：只使用截至τ已confirmed raw pivots；按pivot index排序；同一bar同時High與Low且落入所需配對範圍→該結構UNKNOWN/AMBIGUOUS_INTRABAR_ORDER（不猜先高後低）。相鄰同類pivot保留更極端者（High較高、Low較低；相等保留後者）；直到交錯。每次τ保存其當時版本，不回改歷史輸出。
- **P四pivot HH/HL**：最新4個正規化pivot必須是H1,L1,H2,L2或L1,H1,L2,H2；各pivot距t≤60且最後pivot距t≤20；`H2>1.01H1 AND L2>1.01L1`。缺4個／必要範圍內雙pivot→UNKNOWN；資料完整但比較不成立→FALSE。這個1%是「明顯」核准解釋，不是官方noise band。
- **P可比較RSI高點對**：最新兩個raw confirmed price Swing High a<b，a距t≤60、b距t≤20、b−a≥5；使用**同根price pivot的RSI值**。只有H_b>H_a才構成創高比較；RSI_b≤RSI_a為本版bearish divergence，RSI_b>RSI_a為該pair未背離。非創高pair／缺pair→UNKNOWN，不從「沒找到」推出無背離。不是獨立RSI pivot配對算法。

#### TECH 3.2 固定episode契約

所有episode保存`episode_id, parent_event_id, reference_id, immutable_level, created_at, start_session, deadline_session, latest_state, terminal_reason`；同一parent_event不重建。PENDING不給成功票；終止後不復活；新cross才新episode。同一session若失敗與成功條件同時看似成立，按下面明文優先序；OHLC不證盤中先後，依收盤判定。

| Episode | 已核准規則P | TRUE時點／終止 |
|---|---|---|
| RETEST | 承接TECH 4.1 R9水平突破b、固定P。只看b+1…b+10。首個`L_j≤1.005P AND H_j≥0.995P`為觸及j；任何i∈[b+1,k]有`C_i<0.99P`先FAILED。觸及後在j…min(j+2,b+10)首個`C_k≥P AND C_k>C_(k−1)`為成功；若觸及前已失敗不再找j。 | k根收盤資料可用才SUCCESS_EVENT；之後同episode FALSE/TERMINAL_SUCCESS，不永久TRUE。觸及後最後允許bar仍不成功→FAILED；b+10無觸及→EXPIRED；期限當根先檢驗合法成功再判過期 |
| NO_QUICK_RECLAIM | 在b−1選latestLowAt(b−1,20)=P；`C_(b−1)≥0.99P AND C_b<0.99P`開episode。b…b+3任一C_i≥P→RECLAIMED/FALSE；全四根C_i<P且資料完整，b+3發NO_RECLAIM_EVENT。 | b至b+2 PENDING/UNKNOWN；b+3事件一次；不把結論回填b；缺bar→UNKNOWN/INVALIDATED_DATA，不當未收復 |
| POST_HIGH_TD9 | high first9發生e，P=max(H_(e−8:e))；只e+1…e+9找第一個C_t>P；期間若low first9已出現，先INVALIDATED；成功一次後終止。 | C6在首次成功t TRUE；無事件且完整可觀察窗FALSE；沒有足夠first9歷史UNKNOWN。無cache保守需最近23個Close及episode相關H，才能完整搜尋最近9根的first9 |
| FAILED_BREAKOUT | 承接同一R9突破b、P；b+1…b+5首根`C_t<0.995P`為失敗事件；等於不失敗。沒有失敗到b+5→EXPIRED_NO_FAILURE。 | 失敗t TRUE一次；窗口尚未失敗時**FALSE（「失敗是否已發生」）**，不是預測最終成功；缺必要價格UNKNOWN。與RETEST不同，R10問尚待成立的成功，故PENDING處理不同 |

上述Retest與Failed breakout可描述同一突破的不同結果；它們分屬不同向量、不同t的事件，不允許同一event用兩個別名重複投票。明顯新低episode是否同時有別的支撐已破，只保留各自reference；不改舊P。

**P多episode聚合與冷啟動**：RETEST、NO_QUICK_RECLAIM、FAILED_BREAKOUT可各自保留多個不同parent_event的有限期episode；按每個不可變P獨立推進，槽位輸出是當根所有合格episode結果的三值OR，最多一票。已terminal episode其後只留審計，不反覆TRUE。沒有episode且完整回放所需父事件窗口時FALSE；父事件窗口不完整時UNKNOWN，不由空清單推FALSE。RETEST父事件搜尋b∈[t−10,t−1]、NO_QUICK_RECLAIM b∈[t−3,t]、FAILED_BREAKOUT b∈[t−5,t−1]；重播須取足建立父事件reference的更早Swing資料，不能只截取這幾根。POST_HIGH_TD9則只保留最近一次high first9的episode；新high first9取代舊episode，低first9先取消，成功過的不再出第二次事件。當根RETEST／NO_QUICK_RECLAIM／FAILED_BREAKOUT處理順序為資料合法性→已有episode失效／成功→期限終止→建立當根新parent的episode；新breakout不可同根當retest。POST_HIGH_TD9例外先處理當根first9：low first9取消舊episode；high first9取代舊episode且當根只建立新episode，C6不能引用同根已被取代的舊e發成功；沒有新first9才評估既有episode的後續新高。若某完整未到期episode無觀察資料則UNKNOWN；其他episode已有成功TRUE仍依OR可TRUE。

### TECH 4. 原五向量完整32槽位與附加Entry

所有技術槽位預設DAILY；週月不額外疊票。表中「S」是當根state、「E」是當根event、「EP」是episode結果。事件除明列外僅t根TRUE，次根若無新事件即FALSE；沒有全套必要觀察則UNKNOWN。每列的P參數已明定，非「待AI判斷」。

#### TECH 4.1 Right確認：R1–R10

| ID／欄位 | 可實作完整實作定義 | F繼承／P新增；型態 |
|---|---|---|
| R1 higher_low | 最近兩個raw confirmed Low a<b，a距t≤60、b距t≤20；`L_b>L_a` | F較後前低較高、confirmed；P60/20有效期；S |
| R2 kd_golden_cross | TECH 2.1 golden公式 | F不等式；P使用B03明選SMA序列；E |
| R3 macd_bear_hist_shrinking_or_positive | `(Hist_t<0 AND Hist_p<0 AND abs(Hist_t)<abs(Hist_p)) OR (Hist_p≤0 AND Hist_t>0)` | F空方縮短／翻正；P明確翻正是event，不是持續正值；S或E，每槽最多一票 |
| R4 dif_up | `DIF_t>DIF_p` | F上彎相鄰completed比較；P B04 seed；S |
| R5 emv_turns_positive | `E_p≤0 AND E_t>0` | F原文轉正；P明選cross而非舊欄名positive持續state、B06方法；E |
| R6 rsi_improving_or_near_50 | `45≤RSI_t≤55` OR `30≤RSI_(t−3)<RSI_(t−2)<RSI_p<RSI_t≤50` | F30–50改善；P附近±5與3次嚴格上升（4值）；S。52即使下降亦可TRUE，因為OR |
| R7 ma20_reclaim | `C_p≤MA20_p AND C_t>MA20_t` | F站回cross；P明確舊above名稱不能代表一直站上；E |
| R8 descending_line_volume_breakout | p已知最近兩個High pivot a<b；p−a≤60、b−a≥5、H_b<H_a。`line(i)=H_a+(H_b−H_a)(i−a)/(b−a)`。從b確認session至p每個C_i≤line(i)，且`C_p≤line(p) AND C_t>line(t) AND q_t≥1.5`。 | F下降趨勢放量突破意義；P線選取、60/5、1.5、既破線不得重用；E。線不存在UNKNOWN |
| R9 recent_pressure_breakout | p已知`P=latestHighAt(p,20)`；`C_p≤P AND C_t>P` | F突破壓力；P以最近confirmed High、20根作明確壓力代理；E |
| R10 breakout_retest_success | TECH 3.2 RETEST成功當根 | F原回踩成功語義；P全部容差／期限／順序；EP |

**P附加`off_low`**：取`latestLowAt(t,20)=P`，且`C_t≥1.01P`才TRUE；恰1%成立，缺reference UNKNOWN。這是「已離開最低點」的核准代理，既不是全歷史最低也不是F數值。Right技術entry=`off_low AND threshold_dedup(R,3)`；完整Right仍須由正式Owner提供Fundamentals、Credit/Liquidity、安全、非RD及估值等，不以本稿OHLCV補出TRUE。

#### TECH 4.2 Runaway Up價格：U1–U3

| ID／欄位 | 完整實作定義 | F／P；型態 |
|---|---|---|
| U1 new_20d_close_high | `C_t>max(C_(t−20),…,C_p)`；需要21 closes；相等FALSE | F20日收盤新高；P選「前20不含t」與strict tie；E-like當根新高，可連日各自創高 |
| U2 break_confirmed_swing_high | 原Owner若已指明合法P就用該P；**本規格無另指定時**用latestHighAt(p,20)；`C_p≤P AND C_t>P` | Fconfirmed High與cross；P缺具名level時的核准selector，不覆寫正式P；E |
| U3 higher_high_higher_low | TECH 3.1四pivot，H2>1.01H1且L2>1.01L1 | F HH/HL敘事；P交錯、窗口、1%；S |

#### TECH 4.3 Runaway Up確認：C1–C8

| ID／欄位 | 完整實作定義 | F／P；型態 |
|---|---|---|
| C1 kd_high_sustained_not_breaking | i=t−2…t皆`K_i>80 AND D_i>80`，且`K_t≥D_t AND K_t−K_p≥−10 AND D_t−D_p≥−10` | F80高檔及非死叉崩落；P雙線3根、當根位置、最多跌10點；S |
| C2 macd_bull_hist_expanding | `Hist_t>0 AND Hist_p>0 AND Hist_t>Hist_p` | F同正號擴張；P B04 seed；S |
| C3 ma5_gt_ma10_gt_ma20 | `MA5_t>MA10_t>MA20_t` | F原Runaway三MA鏈，不擴為五MA；S |
| C4 emv_positive_or_improving | `E_t>0 OR E_t>E_p` | F正值／改善；P B06方法；S。已知E_t>0可不被缺p污染 |
| C5 price_volume_healthy | i=t−4…t，`U=ΣV_i·1(r_i>0)`，`D=ΣV_i·1(r_i<0)`；`n_up≥2 AND U≥1.2D AND NOT EXISTS i:(r_i≤−0.01 AND q_i≥1.5)` | F量價健康語義；P5根、2上漲、1.2、−1%／1.5；S。D=0按不等式，不除零；全部平盤FALSE |
| C6 high_td9_then_new_high | TECH 3.2 POST_HIGH_TD9成功事件 | F先完成高TD9後創高；P九根setup最高H、後9根壽命、首次及反向取消；EP |
| C7 rsi_high_no_divergence | `RSI_t>70 AND highPairComparable AND RSI_b>RSI_a`，highPair依TECH 3.1 | F高檔與confirmed可比結構；P同步RSI配對及相等視為未創高；S。RSI≤70可FALSE，缺pair且RSI>70則UNKNOWN |
| C8 eps_guidance_not_worse | 個股：相同issuer、target fiscal period、currency、GAAP／adjusted basis的最新適用官方EPS指引[lo_new,hi_new]及前版；兩端均≥前版才TRUE；撤回FALSE；任一端降低FALSE；缺同目標可比版本UNKNOWN。點值視為lo=hi。 | F基本面／財測非技術依賴；P採雙端不下降窄定義，非所有基本面安全；S。ETF適用性見TECH 7 |

`MA20_OK`：`C_t≥0.99MA20_t`（MA20>0）；F「未明顯跌破」；P1%收盤容差已正式核准，**不是0.25ATR**。Up=`threshold(U,1) AND threshold_dedup(C,3) AND MA20_OK`。正式`ma20_ok`在輸入合法及實作驗證後按此1%公式產生TRUE／FALSE；真實必要輸入不足才依三值為UNKNOWN，不得因舊Candidate標籤拒算。Up接入CMR 7正常模式裁決，仍須全部適用依賴，不是技術單項直接取得Trend或交易許可。

#### TECH 4.4 Runaway Down結構：D1–D3

| ID／欄位 | 完整實作定義 | F／P；型態 |
|---|---|---|
| D1 keeps_breaking_lows | 對i=t−2,t−1,t，皆`C_i<min(C_(i−20),…,C_(i−1))`；23個連續Close；相等不破低 | F持續破前低；P三根各創前20收盤新低，明確不用盤中Low或未確認pivot；S |
| D2 break_confirmed_swing_low | p時合法原Owner指定P；本規格未指明時latestLowAt(p,20)；`C_p≥P AND C_t<P` | Fconfirmed Low及cross；P核准selector；E |
| D3 break_support_no_quick_reclaim | TECH 3.2 NO_QUICK_RECLAIM事件 | F明顯破重要支撐且未快收復；P重要=latestLow、1%破線、3根等待；EP |

#### TECH 4.5 Runaway Down加速：A1–A8

| ID／欄位 | 完整實作定義 | F／P；型態 |
|---|---|---|
| A1 macd_bear_hist_expanding | `Hist_t<0 AND Hist_p<0 AND abs(Hist_t)>abs(Hist_p)` | F同負號擴張；P B04 seed；S |
| A2 kd_low_weak | i=t−2…t雙線均<20；`K_t≤K_p≤K_(t−2)`、`D_t≤D_p≤D_(t−2)`、`K_t≤D_t`，且`K_t<K_(t−2) OR D_t<D_(t−2)` | F低檔續弱；P3根非增＋至少一線累計下降；S。低檔全平FALSE |
| A3 emv_worsening | `E_t<E_p<E_(t−2)<E_(t−3)` | F持續惡化；P三次嚴格下降，不強迫已負；B06方法；S |
| A4 rsi_falling | `RSI_t<RSI_p<RSI_(t−2)<RSI_(t−3)` | F續跌；P三次嚴格下降；S |
| A5 price_down_volume_up | `C_t<C_p AND V_t>VolMA20_t`；等於均量FALSE | F價跌量增及20均量比較；P明選inclusive20基準，不混q或前bar量；S |
| A6 atr_expanding_fast | `ATR_t/ATR_(t−5)≥1.20 AND ATR_t>ATR_p`，基期>0 | F ATR14；P5根增≥20%且最新仍增；S。ATR非方向，不獨立認定跌勢 |
| A7 decline_accelerating | `R_old=C_(t−5)/C_(t−10)−1`，`R_new=C_t/C_(t−5)−1`；`R_old<0 AND R_new<0 AND R_new≤R_old−0.02` | F跌速加快；P相鄰不重疊5session報酬、至少加深2百分點；S |
| A8 rebounds_weaker | 取截至t最新3個已完成且相鄰的normalized Low→High腿L1,H1,L2,H2,L3,H3；可忽略H3後尚無High的最後一個Low。6 pivot距t≤90，H3距t≤20；每Hj>Lj；`a_j=H_j/L_j−1`；`a3<a2<a1 AND a3≤0.8a1`。 | F反彈一次比一次弱；P3次腿、90/20、最後較首次至少少20%幅度；S。無3腿UNKNOWN；3腿完整而不遞減FALSE |

Down=`threshold_dedup(D,1) AND threshold_dedup(A,2)`。不把任何ATR／RSI／TD9一項單獨變成Down。Up與Down同TRUE仍沿正式INVALID→SAFE／Reconcile語義，技術模組只能報衝突，不能下單或自設sell。

**P事件型有效期的必要反例**：D2/D3只有cross／未快速收復事件當根TRUE，不因仍處支撐下永久沿用。如果t時D2 TRUE、D1/D3 FALSE且A≥2，Down TRUE；t+1沒有新D2/D3、D1仍FALSE，即使價格仍在支撐下及A≥2，Down亦可FALSE。這是本稿明示的event-slot核准政策，不是「風險已修復」證明；正式Reduction／Hard Gate／Recovery episode一律不由它解除。若未來模式需持續RD狀態必須另事前核准state-slot契約，不能暗自沿用舊TRUE，也不能把本稿event FALSE作Recovery PASS。

### TECH 5. 補齊原技術減碼9項與左側成熟度8項

#### TECH 5.1 技術減碼S1–S9：核准條件≠賣出權限

F同輪至少3個有效既有訊號；P各敘事實作及去重見TECH 8。這不是B-3 Structural Break後的速度機器，也不啟用其「MACD連續2根」候選。

| ID | 完整公式 | F／P與型態 |
|---|---|---|
| S1 高TD8–9 | `HighTD_t∈{8,9}` | F8–9，S；不使用Low分數 |
| S2 KD死叉 | TECH 2.1 death | F交叉，P B03；E |
| S3 MACD多方柱連續縮短 | `Hist_(t−3)>Hist_(t−2)>Hist_p>Hist_t>0` | F多方柱持續縮短；P3次縮短（4值），**不等於B-3連續2根**；S |
| S4 EMV轉弱 | `E_t<E_p` | F相鄰falling；P B06；S |
| S5 RSI背離 | TECH 3.1 highPairComparable且`RSI_b≤RSI_a` | F需confirmed可比結構；P同步配對及相等不創高；S；非創高pair UNKNOWN |
| S6 爆量不漲 | `q_t≥2 AND abs(r_t)≤0.005 AND C_t≥0.95*max(C_(t−20:p))` | F高檔爆量不漲；P前20均量倍數2、±0.5%、距前20高≤5%；S |
| S7 跌破MA10／20 | `breakdown10 OR breakdown20` | F原二者任一；P同槽最多1票，即使兩者皆TRUE；E |
| S8 突破前高失敗 | TECH 3.2 FAILED_BREAKOUT事件 | F原失敗語義；P固定R9前高及5根／0.5%；EP |
| S9 極高估值＋技術轉弱 | `formal_extreme_valuation_context AND C_t<MA50_t AND MA50_t<MA50_(t−5)`；需55個Close | F原合取敘事及獨立S9槽位；P技術同步弱化明選「收盤低於MA50且MA50較5根前下降」，不OR複用S2–S8；S。估值單項不成立此票 |

S9的Extreme必須來自適用正式估值Owner，不以PE≥23通套十一類。`EXTREME_CANDIDATE`是既有正式業務Enum，名稱與本文件採用狀態無關，必須原樣保留。完整技術減碼Classification／Primary／Sell Permission、核心持有處理仍由原Owner消費本章訊號，不由技術模組越權決定。

#### TECH 5.2 左側技術成熟度M1–M8：只輸出描述／證據，不創速度分數

| ID | 完整實作定義 | F／P |
|---|---|---|
| M1 低TD成熟 | `LowTD∈{5,6,7,8,9}`；另保留F每count原score與×4，不將高TD映射此分數 | F原Low評分；P左側「成熟」核准集合5–9，非所有Low都成熟 |
| M2 KD止跌／golden | golden OR `(K_(t−2)≥K_p AND D_(t−2)≥D_p AND K_t>K_p AND D_t≥D_p)` | F止跌／交叉敘事；P止跌轉折的精確3根形式；同槽最多1票 |
| M3 MACD空方縮短 | `Hist_p<Hist_t<0` | F同負號縮短；P seed |
| M4 DIF上彎 | R4 | F，別名不增票 |
| M5 EMV改善 | `E_t>E_p` | F相鄰改善；P B06 |
| M6 RSI回升 | `RSI_t>RSI_p` | F回升；P用相鄰嚴格>而非R6持續改善 |
| M7 價格2–3日不破低 | **P選3根**：`L_(t−2)≤L_p≤L_t`，且`C_t≥C_(t−2)` | F2–3日敘事；P選3、最低不下降及收盤不弱於起點；不要求Swing已confirmed |
| M8 價跌量縮／止跌K | `(C_t<C_p AND V_t<VolMA20_t)` OR `(H_t>L_t AND C_t≥O_t AND (C_t−L_t)/(H_t−L_t)≥0.75 AND L_t<min(L_(t−5:p)))` | F原敘事；P量基準及止跌K定義，O必要但只污染此分支；本槽兩分支不重複算 |

F LowTD score count1…9依序0.5/0.8/1/1.5/1.8/2/2.5/3/4，乘4後2/3.2/4/6/7.2/8/10/12/16；已知0為0，UNKNOWN分數UNKNOWN，High buy score N/A。本稿不將M1–M8加權成「安全」、不以count切SLOW/NORMAL/ACCELERATED，更不改九階目標或補足率。正常Buy速度由CMR 8的已核准規則消費M1–M8；不是本技術模組另造加權分數或隱藏輸出。

### TECH 6. 日週月趨勢Classifier與衝突矩陣

**F**三週期角色與組合名稱來自工程26，沒有從母規則查到統一Bullish/Bearish數值公式。以下為**P `TREND_C_MA20_SLOPE_MACD_V1`**：每個timeframe獨立計算。

- `bull_f=(C_f>MA20_f) AND (MA20_f>MA20_(f−1)) AND (DIF_f>DEA_f)`。
- `bear_f=(C_f<MA20_f) AND (MA20_f<MA20_(f−1)) AND (DIF_f<DEA_f)`。
- 任一TRUE對應BULLISH／BEARISH；兩者皆FALSE→MIXED_KNOWN；都不能可靠排除且無TRUE→UNKNOWN。公式上bull與bear不應同TRUE，同TRUE→INVALID_INPUT，不猜方向。MIXED_KNOWN不是UNKNOWN也不是中性安全。
- 最少34個完整period可取得當前DEA與MA斜率；週是34週、月是34月，不拿34日替代。上市不夠34月，月趨勢UNKNOWN但日線事實仍保留。

| Daily／Weekly／Monthly | 輸出名稱 | 歸屬 |
|---|---|---|
| BULLISH／BULLISH／BULLISH | MULTI_TIMEFRAME_BULLISH_CONFLUENCE | F矩陣；P方向classifier |
| BEARISH／BULLISH／BULLISH | LONG_TERM_UPTREND_SHORT_TERM_CORRECTION | F矩陣；P方向classifier |
| BULLISH／BEARISH／BULLISH | COUNTERTREND_REBOUND_IN_MEDIUM_WEAKNESS | F矩陣；P方向classifier |
| BEARISH／BEARISH／BEARISH | MULTI_TIMEFRAME_BEARISH_CONFLUENCE | F矩陣；P方向classifier |
| 其他全已知（包括MIXED_KNOWN） | MIXED_TIMEFRAME | F其他混合；P擴展到明知混合方向 |
| 任一必要timeframe UNKNOWN | PARTIAL_CONTEXT；保存各自已知狀態，完整三週期confluence UNKNOWN | F局部UNKNOWN，不假PASS |

週／月不增添Right／Runaway技術票、不覆寫日Entry，不建立Hard Gate。若未來另測不同trend classifier，改method_id並重新驗證，不事後選最漂亮者。

### TECH 7. 非技術必要依賴的完成接口

「技術規格完成」不意味OHLCV可以創出基本面事實。以下接口明定處理，並非填一個TRUE占位。

| 依賴 | 實作規格的精確處理 | F／P |
|---|---|---|
| C8個股EPS指引 | TECH 4 C8；每筆需issuer、target period、announcement timestamp、currency、basis、lo/hi及withdrawal；P有效到target period_end後第一份同target actual發布、或官方withdrawal、或替換指引，取最早。找不到前版同target則UNKNOWN；沒有發指引不是「未惡化」 | F外部Fundamental來源；P雙端及有效期 |
| C8股票ETF | P輸出N/A_ASSET_NOT_ISSUER，**正式計數中不貢獻TRUE且不降低≥3門檻**；不把成分公司指引臨時平均成ETF指引。若正式Owner已有ETF等價producer，須保留其formal applicability／contract並另映射，不得以本版N/A覆寫已有合法等價producer的原值 | F ETF基本面不同；P非issuer排除此票、其餘7票仍可達3。此規格是已核准適用性定義，保留既有正式等價producer的優先權 |
| Fundamentals／Credit-Liquidity／Hard Gate／Runaway風險 | consumer接受原Owner帶source/coverage/as_of的三值；缺或未知→依必要依賴傳播，不用技術替代。相同snapshot_id、τ，UNKNOWN不得默認安全 | F既有Owner邊界 |
| S9 Extreme／Right估值限制 | 接合法Valuation Owner enum／predicate與metric applicability，拒絕將單一PE門檻套全部資產 | F既有Owner邊界 |
| News／Safety coverage | 不新增情緒票；只接已批准coverage contract及active/pending重大事件。缺contract→UNKNOWN，不能靠「24小時沒新聞」通過安全 | F正式Safety Owner；P明確不把前稿24h工程候選當安全 |
| Stage／速度／下單 | 本模組的count/context與predicate接入第5章正式Mode、Stage與速度依賴；最終輸出由對應Owner計算，不以技術全TRUE直接推Stage9；不自動送單 | F權責；P已核准整合接口 |

### TECH 8. 去重、三值threshold與可追溯輸出

#### TECH 8.1 兩層去重（F禁止別名重複；P確切key）

1. **同canonical槽位最多一次**：provider別名如`MACD_golden`與`Hist_turns_positive`同一事件；`above_ma20`不能另外添R7一票；`kd_gold`與`kd_golden_cross`相同；S7同日跌破MA10與MA20只一票。
2. **不以相關性擅改正式槽位**：R8是下降趨勢線＋量能，R9是水平壓力cross；母規則明列兩個canonical訊號，未查得正式alias registry宣告兩者相同。因此各自條件成立可各一票，同日／共用Close不構成自動合併理由；另報`CORRELATED_PRICE_EVIDENCE`，不能偷偷降低票數。如果adapter其實將同一個R9值複製成R8、卻沒有R8獨立線／量證據，R8不得算TRUE，應UNKNOWN/MISSING_R8_EVIDENCE。R10是後來獨立retest結果。
3. R3與R4雖同源MACD，但母規則明列為不同canonical特徵（Histogram轉變與DIF斜率），保留各一票，不把「共用Close」誤當所有技術只能一票。C2、C3等同理。
4. S9保留原第九canonical槽，使用本稿獨立MA50位置／5根斜率的P條件，不用「任何S2–S8為真」再生一票。若實際證據包只複製其他slot且沒有S9指定條件，不得算TRUE。technical-reduction仍按S1–S9每槽至多一票及原≥3；canonical不同與證據互相關聯要分清，後者另報，不改門檻。
5. 不把不同向量的票加成總票：R9與U2可引用同一parent_event_id，但Right及Up分別達其門檻，不報「2個獨立事件」；C6同時支援Up價格背景也不增加一個新U槽。
6. 上游來源有衝突且未裁決，不OR兩來源挑TRUE；先把該槽置UNKNOWN/SOURCE_CONFLICT。重抓或同新聞轉載不是新source fact。

#### TECH 8.2 Threshold

在**固定manifest先完成alias/group解析**後，已知TRUE組數T、UNKNOWN組數U，門檻k：T≥k→TRUE；T+U<k→FALSE；否則UNKNOWN。N/A票在本規格明示applicability下不貢獻T或U，門檻不變；正式consumer對N/A的既有契約優先，本稿不直接改它。

所需manifest必須包含全部32槽及其group，不能刪掉UNKNOWN後聲稱完成。每組truth OR按三值，不用缺資料預設FALSE。需要未知reference時key仍能依canonical group生成，不能因「不知key」重複加UNKNOWN。

#### TECH 8.3 每項輸出必填

`research_method_id, method_version, formal_rule_ref, origin_F_or_P, approval_status, asset_id, listing_id, timeframe, τ, segment_id, seed_session, evaluated_session, data_as_of, expected_latest_completed_period, available_at_max, source_ids_and_digests, formula_parameters, state/event/episode, truth, numeric_inputs, dependency_ids, evidence_ids, dedup_group, reason_codes, episode_id, confirmed_at, calculation_timestamp`。

規則manifest另保存所有P常數：KD_SMA/flat50；EMV3×3/scale1e8；EWMA seeds；RSI45–55/3rise；MA20 .99；R1/结构60/20；R8 60/5/1.5；Retest .995/1.005/.99/10/2；TD9post9；U1 prior20；U3 1.01；C1 3/80/−10；C5 5/2/1.2/−.01/1.5；D1 3×prior20；D3 .99/3；A3/A4 3 declines；A6 5/1.20；A7 5+5/.02；A8 3legs/90/20/.8；S3 3 contractions；S6 2/.005/.95/20；S8 5/.995；S9 MA50/5bar slope；off_low1.01；trend MA20+MACD。**常數全部寫入版本，不容runtime LLM臨時改閾值。**

### TECH 9. 驗收邊界清單（規格級expected，尚非正式程式整合PASS）

下表除「必需」另外說明，其他輸入均合法且已完整。TRUE/FALSE是該指定predicate；UNKNOWN附reason。每個P切點需測`below / equal / above`，Decimal測試用精確小數。

| Case | 輸入／事件 | Expected |
|---|---|---|
| T001 | 13個嚴格遞增Close，最近9個t−4比較皆正，無cache | High count9；Low0；**first9 UNKNOWN**，不能說首次 |
| T002 | 14個嚴格遞增Close，前根與本根count均9 | 本根first9 FALSE；持續9不重建episode |
| T003 | 已知High8，本根C=C_(t−4) | High0、Low0；不是UNKNOWN |
| T004 | 只有V缺失、Close連續13根 | TD9可知；EMV／量價依賴UNKNOWN；不全報告清零 |
| T005 | 最高／最低相等於任一相鄰2根 | 不是strict pivot；若缺右側第二根，狀態PROVISIONAL而非confirmed |
| T006 | pivot i、τ在i+1收盤後／i+2資料可用後 | 前者不可用；後者才可用，禁止回填i |
| T007 | KD p K=D=20，t K21,D20 | golden TRUE；t oversold FALSE；20不算<20 |
| T008 | KD t K=D=80 | golden/death FALSE；overbought FALSE；C1 FALSE |
| T009 | 連續9根HH9=LL9且OHLC合法 | RSV50；K/D須各自滿3樣本才合法；不直接從第9根宣布D50 |
| T010 | MACD 33／34／35個Close | 分別Hist UNKNOWN／首次Hist合法但前後cross輸入尚未全齊，按Kleene：當根嚴格交叉條件已FALSE可直接FALSE，否則UNKNOWN／cross輸入完整；34根全平Close時golden與death均FALSE，不可提前seed DEA |
| T011 | Hist p=−1,t=+0.1 | DIRECTION_SWITCH、golden TRUE；C2與A1皆FALSE；不是同號擴張 |
| T012 | Hist p=−1,t=−0.5／−1／−1.1 | R3 TRUE／FALSE／FALSE；A1 FALSE／FALSE／TRUE |
| T013 | 收盤恰MA20／前根恰MA20後本根高於 | 第一個ABOVE FALSE、AT TRUE；第二個reclaim TRUE |
| T014 | MA20=100，C=99／98.999 | MA20_OK TRUE／FALSE |
| T015 | EMV range0,V>0／V=0 | rawEMV0／UNKNOWN；不把無量除零當0動能 |
| T016 | RSI只有14／15 closes；全平、全升、全跌 | 前者UNKNOWN；後者依序50／100／0 |
| T017 | RSI=30／70 | neither oversold nor overbought；70退出overbought只在p>70才事件 |
| T018 | RSI=45、55、55.001；及52但較p下降 | R6 TRUE、TRUE、FALSE（若另一分支不合）、TRUE |
| T019 | RSI30,35,40,45／30,35,35,45 | improving TRUE／FALSE；第二個整體R6仍因near50 TRUE，需測分支與整體 |
| T020 | U1前20最高100，t=100／100.001 | FALSE／TRUE；只20總根不足→UNKNOWN |
| T021 | p時High未確認、t新確認，C跨它 | 不以該新pivot作當根U2/R9的p已知level |
| T022 | HHHL H2=1.01H1且L2>1.01L1 | U3 FALSE（strict>）；reference不足4 pivot UNKNOWN |
| T023 | 突破P100；回踩L99.5,H100.5，C100且>Cp | band含邊界；b+1之後可R10成功；b同根不可回踩 |
| T024 | Retest某根C98.999且當根價格range觸帶 | 先FAILED；永不成功；C=99恰失敗線不觸發<99 |
| T025 | Retest j=b+9，b+10成功／b+11才成功 | 前者成功；後者超10根不接受，不能多給j+2 |
| T026 | first9 e後C_e>P?／e+9首次C>P／e+10首次C>P | e不算「之後」；e+9 TRUE；e+10 FALSE/EXPIRED |
| T027 | 高點H_b>H_a、RSI_b=RSI_a，RSI_t>70 | C7 FALSE；S5 TRUE；沒有高點pair則兩者UNKNOWN |
| T028 | KD最近3根兩線皆10完全平 | A2 FALSE；不是續弱；一線累計下降且其餘條件合可TRUE |
| T029 | ATRt=1.20×ATR_(t−5)，且ATRt>ATRp | A6 TRUE；基期ATR0 UNKNOWN；上漲引起ATR擴張也不能單項RD |
| T030 | R_old=−.03,R_new=−.05／−.0499 | A7 TRUE／FALSE；兩者任一≥0 FALSE |
| T031 | 3次反彈幅度10%、9%、8% | A8 TRUE；最後8.01%則不滿≤.8×10% FALSE |
| T032 | D3 b破線，b+2尚未收復 | PENDING/UNKNOWN；b+3四根皆<P才TRUE；中間C=P則RECLAIMED/FALSE |
| T033 | A5 V=VolMA20，價格下跌 | FALSE；q>1不等於任意「爆量」門檻 |
| T034 | 19根V100＋當根V200 | inclusive20=105、ratio=200/105；exclusive q需另一根前史，不能拿105冒充100 |
| T035 | C5最近5全平盤、量有效 | n_up0→FALSE；D=0不除零 |
| T036 | S3四根正Hist 4,3,2,1／4,3,2,0 | TRUE／FALSE；第二個是零軸事件不是全正縮短 |
| T037 | S6 q2、abs(r).005、C=.95×prior20max | TRUE（三條含等號）；任一超出相應邊界FALSE |
| T038 | 同日breakdown MA10和MA20；同golden的兩個別名 | S7只1票；golden只1個canonical事件 |
| T039 | R8有獨立線／量證據且R9有水平壓力證據，同日皆TRUE，其他R全FALSE | 兩個canonical票；Right≥3仍FALSE；僅R9值改名R8但無線／量證據時R8 UNKNOWN而非第二個TRUE |
| T040 | threshold k3：T3,U5／T2,U1／T1,U1 | TRUE／UNKNOWN／FALSE |
| T041 | S2、S7 TRUE，Extreme TRUE但S9的MA50條件FALSE／UNKNOWN／TRUE，其他S FALSE | 減碼threshold分別FALSE／UNKNOWN／TRUE；不得僅因S2/S7而令S9 TRUE |
| T042 | C8下界由1降.9、上界由2升2.2 | FALSE，即使midpoint增加；新財年與舊財年不得比較 |
| T043 | C8 ETF沒有issuer guidance | N/A且不降低≥3；不宣稱ETF安全或將UNKNOWN全置FALSE |
| T044 | 日週月D bull,W bear,M bull／M資料不足 | COUNTERTREND_REBOUND…／PARTIAL_CONTEXT，不填Bull |
| T045 | 週四資料齊全但週五預期開市且未收盤 | 本週不完整；用前一完整週，另保留本週PROVISIONAL |
| T046 | 週五官方休市、週四為本週最後session且齊全 | 週四完成可產本週bar；不能強制等週五有假bar |
| T047 | 月末尚未到最後交易session／IPO月中首月 | 未完成月不入；IPO首不完整月依P排除 |
| T048 | 加入τ之後新聞、bar、公司行動更正 | 不改原AS_KNOWN_AT_τ的predicate／episode／count |
| T049 | 拆股日raw價格減半但無完整事件coverage | 受影響結構UNKNOWN，不直接判跌勢；修復仍另vintage |
| T050 | 缺週資料但日signal足夠、正式Owner未要求週確認 | 保存日事實；不把全部日signal歸UNKNOWN；正式資格另Owner裁決 |
| T051 | source基準相同但ema seed_session不同 | 不宣稱逐值等價；method/seed mismatch拒絕混接 |
| T052 | lower evidence source與higher source衝突且未裁決 | 槽UNKNOWN/SOURCE_CONFLICT；不能選較有利者 |
| T053 | t的D2 TRUE、D1/D3 FALSE且A≥2；t+1無新D2/D3、D1 FALSE、A仍≥2 | Down由TRUE轉FALSE（event政策）；不等於正式Recovery或解除Hard Gate；不得暗沿舊D2 TRUE |

### TECH 10. 交接、驗證與完成的準確邊界

1. **設計已補齊**：32槽＋2個Entry條件、9個減碼槽、8個成熟度槽、11個primitive、日週月完成bar與trend、事件狀態機、去重、seed/warm-up、53個具名邊界驗收案例；不存在用「AI綜合判斷」才能算的技術門檻。
2. **直接按稿實作及整合**：完成manifest、primitive、episode、dedup及53個fixture；以固定輸入驗證同seed重播／prefix invariance／Decimal邊界，通過後接入對應正式Owner。測試環境用於驗證，不是永久研究限定；本文件本身不等於工程測試已PASS。
3. **資料及效度證據另行取得**：接入合法PIT OHLCV、calendar、公司行動、EPS／估值Owner輸入；按時間外樣本／跨市場與產業／不同波動分層測性能及敏感度。不得在看結果後改參數卻沿用原version。
4. **本章採用批准已完成**：KD平滑、EMV3,3算法、EMA／RSI／ATR seed、state/event、期限、S9技術弱化與去重映射、ETF C8 applicability、Bull/Bear classifier及所有P常數均按本文實作，毋須再次逐項請准。與歷史producer的逐值相容及正式整合仍需測試；批准不等於策略獲利。
5. **跨章接口**：Price Map五層數值、十一估值模板、基本面／新聞證據、Macro／Credit／Liquidity、Stage逐階政策、補足速度、資金／FX／下單分別依本包具名契約或版本鎖定正式規則管理。技術規格完整不冒稱整個V82所有Owner已完成實作。

#### TECH 外部交叉查核的窄邊界

ATR的TR包含當根range及與前收盤的缺口；ATR擴張只代表波動，不提供上／下方向，與本稿不讓A6單獨等於Down一致。[Fidelity ATR公式與說明](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr)。**該來源不驗證本稿seed、5根／20%、1%價格帶、1.5倍量或任何交易效度。** EMV3,3的完整P方法是本稿明示核准選擇，不借外部常見EMV14文字宣稱正式公式相容。


<!-- PAGEBREAK -->

## 5 模式風險速度與資金契約

版本 CMR 1.0　2026 年 10 月 28 日台灣時間　已核准供工程實作

本章把宏觀、信用、新聞、基本面、風險優先序、四模式、九階目標與資金輸出接成正式實作契約。**本章新增規則已核准採用；實作、測試、投資效果與交易授權分開記錄。** 既有正式公式與門檻原樣保留；只有語意而沒有數學邊界者，採以下明列的核准定義及精確比較，不由AI臨場打分。本章不提供真實標的的下單指令，不宣稱文件更新已改動線上V82。

### CMR 1 版本與執行邊界

- **FORMAL**：本輪提供的 正式V82主規則 v1.21.0 工程 77 正式封版已有內容。來源定位使用章節及工程號，不把同檔仍標 Candidate 的舊草表升格。
- **APPROVED_SUPPLEMENT**：本章新增可重播、可測試的規則已獲採用。其數字是正式實作預設，不是學術共識、危機機率或已完成效力驗證的宣稱。缺資料或缺producer仍如實報告，不能靠批准補值。
- **INPUT REQUIRED**：公式已完整，但缺少本來必須由客戶、券商、主管機關、公司原件或事前 thesis 提供的事實。例如客戶 Target、契約違約條款、有效授權、現金，不是 AI 應補的參數。
- **APPROVAL COMPLETE**：本版新增規則的採用批准已完成，manifest記APPROVED_FOR_IMPLEMENTATION。不得把尚未測試、資料不足或歷史相容識別碼誤當待批准，不新增正式Enum。

本版profile保留獨立id/version及來源證據；歷史`candidate_profile_id/version`可作相容鍵，但現行approval_status為APPROVED_FOR_IMPLEMENTATION。已有正式可執行定義且本版未明示覆蓋者重用；producer尚未接線則記`producer_missing`並完成實作，不以其他不相同公式冒充。正式整合結果與歷史研究輸出分清，歷史輸出不直接貼成當輪結果。

「可實作」的驗收是：給定同一合法輸入 snapshot、規則版本及事前授權，得到唯一結果；必要資料缺失也得到唯一且可追溯的 UNKNOWN／不新增結果。它不代表所有輸入現在都存在。

### CMR 2 共用三值與具名依賴

FORMAL 沿工程 22：UNKNOWN 不等於 FALSE、0、Neutral 或安全。`FALSE AND UNKNOWN=FALSE`，`TRUE AND UNKNOWN=UNKNOWN`，`TRUE OR UNKNOWN=TRUE`，`FALSE OR UNKNOWN=UNKNOWN`，`NOT UNKNOWN=UNKNOWN`。N-of-K 按正式 canonical signal 去重：T≥K 為 TRUE；T+U<K 為 FALSE；其餘 UNKNOWN。已知結論可以短路，但須保留被短路的未知原因。

每個可執行條件保存以下契約；不得把必要條件藏在 `policy_ok`、`safe_enough`、`blockingBase` 或「綜合研判」裡：

```text
rule_id, owner, source_section, authority=FORMAL|APPROVED_SUPPLEMENT
version, effective_from, input_dependencies[], applies_when
expression_ast, comparison_unit, timeframe, available_at_rule
required_evidence[], persistence_rule, reset_rule
on_true_effects[], on_false_effects[], unknown_consumers[]
```

`expression_ast`只允許可稽核算子：比較、AND／OR／NOT、去重 N-of-K、明定窗口的算術、事前定義狀態轉移、具名 Enum 比較。任何 leaf 若沒有來源、型別或算法，不得編譯成預設 TRUE。空 AND／OR 不能自動通過投資條件；只有正式已確認不適用且准中性處理的維度才可省略。適用性 UNKNOWN 必須保留。

**不建立全域 blockingBase 大串聯。** KD、MACD、新聞 Optional Provider 或非該模式的條件未知，只傳播到真正依賴它們的規則。報告 Required 欄位不等於所有 Buy 的 SAFETY_REQUIRED，也不要求每個指標都為 TRUE。每個輸出另列 `required_input_ids` 及 `decision_relevant_unknown_ids`。

### CMR 3 宏觀輸入與可重播語意

#### CMR 3.1 正式資料入口

FORMAL 工程 32／37.1：同輪重用 V70 已驗證且仍 Fresh 的 Macro Snapshot，保留 Fed／政策傾向、2Y／10Y／30Y、實質利率、CPI／Core CPI、PCE／Core PCE、GDP、Employment、Liquidity Regime、Material Macro Events；PPI、Oil、Breakeven、Consumption、EPS 等原有資料不能因最低集合未列而刪除。V82 不重算 V70 的 S0／B0、C／T 或股票戰術總額度。

單筆訊號至少包含 `value, unit, level, direction, speed, as_of, published_at, available_at, source, method, data_quality, issue_codes`，並保存可比 prior 值及其日期／發布版本。V70 若已給正式 level／direction／speed，直接消費；本版補充不得覆蓋既有定義。snapshot 後有已確認新事實時，建立具名 Macro Delta，不用舊快照蓋掉新發布。

**新鮮度不是所有資料一律 24 小時。** APPROVED_SUPPLEMENT 的 adapter 完整定義：

1. 每個 series 註冊官方發布日曆、時區、正式 revision 規則及服務可得延遲；`expected_release_id(t)` 是截至決策 t 已公開且按該 adapter 應可取得的最後一版。
2. 使用的 release 等於 `expected_release_id(t)` 才稱「具最新預期發布覆蓋」；尚未到下一期發布日的月資料不因日曆老化而失效。若官方發布日曆或實際延遲不能驗證，freshness 為 UNKNOWN。
3. 市場日頻使用該來源市場最後一個已完成 session，不以自然日數硬算。資料日、擷取日、發布日分開；抓到舊值不等於新發布。
4. 事件型 Active Assertion 的有效性依 CMR 5，不能用 series freshness 規則自動失效。

以上是已核准adapter契約，不私改正式 freshness 門檻。上游已有正式容忍窗口時沿原值並記版本。

#### CMR 3.2 正式未量化形容詞的核准綁定

下表只在該語意尚無既有正式數值定義時提供本版核准路徑；若既有producer缺失，須實作原定義而不換公式。所有 daily 差分使用來源交易日，所有 period 差分使用同頻、同單位、同季調／同比口徑的已發布資料；不能拿月比和同比相減。以發布時可得版本比較，不用未來修訂值重寫過去。

| 語意 | APPROVED_SUPPLEMENT 完整判定 | 缺資料 |
|---|---|---|
| OAS 擴大／收斂 | 同 series 最新與前一已完成觀測差值 >0／<0；=0 為持平。單位全部轉 bp | 無合法 prior 則方向 UNKNOWN |
| HY 快速擴大 | `HY[t]-HY[t-5] >= 50 bp OR HY[t]-HY[t-20] >= 100 bp` | 依三值 OR；一支 TRUE 可確定，其餘未知保留 |
| 利率快速上升／下降 | 具名 Treasury tenor 或 real yield 的 20-session 差 ≥50 bp／≤−50 bp | 各 tenor 分開，不自行投票成風險 |
| VIX 快速上升 | 5-session 差 ≥10 VIX points | 不用百分比與 points 混算 |
| MOVE 快速上升 | 5-session 差 ≥30 MOVE points | 同上 |
| 通膨鏈加速 | PPI、Core CPI、Core PCE 各自最新可比同比值均 > 各自前次發布同比值，且具名 5Y breakeven 20-session 差 ≥25 bp | 任一 FALSE 可判 FALSE；必要未知依三值傳播 |
| 通膨鏈降溫 | 上述三項同比各 < 前次，且 breakeven 20-session 差 ≤−25 bp | 不把非加速直接當降溫 |
| 政策偏鷹／偏鴿 | 消費 V70 正式 Policy Bias；本版只允許官方 rate decision 的 target midpoint 上調／下調及明確前瞻政策 assertion 的具名離散值分列 | 無法可靠解析文字，不用情緒模型補 bias |
| Macro 對執行的壓力條件 | `inflation_chain_accelerating OR (real_yield_rising_fast AND policy_bias=HAWKISH)` | 不等於 Hard Gate，只有 CMR 8 的核准速度作用 |

50／100 bp、5／20 session、10／30 points、25 bp 都是**已核准的固定實作參數，尚未完成實證驗證**。不能據此宣稱 50 bp「科學地等於快速」，也不能當正式危機已確認。校準需固定來源、窗口、適用市場及未知率，再做跨時段壓力檢驗；門檻設計完整不等於通過校準。

### CMR 4 信用與流動性風險

#### CMR 4.1 正式保留的數字與非數字邊界

FORMAL 第 38–40 章及工程 33：HY、A／BBB／IG OAS、VIX、MOVE、Treasury market function、Repo、SOFR／OIS、Overall Liquidity Regime，以及既有 FRA-OIS／SRF／RRP 均保留，不能只看絕對值。

| 正式指標 | 不重疊的數值區間解讀 | 正式語意 |
|---|---|---|
| HY OAS | <300 bp；300–500 bp（含兩端）；>500 bp；其中 >600 bp 且快速擴大為額外風險標記 | 健康；普通至偏緊；壓力提高；系統風險提高 |
| VIX | <15；15–25（含兩端）；>25–35；>35 | 低波動；正常至偏高；風險厭惡；高度恐慌 |
| MOVE | <90；90–120（含兩端）；>120 | 平穩；偏高；顯著升高 |

HY >600 bp 是 >500 bp 的子條件，不能使 600 bp 以下自動安全；正式已有 280→360 bp 的快速惡化警戒例。單一 PPI 高值不得 Hard Gate；單一 VIX、MOVE 或 OAS band 也不能由本章自行變成全市場 Sell。

FORMAL Level 效果維持：Level 0 正常執行；Level 1 可減量／增加折價要求／提高確認要求；Level 2 停新增高 Beta，核心 ETF 降低承接速度；Level 3 停接刀、保全資本。正式已存在的 Level producer 與條件優先。

#### CMR 4.2 危機語意的已核准實作解釋

以下為 **APPROVED_SUPPLEMENT CMR-CREDIT-01**，補足既有危機語意未量化部分；risk_level及evidence按CMR 4.3接入正式consumer，不創新Gate種類。Hard Gate本身仍由既有Owner按完整條件裁決。

**Treasury 市場功能惡化**：同一事前指定基準 Treasury instrument basket、同一報價時段、同一供應商，最近 3 個已完成 session 每日有效 quoted bid-ask spread 均 ≥各日之前 60 個已完成 session 的中位數 2 倍，且每日有效 displayed depth 均 ≤其各自先前 60-session 中位數的 0.5 倍。基準不得在見到結果後挑選；中位數分母必須 >0，且 60 筆有效值全部存在。spread 與 depth 必須真是相同市場範圍的資料；不能用 ETF spread 冒充 Treasury market function。

**Repo 市場功能惡化**：同一具名 overnight repo benchmark 的有效觀測利率連續 2 個來源營業日高於當日適用、來源可驗證的官方該工具／市場融資走廊上界。若不存在與該benchmark可比較的官方走廊，這個method標UNSUPPORTED_METHOD，布林 `R=UNKNOWN`，不是N/A中性、不是FALSE；不得把政策利率上限任意當所有Repo利率的上限。原Repo fact仍保留；正式其他已存在的可靠producer可繼續自己的輸出，但本版不暗中換公式。C2/C3按三值繼續，O已TRUE可短路C3、W已FALSE可短路相關AND，不因單一method缺失把所有輸出清空。

**官方系統性市場功能中斷**：有效原始中央銀行／市場監管／法定清算機構公告明確宣告非例行的系統範圍付款、清算或 Treasury 結算無法正常運行，且公告的生效範圍涵蓋本輪資產市場。必須保存公告原件及對應句段，`event_scope=SYSTEMIC`、`scheduled_closure=FALSE`、`status=ACTIVE`；普通個股停牌、傳聞及正常休市不符合。狀態及範圍由具名 evidence assertion contract 解析或人工覆核，不能由「恐慌」關鍵字判定。

本版定義：

```text
W = HY_rapid_widening
T = treasury_function_deterioration
R = repo_function_deterioration
O = official_systemic_market_function_interruption
C3 = O OR ((HY_bp > 600) AND W AND (VIX > 35 OR MOVE > 120) AND (T OR R))
C2 = ((HY_bp > 500) AND W) OR ((MOVE > 120) AND T AND R AND (HY_direction = WIDENING))
C1 = (HY_bp >= 300) OR (VIX > 25) OR (MOVE > 120) OR W
```

取最高已成立層：C3 TRUE→3；C3 FALSE 且 C2 TRUE→2；C3/C2 FALSE 且 C1 TRUE→1；三者 FALSE→0。較高層 UNKNOWN 且可能改變答案→Level UNKNOWN，另列可證下界及可能上界；不得沿用舊 0。C3 TRUE 時 C1 缺值不妨礙已知 Level3。C3 尚 UNKNOWN 但下層 TRUE，不能說「只是 Level1」。

這張組合表是**本次已核准的危機語意操作化規則**，不是正式第39／40章原有的既存真值表。60／3／2 sessions、2倍／0.5倍與組合門檻均已採用；實證效力仍待驗證。已確認的正式危機仍可獨立觸發原Gate，不能因C3 FALSE推翻。缺Treasury／Repo source是資料不足，不是危機FALSE，也不是危機TRUE。

#### CMR 4.3 分 consumer 的風險作用

FORMAL Hard Gate、Runaway Down、Structural Break／Emergency 及技術減碼各保留自己的 Owner 和既有優先序，不合併成「Risk Score≥X」。正式 consumer 已有細則者用原細則。尚未量化的信用安全語意，本版明定：

- Base／Left：Level0／1 可進原 Entry；Level2 僅可在 `core_etf=TRUE` 且 `high_beta=FALSE` 的已批准分類下使用核准慢速，其他分類不得臨時當核心；Level3 無正常新增。分類 UNKNOWN 不猜低 Beta。
- Right／Trend 的新增條件：信用條件為 Level≤1；Level2／3 不形成新的 Right／Trend 正向 Buy Eligibility。這是**本版已核准的較嚴解釋**，不是正式把 Level2 永久改為全市場停買。
- 純數值 band 升高、PPI 偏高或本版macro 壓力只依具名映射作用，不新增 Stage cap；本章不寫 `min(stage,6)` 之類無正式根據的上限。
- 已成立分析 context 和新增資格分欄。Gate 下 Right 的正式分析例外見 CMR 7；本段不能把該例外改成一律清空 Mode。

### CMR 5 新聞與事件不是文字情緒分數

#### CMR 5.1 Evidence assertion 的必要資料

新聞系統先回答「哪個可驗證事實發生或改變」，再由既有風險規則消費。下列是可實作 evidence schema，不是要求 AI 給可信度 85 分：

```text
source_document_id, source_uri, source_org, original_origin_id
content_hash, document_version, published_at, available_at, retrieved_at
quoted_span_or_page, issuer_or_subject_ids[], jurisdiction, affected_scope
assertion_id, assertion_type, asserted_value, unit, effective_at
assertion_owner, authority_basis, direct_or_derived
canonical_event_id, event_type, event_version, related_event_ids[]
validation_status, contradiction_ids[], supersedes_assertion_ids[]
required_evidence_rule_id, independence_group_id, persistence_rule_id
```

`validation_status`是evidence 內部欄位，不新增正式頂層業務 Enum。原件無法取得、摘錄無定位、主體不能對齊、重要修訂不能排除或 assertion 真偽有未裁決矛盾時，該 assertion 不可用於正向確認或安全解除，依既有 Field Value State 為 UNKNOWN。

**可靠來源的操作定義**：來源身份／原始 URL 或正式檔案 ID 可驗證；文件 hash／版本可固定；發布與可得時間可重建；所聲稱的事實在該來源的正式權限內。例如法院命令確認法院法律狀態，公司公告能確認「公司發布了該財測」，但公司聲稱沒有舞弊不等於監管已認定不存在舞弊。來源 Tier 不能直接產生事件 Confirmation。

對有結構資料的發布，parser 需固定字段映射及完整測試；對自由文字，LLM 可提出候選 assertion 與原句，但必須由確定性檢查＋具名覆核流程驗證類型、主體、否定、時態、有效範圍後才成為可用事實。**若不能可靠覆核，輸出 UNKNOWN，而不是用任意 NLP probability≥0.8 代替。** 這把「公式缺口」改成明確的「事實驗證工作」，並不假稱已自動理解所有新聞。

#### CMR 5.2 重大性獨立性與持續性

- **Material Update**：同一 Event 新有效版本改變至少一個已登錄、可被下游規則消費的事實字段：法律／監管狀態、財務量值及期間、受影響主體／市場範圍、生效日、正式 disposition、事前 thesis 的可驗證條件或可驗證解除條件。只改標題、情緒措辭、轉載網站或沒有變更的重述，不算重大更新。字段重要性必須在 event_type schema 中事前列明。
- **獨立證據**：依 underlying fact／assertion origin 與原始取得路徑去重，不按網站數、URL 數或 embedding 距離。兩個新聞網站都引用同一公告仍一個來源事實；一份財報中的兩個不同事實可分列，但是否足以跨 domain 及獨立仍由已登錄依賴關係判定。independence 未確定的兩項不得先算成兩票。
- **持續**：每個 thesis／event 事前提供 `persistence_mode`，只能是 `IMMEDIATE_AUTHORITATIVE_EVENT`、`CONSECUTIVE_RELEASES(n)` 或 `CONTINUOUS_CONDITION(window, observation_frequency)`。n、window、頻率必填且核准；這是個別論點的實際輸入，不提供全市場任意「兩季就是破壞」預設。
- 連續 n 期必須是事前定義的相鄰正式發布期，缺一期不能跳過；完整三值 AND 判斷已知 FALSE／UNKNOWN。continuous 模式需列應有 observations，缺觀測不能假裝連續成立，也不以每日重刊同一公告累加天數。
- `IMMEDIATE_AUTHORITATIVE_EVENT`僅在事前 Failure Rule 明定事件即完成持續性要求、且該事件已按其法律／事實 Owner 確認時成立。不能把新聞「爆料」當立即永久破壞。

事件處理不用新聞篇數、利多／利空分數、generic severity threshold 或語意相似度作最終風險判斷。資料不存在 ≠ 負面事件；搜尋不到 ≠ 沒有風險；文件很舊 ≠ 證據失效。

#### CMR 5.3 Coverage 與 Recovery

FORMAL 工程 57–62 原樣保留：`search_coverage_status=COMPLETE/PARTIAL/INSUFFICIENT`；若該欄本身不可裁決，沿 value state UNKNOWN，不造第四個 enum。

- Required Safety、Active Material Event Refresh、關鍵 Persistence／Recovery 能可靠完成，而只有 Optional Provider 失敗→PARTIAL；不單獨 Hard Gate。
- 任一必要安全 domain 缺口、必要 active refresh 未完成、關鍵 persistence 無法可靠保存或安全 recovery 不能重建→INSUFFICIENT；只傳播相依 UNKNOWN，新增 Buy 依資料充足／Permission 規則阻擋；不直接確認 Emergency／Structural Break。
- 每次查詢記 source／scope／window／pagination／結果。成功 0 筆是具名範圍內沒有新增匹配；失敗不能存成成功空集合。
- Cold Start 依次恢復 Persistent Active Registry→最近正式 snapshot references→refresh all active events→general search→dedup/material update→persistence→checkpoint。沒有可恢復基線，不靠最近 N 天搜尋證明舊事件不存在。
- Checkpoint commit 必須 required safety、active refresh、dedup、persistence 四項全部 TRUE；Optional 失敗不推進該 provider cursor，即使 global checkpoint 可前移。
- S1的`incremental_search_overlap_window`、`cold_start_general_news_lookback_window`原為TBD。本版以CMR-SEARCH-01明示補足為7／365天及下述延遲擴展規則，已核准作正式實作窗口；它們不是全域事件失效日。

**正式搜尋契約 CMR-SEARCH-01 為 APPROVED_SUPPLEMENT，補足S1原TBD**： `incremental_search_overlap=7 calendar days`、`cold_start_general_lookback=365 calendar days`。固定半開區間 `[start_at,end_at)`，UTC時間保存並對應來源時區；end_at為本次鎖定的決策時點。增量 start=`last_successful_retrieval_at−7 days`；首次一般搜尋 start=`decision_at−365 days`。已知來源最長發布／索引延遲若超過7天，該來源改用 `max(7 days, registered_max_publication_index_delay)`；延遲缺證據時可執行7日搜尋，但coverage不能宣稱已證完整。發布修訂依document version重抓，不因舊published_at落在窗外就漏掉本窗的updated_at。

每輪manifest必填 `domain_id/entity_ids/source_ids/query_template_id/window/pagination_rule/active_event_ids`。核准預設 Required domains 為：全球宏觀政策與信用／美元資金市場；資產發行主體／基金管理人法定存續；財報與財測；監管／法律／重大政策；事前 thesis 與已恢復 Active Events。適用性由註冊的資產國家、交易市場、產業與thesis域精確匹配，不能把所有世界事件都設全標的必需。個股entity scope為該發行主體及thesis明列實體；ETF為基金／管理人／指數方法及當期已驗證持股全集，另依look-through限制檢查相依風險，不把最大持股當全體。每個domain具名選定有權限的原始提供者（公司／基金官方披露、主管監管、法院／法定清算、官方宏觀發布），一般新聞provider為交叉查核或optional。實際source URI、授權、query與完整持股清單是待接入的資料manifest，不由模型猜；未列完整就不能給coverage COMPLETE。

Provider完成必須：查詢範圍明確、所有page已消費、沒有未解截斷／rate-limit／fetch失敗、檔案版本及hash保存。每個active event不受365天窗限制，逐一按事件source刷新。首次沒有可恢復的安全基線，即使365天搜尋完成仍Recovery INCOMPLETE；不能以核准窗口宣告所有舊事件已消失。**7／365天是已核准攝取窗口，不是對所有事件的充分覆蓋證明。** 應依指定fixture驗證；general-search recovery仍需實際coverage及整合證據，不再重複要求窗口批准。

### CMR 6 基本面與結構風險

#### CMR 6.1 個股事前論點契約

FORMAL B-A／工程 30：正式個股原則 3–7 個 Core Investment Theses、預設 5 但不湊數；每項事前定義 domain、Normal／Deterioration／Failure、Required Evidence、Persistence、Critical、Recoverable／Irreversible 及 recovery requirement。價格跌後不能補 Critical。

為消除形容詞，每項條件必須轉成 CMR 2 AST。可用的三種模板如下；它們不是替各家公司虛構投資論點：

1. **法律／契約型**：`official_assertion(event_type, subject, effective_scope, status)` 與事前明定事件集合精確匹配。若契約規定某 ratio <c 即違約，必須使用原契約 c、計算定義、測試日及豁免／補救條款；不能用通用財務比率代替。
2. **營運數值型**：具名 metric、單位、業務範圍、期間、comparable baseline、operator、threshold、persistence 全部事前保存。例如特定 thesis 的 `segment_revenue_yoy < approved_failure_threshold` 連續 n 個正式季度，n 與 threshold 是此論點事前輸入，不可在結果後調整。無本公司／同類核准經濟根據，狀態為未定義，不拿 EPS 跌 20% 作全世界失敗標準。
3. **結構存續型**：具名許可、專利權、主要契約、融資資格或業務能力的正式狀態。事件必須有 authority-qualified assertion；「護城河變差」「競爭加劇」沒有可驗證條件時，不能直接編譯 FAILED。

每項 thesis 固定至少包含 `normal_expr`、`deterioration_expr`、`failure_expr`、`required_evidence_expr`、`persistence_expr`、`recovery_expr` 及對未識別狀態的處理。確定性解析：

```text
confirmed_failure = failure_expr AND required_evidence_expr AND persistence_expr
if previously FAILED and irreversible: remain FAILED
elif previously FAILED and recoverable:
    only use the formally specified recovery transition;
    no news is not recovery; missing recovery evidence is not recovery
elif confirmed_failure TRUE: FAILED
elif confirmed_failure UNKNOWN and it could change final thesis state: thesis value UNKNOWN
elif deterioration_expr TRUE: DETERIORATING
elif deterioration_expr UNKNOWN: thesis value UNKNOWN
elif normal_expr TRUE: NORMAL
else: thesis value UNKNOWN with uncovered-condition issue
```

NORMAL／DETERIORATING／FAILED 保持正式三狀態，UNKNOWN 是資料值狀態，不新增第四個 thesis Enum。normal 不是簡單 NOT failure；failure FALSE 但 normal/deterioration 都無法證明時，不能自行宣告正常。

#### CMR 6.2 長期可持有和重大破壞的明確輸入

`fundamentals_long_term_viable` 不得用新聞正面比例或 P/E 低來填。每個已批准 Thesis Set 必須帶一份 **Disposition Contract**：對哪些 `thesis_id/status`、具名法定存續事件及結構結果會 `DISALLOW_LONG_TERM_HOLDING`、`DISALLOW_NEW_BUY` 或只 `MONITOR`，以 AST 明列，不能留任意文字。

這個 disposition 是策略的事前實質輸入，像 Project Target 一樣不能由執行程式猜。當已完整評估的禁止長持條件為 TRUE，viable=FALSE；全部必要禁止條件確定 FALSE，且每個 long-term-required thesis 的許可條件 TRUE，viable=TRUE；其餘依三值 UNKNOWN。某非安全 Optional thesis 不確定不自動否決全部 Base。DETERIORATING 不一律等於不可長持，也不一律忽略；精確作用由該 thesis 事前 disposition 決定。

對正式未提供任一公司完整 Thesis Set 的情況，可交付空值可驗證的 schema、編譯器及測試 fixture，**不能交付假裝已替該公司完成的真實 Fundamental 判斷**。這是必需外部證據／投資論點不足，不是把缺算法藏回 Owner。

#### CMR 6.3 正式 Structural Break 與 Emergency

Structural Break 必須同時有：≥2 項獨立重大證據；跨 ≥2 fundamental domains；≥1 事前 thesis 已依 Failure/Evidence/Persistence 確認持續失效；公司、產業／同業及可信公告／監管／新聞交叉查驗。每項條件三值計算，未知不能湊票。

依正式工程46-A/B，只有工程45-C的Structural Break Confirmation已滿足，才啟動以下Risk Grade → Fundamental Cap → RRG鏈。未確認Structural Break時，不得只靠FAILED個數產生正式生效的FC、RRG或Sell；可保留各thesis診斷。非 Emergency 的正式風險級與 Fundamental Cap：1 一般 thesis FAILED→R1／50% OTP；2 不同一般 FAILED→R2／25%；≥3 或任一 Critical FAILED→R3／0%。Critical 優先於一般計數；Recoverable Critical 未滿足正式 recovery 前維持 R3；Irreversible Critical 原版本永久 FAILED。

Emergency 必須按正式事件類型、Evidence Authority × Assertion、confirmation／deconfirmation 規則判；`PENDING_VERIFICATION` 不等於 CONFIRMED。重大舞弊、重大違約、破產／重整、Going Concern 類型仍須完成對應 evidence，不能只靠標題命中。已確認 Emergency 的最高 Execution 優先與退出規則不由本章重設。

**ETF 不套個股 thesis R1/R2/R3。** ETF 走正式結構／look-through。已核准補充 `ETF_VIABLE_01`：

```text
etf_long_term_viable =
    fund_legally_operating
    AND current_mandate_within_client_approved_mandate
    AND nav_reporting_and_creation_redemption_function_valid
    AND NOT confirmed_fund_termination_or_permanent_operational_disqualification
    AND lookthrough_disposition_allows_long_term_holding
```

每個leaf都有確切事實型別：fund status取官方基金／監管有效狀態；mandate取當期prospectus/index-method版本與客戶已批准允許集合的subset比較；NAV及申贖功能取基金正式公告／交易所狀態（例行休市不是失效），若產品結構合法不適用申贖則由已批准structure profile明示N/A；termination/disqualification須有效官方事件而非傳聞。look-through disposition 使用事前的暴露限制清單：對每一限制j，將可靠PIT成分中命中該risk-domain/status條件的權重加總為w_j，與客戶／策略原有 `allowed_exposure_j` 比較；允許為 `w_j <= allowed_exposure_j`。不存在額外限制只有明確核准NONE才N/A，不能把缺列表當無限制。

若成分全集與總權重可證但部分狀態未知，風險權重區間為 `[known_affected_weight, known_affected_weight+unknown_relevant_weight]`：上界≤cap則TRUE；下界>cap則FALSE；其他UNKNOWN。無全集／分母／權重口徑則UNKNOWN。這給出可執行正向路徑，同時不虛構全ETF相同的集中度上限；cap與mandate是本來必須提供的外部策略授權。只用一檔重倉股不代表整檔；缺持股權重不可重分配到已知成分假稱100% coverage。

FORMAL `RRG=MAX(AP-FC,0)`；FC 改善不等於買回，也不自動恢復舊 Stage。正式 B1／B2／B3 仍 Candidate 的減碼百分比／速度／MACD bar 與 ATR 參數，不能在本章升格或借給正常 Buy。

### CMR 7 四模式和九階的單向裁決

#### CMR 7.1 先裁風險衝突再選模式

FORMAL 工程 20／73：Emergency／真正降低風險／Runaway Down／技術減碼的 Execution 優先高於正常 Trend／Right／Left。既有互斥衝突先處理：同一 snapshot Up+Down 非法，使用既有 `INVALID→SAFE: Runaway Down`、禁止新增並要求 Same-run／Timeframe Reconciliation；不得讓正常模式 if/elif 先選 Trend 掩蓋衝突。

正常模式精確遵循 Work3-A：

```text
if RunawayUp == TRUE: Trend
elif RunawayUp == UNKNOWN: UNKNOWN
elif Right == TRUE: Right
elif Right == UNKNOWN: UNKNOWN
elif Left == TRUE: Left
elif Left == UNKNOWN: UNKNOWN
else: Base
```

三個上層predicate都FALSE時，正常Mode selector必回Base，不把客戶授權另加成第四個selector門票。可追溯長期配置授權是Base Context是否可用／Target及Execution的必要專案事實；缺失不能產合法Target或新增，但不偷偷改寫上述if/elif。Base也不是「所有技術指標都不好就猜安全」。正常Mode label不等於Base Execution Eligibility；Fundamental、正式估值追價限制、風險、Permission、Gap、cash/caps/quantity/reconciliation仍各自處理。

#### CMR 7.2 各模式的實際條件

- **Left** FORMAL：`price_condition_at_least_one AND fundamentals_long_term_viable AND left_safety_negations_absent`。價格是至少一項 OR，不把價格／估值雙軸 AND 反向變成正式 Entry。oversold／技術成熟主要控制速度，非第一筆 Left 必要門票。
- **Right** FORMAL：已離開最低點、去重確認信號 ≥3、基本面／信用／非 Runaway Down／既有估值條件與該事件必要 T+1 PASS。技術 TRUE 不替估值 UNKNOWN 補值。UNKNOWN 票不能算 FALSE 或 TRUE；T=3,U=2 已達 3，確認數狀態為 TRUE。
- **Runaway Up** FORMAL：A 價格結構 ≥1、B 強勢確認 ≥3、MA20 結構要求；各 signal 由技術章提供精確 event/state。`position_under_deployed` 不在市場 Predicate 內，它是合法 Stage→Target→Gap 之後的執行需求。
- **Runaway Down** FORMAL：A 結構破壞 ≥1 AND B 空方加速 ≥2；信用惡化是 safety context，不再偷偷增加 B 票。它暫停所有正常新增，但自身不建立 Sell。
- **Event-dependent T+1**：只有依賴該 Event Gap 的 predicate 在正式要求 PASSED 前不能解除，不能把所有無關 Base/Left 全部綁上每個世界新聞。

技術訊號完整量化及去重關係由本文件第4章 TECH 4及TECH 8提供；每個 adapter 必須按 signal_id/version 連接，不能把 EMV14 當 EMV3,3 或把不同 MACD 別名算兩票。

#### CMR 7.3 Hard Gate 的 Left 與 Right 例外不能抹平

- Hard Gate TRIGGERED：正式 `left_safety_negations_absent=FALSE`，故 Left predicate FALSE；可保留左側價格／估值證據，但不能保留正式正向 Left Buy classification。
- 對本輪其他依賴仍足夠的已成立 Right 分析，正式工程 73 案例 2 允許保留 Right／Mode／Stage／Target／Gap，只把新增 Permission 關閉。**不把 Hard Gate 加成 Right 分析的一個全域 NOT Gate 必要項。** 但 Right 自身 Fundamental／非 RD 等條件若失效，仍要重算，不能以例外保留舊 TRUE。
- 不因 Gate 直接把全部 Mode/Stage/Target/Gap 清成 0／NONE／WAIT；也不能說「Hard Gate 不影響任何 predicate」而忽略 Left 安全 Entry。
- Required Safety 不足而 Gate UNKNOWN：Permission FALSE，原因 DATA_INSUFFICIENCY，不偽標市場 Hard Gate 已觸發。

#### CMR 7.4 九階是部署目標不是今日訂單

FORMAL 累積率為：Stage1 10%、2 20%、3 30%、4 45%、5 60%、6 75%、7 85%、8 95%、9 100%，分母只有 Project Target Position。Base reference=1；Left reference=2–7；Right reference=8；Trend **最高**=9，不是成立必滿配。

本章不重造 Left 切點或額外 Macro Stage cap。Stage2–7 的price/valuation 深度規則接本文件PV3及PV4的Stage profile；選階證據以 `candidate_stage_evidence` 與 `stage_restrictions[]` 接口輸入。每個 restriction 必須列 `restriction_id/source/authority/applies_when/expression/effect`；不能只傳黑箱 `ApplicableStagePolicy=TRUE`。

核准resolver 逐階建立 `eligible_s` 三值；在合法適用域驗證深階蘊涵淺階。最高 TRUE 且以上確定 FALSE 才是唯一選階結果；高階 UNKNOWN 能改答案則 UNKNOWN＋已知下界／可能上界。全 FALSE 是無支持階段，不自動 Base。正式 Stage 必要依賴未知，不能把局部選階結果當作完整依賴已知的正式Stage。

Base／Right 的 reference 不是資料不足時的保底數值；無合法 Stage→Rate UNKNOWN→Target UNKNOWN。補足 **APPROVED_SUPPLEMENT CMR-TREND-STAGE-01**：在當輪Trend市場Predicate成立、適用的Fundamental及Stage必要證據可裁決後，`trend_full_target_evidence = (qV < 60) AND A_normal`；qV與A_normal完全重用本文件PV2及PV3估值profile（非Forward PE或正式證實無固定range時，A_normal按該profile的明確N/A中性處理；range適用性UNKNOWN仍UNKNOWN）。此條件TRUE→Stage9；FALSE→Stage8；UNKNOWN→Stage UNKNOWN，可能範圍8–9。這是一個已核准、實證效力尚待驗證的估值約束，不把Left選階2–7拿來推8/9，也不引用Gap或Cash。60及其Stage映射已核准為本版正式實作門檻。若當輪有其他已成立、具名正式Stage限制，先按其明文規則處理，不能由本版Stage9覆蓋；無法對接的正式必要限制須明確列constraint_id並阻止正式發布，不以black-box policy TRUE略過。任何正式適用估值限制必須是具名明文條件；**Extreme Valuation Flag 本身不是禁止買進權，不得單憑flag設cap=0。** Stage8仍可能因風險／資金／估值執行限制而不新增，不等於95%必須當日買滿。

Stage／Target 不讀 Gap、Permission、Cash 或本輪 Execution Amount；Gap 不回流到 Mode。若需診斷「低配」，只在 Target 已決後計算 `Gap>0` 供補足需求／加速。Stage 下降可能產生負 Gap，但本身不自動賣。

### CMR 8 正常買入速度的正式實作方案

FORMAL 40-F／41-F／42-G／43-C 保留「技術調整向同一目標補足速度」。本版已核准 **APPROVED_SUPPLEMENT CMR-SLICE-01** 的每日切片數字，經CMR 9.1作具名slice cap納入既有MIN，不把Maximum默認為今天全買；本次授權不包括自動向券商送出意圖。

唯一成熟度算法為TECH 5.2 **M1–M8** 八個具名slot（低TD成熟、KD止跌／golden、MACD空方縮短、DIF上彎、EMV改善、RSI回升、價格三根不破低、價跌量縮／止跌K）的去重N-of-3：T≥3→MATURE；T+U<3→IMMATURE；其餘UNKNOWN。每個canonical slot最多一票，M8兩分支仍一票；任何同義別名不增票，按技術registry既有關係處理，不能自行新增第五／第九個signal。M3與M4為本版登記的不同訊號slot，並不宣稱統計獨立。沒有五slot fallback或臨場替換。這是本章已核准的速度規則，由速度Owner消費技術章輸出，也不是新的Left Entry門票或Right／Up計票組。

| 正常模式 | IMMATURE 日切片率 | MATURE 日切片率 |
|---|---:|---:|
| Base | 10% 正 Gap | 20% 正 Gap |
| Left | 15% 正 Gap | 25% 正 Gap |
| Right | 25% 正 Gap | 25% 正 Gap |
| Trend | 20% 正 Gap | 20% 正 Gap |

核准 `credit_speed_multiplier`：Level0=1、Level1=0.75、Level2且允許核心慢速=0.5；Level2高Beta／Level3無正常新增。核准 `macro_speed_multiplier`：CMR 3 macro壓力TRUE=0.75，FALSE=1，UNKNOWN則相關切片未知。核准 `valuation_speed_multiplier`：Base或Trend時，適用正式Extreme Valuation Flag TRUE→0.5、FALSE→1、UNKNOWN→未知；Left／Right此乘數固定1，其他具名正式估值限制仍另行適用。0.5是已核准的降速倍數，實證效力尚待驗證，不把Extreme Flag變為全面禁止買進。這使「Trend從9降8」與「Extreme放慢補足」成為兩個分開的作用，不用Target改變冒充速度調整。不新增Macro Stage cap，也不因單一宏觀高值自創Gate。

**APPROVED_SUPPLEMENT CMR-TREND-CHASE-01** 補足「不機械追單日極端大陽線」：使用技術章同口徑completed OHLC及前一根ATR14，`extreme_bull_bar=(C_t>O_t) AND (TR_t>=2×ATR_(t−1)) AND ((C_t−O_t)/TR_t>=0.8)`；TR必須>0、ATR前值>0，TR=0則extreme=FALSE，其他必要缺值依三值。等號成立。只有當 `NOT extreme_bull_bar AND entry_structure` TRUE才有Trend新切片；FALSE時本輪Trend正常新切片0，但Mode、Stage、Gap及安全Permission不改成WAIT／FALSE。entry_structure為下列三值OR：

- MA5回踩：`L_t<=MA5_t AND C_t>=MA5_t AND C_t<=1.01×MA5_t`；
- MA10回踩：相同公式將5換10；
- 技術R10本輪breakout retest success；
- 窄幅整理：最近5個completed bars的`(max H−min L)<=2×ATR_(t−1)`且`C_t>=MA20_t`；
- 趨勢持續確認：本輪及前一完成session各自當時可得的Up predicate都TRUE，不以後來重算的Swing回填前輪。

以上2倍、0.8、1%、5根都是已核准新數字，只定義新增時機；不產生券商工作價格或擅調舊GTC價。entry_structure UNKNOWN且沒有TRUE支路時，Trend新切片未知，不冒充0；已知extreme TRUE可短路成已知不新增。非Trend不使用這個追價predicate。

每日cycle在第一次資料齊全、可合法建立新Buy計畫時建立；來源交易所session、asset、profile version唯一決定`slice_cycle_id`。保存當時已對帳的`G0=MAX(FinalGap_at_cycle_open,0)`、初始率r0及乘數c0/m0/v0，固定 `B0=G0×r0×c0×m0×v0`。若初始必要值UNKNOWN，不建立有額度cycle；後續資料補齊才首次建立。

```text
B_current = MIN(B0, G0 × current_mode_rate × current_credit_multiplier
                       × current_macro_multiplier × current_valuation_multiplier)
cycle_spent = confirmed_new_buy_fills_attributed_to_this_cycle
cycle_committed = remaining_amount_of_nonreleased_unique_intents_attributed_to_this_cycle
cycle_room = MAX(B_current - cycle_spent - cycle_committed, 0)
proposed_new_buy_notional_cap = MIN(cycle_room, formal_maximum_allowed_buy_amount,
                                   remaining_authorized_cross_asset_capacity)
```

B_current使用固定G0，**不使用填單後縮小的current Gap重算日預算**；當輪新Gap僅透過正式Maximum再限制。例：G0=100、B0=25、已成交10、無其他承諾且風險未變→剩餘日預算15，不是90×25%−10=12.5。安全或模式轉弱可讓B_current下修；轉強不能突破B0，沒有自動開第二cycle或提高日預算。

以上只在該模式、風險、Permission及交易條件允許時產生計畫；Permission FALSE／更高風險禁買則正常新增0並按原規則處理尚未成交單。maturity UNKNOWN對Right/Trend的相同rate不造成無必要UNKNOWN；Base/Left則切片未知或顯示區間，不擅取低值冒充確定。信用／宏觀／估值乘數及Trend時機均已核准，正式切片按本版整合；真實必要輸入不足或實作尚未驗證仍如實記錄。

**重複、取消與跨日**：ledger以唯一intent_id冪等計入，planned commitment與broker reservation分層，不假裝計畫已占券商cash；同一intent已在Active exposure中，Gap不再額外重扣。cycle_committed只管理該cycle預算，與正式Gap的global exposure不是第二次計算同一公式。Cancel requested仍占commitment；只有確認CANCELLED／EXPIRED／REJECTED或正式解除本地未送計畫才釋放未成交承諾，當cycle仍開放且全部當下條件允許時可用新intent重用該釋放額度，總`spent+committed+new`不超過B_current。已成交額永不因取消／重跑歸零；換run_id不重置cycle。同session後續提高ProjectTarget也不提高B0，需下一合法session或獨立明確授權的擴張cycle。session結束後該cycle不得新增intent，但尚Live的GTC繼續保留原cycle及曝險；下一session的G0已包含該Active exposure，不把舊單當作未占用Gap。若帳本或狀態未知，新承諾暫停，不猜已釋放。

這組 10／20／15／25% 及 0.75／0.5 已核准作本版固定參數，未證明優於等額分期或原核准策略；不能與正式減碼 NORMAL=100% 或候選 B 系列表混用。本版正式實作採本表；後續變更須另立版本與授權，不能默認Maximum全額送出。

### CMR 9 資金與訂單上限

#### CMR 9.1 單檔正式數學

工程 35–39 公式原樣保存，同 run／同幣別／同估值價格：

```text
Target = ProjectTarget × LadderRate
Confirmed = confirmed_qty × canonical_valuation_price
ActiveBuy = Σ(active_buy_remaining_qty × canonical_valuation_price)
ActiveSell = Σ(active_sell_remaining_qty × canonical_valuation_price)
Projected = Confirmed + ActiveBuy - ActiveSell
FinalGap = Target - Projected
```

Target 是策略累積目標，不是每日購買金額。Active Order 服務 projected exposure；order working price 服務保留現金與實際訂單 notional，不能混用。SUBMITTED／OPEN／PARTIAL_FILL／CANCEL_PENDING／REPLACE_PENDING 未成交部分仍計 Active；取消建議不等於取消已確認。FILLED 尚未進 AP 的對帳空窗，不得讓 exposure 暫時消失。

FORMAL Permission 只依 Data Sufficiency PASS、Hard Gate NOT_TRIGGERED、更高風險允許、必要專案與執行輸入已知；Gap 不進 Permission。TRUE 時：

```text
MaximumAllowedBuy = MIN(MAX(FinalGap,0), available_cash, all_applicable_explicit_authorized_caps)
```

正式37-F同時記`buy_amount_pre_round=maximum_allowed_buy_amount`；本章保留此公式。本版已明確核准CMR-SLICE-01的日切片作既有execution intent的具名授權slice cap，由正式MIN消費。這是本次明示整合補充，不是宣稱40-F原本已有具體切片數字；實作與資金帳本一致性仍須驗證。

券商 net `available_to_trade` 已扣 reserved 就直接使用，不再扣 Active Buy。只有 gross cash 才扣可信 reservation。必要 cap、費用、cash、交易單位／tick 未知不猜 0 或∞；若已確知本輪不新增，amount/qty 可為已知 0，原 cash 仍保持 UNKNOWN。

**上限示例僅為驗收 fixture**：Target100、Confirmed40、ActiveBuy10、ActiveSell0→Projected50／Gap50；net available_cash20→Maximum至多20，不再把 ActiveBuy10重扣成10。不是任何標的的下單建議。

#### CMR 9.2 跨標的總池及資金來源

FORMAL 工程63：V70股票額度是總 ceiling，不是新的現金。先計同 accounting base 的 ceiling，再扣 confirmed exposure＋有效 buy reservation＋其他 commitment−只已確認釋放部分，得到 incremental room；再和已授權、實際可用的 incremental funding 取 MIN。本輪所有新建／增加 Buy 合計不得超過剩餘 capacity。若先前 exposure 已高於 ceiling，新增能力=0，保留 overage，不因此強制賣。

單檔cap不拿來壓整體stock pool；新增現金授權不混成總配置ceiling。補足 **APPROVED_SUPPLEMENT CMR-ALLOC-01** 的分配，不對真實客戶資金作任何操作：

1. 鎖定本輪獲授權資產集合及每檔唯一`authorized_funding_bucket_id`；bucket必有實際幣別及可用現金。多來源尚未指定優先／歸屬時，該檔allocation UNKNOWN，不擅賣資產或換匯。正式已有批准priority則正式沿其規則，無適用既有priority時，本版採下列已核准比例方案。
2. 每檔`slice_i`取CMR 8已算的日餘額及本檔Gap／明確caps上限；尚未因共享cash或共享V70額度同時重複預留。每個bucket內令`S_b=Σslice_i`（轉為該bucket幣別），`a_b=1`若S_b=0，否則`MIN(1,available_authorized_cash_b/S_b)`；`b_i=a_b×slice_i`。S_b=0是所有slice已知0，不是缺資料代0。
3. 用有來源的同輪reporting FX正規化b_i到Budget Currency，令`S=Σb_i`、`a=1`若S=0，否則`MIN(1,remaining_tactical_incremental_room/S)`；分配`allocation_i=a×b_i`。共享現金只在bucket約束一次，共享總池只在此約束一次；單檔既有Maximum仍作最終不得突破的check，不重減既有reservation。
4. 再按各市場合法price／lot／fractional規則向下形成合法notional；費用／稅費依可靠adapter預留，不猜0。量化後未用餘額**本cycle不重新分配**，避免rounding排序暗中偏袒字母較前資產。所有最終new amount總和≤共同容量，所有bucket用款≤其可用額。
5. 某競爭資產slice或必要FX／bucket／cap UNKNOWN且可能改變比例時，該共享allocation group UNKNOWN，不把該資產當0偷偷分完；已知總可用容量0時，新allocation全為已知0而原未知欄保留。未參與該bucket／pool的其他群組不被污染。

這個比例分配是明示、可測且已核准的本版政策，不宣稱正式V82原本採pro-rata，也不重設ProjectTarget。已授權Target由客戶指定是固定金額、動態估值或其他合法政策；本章不假定總資產常數或自算Target。

FORMAL 工程64：SGOV logical dry-powder bucket≠實際 SGOV 持倉≠可交易現金≠正式債券配置。未部署額度不授權出售 SGOV／別的資產或換匯。USD/TWD 不裸數相加；FX 正規化保存 target-per-source 方向、來源、時點與用途，reporting conversion 不改 cash balance。所有實際資金來源及交易仍須用戶／專案授權與券商確認。

### CMR 10 輸出必須同時說明已知與未知

仍為正式 49 Canonical Fields 與 13 欄 Execution View，不加第50／第14欄。規則 profile、診斷區間及參數批准狀態進 sidecar 或正式 Owner 允許的 nested evidence，保留 `run_id`、`v82_snapshot_id`、upstream snapshots、rule_version_set、as_of、available_at、lineage。

使用者閱讀順序：

1. **可證分析**：資產類別、正式估值與基本面／事件證據、技術、市場風險；各自資料日期及 UNKNOWN 原因。
2. **模式及目標**：依本版核准規則及既有Owner依賴呈現正式模式、九階、累積率、Project Target與Target；另標實作驗證狀態，不拿歷史研究輸出冒充當輪結果。
3. **權限及需求**：Hard Gate／Data Sufficiency／更高風險；Final Gap；Permission；合法 cap／cash；不把有 Gap 寫成應買。
4. **本輪結果**：已知 No-new-buy、待必要資料、正常切片計畫或正式風險 Owner 結果。不自動送單。Recommendation、Intent、Submitted、Fill、Confirmed Position 分欄。
5. **下一個可改變結論的條件**：缺哪個 input_id、哪個 source、預期發布／refresh 事件、取消／重算條件。不要只寫「觀察市場」。

已完整裁決不下單→execution amount／quantity KNOWN0、price／planned fill N/A、should_place_order FALSE。若是否執行本來未知→相關欄 UNKNOWN，不把「不知道」美化成「今天不買」。Hard Gate 令已知正常不新增時，不需要為了填完 qty0 先猜 cash。實作尚未驗證時不代表formal output_status COMPLETE。

### CMR 11 邊界驗收案例

數字均為測試 fixture；本表是預期規格，除另附實際測試報告外一律 NOT_RUN，不冒稱 runtime、回測或實盤驗收 PASS。

| ID | 輸入邊界 | 必須得到的結果 |
|---|---|---|
| MR01 | HY=300/500/600 bp | 300、500在正式3–5區；600不滿足嚴格>600；不得錯用≥600 |
| MR02 | HY 5日變動49.999／50 bp | 核准快速5日支路分別FALSE／TRUE；20日支路另按OR處理 |
| MR03 | 5日快速TRUE、20日prior未知 | 快速TRUE，保留20日UNKNOWN，不全局阻擋 |
| MR04 | prior頻率不同／percent與bp未正規化 | 拒比較，UNKNOWN＋frequency/unit issue，不產快慢結論 |
| MR05 | C2 TRUE，C3 UNKNOWN | Level UNKNOWN，可證至少2、可能3；不得固定Level2 |
| MR06 | PPI單月偏高、其他鏈未同步 | 不因PPI單獨Hard Gate，不新增Stage cap |
| MR07 | 新聞來源成功0筆；另一來源失敗 | 各記不同結果；不能兩者都存空集合／無風險 |
| MR08 | 五站轉載同公司公告 | 一個原始assertion lineage，不能五個獨立證據 |
| MR09 | 同文件兩不同domain事實，但共同一個未獨立事件 | 分列事實但不自動增加兩個獨立重大證據 |
| MR10 | 很舊法院命令仍有效 | item可STALE，assertion可VALID，不機械解除事件 |
| MR11 | 公司否認舞弊但監管仍調查 | 公司否認是有效「公司聲稱」；不得當監管已解除或風險已FALSE |
| MR12 | Optional Provider失敗，必要覆蓋與refresh/persistence完整 | 可PARTIAL；不單獨新Gate；該provider cursor不前移 |
| MR13 | 一般搜尋完整但Registry persistence失敗 | 若影響必要安全→INSUFFICIENT／相依UNKNOWN，不COMPLETE |
| MR14 | Thesis failure TRUE、evidence TRUE、persistence UNKNOWN | 不FAILED；相關thesis值UNKNOWN；不能用新聞篇數補持續 |
| MR15 | 連續2期要求，中間一季資料缺失 | 不跳過缺季累成2期；適用三值，不能判滿足 |
| MR16 | Critical是價格下跌後才添加 | 不採為原episode事前Critical；保留新版本及批准狀態 |
| MR17 | R3已成立、Emergency僅PENDING | 原B系列Owner繼續；不建立Emergency速度 |
| MR18 | ETF單一重倉股FAILED | 不機械把ETF設公司R3，走look-through及ETF結構 |
| MR19 | HardGate TRUE、Left價格TRUE | 正式Left predicate FALSE、Permission FALSE；價格context保留 |
| MR20 | HardGate TRUE、當輪Right自身條件仍完整 | 可保留Right/Stage分析，Buy0；不WAIT，不自動Sell |
| MR21 | RunawayUp UNKNOWN、Right TRUE | Mode UNKNOWN，不偷選Right |
| MR22 | Up TRUE與Down TRUE同snapshot | INVALID→SAFE Down、禁新Buy、reconcile；不選Trend繞過 |
| MR23 | Left一項正式價格TRUE、其他價格UNKNOWN | 正式價格OR可TRUE；不能以選階全AND反向否決 |
| MR24 | Right T=3,U=2；T=2,U=1；T=1,U=1 | 確認數分別TRUE／UNKNOWN／FALSE；其他必要條件另判 |
| MR25 | Trend已合法Target100、Projected110 | Gap−10，正常Buy0，Mode不因Gap變；不自動Sell |
| MR26 | Mode=Base但Required Stage input缺失 | Stage/Rate/Target按依賴UNKNOWN，不默認Stage1 |
| MR27 | 只有ExtremeValuationFlag TRUE | 不憑flag設cap0；消費具名正式限制／核准速度而已 |
| MR28 | CMR slice maturity UNKNOWN，但Mode Right | 該表兩種maturity rate相同，slice rate可知25%；不必要UNKNOWN |
| MR29 | 同日同asset重跑3次換run_id | 不重置slice_cycle_id，無三份日額度；已承諾intent不重複計 |
| MR30 | Target100、Confirmed40、ActiveBuy10、netcash20 | Gap50、現金20；不重扣ActiveBuy；Max≤20 |
| MR31 | 訂單CANCEL_PENDING | 曝險仍Active，不釋放Gap／cash，直到券商確認 |
| MR32 | FILLED但AP尚未對帳 | 不讓曝險消失形成虛增Gap；新Buy依賴阻擋 |
| MR33 | cash UNKNOWN但HardGate已TRUE | cash仍UNKNOWN，已知不新增的amount/qty可0 |
| MR34 | 必要cap UNKNOWN | 不當∞、0或忽略；上限依賴UNKNOWN／不產送出意圖 |
| MR35 | ceiling100、已有confirmed股票110 | 新增capacity0、overage10；不由ceiling自行賣10 |
| MR36 | logical SGOV dry powder20、真實現金0 | 不當可買20；logical bucket不授權SGOV賣出／FX |
| MR37 | 正式49欄加入Level上下界 | 放sidecar，仍49／13，不新增正式Enum |
| MR38 | 核准公式完整但數字未經實證校準 | 按核准規則實作及計算，不稱策略有效／production可用 |
| MR39 | Trend成立、qV=59.999／60且A_normal TRUE | Stage9／8；無Gap輸入；採用已核准，仍不冒稱測試已跑 |
| MR40 | Trend成立、qV UNKNOWN、A_normal FALSE | full-target AND為FALSE，Stage8；保留qV未知 |
| MR41 | G0=100、B0=25、已fill10、無commitment、風險不變 | cycle room15，不重算90×25%−10 |
| MR42 | cycle已fill10、live未成交5，申請cancel但未確認 | spent10/committed5，room至多10；確認cancel後才可釋放5 |
| MR43 | ETF受影響已知權重5%、未知2%、核准cap6% | 區間[5%,7%]跨cap，look-through許可UNKNOWN，不用5%判安全 |
| MR44 | 首次365天搜尋完成、所有舊Active Registry無法恢復 | 仍Recovery INCOMPLETE，不能宣稱歷史事件全部解除 |
| MR45 | 增量provider last_success=t，overlap7天 | start=t−7天；不是t+7天，半開區間邊界重複由版本去重 |
| MR46 | Repo無合法可比corridor | R UNKNOWN／UNSUPPORTED_METHOD；不N/A參與AND、不判正常 |
| MR47 | 同bucket正常slice30與10、cash20、global room≥20 | 分配15與5，再lot floor；未用餘額不再分配 |
| MR48 | 三上層predicate都FALSE、客戶授權UNKNOWN | selector為Base；授權依賴Target／Execution未知，不創第五Mode |
| MR49 | 只有一個共享資產slice未知、總pool容量已知0 | 所有新增allocation可知0，原slice及資料未知仍保存 |
| MR50 | Trend／Base、Extreme Flag TRUE、其他乘數1 | 切片乘0.5，不因flag將Permission設FALSE或cap0 |
| MR51 | Trend極端大陽predicate TRUE、entry_structure UNKNOWN | 新增時機FALSE、正常新切片0；Mode/Stage/Gap保留 |
| MR52 | Down事件D2昨日TRUE、今日FALSE，D1/D3今日FALSE | 按當輪Down重算；不沿用昨日event TRUE，也不由此解除已存Gate／Emergency |

#### CMR 一條能走完的合成正向路徑

這只是無市場含義的fixture：已批准專案Target=100單位；ETF所有viable leaf有可靠證據為TRUE，必要look-through限制完整；正式Gate未觸發、Required Safety PASS、無更高Risk。Up=FALSE，Right的off-low=TRUE且去重3票TRUE，Right必要估值／信用條件TRUE；正常Mode=Right，該fixture所有Stage依賴已知→Stage8／Target95。Confirmed20、ActiveBuy5、ActiveSell0→Projected25／Gap70。信用Level0、macro pressure FALSE；Right的valuation multiplier固定1；cycle G0=70、Right率25%→B0=17.5。cash50、合法單檔caps≥17.5、共同剩餘容量≥17.5、無既有cycle承諾→新notional cap17.5。若合法order price=1、minimum lot=1且fixture明示費用0（僅合成已知輸入），向下量化17單位、notional17，剩0.5不重新分配。這證明契約有可通的正向實作路徑，不只會UNKNOWN→不買；**沒有真實資料、沒有真實Order Intent，也不因此取得下單授權。**

### CMR 12 採用已核准與仍需取得的證據

**公式及契約已能交工程實作**：三值規則、具名 dependencies、Macro current/prior adapter、信用核准操作化、Evidence schema、Material Update／independence／persistence、Thesis AST、四模式、Hard Gate例外、Stage interface、日切片／估值降速／Trend時機／共享分配規則、資金分層、輸出與邊界 fixture。

**仍需外部事實或事前策略輸入**：每個標的已批准 class／subtype／Thesis Set／Disposition；可靠市場與財務／新聞原件；Treasury depth／spread及適用Repo corridor來源；客戶Target／caps／funding；券商現金／持倉／orders；正式時間與來源manifest。這些不能從形容詞、股價或使用者「快做完」推論出來。

**本章新增規則已核准**：宏觀窗口與幅度、信用組合與consumer映射、正常Buy切片、Stage profile、新聞7／365天窗口與本章所有明列的新定義，均可直接實作。數字與source adapter須一起版本化；尚未接入的真實來源及coverage證據仍須取得，不因採用批准而宣告全域Recovery或生產部署已完成。

**仍需運行證據**：AST編譯／型別／無環檢查、same-run與PIT回放、正式Owner adapter整合、上述52組fixture與正向路徑實際測試、歷史／跨市場與危機段校準、未碰holdout、費用／滑價與資金一致性。可重播、接線正確、策略經濟有效、production解除HOLD是四種不同完成度。

本章完成的交付標準不是把所有未知硬填成數字，而是**所有語意有正式來源、核准公式或必需證據欄位，所有缺口有明確種類和下游效果；沒有黑箱 policy、沒有新聞情緒分數冒充風險、沒有把設計批准誤當交易授權。**

### CMR 來源定位

正式主規則及其固定版本見第9章S1。核對工程22；正式第37.1／38.1及39至40章；工程35至44；B-A Core Investment Thesis／Structural Break；工程57至67；工程73案例1、2、3、6、7、8、11、12、13及互斥矩陣；Work7 Candidate治理。未修改正式原件，讀取規則不等於驗證任何真實市場值。


<!-- PAGEBREAK -->

## 6 研究驗證與版本發布契約

本章分開記錄規則採用批准、工程實作、真實資料與投資效力證據。本版採用批准已完成；各證據層不得互相冒充。

### VAL 1 完成層次

1. SPEC_COMPLETE：所有分支、資料型別、公式、邊界、時間、缺值及輸出已定義；未知資料有明確結果，不靠工程師補猜策略。
2. SYNTHETIC_VERIFIED：對指定版本程式實際執行合成與性質測試，保留命令、輸入、輸出、commit和失敗紀錄。
3. DATA_REPLAY_VERIFIED：真實來源、公司行動、時間戳及歷史版本可重播；數字逐欄交叉核對。
4. EMPIRICALLY_EVALUATED：對預先凍結策略、成本和樣本外分段完成歷史評估；評估完畢不等於表現良好。
5. PRODUCTION_APPROVED：正式入口端到端驗證及生產操作放行完成；本版規則語義及數值的採用批准已完成，不需重複請准。生產狀態與交易操作授權另記，上述任一層不能冒充其他層。

### VAL 2 預註冊實驗清單

每次研究凍結：spec_hash、data_manifest_hash、code_commit、profile/subtype版本、全部參數、對照組、樣本起迄、訓練與測試切分、費用、滑價、匯率、資金流、評估指標。以首次測試前的雜湊為準；修改後是新trial而非覆蓋舊結果。登記全部失敗trial，禁止只留下最佳結果。

核准規則使用標的自身可比歷史分位而非以未來收益逐股尋找最佳買點。十一類是方法選擇及適用性，而不是十一組臨場最佳化數字。若未來做類別參數調整，須共用訓練/測試規程，不能在測試段反覆調整。

### VAL 3 時間與交易可行性

- 各歷史分析時點只使用當時已發表且可取得的資料；當前下載日不能充當當年available_at。今日重編的成分或估值不能倒灌歷史。
- 以訊號計算完成且資料可得之後的下一個合法可成交時點模擬；不能用已知收盤訊號回填同一收盤成交。
- 休市、停牌、漲跌停、整股/碎股限制、幣別、最低費用、價差、滑價及流動性限制須由市場契約輸入。缺少成本/成交契約時只做訊號重播，不輸出策略績效。
- 公司行動、分紅、匯率及總報酬口徑分開；分紅統計再投資不等於帳戶已結算現金。不得雙重計算。
- ETF成分穿透使用當時成分；排除下市標的會造成存活偏差，須保留或揭露。

### VAL 4 比較與風險衡量

對照組以相同起始資產、外部資金流、目標配置及可交易限制建立：持有既有組合、固定日期等額部署、原有可執行V82版本。無可執行原版本時明示無法比較，不造一套對照。

報告累積/年化報酬、最大回撤、時間加權報酬、資金加權報酬（有唯一有效解才報）、波動、換手、費用、部署延遲、閒置現金、目標偏離、尾部風險及不能執行率。不可只優化勝率或Sharpe；失去部署機會亦列入。

採時間順序樣本外與制度分段。任何使用未來H日報酬的校準標籤，訓練/測試交界需剔除標籤觀察窗重疊，間隔由H推導而非任意固定。測試期不重新選參數。每類另留整個標的作跨標的驗證；單一ETF成功不得推論整類有效。

### VAL 5 參數與穩定性

核准切點明確定義實作及後續研究命題，並非證明最優。敏感度實驗需預先定義鄰域、一起公布結果；不能在看到測試結果後把最好鄰點升為原設計。檢查訊號頻率、邊界翻轉率、缺值率、類別差異、制度轉折、來源切換及重編影響。參數穩定不代表未來獲利。

### VAL 6 放行門檻

工程硬條件：所有已列不變量測試通過；無未處理例外；缺值不造假；時間無前視；同輸入與版本重播一致；無越權寫回或交易；正式來源對照無未裁決衝突。上述任何失敗均禁止宣稱驗收完成。

投資績效接受標準（可接受回撤、部署延遲及基準差異）屬使用者風險偏好與後續部署決策，不由本文件捏造數值。其未指定不撤銷本版公式的採用批准，也不阻擋工程實作及評估。現有資料沒有證明production放行，不能標production_approved=true；本文件不授權自動下單。

### VAL 7 研究依據與限度

Bailey等人的原始研究指出大量策略嘗試會增加回測過度擬合風險，單一holdout不能當充分保證；本契約據此保存所有trial並區分設計與實證。[閱讀回測過度擬合研究](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf) 。此論文不驗證本V82門檻。

S&P官方Index Mathematics說明價格指數、總報酬及公司行動方法有明確差異；本規格自行定義W方法必須獨立命名，不能冒稱與官方指數完全一致。[閱讀S&P指數數學](https://www.spglobal.com/spdji/en/documents/methodologies/methodology-index-math.pdf) 。


<!-- PAGEBREAK -->

## 7 全域驗收與可追溯性

### QA1 每條規則必填契約


每個 rule_id 至少具備：

- 唯一Owner、既有正式來源或APPROVED_SUPPLEMENT來源、version、effective interval、artifact hash；本版新增規則明記使用者採用批准，不冒稱S1早已含同一新公式。
- 合法適用域：class／asset type／subtype／Grade 等獨立欄位；零匹配、多匹配、衝突與不支援的行為。
- 完整 input_dependencies、型別、幣別、量綱、period、bar completion、adjustment basis；不得有未登錄隱性輸入。
- 經濟 as_of、available_at、retrieved_at、決策 cutoff、資料時區與日曆、source/revision 選擇規則。
- 完整公式或決策表：所有比較的等號歸屬、單位、視窗、最少有效資料、seed、warm-up、event/state 有效期、reset、失效、Tie-break。
- applicability、requirement_level、value_state 分欄；所有合法 UNKNOWN/N/A/缺失/錯誤分支。
- 輸出型別與正式 consumer；規則不得透過 side effect 更新另一 Owner 的欄位。
- 至少一個正向、反向、邊界、必要缺值、無關缺值、PIT、失效／重設與衝突 fixture；指定預期，不標成已跑結果。
- 核准數字的測量或經濟理由、允許校準範圍及不變正式條款；「看起來保守」不能充當已驗證理由。

**閉合檢查：** 遍歷全部 referenced rule_id／parameter_id／field_id／signal_id。每個引用必須落到本包明確定義或版本鎖定正式來源；外部資料 producer 可以尚未接，但其交付型別與不足行為必須明確。不得以兩份文件互相指向形成空定義。


### QA2 全域驗收案例


本節共68個案例：A7、B9、C13、D13、E10、F10、G6；全為 **DESIGNED_NOT_RUN**。數字僅為測試 fixture，不新增策略門檻。K、N 依各正式投票組；沒有對應正式定義的數字只測邏輯。

#### QA A 型別 三值與規則完整性

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| A01 | 三值 AND／OR 全九組、NOT 全三組 | 強 Kleene 表完整；FALSE∧U=FALSE、TRUE∨U=TRUE、¬U=U |
| A02 | 去重後 N-of-K：T≥K；T+U<K；其餘 | TRUE；FALSE；UNKNOWN，未知別名不得膨脹 U |
| A03 | 空子句、適用性 UNKNOWN、OPTIONAL 缺失各一組 | 無中性政策不能 all([])=TRUE；UNKNOWN 不刪成 N/A；無關 Optional 不全局阻擋 |
| A04 | rule_id／parameter_id 無法解析；相互引用但無 terminal 定義 | SPEC_INCOMPLETE 診斷；不得用安全停止宣稱正向政策完整 |
| A05 | 缺值 null、NaN、±Infinity、缺單位、錯幣別 | 依型別／資料品質拒絕或 UNKNOWN，不能等於0或合法低值 |
| A06 | 比較門檻恰等於值、來源精度相同或不同 | 按明列 <／≤／≥／>，不得顯示四捨五入後再判斷或自造 epsilon |
| A07 | 本版參數已核准且值／語意完整；另一必要實際輸入空白 | 前者按核准公式實作，不因舊標籤拒算；後者按INPUT_REQUIRED與相依三值處理，不虛構資料 |

#### QA B 路由 估值與十一類

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| B01 | 對 C01–C11 各執行唯一有效 profile、零匹配與多匹配 | 唯一才成功；零／多匹配診斷，不字典 first-match |
| B02 | 金融＋高品質；半導體＋高成長；高Beta＋虧損 | 合法 subtype precedence 有既有來源或本版明示核准補充；不以品質／Beta改經濟估值方法 |
| B03 | Forward PE 失效、PB 合法；主 PE 合法但 PE 歷史不足 | 前者 PB 自己歷史／range；後者保留 PE 主指標與未知分位，不為湊歷史換法 |
| B04 | PE≤0／無經濟意義；負 FCF Yield | PE 不判極便宜；yield 不截0或機械認便宜，走方法適用性 |
| B05 | raw FCF Yield rank＝90／5 | 昂貴分位＝10／95；方向相反且不套 PE 絕對數字 |
| B06 | 另一 ETF、指數或 share class 的歷史可用但本標的不足 | 不串用；保留本標的資料不足 |
| B07 | 中小型獲利公司比例當成倍數傳入；SOXX 套 QQQ PE 界 | 型別／scope 拒絕，不能計 Stage |
| B08 | 六個正式 PE range 類別逐切點；五個無正式固定 range 類別 | 已有切點保留，邊界不重疊；未有的只可採本文已明列的核准補充；本文未訂的range不得虛構 |
| B09 | ETF missing exposure 增加、成分分母未全知、跨日 holdings | 不重標未知權重為0或把已知重攤100%；未同截面不混算 |

#### QA C 模式 階梯與依賴

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| C01 | Up TRUE；Right TRUE；Left TRUE | 正常 Trend；其他 Predicate 可保留，安全與執行優先序另判 |
| C02 | Up UNKNOWN、Right TRUE；Up FALSE、Right UNKNOWN、Left TRUE | 正常 Mode UNKNOWN；不偷選 Right／Left |
| C03 | Up FALSE、Right FALSE、Left FALSE | Base；仍不證 Base Buy eligibility |
| C04 | Up TRUE＋Down TRUE 同 snapshot；Left/Right TRUE＋Down TRUE | 正式非法衝突，採 Down 安全結果、禁止新買、要求 reconcile；不能單純選Trend |
| C05 | Stage→Target→Gap→under_deployed→Stage 或 Permission→Safety | 發布／建置 DAG 驗收失敗；不以昨日值或迭代解圈 |
| C06 | 固定所有市場事實，只改持倉／活動訂單使Gap由正到負 | 不因 Gap 數值回改正常市場 Predicate／Stage；只變執行需要，另有合法專案政策須顯名 |
| C07 | B2 TRUE、B3 TRUE、B4 UNKNOWN、B5–7 FALSE | 選階結果 UNKNOWN；診斷界3–4，不能以3直接交易 |
| C08 | 全 FALSE；無 TRUE但有UNKNOWN；最高TRUE=5、6–7 FALSE且低階UNKNOWN | 分別無支持階段、UNKNOWN無虛構下界、最大值可5但保留低階未知與一致性檢查 |
| C09 | 同完整合法域 B4 TRUE、B3 FALSE | 已反證聲稱巢狀；停止選階，不取max掩蓋；runtime先查跨snapshot／版本錯配 |
| C10 | 選階結果5確定、正式必要Stage政策UNKNOWN；無關高階已FALSE | 正式Stage仍UNKNOWN；不相關未知不應污染已不可能路徑 |
| C11 | 九個合法Stage、PTP=1000 | 目標100/200/300/450/600/750/850/950/1000，非本輪買入量 |
| C12 | Stage6降Stage3且Projected高於新Target | 負Gap／Buy0；無獨立Risk Sell依據不自動賣出 |
| C13 | Trend成立但估值／其他Stage限制不許9 | 依明確 resolver 得較低合法Stage或UNKNOWN，不機械滿配；不回讀Gap |

#### QA D 技術訊號 風險與證據

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| D01 | 每項「明顯／持續／快速／健康／未過高」語意 | 均能解析成具單位、視窗、等號、seed、事件有效期與reset的公式，不能留形容詞 |
| D02 | 同一 MACD alias 兩個TRUE＋另一TRUE；門檻3 | 只能2票；同一訊號多UNKNOWN只1個可能票 |
| D03 | MA20及MACD共享OHLC但屬正式獨立slot | 不能按共同raw data錯殺去重；slot的合法性有Registry依據 |
| D04 | 單個KD／MACD／EMV／RSI／TD9極端；其餘不滿足上層 | 不單獨建立Hard Gate／Structural Break／Sell或買賣分類 |
| D05 | Runaway Down：A價格結構至少1＋B加速至少2；「跌很多」但A/B不足 | 前者按三值；後者不能把跌幅當RD，RD也不自動等於Sell／Structural Break |
| D06 | Hard Gate TRIGGERED，PV選階6；另已成立Right分析 | Left safety FALSE、Left predicate FALSE、禁止Left意圖而留PV；Right可留合法分析，Permission FALSE；不直接把Stage清0 |
| D07 | Required Safety不足且Gate UNKNOWN；Optional soft資料不足 | 前者Permission FALSE／DATA_INSUFFICIENCY，不偽稱Gate觸發；後者只污染真正依賴 |
| D08 | Extreme Flag ON但無新增買入否決來源 | 降追價／調速等只按明確規則，Flag本身不變Hard Gate或一律Buy0 |
| D09 | 同一事件五次轉載；同一文件兩個可獨立重大事實 | 前者不五票；後者不能只因同文件就一律合併；按underlying event/domain關係 |
| D10 | Structural Break只有兩則新聞但同domain／無事前Thesis持續Failure | 不成立；至少獨立重大證據跨兩domain及事前Thesis持續失效與正式交叉驗證 |
| D11 | 已確認Structural Break、技術速度資料不足 | 只限正式Reduction NORMAL安全fallback並留technical insufficiency；不可外推正常Buy |
| D12 | Pending／unconfirmed Emergency；confirmed Emergency | 不將pending當confirmed；confirmed最高Execution Intent且不新造Sell rate／deadline |
| D13 | Daily／Weekly／Monthly同名指標與bearish confluence | 各完成bar、aggregation、seed／warm-up及available_at均明列；不得用未完成週/月bar或把日線結果複製成三票 |

#### QA E 新聞 資料品質與時間

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| E01 | 所有欄as_of相同，但available_at分別≤t及>t | 只前者可用；retrieved_at不能替代available_at |
| E02 | future Swing confirmation、未完成週／月bar、盤中值混completed close | 當輪不得消費未來／未完成資料；event/state依契約維持 |
| E03 | Optional provider失敗；Required safety或Active Refresh失敗 | 前者可PARTIAL且不單獨Gate；後者依正式INSUFFICIENT／Permission阻擋 |
| E04 | 搜尋成功0筆；搜尋失敗；無Registry recovery只查近期90天 | 不混為同狀態；不能以近期零筆推舊Active事件結案 |
| E05 | Search STALE但Evidence VALID；coverage本身不可判定 | freshness與validity保留；UNKNOWN為value state不創第四coverage enum |
| E06 | persistence失敗／checkpoint未commit／cancel狀態中斷恢復 | 不前移失敗來源cursor、不虛構安全完整；按恢復契約處理 |
| E07 | 同snapshot改retrieved_at；後到修訂重寫過去資料 | 前者不能改決策as_of；後者另vintage，不倒灌舊決策 |
| E08 | 同基金split+dividend、支付日再現、adjusted close混raw | 合法事件依同單位只計一次；支付日不二次入帳；調整口徑混用拒絕 |
| E09 | W缺session／未知calendar／未知公司行動coverage／σ=0 | 斷鏈或UNKNOWN，不前填、不跳接、不除零；重seed不跨segment帶高點／分布 |
| E10 | D=0、σ UNKNOWN；D>0、σ UNKNOWN | 前者新增3–7價格FALSE可短路，σ仍UNKNOWN；後者若可能改變則UNKNOWN |

#### QA F 資金 訂單與副作用

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| F01 | Target100、Confirmed40、Active Buy10、Active Sell0 | Projected50、Gap50，不Gap外再減同筆10 |
| F02 | Available-to-trade20已扣Reserved10；Gap50 | Cash仍20，不扣成10；若現金來源是不同語意須顯名轉換 |
| F03 | Cancel／Replace Pending、部分成交、重送相同run | 按正式活動曝險維持，未確認取消不釋出Gap；去重／idempotency不重下 |
| F04 | 必要Cap未知、幣別未知、FX過期、lot/tick未知 | 不視∞／0或自動忽略；無合法可送買單 |
| F05 | Permission TRUE、Gap正，但Base資格否決／slice未定／價格不合法 | 不產Buy；Permission及Maximum不是完整買入授權 |
| F06 | Gate已TRIGGERED且Cash UNKNOWN | Cash仍UNKNOWN但本輪正常Buy可知0；不全欄污染 |
| F07 | 期望Buy amount已算，最小量／交易單位四捨五入可能超上限 | 量化後仍不得超Gap、cash、caps；明列floor／不交易及費用預留語意 |
| F08 | 相同市場輸入重跑，不同對帳版本／fill arrival | 不修改舊snapshot；新run重算Gap，舊意圖需依正式有效性／重放契約失效 |
| F09 | W假設除息日再投資所得「現金」 | 不作broker可用現金、不形成資金注入或付款證據 |
| F10 | 上游V70預算足夠但券商cash不足；或反之 | 分別保留限制；不把預算空間當現金，不重算S0/B0 |

#### QA G 輸出與證據層次

| ID | 操作／輸入 | 唯一預期 |
|---|---|---|
| G01 | 加選階診斷上下界、profile、測試狀態 | 仍49個Canonical欄／13個Execution View欄；新診斷存sidecar／合法nested evidence |
| G02 | 同輸入／規則／source snapshot重播 | 決策與evidence可確定重播；生成時間可變但不假冒來源時間 |
| G03 | 研究kernel90項PASS，但正式T01–T42未跑 | 僅報kernel範圍；正式整合仍NOT_RUN，不繼承PASS |
| G04 | VT／VWRA兩路通；用當下下載歷史當PIT | 只證兩路有限管線，非充分獨立樣本；retrieval不證歷史available_at |
| G05 | 看holdout後改參數／通關線／normalization | 該holdout已被使用；不可仍標盲驗，版本與新驗證證據重新鎖定 |
| G06 | 找不到正向例但所有缺值均可fail-closed | 安全拒絕程式路徑可完整，完整三層策略規格仍不通過 |


### QA3 跨章一致性


發布前逐一比對下列名詞是否同一規則：

1. 原生Swing／ATR與W／Z／qP：同名特徵不得混口徑；一套不得偷偷替代另一套。
2. Stage2最少合法價格OR與Stage3–7加深門檻：不可一份保留Stage2基線，另一份要求Stage2必先過qP。
3. 正式Grade／Macro／基本面規則與新增規則中的stage限制：caps與speed的作用域、未知規則與是否新政策必須一致。
4. MA20保護、兩根MACD確認、KD／EMV平滑seed、訊號event有效期：同ID不能有不同數字或視窗。
5. Right至少三票、Runaway Up A至少1/B至少3、Down A至少1/B至少2：原slot與新增量化別名需一對一，不新增計票資格。
6. Hard Gate對Left的因果重算與對Right分析保留；不可「一律不改Mode」與「一律清空」並存。
7. Extreme Flag調速與非禁止買進權；本版若另有Stage或價位限制須明標採用差異，不冒稱S1原有。
8. 財務／技術unknown、適用域外未定policy、資料producer未接、實作未驗證：分別列原因；本版採用批准已完成，不能以舊狀態新增批准阻擋。
9. 本版適用域是否包含11類，以及每個subtype的fallback是否真正閉合。
10. Buy slice到底是Gap、Maximum、Stage target增量還是PTP的比例；不同分母不得混用。
11. 制度轉折／來源修訂／滾動窗口：不得一份要求固定，另一份允許擇優重置。
12. 正式輸出與Canonical schema：核准規則經驗證後接對應Owner；診斷仍存sidecar／合法nested evidence，不因舊研究隔離契約永久禁寫正式Stage。


### QA4 驗收紀錄

每項保留test_id、spec_version、input_fixture_id及hash、expected、observed、test_layer、execution_time、runner、result與證據定位。未執行標DESIGNED_NOT_RUN；文義對照只標STATIC_REVIEW。技術T001至T053、模式MR01至MR52與本章全域A至G案例各有命名空間，不能與正式T01至T42整合案例混淆。

### QA5 十一類與九階追溯

下列矩陣是可實作的參數化驗收設計，狀態均為DESIGNED_NOT_RUN；不能與第8章已跑過的窄範圍selector測試合併計成整合PASS。C01至C11一一對應PV4 1至PV4 11。每個Cxx-Syy格的fixture由該類路由、下表指定的階段輸入及共同安全契約組成；expected按本版已核准規則驗證，完整Owner依賴通過後可產正式Stage，但本表不是已執行結果。

共同前置：使用同asset、snapshot及版本，所有當輪適用的安全、基本面、授權與Stage必要證據均合法且可裁決，無更高風險、無衝突；ETF依CMR 6.3 viable及look-through，個股依CMR 6.1至6.3事前Thesis及風險。C01至C08採各自合法Forward PE路徑；C09限定已核實Industrials sector ETF的PV4A核准路由；C10與C11採已核實獲利成長個股路由。這是每類一條受支援正向路徑，不宣稱所有subtype已取得資料。

純選階接口fixture的selected_primary為合法Forward PE=10；C01至C06的正式range適用性具證據TRUE，C07至C11具證據確認無適用range而為FALSE／N/A。qP與qV是已合法生成的介面輸入；原始價格、估值史及range resolver仍須另作端到端fixture。非Forward PE、金融／虧損／不穩定EPS、override、分類衝突及資料不足另依PV2、PV4A及QA2 B組測試，不用本正向fixture取代。

| 階段fixture | 鎖定輸入及必要市場條件 | 唯一預期及規則 |
|---|---|---|
| S01 | Up FALSE、Right FALSE、Left FALSE，Base授權及所有Stage依賴完整 | Base參考Stage1；CMR 7.1及7.4；不可由UNKNOWN回退 |
| S02 | Up／Right FALSE、Left TRUE；B2 TRUE、D>0、qP=50、qV=80 | 唯一PV選階Stage2；PV3；qP<75排除Stage3至7 |
| S03 | 同S02的Left條件；D>0、qP=80、qV=50 | 唯一PV選階Stage3；PV3；Stage4的qV<40 FALSE |
| S04 | 同S02的Left條件；D>0、qP=80、qV=30 | 唯一PV選階Stage4；PV3；Stage5的qP≥90 FALSE |
| S05 | 同S02的Left條件；D>0、qP=95、qV=30 | 唯一PV選階Stage5；PV3；Stage6的qV<20 FALSE |
| S06 | 同S02的Left條件；D>0、qP=95、qV=10 | 唯一PV選階Stage6；PV3；Stage7的qP≥97.5 FALSE |
| S07 | 同S02的Left條件；D>0、qP=99、qV=10 | 唯一PV選階Stage7；PV3；沒有Stage8／9結果回流 |
| S08 | Up FALSE、Right TRUE；off-low TRUE、至少3去重確認、所需T+1 PASS | Right參考Stage8；TECH 4.1、7、8及CMR 7；另測Trend qV=60只到Stage8 |
| S09 | Up TRUE且Down FALSE；qV=50、A_normal TRUE或明定N/A，適用Stage依賴完整 | TrendStage9；TECH 4.2至4.3及CMR 7.4；不是必須當日滿配 |

每一格代表明確的class_id×stage fixture ID，不以空白或「同上」隱藏覆蓋。完整九階拆成兩張窄表以便閱讀。

| 類別 | Stage1 | Stage2 | Stage3 | Stage4 | Stage5 |
|---|---|---|---|---|---|
| C01 全球ETF | C01-S01 | C01-S02 | C01-S03 | C01-S04 | C01-S05 |
| C02 美國核心 | C02-S01 | C02-S02 | C02-S03 | C02-S04 | C02-S05 |
| C03 科技成長 | C03-S01 | C03-S02 | C03-S03 | C03-S04 | C03-S05 |
| C04 台灣權值 | C04-S01 | C04-S02 | C04-S03 | C04-S04 | C04-S05 |
| C05 製藥醫療 | C05-S01 | C05-S02 | C05-S03 | C05-S04 | C05-S05 |
| C06 美國中小 | C06-S01 | C06-S02 | C06-S03 | C06-S04 | C06-S05 |
| C07 半導體 | C07-S01 | C07-S02 | C07-S03 | C07-S04 | C07-S05 |
| C08 國防軍工 | C08-S01 | C08-S02 | C08-S03 | C08-S04 | C08-S05 |
| C09 產業主題 | C09-S01 | C09-S02 | C09-S03 | C09-S04 | C09-S05 |
| C10 成熟個股 | C10-S01 | C10-S02 | C10-S03 | C10-S04 | C10-S05 |
| C11 高Beta個股 | C11-S01 | C11-S02 | C11-S03 | C11-S04 | C11-S05 |

| 類別 | Stage6 | Stage7 | Stage8 | Stage9 |
|---|---|---|---|---|
| C01 全球ETF | C01-S06 | C01-S07 | C01-S08 | C01-S09 |
| C02 美國核心 | C02-S06 | C02-S07 | C02-S08 | C02-S09 |
| C03 科技成長 | C03-S06 | C03-S07 | C03-S08 | C03-S09 |
| C04 台灣權值 | C04-S06 | C04-S07 | C04-S08 | C04-S09 |
| C05 製藥醫療 | C05-S06 | C05-S07 | C05-S08 | C05-S09 |
| C06 美國中小 | C06-S06 | C06-S07 | C06-S08 | C06-S09 |
| C07 半導體 | C07-S06 | C07-S07 | C07-S08 | C07-S09 |
| C08 國防軍工 | C08-S06 | C08-S07 | C08-S08 | C08-S09 |
| C09 產業主題 | C09-S06 | C09-S07 | C09-S08 | C09-S09 |
| C10 成熟個股 | C10-S06 | C10-S07 | C10-S08 | C10-S09 |
| C11 高Beta個股 | C11-S06 | C11-S07 | C11-S08 | C11-S09 |

### QA6 十一類與四模式生命週期追溯

每個Cxx-MB／ML／MR／MT依相同Cxx路由及上列S01／S03／S08／S09進入對應模式，並實作以下完整序列。Entry適用CMR 7及TECH必要predicate；切片依CMR 8；共享資金、lot、活動意圖與對帳依CMR 9。Base與Left的成熟度TRUE／FALSE／UNKNOWN分支均測；Right及Trend的固定率不因無關成熟度未知而失效。模式暫停不是新增第五個Mode。

共同生命週期fixture：初始正Gap及全部執行必要證據已知，credit Level0、macro FALSE、Extreme Flag FALSE、現金及caps足夠，建立唯一daily cycle；第一次產生正切片。同session重跑不重置額度；填單減少cycle room，CANCEL_PENDING仍保留commitment，confirmed cancel才釋放。其後觸發Hard Gate時所有正常新Buy為0；Left依CMR 7.3重算為FALSE，Right只在自身條件仍成立時保留當輪分析。解除須各自有效Recovery與當輪完整重算，不能由舊event消失或重抓0筆新聞自動恢復。下一合法session才可建立下一cycle。只驗狀態機，不發真實訂單。

Trend另加CMR 8的extreme bull bar與entry_structure分支：已知極端大陽使新增時機FALSE但保留市場Mode／Stage／Gap；條件UNKNOWN則相依切片UNKNOWN；解除後仍受同cycle餘額限制。較高模式UNKNOWN不允許回退，Up與Down衝突先走CMR 7.1。相應反向驗收包括MR19至MR22、MR28至MR34、MR41至MR42及MR48至MR52。

| 類別 | Base生命週期 | Left生命週期 | Right生命週期 | Trend生命週期 |
|---|---|---|---|---|
| C01 全球ETF | C01-MB | C01-ML | C01-MR | C01-MT |
| C02 美國核心 | C02-MB | C02-ML | C02-MR | C02-MT |
| C03 科技成長 | C03-MB | C03-ML | C03-MR | C03-MT |
| C04 台灣權值 | C04-MB | C04-ML | C04-MR | C04-MT |
| C05 製藥醫療 | C05-MB | C05-ML | C05-MR | C05-MT |
| C06 美國中小 | C06-MB | C06-ML | C06-MR | C06-MT |
| C07 半導體 | C07-MB | C07-ML | C07-MR | C07-MT |
| C08 國防軍工 | C08-MB | C08-ML | C08-MR | C08-MT |
| C09 產業主題 | C09-MB | C09-ML | C09-MR | C09-MT |
| C10 成熟個股 | C10-MB | C10-ML | C10-MR | C10-MT |
| C11 高Beta個股 | C11-MB | C11-ML | C11-MR | C11-MT |

99個class-stage格與44個class-mode格是參數化追溯單元，不是143個已執行測試，也不與TECH 53、CMR 52、全域68案例直接相加為獨立覆蓋數。任何實作須保留展開後的完整fixture、獨立expected、observed及版本receipt。


<!-- PAGEBREAK -->

## 8 資料與實作證據的實際邊界

官方取證為2026年10月27日18時50分至18時55分UTC，VWRA既有快取增補於19時08分UTC；as_of、retrieved_at及歷史available_at分開。以下是實際有限樣本，不是當前買點或全歷史PIT認證。

| 來源 | 實際取得的資料 | 不能推論的事情 |
|---|---|---|
| VT 官方CSV | 2025年250列Market Price／NAV；2026年10月1–26日18列；40筆現金分派 | 尚非已核定raw日頻全歷史或完整拆股庫；無OHLC／volume／adjustment flag |
| VT 10年網頁視圖 | 120列月度NAV | 不能當10年日線市場收盤，不能補日頻缺口 |
| VWRA 第三方原樣快取 | 1834列；71列不符OHLC關係；末段683列結構自洽 | 非發行人下載；後綴自洽不證準確、交易日完整、調整語意或PIT |
| VWRA 近期對照 | 10個重疊Close與官方USD兩位小數顯示一致 | 只證該批顯示精度，不認證其他歷史OHLC／公司行動 |

VT產品P/E tooltip明指過去一年盈利、growth明指過去五年平均年度增長；不當Forward PE／未來EPS。VWRA factsheet的PE示例支持歷史方向，但組合全口徑未核實，growth歷史／預測仍未知，不能借VT。官方當期值不因未披露全部細節而抹除，正式准入沿既有Owner契約，不另造逆向重建門檻。

[VT官方產品及定義](https://investor.vanguard.com/investment-products/etfs/profile/vt)　[VT官方下載頁](https://advisors.vanguard.com/investments/products/vt/vanguard-total-world-stock-etf)　[VWRA官方事實表](https://fund-docs.vanguard.com/FTSE_All-World_UCITS_ETF_USD_Accumulating_9679_INT_OFF_ETF_EN.pdf)

VWRA受資格確認保護的發行人下載本輪未取得，不聲明資格或繞過；不等於資料不存在。既有快取日期2019年7月23日早於官方上市日7月25日，最早列不可默認為真實交易日。兩檔均未驗證具發布時間、版本修訂及同口徑連續估值史；今日歷史行或搜尋舊日期不能當當時available_at。


### 既有全球ETF研究原型的限定結果

上一版全球ETF研究原型已執行90項單元方法，包含17個候選案例、4050組有限邊界及W十組規格；主線獨立重跑90項通過，W限定同儕複核16項通過。正常及最佳化執行、語法編譯與合成demo重播通過。這些只覆蓋該舊研究kernel，不為1.0完整十一類、技術、宏觀、模式及切片整合背書。

該歷史原型formal_stage永為null；未產正式Mode、Permission、Gap、Cash或Orders。這是舊test harness的實作事實，不是1.0的runtime指令；工程須按本版完成正式整合，不沿用null禁令。原生feed至snapshot sampler、真實calendar與price vintage loader、正式來源映射及持久化revision ledger在該原型仍未完成。所有合成proof ID不是市場來源已驗證的證據。

### v0.4 純選階參考器的歷史實際檢查

v0.4編製時對Stage2至7純選階參考器執行10個單元方法，正常及Python最佳化模式均通過；獨立檢閱者以另外9個方法在兩種模式重跑通過。獨立集含11類乘6階合法Forward PE fixtures、六組絕對區間邊界、77組非法PE、4224組有限巢狀格點，以及三值、range適用性UNKNOWN、無支持與高階UNKNOWN行為。

參考器假定當前估值已經通過合法Waterfall；不實作真實資料Resolver、專屬range override或正式Mode／Stage／Permission。其保守布林可能階段上界不宣稱是所有共享數值約束下精確可達的集合，更不是可執行下界。這些結果不能替代第4章技術、第5章模式風險及第7章全域案例的實際整合測試。

該歷史受檢選階程式SHA256為69112e7ae967dfcf97fe5da094e42c21ec851cc15ec5c56fe0dd2e630e890423。版本識別用於重播；本版採用批准不改寫此程式或增加其測試範圍。

### 本版技術數值的限定檢查

本輪另執行35項技術數值單元方法，主線獨立以正常及Python最佳化模式重跑均通過。範圍是受測primitive的公式、seed、數值一致性及邊界，不是TECH T001至T053全部事件／生命週期／整合案例通過，也不是CMR MR01至MR52或全域68案例通過。受檢技術來源SHA256為2d31ade8631eddf30f4ce2d3015d8ef67740434c02bfecc9b4d68fd1744e7de5。

### 本版限定靜態一致性審查

獨立檢閱曾對v0.4十一類路由、技術Predicate及模式風險來源鎖定版本完成限定靜態一致性審查，結論為可交工程依規格實作。已修正的重要歧義包括Structural Break確認前置、事件有效期、未知傳播、Stage與Gap分離及日切片資金口徑。這是歷史規格審查，不是全域測試；1.0新增的採用批准來自本次使用者指示，不將它算成技術驗證。第7章追溯矩陣仍為設計案例。

### 本版未執行的驗收範圍

第7章68個全域案例目前為DESIGNED_NOT_RUN；技術與模式章所列expected仍屬設計驗收，除非另有具版本實跑receipt，不能標PASS。正式T01至T42 Owner整合仍NOT_RUN。未取得連續真實PIT估值與完整公司行動證據，不宣稱本版回測、策略效力、正式接線或Production放行完成。


<!-- PAGEBREAK -->

## 9 來源與版本

S1 正式V82主規則，v1.21.0，工程77，2026年9月23日。本文以提供的正式版本核對，不宣稱已取得其後所有修訂。主規則SHA256為392e54808c33cce99e3567f0e8942650ad50b382d9fc87acbbe20f012b568372。重點來源包括估值§32、工程22至26、35至44、57至67、73、Thesis及Work7治理。

[開啟正式V82主規則](https://drive.google.com/file/d/1EObD96ptt3Io_YtTNGTWW1bms30wKguz/view)

S2 2026年10月21日技術來源映射候選，SHA256為076fa4ddf9be1d529622893264737d86b2f95974b26f160bbc33dc4cc31e6461。只說明既有候選producer；不是正式來源核定，也不是本版公式逐值相容證明。

S3 Vanguard官方VT與VWRA產品資料及有限下載樣本。來源、as_of、擷取時間與限制見第8章；產品頁當期數字不能認證歷史available_at。

[VT官方產品及定義](https://investor.vanguard.com/investment-products/etfs/profile/vt)　[VWRA官方基金頁](https://www.vanguardoffshore.com/en/product/etf/equity/9679/ftse-all-world-ucits-etf-usd-accumulating)

S4 Bailey、Borwein、López de Prado與Zhu，The Probability of Backtest Overfitting，2015年2月修訂。僅支持多重試驗與過擬合風險，不支持本版任何買點或策略績效。

[閱讀原始研究](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf)

S5 S&P Index Mathematics與FTSE GEIS計算方法僅作總報酬與公司行動方法的參照；本版W是已核准的獨立方法，不宣稱完整複製官方指數。

[S&P方法參照](https://www.spglobal.com/spdji/en/documents/methodologies/methodology-index-math.pdf)　[FTSE方法參照](https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/ftse-global-equity-index-series-guide-to-calc.pdf)

本版所有新增常數、方法、時窗、狀態機與Stage對應隨1.0凍結，已獲使用者採用批准。工程直接依本版實作、驗證及整合，不再要求同一批規則逐項重批。後續改公式、改參數或擴大適用域須另立版本與授權；文稿交付、合成測試或資料接線成功均不等於交易授權。
