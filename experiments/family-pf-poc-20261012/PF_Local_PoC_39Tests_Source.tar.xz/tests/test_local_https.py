"""Local TLS handshake checks only.  NOT proof of a remote MCP deployment."""
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler,HTTPServer
from threading import Thread
from pathlib import Path
import ssl, urllib.request, urllib.error
import pytest
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa

class Health(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path !='/health': self.send_response(404); self.end_headers(); return
        self.send_response(200); self.send_header('Content-Type','text/plain');self.end_headers();self.wfile.write(b'healthy')
    def log_message(self,*args):pass

def makecert(tmp):
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')]);now=datetime.now(timezone.utc)
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=1))
          .not_valid_after(now+timedelta(minutes=30))
          .add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost')]),critical=False)
          .sign(key,hashes.SHA256()))
    certfile=tmp/'cert.pem';keyfile=tmp/'key.pem'
    certfile.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    keyfile.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    return certfile,keyfile

@contextmanager
def https(tmp_path):
    cert,key=makecert(tmp_path)
    server=HTTPServer(('127.0.0.1',0),Health)
    sslctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);sslctx.load_cert_chain(certfile=str(cert),keyfile=str(key))
    server.socket=sslctx.wrap_socket(server.socket,server_side=True)
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    try:yield f'https://localhost:{server.server_port}/health',cert
    finally:server.shutdown();thread.join(timeout=3);server.server_close()

def test_37_locally_trusted_https(tmp_path):
    with https(tmp_path) as (url,cert):
        ctx=ssl.create_default_context(cafile=str(cert))
        with urllib.request.urlopen(url,context=ctx,timeout=3) as resp:
            assert resp.status==200 and resp.read()==b'healthy'

def test_38_untrusted_certificate_denied(tmp_path):
    with https(tmp_path) as (url,cert):
        with pytest.raises(urllib.error.URLError):
            urllib.request.urlopen(url,context=ssl.create_default_context(),timeout=3)

def test_39_unreachable_endpoint_fail_closed():
    with pytest.raises((urllib.error.URLError,ConnectionError,TimeoutError,OSError)):
        urllib.request.urlopen('https://127.0.0.1:1/health',timeout=1)
