import asyncio
import httpx
from pf_mcp_gate import app

async def req(method, path='/mcp', json=None, headers=None):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='https://pf.invalid') as c:
        return await c.request(method,path,json=json,headers=headers)

def test_health_is_explicitly_hold():
    x=asyncio.run(req('GET','/healthz'))
    assert x.status_code==200 and x.json()['data_access'] is False

def test_initialize_public_no_customer_data():
    x=asyncio.run(req('POST',json={'jsonrpc':'2.0','id':1,'method':'initialize'}))
    assert x.status_code==200 and 'capabilities' in x.json()['result']

def test_tools_list_empty_until_verified_identity():
    x=asyncio.run(req('POST',json={'jsonrpc':'2.0','id':2,'method':'tools/list'}))
    assert x.json()['result']['tools']==[]

def test_forged_project_header_denied():
    x=asyncio.run(req('POST',json={'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'read_family'}},headers={'X-Project-ID':'PF_TEST_PROJECT_A'}))
    assert x.status_code==403 and x.json()['gate']=='HOLD'

def test_fake_bearer_is_denied():
    x=asyncio.run(req('POST',json={'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'modify_family'}},headers={'Authorization':'Bearer fake.jwt.token'}))
    assert x.status_code==403

def test_payload_project_claim_is_denied():
    x=asyncio.run(req('POST',json={'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':'read_family','arguments':{'project':'PF_TEST_PROJECT_A','client_id':'PF_TEST_CLIENT_A'}}}))
    assert x.status_code==403

def test_malformed_input_denied():
    x=asyncio.run(req('POST',json=['bad']))
    assert x.status_code==400
