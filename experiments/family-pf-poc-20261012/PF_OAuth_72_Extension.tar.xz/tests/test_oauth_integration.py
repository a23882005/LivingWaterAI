import base64
import json
import time
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives import hashes
from fastapi.testclient import TestClient
from pf_backend_auth import ClientScope,Resource
from pf_oauth_verifier import JWTVerifier,TokenRejected,make_app

def enc(obj): return base64.urlsafe_b64encode(json.dumps(obj,separators=(',',':')).encode()).rstrip(b'=').decode()

@pytest.fixture
def env():
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    other=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    v=JWTVerifier('https://issuer.test/','pf-test',{ 'good':key.public_key() })
    scope=ClientScope({'https://issuer.test/|joseph':frozenset({'joseph'}),'https://issuer.test/|mou':frozenset({'mou'})},
                      {'r-j':Resource('r-j','joseph','synthetic-j'),'r-m':Resource('r-m','mou','synthetic-m')})
    def sign(sub='joseph',key_override=None,**override):
        head={'alg':'RS256','typ':'JWT','kid':'good'}
        now=int(time.time()); payload={'iss':'https://issuer.test/','aud':'pf-test','sub':sub,'exp':now+300,'iat':now,'nbf':now-1}
        payload.update(override)
        signing=f'{enc(head)}.{enc(payload)}'; signed=(key_override or key).sign(signing.encode(),padding.PKCS1v15(),hashes.SHA256())
        return signing+'.'+base64.urlsafe_b64encode(signed).rstrip(b'=').decode()
    return TestClient(make_app(v,scope)),scope,sign,v,other

def call(client,token,client_id,resource_id,project='anything'):
    headers={} if token is None else {'Authorization':'Bearer '+token}
    return client.post('/pf/resource/read',headers=headers,json={'active_client_id':client_id,'resource_id':resource_id,'project_hint':project})

def test_joseph_allowed(env):
    c,s,sign,*_=env; assert call(c,sign(),'joseph','r-j').json()['content']=='synthetic-j'
def test_mou_allowed(env):
    c,s,sign,*_=env; assert call(c,sign('mou'),'mou','r-m').status_code==200
def test_cross_joseph_to_mou(env):
    c,s,sign,*_=env; assert call(c,sign(),'mou','r-m').status_code==403
def test_cross_mou_to_joseph(env):
    c,s,sign,*_=env; assert call(c,sign('mou'),'joseph','r-j').status_code==403
def test_resource_id_tamper(env):
    c,s,sign,*_=env; assert call(c,sign(),'joseph','r-m').status_code==403
def test_project_name_impersonation(env):
    c,s,sign,*_=env; assert call(c,sign(),'mou','r-m',project='mou').status_code==403
def test_no_token(env):
    c,s,sign,*_=env; assert call(c,None,'joseph','r-j').status_code==401
def test_invalid_signature(env):
    c,s,sign,v,other=env; assert call(c,sign(key_override=other),'joseph','r-j').status_code==401
def test_expired(env):
    c,s,sign,*_=env; assert call(c,sign(exp=int(time.time())-10),'joseph','r-j').status_code==401
def test_future_nbf(env):
    c,s,sign,*_=env; assert call(c,sign(nbf=int(time.time())+100),'joseph','r-j').status_code==401
def test_bad_issuer(env):
    c,s,sign,*_=env; assert call(c,sign(iss='https://evil.test/'),'joseph','r-j').status_code==401
def test_bad_audience(env):
    c,s,sign,*_=env; assert call(c,sign(aud='elsewhere'),'joseph','r-j').status_code==401
def test_empty_subject(env):
    c,s,sign,*_=env; assert call(c,sign(sub=''),'joseph','r-j').status_code==401
def test_audit_denials(env):
    c,s,sign,*_=env;call(c,sign(),'mou','r-m');call(c,None,'joseph','r-j')
    assert len(s.audit)==2 and all(x['decision']=='DENY' for x in s.audit)
