import pytest
from pf_backend_auth import ClientScope, Resource, AuthorizationDenied

@pytest.fixture
def scope():
    return ClientScope({'u_j': frozenset({'joseph'}), 'u_m': frozenset({'mou'})},
      {'r_j': Resource('r_j','joseph','SYNTHETIC_J'),
       'r_m': Resource('r_m','mou','SYNTHETIC_M')})

def test_joseph_own(scope):
    assert scope.read(verified_user_id='u_j', active_client_id='joseph',resource_id='r_j') == 'SYNTHETIC_J'
def test_mou_own(scope):
    assert scope.read(verified_user_id='u_m',active_client_id='mou',resource_id='r_m') == 'SYNTHETIC_M'
@pytest.mark.parametrize('user,active,resource', [
    ('u_j','joseph','r_m'), ('u_m','mou','r_j'),
    ('u_j','mou','r_m'), ('u_m','joseph','r_j'),
    ('u_j','joseph','missing'), (None,'joseph','r_j'),
    ('u_j',None,'r_j'), ('u_j','joseph','r_m')])
def test_cross_scope_denied(scope,user,active,resource):
    with pytest.raises(AuthorizationDenied):
        scope.read(verified_user_id=user,active_client_id=active,resource_id=resource,
                   project_hint='joseph')
    assert scope.audit[-1]['decision'] == 'DENY'

def test_prompt_project_does_not_grant(scope):
    with pytest.raises(AuthorizationDenied):
        scope.read(verified_user_id='u_m',active_client_id='mou',resource_id='r_j',project_hint='Joseph')

def test_audit_allow_and_deny(scope):
    scope.read(verified_user_id='u_j',active_client_id='joseph',resource_id='r_j')
    with pytest.raises(AuthorizationDenied):
        scope.read(verified_user_id='u_j',active_client_id='joseph',resource_id='r_m')
    assert [x['decision'] for x in scope.audit] == ['ALLOW','DENY']
    assert all('content' not in x for x in scope.audit)
