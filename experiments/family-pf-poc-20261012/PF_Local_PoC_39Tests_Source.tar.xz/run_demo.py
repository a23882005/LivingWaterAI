"""Small, self-contained synthetic verification. No real data, no deployment."""
import secrets,tempfile
from pathlib import Path
from fastapi.testclient import TestClient
from pf_poc import Store,make_app

def run():
    with tempfile.TemporaryDirectory(prefix='pf_demo_') as td:
        s=Store(str(Path(td)/'synthetic.db'),secrets.token_bytes(32));app=make_app(s)
        token_a=s.issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_A')
        token_b=s.issue_for_test(project='PF_TEST_PROJECT_B',client='PF_TEST_CLIENT_B')
        a=TestClient(app,headers={'Authorization':f'Bearer {token_a}'})
        b=TestClient(app,headers={'Authorization':f'Bearer {token_b}'})
        route='/v1/profile'
        before=a.get(route,params={'requested_client_id':'PF_TEST_CLIENT_A'});assert before.status_code==200
        denied=a.get(route,params={'requested_client_id':'PF_TEST_CLIENT_B'});assert denied.status_code==403
        preview=a.post('/v1/propose',json={'requested_client_id':'PF_TEST_CLIENT_A','after_amount':1800,'expected_version':1})
        assert preview.status_code==200
        assert a.get(route,params={'requested_client_id':'PF_TEST_CLIENT_A'}).json()['amount']==1000
        result=a.post('/v1/confirm',json={'requested_client_id':'PF_TEST_CLIENT_A','confirmation_token':preview.json()['confirmation_token']})
        assert result.status_code==200
        assert a.get(route,params={'requested_client_id':'PF_TEST_CLIENT_A'}).json()['amount']==1800
        assert b.get(route,params={'requested_client_id':'PF_TEST_CLIENT_B'}).json()['amount']==1000
        replay=a.post('/v1/confirm',json={'requested_client_id':'PF_TEST_CLIENT_A','confirmation_token':preview.json()['confirmation_token']})
        assert replay.status_code==409
        after_restart=TestClient(make_app(Store(s.path,s.key)),headers={'Authorization':f'Bearer {token_a}'})
        assert after_restart.get(route,params={'requested_client_id':'PF_TEST_CLIENT_A'}).json()['amount']==1800
        print('LOCAL DEMO PASS: Project A -> Test Client A READ=200; A reading B=403;')
        print('Change 1000 -> 1800 after confirmation, Replay=409; B remains 1000; Restart readback=1800.')
        print('NOTICE: test identity tokens are synthetic. This is NOT live ChatGPT Project identity proof.')

if __name__=='__main__':run()
