"""Pure proposed Stage2-7 selector. NOT formal V82; no execution permission."""
from decimal import Decimal
from itertools import product
CUTS={'GLOBAL_EQUITY_ETF':(14,18),'US_LARGE_CORE_ETF':(16,20),'TECH_AI_HIGH_GROWTH_ETF':(18,24),'TAIWAN_LARGE_CAP_ETF':(14,19),'PHARMA_HEALTHCARE_ETF':(14,19),'US_SMALL_MID_CAP_ETF':(13,18),'SEMICONDUCTOR_ETF':None,'DEFENSE_MILITARY_ETF':None,'SECTOR_THEME_ETF':None,'LARGE_MATURE_HIGH_QUALITY_STOCK':None,'HIGH_BETA_EVENT_STOCK':None}

def AND(*xs):
    if any(x is False for x in xs): return False
    return None if any(x is None for x in xs) else True

def number(x,lo=None,hi=None,positive=False):
    if x is None or isinstance(x,bool):return None
    try:y=Decimal(str(x))
    except Exception:return None
    if not y.is_finite() or (lo is not None and y<lo) or (hi is not None and y>hi) or (positive and y<=0): return None
    return y

def cmp(x,op,y):return None if x is None else (x>=y if op=='>=' else x<y if op=='<' else x>y)

def evaluate(profile, price_entry, valuation_legal, depth, q_price, q_value, metric, metric_value, absolute_range_applicability=None):
    if profile not in CUTS:raise ValueError('unknown profile')
    if any(x is not None and type(x) is not bool for x in [price_entry,valuation_legal]):raise ValueError('invalid predicate')
    if metric not in {'FORWARD_PE','TRAILING_PE','CAPE','PB','PTBV','EV_EBITDA','EV_SALES','PS','FCF_YIELD'}:raise ValueError('not a legal valuation metric')
    p=number(q_price,0,100); v=number(q_value,0,100); d=number(depth,0)
    pe=number(metric_value,positive=True) if metric=='FORWARD_PE' else None
    legal=AND(valuation_legal, None if metric=='FORWARD_PE' and pe is None else True)
    b=AND(price_entry,legal); states={2:b}
    for stage,pc,vc in [(3,75,60),(4,75,40),(5,90,40),(6,90,20),(7,Decimal('97.5'),20)]:
        a=True
        if metric=='FORWARD_PE':
            a=(cmp(pe,'<',CUTS[profile][0 if stage>=6 else 1]) if CUTS[profile] else None) if absolute_range_applicability is True else True if absolute_range_applicability is False else None
        states[stage]=AND(b,cmp(d,'>',0),cmp(p,'>=',pc),cmp(v,'<',vc),a)
    # Enumerate compatible truth completions. Null means no supported stage.
    unknown=[s for s,x in states.items() if x is None]; possible=set()
    for values in product([False,True],repeat=len(unknown)):
        resolved=dict(states);resolved.update(zip(unknown,values))
        if any(resolved[s] and not resolved[s-1] for s in range(3,8)):continue
        possible.add(max((s for s,x in resolved.items() if x),default=0))
    if not possible:raise ValueError('inconsistent nested stage states')
    return {'states':states,'candidate_stage':(next(iter(possible)) or None) if len(possible)==1 else None,'status':'DETERMINATE' if len(possible)==1 else 'UNKNOWN','boolean_upper_bound_possible_stages':[x or None for x in sorted(possible)],'formal_stage':None,'research_only':True}
