"""PF OAuth JWT verifier and scoped data endpoint, offline integration prototype.
Production must use provider-published pinned issuer/JWKS over trusted HTTPS and
operational rotation/revocation controls. Test keys are synthetic.
"""
import base64
import json
import time
from dataclasses import dataclass
from typing import Mapping
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from pf_backend_auth import ClientScope, Resource, AuthorizationDenied

class TokenRejected(Exception):
    pass

def _b64decode(s):
    try:
        return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))
    except (ValueError, TypeError) as exc:
        raise TokenRejected('bad_encoding') from exc

def _jsonpart(s):
    try:
        value = json.loads(_b64decode(s))
        if not isinstance(value, dict):
            raise ValueError()
        return value
    except (ValueError, UnicodeDecodeError) as exc:
        raise TokenRejected('bad_json') from exc

@dataclass
class JWTVerifier:
    issuer: str
    audience: str
    public_keys: Mapping[str, rsa.RSAPublicKey]
    leeway_seconds: int = 0

    def verify(self, token: str, now: int | None = None) -> str:
        if not isinstance(token, str) or len(token)>12000:
            raise TokenRejected('bad_token')
        parts = token.split('.')
        if len(parts) != 3:
            raise TokenRejected('bad_token')
        header, payload = _jsonpart(parts[0]), _jsonpart(parts[1])
        if header.get('alg') != 'RS256' or header.get('typ') not in (None, 'JWT'):
            raise TokenRejected('bad_algorithm')
        kid = header.get('kid')
        if not isinstance(kid, str) or kid not in self.public_keys:
            raise TokenRejected('unknown_key')
        try:
            self.public_keys[kid].verify(_b64decode(parts[2]), f'{parts[0]}.{parts[1]}'.encode(), padding.PKCS1v15(), hashes.SHA256())
        except Exception as exc:
            raise TokenRejected('bad_signature') from exc
        t = int(time.time()) if now is None else now
        aud = payload.get('aud')
        auds = [aud] if isinstance(aud, str) else aud if isinstance(aud, list) else []
        if payload.get('iss') != self.issuer or self.audience not in auds:
            raise TokenRejected('bad_issuer_or_audience')
        if len(auds)>1 and payload.get('azp') is None:
            raise TokenRejected('azp_required')
        exp, nbf, iat = payload.get('exp'), payload.get('nbf'), payload.get('iat')
        if not isinstance(exp, int) or isinstance(exp, bool) or exp <= t-self.leeway_seconds:
            raise TokenRejected('expired')
        if nbf is not None and (not isinstance(nbf, int) or nbf > t+self.leeway_seconds):
            raise TokenRejected('not_yet_valid')
        if iat is not None and (not isinstance(iat, int) or iat > t+self.leeway_seconds):
            raise TokenRejected('bad_iat')
        sub = payload.get('sub')
        if not isinstance(sub, str) or not sub or len(sub)>256:
            raise TokenRejected('bad_subject')
        return f'{self.issuer}|{sub}'

class ReadBody(BaseModel):
    active_client_id: str
    resource_id: str
    project_hint: str | None = None

def make_app(verifier: JWTVerifier, scope: ClientScope):
    app = FastAPI()
    @app.post('/pf/resource/read')
    def read_resource(body: ReadBody, authorization: str | None = Header(default=None)):
        if not authorization or not authorization.startswith('Bearer '):
            scope.audit.append({'action':'oauth_authentication','decision':'DENY','reason':'missing_bearer'})
            raise HTTPException(401, 'unauthorized')
        try:
            uid = verifier.verify(authorization[7:])
        except TokenRejected as exc:
            scope.audit.append({'action':'oauth_authentication','decision':'DENY','reason':str(exc)})
            raise HTTPException(401, 'unauthorized') from exc
        try:
            content = scope.read(verified_user_id=uid, active_client_id=body.active_client_id,
                                 resource_id=body.resource_id, project_hint=body.project_hint)
        except AuthorizationDenied as exc:
            raise HTTPException(403, 'access_denied') from exc
        return {'content': content}
    return app
