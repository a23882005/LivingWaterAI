# V82 技術 Predicate 完整研究規格 v0.4

**結論：本稿已把原五向量32個槽位、MA20保護、離開最低點、技術減碼9項、左側成熟度8項及日／週／月趨勢，逐一寫成可實作／可驗收的研究定義，不再以「持續、明顯、快速、健康」留空。**

狀態：`CANDIDATE_SPECIFIED / RESEARCH_ONLY / NOT_APPROVED / NOT_BACKTESTED`。完成的是設計，不是正式策略批准、真行情驗證、系統接線或交易許可。沒有修改V82母規則、正式程式、資料庫、投票門檻或券商狀態。研究輸出不得寫入正式Classification、Mode、Stage、Permission、Execution；`formal_*`一律不由本研究模組產生。

日期：2026-10-27 UTC。適用：有可靠交易日曆、同listing OHLCV及公司行動證據的上市股票／股票ETF。數字候選不是已證實跨資產通用常數。價格以自身資料運算；不從VT、QQQ或指數借價格替其他標的補洞。ETF的C8適用性另見§7，不偽造「ETF公司EPS」。

**股性與參數的明確分界**：下列1%、0.5%、20%、1.5倍、期間等是`technical_baseline_profile_v0.4`的固定研究起點，**不是已證實適用所有股票／十一類的共用有效閾值，也不等於已完成逐股校準**。相同算法使用各標的自己的OHLCV、Swing及ATR，但原生自有資料不會自動使固定百分比完成波動適配。每輪在開始前解析並鎖定`class_profile_id + instrument_profile_id + technical_parameter_version + effective_from + hash`：已有事前登記的研究override才覆蓋指定P參數；否則明示`BASELINE_UNVALIDATED`使用本稿確定預設。F參數不可override。不得當輪看訊號好壞自動調band、以AI主觀股性換閾值、或回測後改參數沿用舊version；任何新profile需另樣本外／敏感度驗證。正式准入仍需Owner核准，baseline可計算不代表可交易。

## 0. 來源、標記與優先序

- **F＝正式繼承**：V82.md v1.21.0，SHA256 `392e54808c33cce99e3567f0e8942650ad50b382d9fc87acbbe20f012b568372`。本輪直接讀工程23–26、42–43、原特殊分類清單、原26／27章Swing、B-3與Work7治理；行號以原檔為準。
- **P＝本稿明確提出的研究預設**：新增算法、種子、窗口、容差、對應或有效期。每列都指出P；即使相似於常見技術分析，也不因此變成正式V82。
- **M＝已存在候選producer的證據**：`W5_09_TECHNICAL_SOURCE_MAPPING_20261021.md`，SHA256 `076fa4ddf9be1d529622893264737d86b2f95974b26f160bbc33dc4cc31e6461`；其中Yahoo候選producer不是已核准正式來源。M不等於F。
- 既有15組量化提案在本稿被整合及補完；若候選之間衝突，以本稿version／method_id為研究規格，**不改變正式SOT優先權**。
- `Work7-A/B-3`的**MACD連續2個完成Bar、0.25×ATR noise band仍不啟用**。本稿其他新期間／百分比只以P名義存在，不借正式或B-3名稱混入。

| 正式來源 | 此稿承接的確定內容F | 本稿不能冒稱已正式確定的內容P |
|---|---|---|
| 工程23，原行412–633、635–799 | TD9日線；Close與t−4比較；9封頂；同向不重複事件；最低13根計當前count；Low分數及×4 | 冷啟動事件可辨識細節、C6事件壽命／創高基準 |
| 工程24，原行236–311 | KD9,3,3及20/80；MACD12,26,9及DIF−DEA；MA5/10/20/50/60/200；交叉不等式 | KD平滑／零range、EMA與RSI種子、敘事持續期 |
| 工程25，原行136–181 | EMV3,3、RSI14及30/70、量與5/20均量比較、局部UNKNOWN | EMV3,3具體算法；量能分母是否含當根；量能倍數與「健康」 |
| 工程26，原行63–109 | 三週期角色、四種已命名組合、same-run alignment | Bullish/Bearish數值分類器及聚合週界細節 |
| 原分類清單，原行7750–8110；工程42/43，原行27923–28065 | Right≥3；Up價格≥1＋強勢≥3＋MA20；Down價格≥1＋加速≥2 | 「明顯／快速／持續／附近」的具體研究門檻及生命期 |
| 原26／27章，原行12900–13480 | Swing High/Low前2＋後2、嚴格比較；未確認不使用 | 擺動串正規化、配對窗口、同bar雙pivot處理 |

## 1. 完整資料與時間契約

### 1.1 指數、型別、局部缺值

`τ`是本輪知識截止UTC時間；`t`是該timeframe預期最新**已收市且正式Close可靠可用**的完整bar；`p=t−1`。所有加減以交易session／完成週／完成月索引，不是日曆天。`C,H,L,O,V`屬同instrument、listing、currency、price_basis、volume_unit、calendar_version及snapshot_vintage。價格有限且>0；`L≤min(O,C)≤max(O,C)≤H`；V有限且≥0。O缺失不污染只需Close的TD9；H/L缺失不污染MA、RSI、MACD。任何依賴的值或口徑無法核對，只讓該輸出UNKNOWN。

布林採Kleene三值：`FALSE AND UNKNOWN=FALSE`，`TRUE AND UNKNOWN=UNKNOWN`，`TRUE OR UNKNOWN=TRUE`，`FALSE OR UNKNOWN=UNKNOWN`；NOT UNKNOWN仍UNKNOWN。完整資料下不符合公式才FALSE。無合格比較對、必要歷史不滿、沒有可靠來源，均非0／FALSE。事件尚待觀察是PENDING／UNKNOWN，不先當成功。

**P數值運算**：來源數值以十進位字串讀入；Decimal精度50、ROUND_HALF_EVEN；公式內不做展示四捨五入；逐步按所列遞迴順序計算；比較以運算值，不加未登記epsilon。只有展示層按來源精度／顯示精度格式化。division by zero、NaN、Infinity→UNKNOWN＋reason。記錄runtime及decimal context以便重播。

### 1.2 價格與公司行動

**F**技術用核對後Canonical Close，不可把Adj Close或總報酬曲線W偷偷換進來。**P研究預設**選`CANONICAL_CLOSE_VERIFIED_RAW_SEGMENTED_V1`：以經來源核證的未調整OHLC及實股量運算；拆併股、換listing、幣別改制、實物分拆、無法確定的權利事件處切斷價格／量能可比段。事件當日若新口徑資料合法可開新segment，但不得把舊segment價格／EMA／Swing搬過來。一般同幣別現金除息保留其市場價格缺口並標記事件，不擅自抹去；本稿不聲稱除息跳空就是基本面惡化。若正式Owner核准另一套split-adjusted Canonical Close，必須另method_id、完整PIT調整因子與數值對照，不與本預設混算。

公司行動「無事件」必須由完整有效coverage證明；空查詢不是無事件。原producer的`auto_adjust=False`只是一個請求參數，不足以認證實際raw／split語義。OHLCV任一欄不得跨不同調整基準拼接。

### 1.3 PIT、缺bar、修訂與冷啟動

每筆保存`economic_as_of, available_at, retrieved_at, revision_id, source_digest`。只用`available_at≤τ`有效版本；retrieved_at不是歷史available_at。當日收盤已發生但正式Close尚未可靠發布，該session不成立Completed Bar；保留WAITING_OFFICIAL_CLOSE，不冒用盤中價。來源聲稱已發布卻缺資料，當前依賴UNKNOWN/STALE；不得把前日值改日期。

預期開市但缺必要bar不得forward-fill、跳接或將V補0。每個primitive依其依賴建立連續segment；例如缺V只中斷量能與EMV，不中斷完整Close的MA／TD9。遞迴從固定`seed_session`開始；同一次方法不任意改拉取起點來改結果。可靠state cache須保存方法hash、segment、last_session、所有遞迴state與來源vintage。更正建立RESTATED新版本；原AS_KNOWN_AT_τ輸出不可被新資料回填。歷史錯誤可註記，但不偽造當時可知。

### 1.4 日／週／月完成bar（F角色＋P確定聚合）

| timeframe | 完整bar及聚合算法 | 價格／量與可用時點 | 歸屬 |
|---|---|---|---|
| DAILY | 主上市市場交易session；半日市依官方calendar正式收盤；排除盤前盤後 | 使用官方session O/H/L/C/V；available_at為各必要欄實際可靠可得時點 | F只用Completed；P欄級completion實作 |
| WEEKLY | **P**交易所本地日期週一00:00至下一週一00:00；以該週calendar最後一個開市session為週終。該週預期session全部結束且必要資料齊全才完成；週五休市可週四完成 | O=首session O；H=max H；L=min L；C=末session C；V=sum V；availability=max必要成分available_at及calendar可用時點 | F週獨立；P聚合界線／算法 |
| MONTHLY | **P**交易所本地曆月；最後開市session完成且整月必要成分齊全才完成；月底假日不延伸至下一月 | 同上；不能用今天未完成的月K取代上月已完成K | F月獨立；P聚合界線／算法 |

一週／一月若完整calendar證明全無交易session則不產bar，不捏造0成交。IPO首個不完整週／月、資料起點在週月中間、斷鏈／公司行動跨越期間：P排除該週月聚合，下一個完整可比期間才開新段。停牌日須有官方session處理契約；未取得則該period UNKNOWN，不猜「休市」。跨DST依calendar時區轉UTC，不寫固定16:00UTC。

週月指標在聚合後獨立運算、獨立seed；日RSI不可週末改標Weekly。**正式TD9只DAILY**；週／月TD9輸出N/A_NOT_IN_V82_TD9_CONTRACT，不產數值或票。日週月各自as_of不同屬正常，但同一run_id／τ／vintage不可拼接未來值。

## 2. Primitive公式、seed、warm-up與邊界

共同：`SMA_N(X)_t=(Σ_{i=t−N+1}^t X_i)/N`，必須N個連續合法值；不足UNKNOWN，不縮窗口。`EMA_{α,m}`從第一個合法值x_s設e_s=x_s，其後`e_i=αx_i+(1−α)e_(i−1)`；內部自s開始更新，但至少m個連續值才對外發布。缺值重開segment而不skipna。

| ID／數值 | 完整研究算法與首次合法點（segment index從0） | 正式繼承F／新增P |
|---|---|---|
| B01 TD9 | `h_i=(C_i>C_(i−4))`,`l_i=(C_i<C_(i−4))`；h真→High=min(9,priorHigh+1)、Low=0；l真對稱；相等兩側0。count0/1..8/9對應INACTIVE/COUNTING/COMPLETED；當前count需13 closes，i≥12。可直接由最近最多9個同向比較的連續run長度封頂算count，不能用未知prior=0假裝已知。 | F方向、比較、reset、封頂、13根；P可直接run-length實作 |
| B02 TD9首次9 | `first_high9_i=(High_i=9 AND High_(i−1)<9)`，Low對稱；同方向9後不再事件。無cache一般需14 closes才同時確定兩個count；若已有可證明reset亦可更早辨識，但不得推測。13根只能確定當前9，不能普遍斷言「今天首次9」。 | F首次事件不重複；P冷啟動事件可辨識規則 |
| B03 KD | `HH9=max(H_(i−8:i))`,`LL9=min(L_(i−8:i))`; range>0時`RSV=100(C−LL9)/(HH9−LL9)`；range=0且OHLC合法時**P RSV=50**。`K=SMA3(RSV)`,`D=SMA3(K)`；RSV首i8、K首i10、D首i12；需要前值cross首i13（14 OHLC bars）。 | F9,3,3；P明選兩層SMA，**不聲稱等同另一平台遞迴KD或正式指定平滑**；M既有候選producer亦用SMA |
| B04 MACD | `EMA12=EMA_(2/13,12)(C)`、`EMA26=EMA_(2/27,26)(C)`；`DIF=EMA12−EMA26`自i25合法；`DEA=EMA_(2/10,9)(DIF)`從i25首DIF作seed，i33首合法；`Hist=DIF−DEA`，i33首合法，cross首i34（35 closes）。 | F12,26,9及Hist不乘2；P遞迴seed與發布屏蔽，M與adjust=False目標相容但尚非逐值核驗 |
| B05 MA | `MA_N=SMA_N(C)`，N∈{5,10,20,50,60,200}；首i=N−1；cross需N+1 closes | F期間、SMA及完整N根 |
| B06 EMV研究3,3 | 中點`M_i=(H_i+L_i)/2`；`rawEMV_i=(M_i−M_(i−1))*(H_i−L_i)*100000000/V_i`；V_i>0；若range=0且V>0，rawEMV=0；V=0→UNKNOWN。`Efast=SMA3(rawEMV)`，`E=SMA3(Efast)`。raw首i1、fast首i3、E首i5（6 HL/V bars），相鄰比較需7 bars。所有本稿E只指此第二層輸出。 | F僅3,3與正負／升降；**P整個`EMV_ARMS_SMA3_SMA3_SCALE1E8`定義**，不是找回了未取得的官方公式；不將emv_14更名 |
| B07 RSI14 | Δ_i=C_i−C_(i−1)，g=max(Δ,0)，d=max(−Δ,0)；`G=EMA_(1/14,14)(g)`,`Dloss=EMA_(1/14,14)(d)`；從首Δ_i1種子，14個Δ後i14首合法（15 closes）。G,Dloss>0→`100−100/(1+G/Dloss)`；G>0,Dloss=0→100；G=0,Dloss>0→0；兩者0→50。 | F14、30/70及數值保留；P此EWMA首觀察種子／全平50，不冒稱SMA-seeded Wilder完全等價 |
| B08 ATR14 | i0處`TR_0=H_0−L_0`；其後`TR_i=max(H_i−L_i,abs(H_i−C_(i−1)),abs(L_i−C_(i−1)))`；`ATR=EMA_(1/14,14)(TR)`，首i13（14 bars）。 | F ATR14；P seed=首TR、首bar TR採range，不能與其他seed混用 |
| B09 Volume | `VolMA_N=SMA_N(V)`、`ratio_inclusive_N=V/VolMA_N`，N=5,20，50在需要時；均量0→ratio UNKNOWN。另研究`B_i=SMA20(V)_(i−1)`、`q_i=V_i/B_i`，需21 bars且B_i>0。 | F5/20、需要時50；P正式未明示分母納入t，本稿明定inclusive供基礎比較、exclusive q供研究門檻；兩者不同欄名 |
| B10 Return | `r_i=C_i/C_(i−1)−1`；首i1；不混總報酬W，百分點差用0.01表示1個百分點 | P明選raw市場收盤簡單報酬 |
| B11 Swing | Low pivot i：`L_i<min(L_(i−2),L_(i−1),L_(i+1),L_(i+2))`；High反向嚴格>。最早第5根bar完成時確認第3根pivot。`confirmed_at=max`五根必要欄及calendar可靠可用時點；i+2完成前不能使用。 | F前2後2及strict；P欄級availability記帳 |

**表列「cross首／需要N+1根」指前後兩根全部輸入首次齊全，不是強制在此之前一律UNKNOWN。** 仍須用§1.1三值短路：例如首個合法MA當根C=MA，reclaim及breakdown的當根嚴格不等式已FALSE，即使前MA未知仍可FALSE；first9當根已知count<9也可FALSE。

P warm-up到表列首次合法點即可給**研究**數值，沒有偷偷另加「200根趨穩」規則。遞迴早期值明標seed_sensitive；統計比較必須使用同seed/vintage。若正式Owner要SMA-seeded Wilder或其他平滑，另version後重算全部衍生，不只換最後一個數值。

### 2.1 基礎狀態及Cross（每列F，除列明的P邊界）

| 數值 | TRUE公式／狀態列舉 | 邊界 |
|---|---|---|
| KD golden/death | `K_p≤D_p AND K_t>D_t`／`K_p≥D_p AND K_t<D_t` | 當根相等沒有cross；前根相等可cross；資料缺則三值 |
| KD range/direction | oversold=`K<20 OR D<20`；overbought=`K>80 OR D>80`；rising雙線相較p皆>，falling皆< | P雙線均=前值列FLAT；其餘非升非降列MIXED，不捏UNKNOWN；20/80不算超買賣 |
| MACD cross | golden=`DIF_p≤DEA_p AND DIF_t>DEA_t`；death反向 | Hist由≤0到>0是同一golden事件別名，不另投票 |
| MACD zero | ABOVE_ZERO=DIF>0且DEA>0；BELOW_ZERO兩者<0；異號STRADDLING_ZERO | P任一恰0另列ON_ZERO，不誤列多空 |
| MACD histogram | 正負同號且abs增／減→EXPANDING／CONTRACTING；反號／從0進非0先列DIRECTION_SWITCH | P同值FLAT；當根0列AT_ZERO。H即Hist，避免與High混淆 |
| MA | ABOVE/AT/BELOW按C與同根MA比較；reclaim=`C_p≤MA_p AND C_t>MA_t`；breakdown=`C_p≥MA_p AND C_t<MA_t` | F5線bull=5>10>20>50>200，bear反向；MA60不塞入鏈 |
| EMV | POSITIVE E>0、NEGATIVE E<0；RISING E_t>E_p、FALLING反向；轉正=`E_p≤0 AND E_t>0` | P零值ZERO、相等FLAT；絕對值不能跨平台／volume unit比較 |
| RSI | OVERSOLD <30；LOW_MID 30≤RSI≤50；MID_HIGH 50<RSI≤70；OVERBOUGHT >70；EXIT_OVERBOUGHT=`RSI_p>70 AND RSI_t≤70` | F30/70與exit；P完整互斥range命名；50屬LOW_MID |
| Volume quadrant | 價向=C_t對C_p；量向=V_t對VolMA20_t。正負組成四象限；任一恰相等列FLAT並保留兩個子方向 | F四象限；P本稿量方向選inclusive MA20及「無實質方向」採精確相等，不猜噪音帶 |

**TD9高／低歧義的裁決**：本案母規則已明文High=Close高於四根前、Low反向，不是「今天High更高／Low更低」，不對調為買／賣名稱，也不是完整DeMark Countdown 13／price-flip／perfection算法。第三方只叫TD9的值不可盲接。若使用者原先口語「高低TD9」想表達別種公式，另列新候選，不改F。**EMV3,3的歧義則確實仍在正式來源；本稿以獨立P方法把研究設計完成，不聲稱已解決正式來源相容性。**

## 3. 結構選擇器與事件狀態機（全部新增處標P）

### 3.1 支撐／壓力與擺動串

- `latestHighAt(s,w)`：在s時已confirmed且可用、pivot index∈[s−w,s]的最近一個High pivot；按pivot index最大選取；Low對稱。**P w=20日**；不存在可比pivot→UNKNOWN/NO_ELIGIBLE_REFERENCE，不設0。
- 交叉在t使用`latestHighAt(p,20)`固定P；`C_p≤P AND C_t>P`。支撐跌破對稱`C_p≥P AND C_t<P`。p時尚未confirmed的pivot即使t確認，也不能反推昨天已知level。
- **P normalized swing sequence**：只使用截至τ已confirmed raw pivots；按pivot index排序；同一bar同時High與Low且落入所需配對範圍→該結構UNKNOWN/AMBIGUOUS_INTRABAR_ORDER（不猜先高後低）。相鄰同類pivot保留更極端者（High較高、Low較低；相等保留後者）；直到交錯。每次τ保存其當時版本，不回改歷史輸出。
- **P四pivot HH/HL**：最新4個正規化pivot必須是H1,L1,H2,L2或L1,H1,L2,H2；各pivot距t≤60且最後pivot距t≤20；`H2>1.01H1 AND L2>1.01L1`。缺4個／必要範圍內雙pivot→UNKNOWN；資料完整但比較不成立→FALSE。這個1%是「明顯」研究解釋，不是官方noise band。
- **P可比較RSI高點對**：最新兩個raw confirmed price Swing High a<b，a距t≤60、b距t≤20、b−a≥5；使用**同根price pivot的RSI值**。只有H_b>H_a才構成創高比較；RSI_b≤RSI_a為本候選bearish divergence，RSI_b>RSI_a為該pair未背離。非創高pair／缺pair→UNKNOWN，不從「沒找到」推出無背離。不是獨立RSI pivot配對算法。

### 3.2 固定episode契約

所有episode保存`episode_id, parent_event_id, reference_id, immutable_level, created_at, start_session, deadline_session, latest_state, terminal_reason`；同一parent_event不重建。PENDING不給成功票；終止後不復活；新cross才新episode。同一session若失敗與成功條件同時看似成立，按下面明文優先序；OHLC不證盤中先後，依收盤判定。

| Episode | 確定研究規則P | TRUE時點／終止 |
|---|---|---|
| RETEST | 承接§4.1 R9水平突破b、固定P。只看b+1…b+10。首個`L_j≤1.005P AND H_j≥0.995P`為觸及j；任何i∈[b+1,k]有`C_i<0.99P`先FAILED。觸及後在j…min(j+2,b+10)首個`C_k≥P AND C_k>C_(k−1)`為成功；若觸及前已失敗不再找j。 | k根收盤資料可用才SUCCESS_EVENT；之後同episode FALSE/TERMINAL_SUCCESS，不永久TRUE。觸及後最後允許bar仍不成功→FAILED；b+10無觸及→EXPIRED；期限當根先檢驗合法成功再判過期 |
| NO_QUICK_RECLAIM | 在b−1選latestLowAt(b−1,20)=P；`C_(b−1)≥0.99P AND C_b<0.99P`開episode。b…b+3任一C_i≥P→RECLAIMED/FALSE；全四根C_i<P且資料完整，b+3發NO_RECLAIM_EVENT。 | b至b+2 PENDING/UNKNOWN；b+3事件一次；不把結論回填b；缺bar→UNKNOWN/INVALIDATED_DATA，不當未收復 |
| POST_HIGH_TD9 | high first9發生e，P=max(H_(e−8:e))；只e+1…e+9找第一個C_t>P；期間若low first9已出現，先INVALIDATED；成功一次後終止。 | C6在首次成功t TRUE；無事件且完整可觀察窗FALSE；沒有足夠first9歷史UNKNOWN。無cache保守需最近23個Close及episode相關H，才能完整搜尋最近9根的first9 |
| FAILED_BREAKOUT | 承接同一R9突破b、P；b+1…b+5首根`C_t<0.995P`為失敗事件；等於不失敗。沒有失敗到b+5→EXPIRED_NO_FAILURE。 | 失敗t TRUE一次；窗口尚未失敗時**FALSE（「失敗是否已發生」）**，不是預測最終成功；缺必要價格UNKNOWN。與RETEST不同，R10問尚待成立的成功，故PENDING處理不同 |

上述Retest與Failed breakout可描述同一突破的不同結果；它們分屬不同向量、不同t的事件，不允許同一event用兩個別名重複投票。明顯新低episode是否同時有別的支撐已破，只保留各自reference；不改舊P。

**P多episode聚合與冷啟動**：RETEST、NO_QUICK_RECLAIM、FAILED_BREAKOUT可各自保留多個不同parent_event的有限期episode；按每個不可變P獨立推進，槽位輸出是當根所有合格episode結果的三值OR，最多一票。已terminal episode其後只留審計，不反覆TRUE。沒有episode且完整回放所需父事件窗口時FALSE；父事件窗口不完整時UNKNOWN，不由空清單推FALSE。RETEST父事件搜尋b∈[t−10,t−1]、NO_QUICK_RECLAIM b∈[t−3,t]、FAILED_BREAKOUT b∈[t−5,t−1]；重播須取足建立父事件reference的更早Swing資料，不能只截取這幾根。POST_HIGH_TD9則只保留最近一次high first9的episode；新high first9取代舊episode，低first9先取消，成功過的不再出第二次事件。當根RETEST／NO_QUICK_RECLAIM／FAILED_BREAKOUT處理順序為資料合法性→已有episode失效／成功→期限終止→建立當根新parent的episode；新breakout不可同根當retest。POST_HIGH_TD9例外先處理當根first9：low first9取消舊episode；high first9取代舊episode且當根只建立新episode，C6不能引用同根已被取代的舊e發成功；沒有新first9才評估既有episode的後續新高。若某完整未到期episode無觀察資料則UNKNOWN；其他episode已有成功TRUE仍依OR可TRUE。

## 4. 原五向量完整32槽位與附加Entry

所有技術槽位預設DAILY；週月不額外疊票。表中「S」是當根state、「E」是當根event、「EP」是episode結果。事件除明列外僅t根TRUE，次根若無新事件即FALSE；沒有全套必要觀察則UNKNOWN。每列的P參數已明定，非「待AI判斷」。

### 4.1 Right確認：R1–R10

| ID／欄位 | 可實作完整候選定義 | F繼承／P新增；型態 |
|---|---|---|
| R1 higher_low | 最近兩個raw confirmed Low a<b，a距t≤60、b距t≤20；`L_b>L_a` | F較後前低較高、confirmed；P60/20有效期；S |
| R2 kd_golden_cross | §2.1 golden公式 | F不等式；P使用B03明選SMA序列；E |
| R3 macd_bear_hist_shrinking_or_positive | `(Hist_t<0 AND Hist_p<0 AND abs(Hist_t)<abs(Hist_p)) OR (Hist_p≤0 AND Hist_t>0)` | F空方縮短／翻正；P明確翻正是event，不是持續正值；S或E，每槽最多一票 |
| R4 dif_up | `DIF_t>DIF_p` | F上彎相鄰completed比較；P B04 seed；S |
| R5 emv_turns_positive | `E_p≤0 AND E_t>0` | F原文轉正；P明選cross而非舊欄名positive持續state、B06方法；E |
| R6 rsi_improving_or_near_50 | `45≤RSI_t≤55` OR `30≤RSI_(t−3)<RSI_(t−2)<RSI_p<RSI_t≤50` | F30–50改善；P附近±5與3次嚴格上升（4值）；S。52即使下降亦可TRUE，因為OR |
| R7 ma20_reclaim | `C_p≤MA20_p AND C_t>MA20_t` | F站回cross；P明確舊above名稱不能代表一直站上；E |
| R8 descending_line_volume_breakout | p已知最近兩個High pivot a<b；p−a≤60、b−a≥5、H_b<H_a。`line(i)=H_a+(H_b−H_a)(i−a)/(b−a)`。從b確認session至p每個C_i≤line(i)，且`C_p≤line(p) AND C_t>line(t) AND q_t≥1.5`。 | F下降趨勢放量突破意義；P線選取、60/5、1.5、既破線不得重用；E。線不存在UNKNOWN |
| R9 recent_pressure_breakout | p已知`P=latestHighAt(p,20)`；`C_p≤P AND C_t>P` | F突破壓力；P以最近confirmed High、20根作明確壓力代理；E |
| R10 breakout_retest_success | §3.2 RETEST成功當根 | F原回踩成功語義；P全部容差／期限／順序；EP |

**P附加`off_low`**：取`latestLowAt(t,20)=P`，且`C_t≥1.01P`才TRUE；恰1%成立，缺reference UNKNOWN。這是「已離開最低點」的研究代理，既不是全歷史最低也不是F數值。研究Right技術entry=`off_low AND threshold_dedup(R,3)`；完整Right仍須由正式Owner提供Fundamentals、Credit/Liquidity、安全、非RD及估值等，不以本稿OHLCV補出TRUE。

### 4.2 Runaway Up價格：U1–U3

| ID／欄位 | 完整候選定義 | F／P；型態 |
|---|---|---|
| U1 new_20d_close_high | `C_t>max(C_(t−20),…,C_p)`；需要21 closes；相等FALSE | F20日收盤新高；P選「前20不含t」與strict tie；E-like當根新高，可連日各自創高 |
| U2 break_confirmed_swing_high | 原Owner若已指明合法P就用該P；**本研究無另指定時**用latestHighAt(p,20)；`C_p≤P AND C_t>P` | Fconfirmed High與cross；P缺具名level時的研究selector，不覆寫正式P；E |
| U3 higher_high_higher_low | §3.1四pivot，H2>1.01H1且L2>1.01L1 | F HH/HL敘事；P交錯、窗口、1%；S |

### 4.3 Runaway Up確認：C1–C8

| ID／欄位 | 完整候選定義 | F／P；型態 |
|---|---|---|
| C1 kd_high_sustained_not_breaking | i=t−2…t皆`K_i>80 AND D_i>80`，且`K_t≥D_t AND K_t−K_p≥−10 AND D_t−D_p≥−10` | F80高檔及非死叉崩落；P雙線3根、當根位置、最多跌10點；S |
| C2 macd_bull_hist_expanding | `Hist_t>0 AND Hist_p>0 AND Hist_t>Hist_p` | F同正號擴張；P B04 seed；S |
| C3 ma5_gt_ma10_gt_ma20 | `MA5_t>MA10_t>MA20_t` | F原Runaway三MA鏈，不擴為五MA；S |
| C4 emv_positive_or_improving | `E_t>0 OR E_t>E_p` | F正值／改善；P B06方法；S。已知E_t>0可不被缺p污染 |
| C5 price_volume_healthy | i=t−4…t，`U=ΣV_i·1(r_i>0)`，`D=ΣV_i·1(r_i<0)`；`n_up≥2 AND U≥1.2D AND NOT EXISTS i:(r_i≤−0.01 AND q_i≥1.5)` | F量價健康語義；P5根、2上漲、1.2、−1%／1.5；S。D=0按不等式，不除零；全部平盤FALSE |
| C6 high_td9_then_new_high | §3.2 POST_HIGH_TD9成功事件 | F先完成高TD9後創高；P九根setup最高H、後9根壽命、首次及反向取消；EP |
| C7 rsi_high_no_divergence | `RSI_t>70 AND highPairComparable AND RSI_b>RSI_a`，highPair依§3.1 | F高檔與confirmed可比結構；P同步RSI配對及相等視為未創高；S。RSI≤70可FALSE，缺pair且RSI>70則UNKNOWN |
| C8 eps_guidance_not_worse | 個股：相同issuer、target fiscal period、currency、GAAP／adjusted basis的最新適用官方EPS指引[lo_new,hi_new]及前版；兩端均≥前版才TRUE；撤回FALSE；任一端降低FALSE；缺同目標可比版本UNKNOWN。點值視為lo=hi。 | F基本面／財測非技術依賴；P採雙端不下降窄定義，非所有基本面安全；S。ETF適用性見§7 |

`MA20_OK`：`C_t≥0.99MA20_t`（MA20>0）；F「未明顯跌破」；P1%收盤容差，**不是0.25ATR**。研究Up=`threshold(U,1) AND threshold_dedup(C,3) AND MA20_OK`。有正式阈值／Owner後仍以正式Owner決策，本稿不能讓研究Up取得正式Trend。

### 4.4 Runaway Down結構：D1–D3

| ID／欄位 | 完整候選定義 | F／P；型態 |
|---|---|---|
| D1 keeps_breaking_lows | 對i=t−2,t−1,t，皆`C_i<min(C_(i−20),…,C_(i−1))`；23個連續Close；相等不破低 | F持續破前低；P三根各創前20收盤新低，明確不用盤中Low或未確認pivot；S |
| D2 break_confirmed_swing_low | p時合法原Owner指定P；本研究未指明時latestLowAt(p,20)；`C_p≥P AND C_t<P` | Fconfirmed Low及cross；P研究selector；E |
| D3 break_support_no_quick_reclaim | §3.2 NO_QUICK_RECLAIM事件 | F明顯破重要支撐且未快收復；P重要=latestLow、1%破線、3根等待；EP |

### 4.5 Runaway Down加速：A1–A8

| ID／欄位 | 完整候選定義 | F／P；型態 |
|---|---|---|
| A1 macd_bear_hist_expanding | `Hist_t<0 AND Hist_p<0 AND abs(Hist_t)>abs(Hist_p)` | F同負號擴張；P B04 seed；S |
| A2 kd_low_weak | i=t−2…t雙線均<20；`K_t≤K_p≤K_(t−2)`、`D_t≤D_p≤D_(t−2)`、`K_t≤D_t`，且`K_t<K_(t−2) OR D_t<D_(t−2)` | F低檔續弱；P3根非增＋至少一線累計下降；S。低檔全平FALSE |
| A3 emv_worsening | `E_t<E_p<E_(t−2)<E_(t−3)` | F持續惡化；P三次嚴格下降，不強迫已負；B06方法；S |
| A4 rsi_falling | `RSI_t<RSI_p<RSI_(t−2)<RSI_(t−3)` | F續跌；P三次嚴格下降；S |
| A5 price_down_volume_up | `C_t<C_p AND V_t>VolMA20_t`；等於均量FALSE | F價跌量增及20均量比較；P明選inclusive20基準，不混q或前bar量；S |
| A6 atr_expanding_fast | `ATR_t/ATR_(t−5)≥1.20 AND ATR_t>ATR_p`，基期>0 | F ATR14；P5根增≥20%且最新仍增；S。ATR非方向，不獨立認定跌勢 |
| A7 decline_accelerating | `R_old=C_(t−5)/C_(t−10)−1`，`R_new=C_t/C_(t−5)−1`；`R_old<0 AND R_new<0 AND R_new≤R_old−0.02` | F跌速加快；P相鄰不重疊5session報酬、至少加深2百分點；S |
| A8 rebounds_weaker | 取截至t最新3個已完成且相鄰的normalized Low→High腿L1,H1,L2,H2,L3,H3；可忽略H3後尚無High的最後一個Low。6 pivot距t≤90，H3距t≤20；每Hj>Lj；`a_j=H_j/L_j−1`；`a3<a2<a1 AND a3≤0.8a1`。 | F反彈一次比一次弱；P3次腿、90/20、最後較首次至少少20%幅度；S。無3腿UNKNOWN；3腿完整而不遞減FALSE |

研究Down=`threshold_dedup(D,1) AND threshold_dedup(A,2)`。不把任何ATR／RSI／TD9一項單獨變成Down。Up與Down同TRUE仍沿正式INVALID→SAFE／Reconcile語義，研究模組只能報衝突，不能下單或自設sell。

**P事件型有效期的必要反例**：D2/D3只有cross／未快速收復事件當根TRUE，不因仍處支撐下永久沿用。如果t時D2 TRUE、D1/D3 FALSE且A≥2，研究Down TRUE；t+1沒有新D2/D3、D1仍FALSE，即使價格仍在支撐下及A≥2，研究Down亦可FALSE。這是本稿明示的event-slot研究政策，不是「風險已修復」證明；正式Reduction／Hard Gate／Recovery episode一律不由它解除。研究mode若需持續RD狀態必須另事前核准state-slot契約，不能暗自沿用舊TRUE，也不能把本稿event FALSE作Recovery PASS。

## 5. 補齊原技術減碼9項與左側成熟度8項

### 5.1 技術減碼S1–S9：候選條件≠賣出權限

F同輪至少3個有效既有訊號；P各敘事實作及去重見§8。這不是B-3 Structural Break後的速度機器，也不啟用其「MACD連續2根」候選。

| ID | 完整公式 | F／P與型態 |
|---|---|---|
| S1 高TD8–9 | `HighTD_t∈{8,9}` | F8–9，S；不使用Low分數 |
| S2 KD死叉 | §2.1 death | F交叉，P B03；E |
| S3 MACD多方柱連續縮短 | `Hist_(t−3)>Hist_(t−2)>Hist_p>Hist_t>0` | F多方柱持續縮短；P3次縮短（4值），**不等於B-3連續2根**；S |
| S4 EMV轉弱 | `E_t<E_p` | F相鄰falling；P B06；S |
| S5 RSI背離 | §3.1 highPairComparable且`RSI_b≤RSI_a` | F需confirmed可比結構；P同步配對及相等不創高；S；非創高pair UNKNOWN |
| S6 爆量不漲 | `q_t≥2 AND abs(r_t)≤0.005 AND C_t≥0.95*max(C_(t−20:p))` | F高檔爆量不漲；P前20均量倍數2、±0.5%、距前20高≤5%；S |
| S7 跌破MA10／20 | `breakdown10 OR breakdown20` | F原二者任一；P同槽最多1票，即使兩者皆TRUE；E |
| S8 突破前高失敗 | §3.2 FAILED_BREAKOUT事件 | F原失敗語義；P固定R9前高及5根／0.5%；EP |
| S9 極高估值＋技術轉弱 | `formal_extreme_valuation_context AND C_t<MA50_t AND MA50_t<MA50_(t−5)`；需55個Close | F原合取敘事及獨立S9槽位；P技術同步弱化明選「收盤低於MA50且MA50較5根前下降」，不OR複用S2–S8；S。估值單項不成立此票 |

S9的Extreme必須來自適用正式估值Owner，不以PE≥23通套十一類，也不把`EXTREME_CANDIDATE`字樣誤當本稿未批准候選。完整技術減碼Classification／Primary／Sell Permission、核心持有處理仍是原Owner，不在本稿產生。

### 5.2 左側技術成熟度M1–M8：只輸出描述／證據，不創速度分數

| ID | 完整候選定義 | F／P |
|---|---|---|
| M1 低TD成熟 | `LowTD∈{5,6,7,8,9}`；另保留F每count原score與×4，不將高TD映射此分數 | F原Low評分；P左側「成熟」研究集合5–9，非所有Low都成熟 |
| M2 KD止跌／golden | golden OR `(K_(t−2)≥K_p AND D_(t−2)≥D_p AND K_t>K_p AND D_t≥D_p)` | F止跌／交叉敘事；P止跌轉折的精確3根形式；同槽最多1票 |
| M3 MACD空方縮短 | `Hist_p<Hist_t<0` | F同負號縮短；P seed |
| M4 DIF上彎 | R4 | F，別名不增票 |
| M5 EMV改善 | `E_t>E_p` | F相鄰改善；P B06 |
| M6 RSI回升 | `RSI_t>RSI_p` | F回升；P用相鄰嚴格>而非R6持續改善 |
| M7 價格2–3日不破低 | **P選3根**：`L_(t−2)≤L_p≤L_t`，且`C_t≥C_(t−2)` | F2–3日敘事；P選3、最低不下降及收盤不弱於起點；不要求Swing已confirmed |
| M8 價跌量縮／止跌K | `(C_t<C_p AND V_t<VolMA20_t)` OR `(H_t>L_t AND C_t≥O_t AND (C_t−L_t)/(H_t−L_t)≥0.75 AND L_t<min(L_(t−5:p)))` | F原敘事；P量基準及止跌K定義，O必要但只污染此分支；本槽兩分支不重複算 |

F LowTD score count1…9依序0.5/0.8/1/1.5/1.8/2/2.5/3/4，乘4後2/3.2/4/6/7.2/8/10/12/16；已知0為0，UNKNOWN分數UNKNOWN，High buy score N/A。本稿不將M1–M8加權成「安全」、不以count切SLOW/NORMAL/ACCELERATED，更不改九階目標或補足率。這些後者需原Speed Owner或另候選研究，不是本技術predicate規格的隱藏輸出。

## 6. 日週月趨勢Classifier與衝突矩陣

**F**三週期角色與組合名稱來自工程26，沒有從母規則查到統一Bullish/Bearish數值公式。以下為**P `TREND_C_MA20_SLOPE_MACD_V1`**：每個timeframe獨立計算。

- `bull_f=(C_f>MA20_f) AND (MA20_f>MA20_(f−1)) AND (DIF_f>DEA_f)`。
- `bear_f=(C_f<MA20_f) AND (MA20_f<MA20_(f−1)) AND (DIF_f<DEA_f)`。
- 任一TRUE對應BULLISH／BEARISH；兩者皆FALSE→MIXED_KNOWN；都不能可靠排除且無TRUE→UNKNOWN。公式上bull與bear不應同TRUE，同TRUE→INVALID_INPUT，不猜方向。MIXED_KNOWN不是UNKNOWN也不是中性安全。
- 最少34個完整period可取得當前DEA與MA斜率；週是34週、月是34月，不拿34日替代。上市不夠34月，月趨勢UNKNOWN但日線事實仍保留。

| Daily／Weekly／Monthly | 輸出名稱 | 歸屬 |
|---|---|---|
| BULLISH／BULLISH／BULLISH | MULTI_TIMEFRAME_BULLISH_CONFLUENCE | F矩陣；P方向classifier |
| BEARISH／BULLISH／BULLISH | LONG_TERM_UPTREND_SHORT_TERM_CORRECTION | F矩陣；P方向classifier |
| BULLISH／BEARISH／BULLISH | COUNTERTREND_REBOUND_IN_MEDIUM_WEAKNESS | F矩陣；P方向classifier |
| BEARISH／BEARISH／BEARISH | MULTI_TIMEFRAME_BEARISH_CONFLUENCE | F矩陣；P方向classifier |
| 其他全已知（包括MIXED_KNOWN） | MIXED_TIMEFRAME | F其他混合；P擴展到明知混合方向 |
| 任一必要timeframe UNKNOWN | PARTIAL_CONTEXT；保存各自已知狀態，完整三週期confluence UNKNOWN | F局部UNKNOWN，不假PASS |

週／月不增添Right／Runaway技術票、不覆寫日Entry，不建立Hard Gate。若未來另測不同trend classifier，改method_id並重新驗證，不事後選最漂亮者。

## 7. 非技術必要依賴的完成接口

「技術規格完成」不意味OHLCV可以創出基本面事實。以下接口明定處理，並非填一個TRUE占位。

| 依賴 | 研究規格的精確處理 | F／P |
|---|---|---|
| C8個股EPS指引 | §4 C8；每筆需issuer、target period、announcement timestamp、currency、basis、lo/hi及withdrawal；P有效到target period_end後第一份同target actual發布、或官方withdrawal、或替換指引，取最早。找不到前版同target則UNKNOWN；沒有發指引不是「未惡化」 | F外部Fundamental來源；P雙端及有效期 |
| C8股票ETF | P輸出N/A_ASSET_NOT_ISSUER，**研究計數中不貢獻TRUE且不降低≥3門檻**；不把成分公司指引臨時平均成ETF指引。若正式Owner已有ETF等價producer，須保留其formal applicability／contract並另映射，不能讓研究N/A覆寫正式原值 | F ETF基本面不同；P非issuer排除此票、其餘7票仍可達3。此規格是明示研究選擇，不是宣告F槽位可選 |
| Fundamentals／Credit-Liquidity／Hard Gate／Runaway風險 | consumer接受原Owner帶source/coverage/as_of的三值；缺或未知→依必要依賴傳播，不用技術替代。相同snapshot_id、τ，UNKNOWN不得默認安全 | F既有Owner邊界 |
| S9 Extreme／Right估值限制 | 接合法Valuation Owner enum／predicate與metric applicability，拒絕將單一PE門檻套全部資產 | F既有Owner邊界 |
| News／Safety coverage | 不新增情緒票；只接已批准coverage contract及active/pending重大事件。缺contract→UNKNOWN，不能靠「24小時沒新聞」通過安全 | F正式Safety Owner；P明確不把前稿24h工程候選當安全 |
| Stage／速度／下單 | 本模組沒有輸出端；研究count/context供審核，不連接Order或Permission；不得以技術全TRUE推 Stage9 | F權責；P物理研究隔離 |

## 8. 去重、三值threshold與可追溯輸出

### 8.1 兩層去重（F禁止別名重複；P確切key）

1. **同canonical槽位最多一次**：provider別名如`MACD_golden`與`Hist_turns_positive`同一事件；`above_ma20`不能另外添R7一票；`kd_gold`與`kd_golden_cross`相同；S7同日跌破MA10與MA20只一票。
2. **不以相關性擅改正式槽位**：R8是下降趨勢線＋量能，R9是水平壓力cross；母規則明列兩個canonical訊號，未查得正式alias registry宣告兩者相同。因此各自條件成立可各一票，同日／共用Close不構成自動合併理由；另報`CORRELATED_PRICE_EVIDENCE`，不能偷偷降低票數。如果adapter其實將同一個R9值複製成R8、卻沒有R8獨立線／量證據，R8不得算TRUE，應UNKNOWN/MISSING_R8_EVIDENCE。R10是後來獨立retest結果。
3. R3與R4雖同源MACD，但母規則明列為不同canonical特徵（Histogram轉變與DIF斜率），研究保留各一票，不把「共用Close」誤當所有技術只能一票。C2、C3等同理。
4. S9保留原第九canonical槽，使用本稿獨立MA50位置／5根斜率的P條件，不用「任何S2–S8為真」再生一票。若實際證據包只複製其他slot且沒有S9指定條件，不得算TRUE。technical-reduction仍按S1–S9每槽至多一票及原≥3；canonical不同與證據互相關聯要分清，後者另報，不改門檻。
5. 不把不同向量的票加成總票：R9與U2可引用同一parent_event_id，但Right及Up分別達其門檻，不報「2個獨立事件」；C6同時支援Up價格背景也不增加一個新U槽。
6. 上游來源有衝突且未裁決，不OR兩來源挑TRUE；先把該槽置UNKNOWN/SOURCE_CONFLICT。重抓或同新聞轉載不是新source fact。

### 8.2 Threshold

在**固定manifest先完成alias/group解析**後，已知TRUE組數T、UNKNOWN組數U，門檻k：T≥k→TRUE；T+U<k→FALSE；否則UNKNOWN。N/A票在本研究明示applicability下不貢獻T或U，門檻不變；正式consumer對N/A的既有契約優先，本稿不直接改它。

所需manifest必須包含全部32槽及其group，不能刪掉UNKNOWN後聲稱完成。每組truth OR按三值，不用缺資料預設FALSE。需要未知reference時key仍能依canonical group生成，不能因「不知key」重複加UNKNOWN。

### 8.3 每項輸出必填

`research_method_id, method_version, formal_rule_ref, origin_F_or_P, approval_status, asset_id, listing_id, timeframe, τ, segment_id, seed_session, evaluated_session, data_as_of, expected_latest_completed_period, available_at_max, source_ids_and_digests, formula_parameters, state/event/episode, truth, numeric_inputs, dependency_ids, evidence_ids, dedup_group, reason_codes, episode_id, confirmed_at, calculation_timestamp`。

研究manifest另保存所有P常數：KD_SMA/flat50；EMV3×3/scale1e8；EWMA seeds；RSI45–55/3rise；MA20 .99；R1/结构60/20；R8 60/5/1.5；Retest .995/1.005/.99/10/2；TD9post9；U1 prior20；U3 1.01；C1 3/80/−10；C5 5/2/1.2/−.01/1.5；D1 3×prior20；D3 .99/3；A3/A4 3 declines；A6 5/1.20；A7 5+5/.02；A8 3legs/90/20/.8；S3 3 contractions；S6 2/.005/.95/20；S8 5/.995；S9 MA50/5bar slope；off_low1.01；trend MA20+MACD。**常數全部寫入版本，不容runtime LLM臨時改閾值。**

## 9. 驗收邊界清單（規格級expected，尚非正式程式整合PASS）

下表除「必需」另外說明，其他輸入均合法且已完整。TRUE/FALSE是該指定predicate；UNKNOWN附reason。每個P切點需測`below / equal / above`，Decimal測試用精確小數。

| Case | 輸入／事件 | Expected |
|---|---|---|
| T001 | 13個嚴格遞增Close，最近9個t−4比較皆正，無cache | High count9；Low0；**first9 UNKNOWN**，不能說首次 |
| T002 | 14個嚴格遞增Close，前根與本根count均9 | 本根first9 FALSE；持續9不重建episode |
| T003 | 已知High8，本根C=C_(t−4) | High0、Low0；不是UNKNOWN |
| T004 | 只有V缺失、Close連續13根 | TD9可知；EMV／量價依賴UNKNOWN；不全報告清零 |
| T005 | 最高／最低相等於任一相鄰2根 | 不是strict pivot；若缺右側第二根，狀態PROVISIONAL而非confirmed |
| T006 | pivot i、τ在i+1收盤後／i+2資料可用後 | 前者不可用；後者才可用，禁止回填i |
| T007 | KD p K=D=20，t K21,D20 | golden TRUE；t oversold FALSE；20不算<20 |
| T008 | KD t K=D=80 | golden/death FALSE；overbought FALSE；C1 FALSE |
| T009 | 連續9根HH9=LL9且OHLC合法 | RSV50；K/D須各自滿3樣本才合法；不直接從第9根宣布D50 |
| T010 | MACD 33／34／35個Close | 分別Hist UNKNOWN／首次Hist合法但前後cross輸入尚未全齊，按Kleene：當根嚴格交叉條件已FALSE可直接FALSE，否則UNKNOWN／cross輸入完整；34根全平Close時golden與death均FALSE，不可提前seed DEA |
| T011 | Hist p=−1,t=+0.1 | DIRECTION_SWITCH、golden TRUE；C2與A1皆FALSE；不是同號擴張 |
| T012 | Hist p=−1,t=−0.5／−1／−1.1 | R3 TRUE／FALSE／FALSE；A1 FALSE／FALSE／TRUE |
| T013 | 收盤恰MA20／前根恰MA20後本根高於 | 第一個ABOVE FALSE、AT TRUE；第二個reclaim TRUE |
| T014 | MA20=100，C=99／98.999 | MA20_OK TRUE／FALSE |
| T015 | EMV range0,V>0／V=0 | rawEMV0／UNKNOWN；不把無量除零當0動能 |
| T016 | RSI只有14／15 closes；全平、全升、全跌 | 前者UNKNOWN；後者依序50／100／0 |
| T017 | RSI=30／70 | neither oversold nor overbought；70退出overbought只在p>70才事件 |
| T018 | RSI=45、55、55.001；及52但較p下降 | R6 TRUE、TRUE、FALSE（若另一分支不合）、TRUE |
| T019 | RSI30,35,40,45／30,35,35,45 | improving TRUE／FALSE；第二個整體R6仍因near50 TRUE，需測分支與整體 |
| T020 | U1前20最高100，t=100／100.001 | FALSE／TRUE；只20總根不足→UNKNOWN |
| T021 | p時High未確認、t新確認，C跨它 | 不以該新pivot作當根U2/R9的p已知level |
| T022 | HHHL H2=1.01H1且L2>1.01L1 | U3 FALSE（strict>）；reference不足4 pivot UNKNOWN |
| T023 | 突破P100；回踩L99.5,H100.5，C100且>Cp | band含邊界；b+1之後可R10成功；b同根不可回踩 |
| T024 | Retest某根C98.999且當根價格range觸帶 | 先FAILED；永不成功；C=99恰失敗線不觸發<99 |
| T025 | Retest j=b+9，b+10成功／b+11才成功 | 前者成功；後者超10根不接受，不能多給j+2 |
| T026 | first9 e後C_e>P?／e+9首次C>P／e+10首次C>P | e不算「之後」；e+9 TRUE；e+10 FALSE/EXPIRED |
| T027 | 高點H_b>H_a、RSI_b=RSI_a，RSI_t>70 | C7 FALSE；S5 TRUE；沒有高點pair則兩者UNKNOWN |
| T028 | KD最近3根兩線皆10完全平 | A2 FALSE；不是續弱；一線累計下降且其餘條件合可TRUE |
| T029 | ATRt=1.20×ATR_(t−5)，且ATRt>ATRp | A6 TRUE；基期ATR0 UNKNOWN；上漲引起ATR擴張也不能單項RD |
| T030 | R_old=−.03,R_new=−.05／−.0499 | A7 TRUE／FALSE；兩者任一≥0 FALSE |
| T031 | 3次反彈幅度10%、9%、8% | A8 TRUE；最後8.01%則不滿≤.8×10% FALSE |
| T032 | D3 b破線，b+2尚未收復 | PENDING/UNKNOWN；b+3四根皆<P才TRUE；中間C=P則RECLAIMED/FALSE |
| T033 | A5 V=VolMA20，價格下跌 | FALSE；q>1不等於任意「爆量」門檻 |
| T034 | 19根V100＋當根V200 | inclusive20=105、ratio=200/105；exclusive q需另一根前史，不能拿105冒充100 |
| T035 | C5最近5全平盤、量有效 | n_up0→FALSE；D=0不除零 |
| T036 | S3四根正Hist 4,3,2,1／4,3,2,0 | TRUE／FALSE；第二個是零軸事件不是全正縮短 |
| T037 | S6 q2、abs(r).005、C=.95×prior20max | TRUE（三條含等號）；任一超出相應邊界FALSE |
| T038 | 同日breakdown MA10和MA20；同golden的兩個別名 | S7只1票；golden只1個canonical事件 |
| T039 | R8有獨立線／量證據且R9有水平壓力證據，同日皆TRUE，其他R全FALSE | 兩個canonical票；Right≥3仍FALSE；僅R9值改名R8但無線／量證據時R8 UNKNOWN而非第二個TRUE |
| T040 | threshold k3：T3,U5／T2,U1／T1,U1 | TRUE／UNKNOWN／FALSE |
| T041 | S2、S7 TRUE，Extreme TRUE但S9的MA50條件FALSE／UNKNOWN／TRUE，其他S FALSE | 減碼threshold分別FALSE／UNKNOWN／TRUE；不得僅因S2/S7而令S9 TRUE |
| T042 | C8下界由1降.9、上界由2升2.2 | FALSE，即使midpoint增加；新財年與舊財年不得比較 |
| T043 | C8 ETF沒有issuer guidance | N/A且不降低≥3；不宣稱ETF安全或將UNKNOWN全置FALSE |
| T044 | 日週月D bull,W bear,M bull／M資料不足 | COUNTERTREND_REBOUND…／PARTIAL_CONTEXT，不填Bull |
| T045 | 週四資料齊全但週五預期開市且未收盤 | 本週不完整；用前一完整週，另保留本週PROVISIONAL |
| T046 | 週五官方休市、週四為本週最後session且齊全 | 週四完成可產本週bar；不能強制等週五有假bar |
| T047 | 月末尚未到最後交易session／IPO月中首月 | 未完成月不入；IPO首不完整月依P排除 |
| T048 | 加入τ之後新聞、bar、公司行動更正 | 不改原AS_KNOWN_AT_τ的predicate／episode／count |
| T049 | 拆股日raw價格減半但無完整事件coverage | 受影響結構UNKNOWN，不直接判跌勢；修復仍另vintage |
| T050 | 缺週資料但日signal足夠、正式Owner未要求週確認 | 保存日事實；不把全部日signal歸UNKNOWN；正式資格另Owner裁決 |
| T051 | source基準相同但ema seed_session不同 | 不宣稱逐值等價；method/seed mismatch拒絕混接 |
| T052 | lower evidence source與higher source衝突且未裁決 | 槽UNKNOWN/SOURCE_CONFLICT；不能選較有利者 |
| T053 | t的D2 TRUE、D1/D3 FALSE且A≥2；t+1無新D2/D3、D1 FALSE、A仍≥2 | 研究Down由TRUE轉FALSE（event政策）；不等於正式Recovery或解除Hard Gate；不得暗沿舊D2 TRUE |

## 10. 交接、驗證與完成的準確邊界

1. **設計已補齊**：32槽＋2個Entry條件、9個減碼槽、8個成熟度槽、11個primitive、日週月完成bar與trend、事件狀態機、去重、seed/warm-up、53個具名邊界驗收案例；不存在用「AI綜合判斷」才能算的技術門檻。
2. **下一步可直接按稿做獨立研究模組**：先把manifest、primitive、episode、dedup及53個fixture實作到隔離sandbox；再用固定輸入比較同seed重播／prefix invariance／Decimal邊界。這份文稿本身不等於這些工程測試已PASS。
3. **效度與可用性仍要另外證明**：批准後取得合法PIT OHLCV、calendar、公司行動、EPS／估值Owner輸入；按時間外樣本／跨市場與產業／不同波動分層測性能及敏感度。不得在看結果後改參數卻沿用原version。
4. **正式相容仍待Owner批准**：KD平滑、EMV3,3實際指定公式、EMA／RSI／ATR seed、state/event、期限、S9技術弱化實作與真正alias映射、ETF C8 applicability、Bull/Bear classifier、所有P常數。這些是已寫出明確候選、待比較與批准，不再是設計空白。批准不等於策略獲利。
5. **本稿不替代其他完整設計分工**：Price Map五層數值、十一估值模板、基本面／新聞證據、Macro／Credit／Liquidity、Stage逐階政策、補足速度、資金／FX／下單仍由各自契約管理。技術規格完整不冒稱整個V82所有Owner已完成實作。

### 外部交叉查核的窄邊界

ATR的TR包含當根range及與前收盤的缺口；ATR擴張只代表波動，不提供上／下方向，與本稿不讓A6單獨等於Down一致。[Fidelity ATR公式與說明](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr)。**該來源不驗證本稿seed、5根／20%、1%價格帶、1.5倍量或任何交易效度。** EMV3,3的完整P方法是本稿明示研究選擇，不借外部常見EMV14文字宣稱正式公式相容。
