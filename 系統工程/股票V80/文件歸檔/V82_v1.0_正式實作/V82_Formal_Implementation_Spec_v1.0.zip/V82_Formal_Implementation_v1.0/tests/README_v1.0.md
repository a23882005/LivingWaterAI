# 保留原樣的參考測試

這三組程式是歷史 v0.4 測試 harness，為了可重現性原樣保留；測試檔、公式、回傳 API、舊設定及舊 receipt 都不因升版改字樣。

- `selector/`：10 項條件核方法。
- `independent_selector/`：9 項獨立條件核方法。
- `technical_numeric/`：35 項技術 primitive 數值方法。

歷史 `candidate_stage`、`research_only=true`、`formal_stage=null` 與舊設定的 `CANDIDATE_UNVALIDATED` 描述的是這些窄測試器，不是 v1.0 規則狀態。它們不代表正式引擎已實作，也不能用來阻擋已批准規則在有效輸入下產生確定結果。正式實作需另建接線與輸出契約，不能照抄常數 null。

批准狀態請讀 `../config/V82_approved_implementation_v1.0.json`；本次重跑結果在 `../verification/v1.0_rerun/`。所有舊 receipt 保留不覆蓋；normal 與 `-O` 重跑只核對同一窄測試範圍，不代表 TECH 53、CMR 52、全域 68 或正式整合已執行。

`boolean_upper_bound_possible_stages` 仍僅是巢狀布林未知的保守上界集合，不是共享數值特徵約束下精確可達階段，不得推導最低買入或機率。
