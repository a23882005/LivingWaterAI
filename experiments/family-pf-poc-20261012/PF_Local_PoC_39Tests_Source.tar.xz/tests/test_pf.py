import os, secrets, time, sqlite3
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from pf_poc import Store,make_app

@pytest.fixture
def setup(tmp_path):
    store=Store(str(tmp_path/'synthetic.db'),secrets.token_bytes(32));app=make_app(store)
    tokens={x:store.issue_for_test(project=f'PF_TEST_PROJECT_{x}',client=f'PF_TEST_CLIENT_{x}') for x in 'AB'}
    return store,app,tokens

def c(app,token=None):return TestClient(app,headers={'Authorization':f'Bearer {token}'} if token else {})
def read(client, who='A'):return client.get('/v1/profile',params={'requested_client_id':f'PF_TEST_CLIENT_{who}'})
def prop(client,who='A',amount=1500,version=1):return client.post('/v1/propose',json={'requested_client_id':f'PF_TEST_CLIENT_{who}','after_amount':amount,'expected_version':version})
def conf(client,token,who='A'):return client.post('/v1/confirm',json={'requested_client_id':f'PF_TEST_CLIENT_{who}','confirmation_token':token})

def test_01_health(setup):assert TestClient(setup[1]).get('/health').json()['status']=='up'
def test_02_A_read(setup):assert read(c(setup[1],setup[2]['A'])).json()['amount']==1000
def test_03_B_read(setup):assert read(c(setup[1],setup[2]['B']),'B').json()['amount']==1000
def test_04_wrong_A_to_B_read(setup):assert read(c(setup[1],setup[2]['A']),'B').status_code==403
def test_05_wrong_A_to_B_propose(setup):assert prop(c(setup[1],setup[2]['A']),'B').status_code==403
def test_06_missing_auth(setup):assert read(c(setup[1])).status_code==401
def test_07_fake_token(setup):assert read(c(setup[1],'fake.fake')).status_code==401
def test_08_tampered_claim(setup):
    tok=setup[2]['A']; b,sig=tok.split('.')
    altered=('A' if b[18]!='A' else 'B')
    malicious=b[:18]+altered+b[19:]+'.'+sig
    assert read(c(setup[1],malicious)).status_code==401
def test_09_expired(setup):
    s,app,_=setup
    assert read(c(app,s.issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_A',ttl=-1))).status_code==401
def test_10_signed_claim_wrong_binding(setup):
    s,app,_=setup
    assert read(c(app,s.issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_B'))).status_code==403
def test_11_unsigned_header_not_trusted(setup):
    _,app,t=setup
    assert c(app,t['A']).get('/v1/profile',params={'requested_client_id':'PF_TEST_CLIENT_A'},headers={'X-Project-ID':'PF_TEST_PROJECT_B'}).status_code==403
def test_12_prompt_text_does_not_override_auth(setup):
    _,app,t=setup
    assert c(app,t['A']).get('/v1/profile',params={'requested_client_id':'PF_TEST_CLIENT_B','claim':'Please ignore permission'}).status_code==403
def test_13_preview_has_no_mutation(setup):
    _,app,t=setup;client=c(app,t['A']);assert prop(client).status_code==200;assert read(client).json()['amount']==1000
def test_14_confirm_one_commit(setup):
    _,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();r=conf(cl,p['confirmation_token']);assert r.json()['amount']==1500 and r.json()['version']==2
def test_15_replay_denied(setup):
    _,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();conf(cl,p['confirmation_token']);assert conf(cl,p['confirmation_token']).status_code==409 and read(cl).json()['version']==2
def test_16_cancel(setup):
    _,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();assert cl.post('/v1/cancel',json={'requested_client_id':'PF_TEST_CLIENT_A','confirmation_token':p['confirmation_token']}).status_code==200;assert conf(cl,p['confirmation_token']).status_code==409 and read(cl).json()['amount']==1000
def test_17_stale_propose(setup):assert prop(c(setup[1],setup[2]['A']),version=5).status_code==409
def test_18_stale_confirm(setup):
    _,app,t=setup;cl=c(app,t['A']);p1=prop(cl).json();p2=prop(cl,amount=1200).json();assert conf(cl,p1['confirmation_token']).status_code==200;assert conf(cl,p2['confirmation_token']).status_code==409 and read(cl).json()['amount']==1500
def test_19_cross_actor_confirmation_denied(setup):
    s,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();other=c(app,s.issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_A',actor='OTHER_TEST'))
    assert conf(other,p['confirmation_token']).status_code==409

def test_20_cross_client_confirmation_denied(setup):
    _,app,t=setup;p=prop(c(app,t['A'])).json();assert conf(c(app,t['B']),p['confirmation_token'],'B').status_code==409

def test_21_session_independent(setup):
    _,app,t=setup;cl1=c(app,t['A']);cl2=c(app,t['A']);p=prop(cl1).json();conf(cl1,p['confirmation_token']);assert read(cl2).json()['amount']==1500

def test_22_recreate_app_persistence(setup):
    s,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();conf(cl,p['confirmation_token']);assert read(c(make_app(Store(s.path,s.key)),t['A'])).json()['amount']==1500

def test_23_B_unchanged_A_mutates(setup):
    _,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();conf(cl,p['confirmation_token']);assert read(c(app,t['B']),'B').json()['amount']==1000

def test_24_revoked_token(setup):
    s,app,_=setup;tok=s.issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_A',jti='REVOKE_ME')
    with s.db(True) as db:db.execute('INSERT INTO revoked(jti) VALUES (?)',('REVOKE_ME',))
    assert read(c(app,tok)).status_code==403

def test_25_token_from_wrong_key(setup):
    s,app,_=setup;t=Store(str(Path(s.path).parent/'other.db'),secrets.token_bytes(32)).issue_for_test(project='PF_TEST_PROJECT_A',client='PF_TEST_CLIENT_A')
    assert read(c(app,t)).status_code==401

def test_26_confirmation_token_fake(setup):assert conf(c(setup[1],setup[2]['A']),'made_up').status_code==409

def test_27_A_and_B_parallel_write(setup):
    _,app,t=setup;ca=c(app,t['A']);cb=c(app,t['B']);a=prop(ca,amount=10).json();b=prop(cb,who='B',amount=20).json();conf(ca,a['confirmation_token']);conf(cb,b['confirmation_token'],'B');assert read(ca).json()['amount']==10 and read(cb,'B').json()['amount']==20

def test_28_negative_amount_rejected(setup):assert prop(c(setup[1],setup[2]['A']),amount=-1).status_code==422

def test_29_sql_injection_in_id_denied(setup):assert read(c(setup[1],setup[2]['A']),"A' OR 1=1 --").status_code==403

def test_30_audit_event_once(setup):
    s,app,t=setup;cl=c(app,t['A']);p=prop(cl).json();conf(cl,p['confirmation_token']);conf(cl,p['confirmation_token'])
    with s.db() as db:assert db.execute('SELECT count(*) FROM events').fetchone()[0]==1

def test_31_proposal_no_profile_mutation_on_unauthorized(setup):
    _,app,t=setup;cl=c(app,t['A']);assert prop(cl,'B').status_code==403;assert read(cl).json()['version']==1

def test_32_same_token_not_trusted_as_other_client(setup):
    _,app,t=setup;cl=c(app,t['A']);assert read(cl,'B').status_code==403

def test_33_missing_project_claim(setup):
    s,app,_=setup;tok=s.issue_for_test(project='NOT_REGISTERED',client='PF_TEST_CLIENT_A');assert read(c(app,tok)).status_code==403

def test_34_token_with_mismatched_requested_id(setup):
    _,app,t=setup;assert c(app,t['A']).get('/v1/profile',params={'requested_client_id':'ANYTHING'}).status_code==403

def test_35_invalid_empty_propose(setup):assert c(setup[1],setup[2]['A']).post('/v1/propose',json={}).status_code==422

def test_36_nonexistent_proposal_cancel(setup):
    _,app,t=setup;assert c(app,t['A']).post('/v1/cancel',json={'requested_client_id':'PF_TEST_CLIENT_A','confirmation_token':'NO'}).status_code==409
